# Diseño de la hoja Pre-ACM

Sigue al pie de la letra `ACM/02_Manual_de_marca_reportes.md` (paleta, tipografías, header "CS." + "AGENTE INMOBILIARIO · RED SUMA", pie legal con línea dorada y número en Goodtime). Todo está implementado en `generar_preacm.py`.

## Estructura (una sola hoja A4, número 01)

| Bloque | Contenido | Componente del manual |
|---|---|---|
| Título | "Punto de partida." + pill azul "PRE-ACM · LECTURA DE MERCADO" | Título Goodtime con punto + pill |
| Subtítulo | "Un primer análisis con los pocos datos que tengo de tu propiedad." | Subtítulo dorado |
| Datos | Propiedad · Según tu descripción · Preparado para · Fecha | Línea de datos (como el Checklist) |
| Rango (protagonista) | "HOY EN [ZONA]" · "Los [tipología] se publican entre" · **USD X y USD Y** (azul profundo) · aclaración | Tarjeta blanca + cifra protagonista |
| Tira de avisos | Un punto por aviso; banda azul = mitad central (P25–P75); marcador dorado cálido = mediana; EL MÁS BARATO / PRECIO TÍPICO / EL MÁS CARO (palabras simples, nada de "mediana") | Barra de rango |
| Para tener en cuenta | Recuadro con borde dorado y dos aclaraciones fijas: "Son precios publicados, no de venta." · "No todos los avisos están bien detallados." (mismo componente que el ACM) | Recuadro "Para tener en cuenta" |
| (opcional) 3 KPIs | Avisos · Precio por m² · Superficie. Apagados por defecto (`informe.mostrar_kpis`) para que la hoja se lea rápido | Cajas KPI |
| Lo que un número al aire no te dice | 3 tarjetas grises "dato grande + una línea" con ícono lineal dorado (cartel, regla, edificio): 01 Publicar no es vender. · 02 10 m² pueden variar USD X. · 03 En un mismo complejo existen precios distintos. Debajo, remate en negrita: "¿Cuánto vale el tuyo? Eso no sale de un formulario. Sale de verlo." | Cajas + cifra en azul marino |
| Conmigo se trabaja en equipo | Tarjeta blanca: frase en Goodtime en dos líneas (la 2.ª en dorado) · rótulo · dos cajas lado a lado: VOS (gris) y YO (azul marino, texto blanco) · cierre en negrita | Tarjeta blanca + etiquetas |
| Contacto + botón | Nombre en Chillax, cargo, WhatsApp, mail y web + **botón azul "COORDINEMOS LA VISITA →"** con link a WhatsApp y mensaje precargado "Hola Cristian, agendemos una reunión para ver mi propiedad en [dirección]." | Tarjeta de contacto + botón |
| Aclaración | Cantidad de avisos, fuentes, fecha, exclusiones y "No es una tasación." | Texto chico en Inter |

## Escala tipográfica (para que todo se vea parejo)
Solo 6 tamaños + legal. No se inventan tamaños nuevos:
| Tamaño | Uso |
|---|---|
| 38 px | Rango (única cifra protagonista) |
| 31 px | Título de la hoja (Goodtime) |
| 20 px | Frase "No tomo todas…" (Goodtime) y nombre en Chillax |
| 15 px | Subtítulo, frase del rango, titulares de tarjetas, valores de la barra, remate |
| 11 px | Todo el cuerpo de texto; encabezados de sección en MAYÚSCULAS espaciadas; botón |
| 9,4 px | Etiquetas en MAYÚSCULAS grises, datos de contacto, línea de datos |
| 7,7 px | Legales (Inter) |

## Criterio de lectura ("apto para todos")
- Una idea por línea, frases cortas, la frase fuerte arriba y en negrita.
- Cada tarjeta: una cifra o afirmación grande y como máximo 2 líneas debajo.
- **Nunca nombrar direcciones de otros avisos en el PDF** (la publicación puede cambiar o bajarse). Los ejemplos van genéricos ("en un mismo complejo"); las direcciones quedan en el chat.
- Nada de reto al cliente ("no estás vendiendo zapatillas"): firme, pero siempre con el porqué.

## Reglas
- Una sola cifra protagonista: el rango.
- Si se agrega o cambia algo, tiene que seguir entrando en una hoja. Primero se acortan textos, después se achican márgenes.
