# Contexto: pre-ACM

Se lee **solo** cuando Cris pide un pre-ACM. Todo lo de este archivo está copiado tal cual de donde ya estaba; cada bloque dice de dónde sale. Lo que se sumó el 2 de octubre de 2026 por decisión de Cris dice "Decisión de Cris (2-oct-2026)". Las reglas generales (no inventar, OK de Cris, números del script, PDF para el cliente y cocina en el chat, español rioplatense, USD) están en las instrucciones del proyecto y no se repiten acá.

---

## 1. Cuándo se usa

*Fuente: memoria del proyecto (pedido de Cris).*

cuando diga "quiero hacer un pre-ACM", armar la hoja pre-ACM con el formato aprobado (docs y generar_preacm.py en la carpeta pre-ACM/ del proyecto); cuando diga "quiero hacer un ACM", hacer el ACM normal (carpeta ACM/).

*Fuente: `pre-ACM/01_Instrucciones_preACM.md` (copia exacta).*

Es la respuesta a quien pide "un valor por arriba" y no deja ver la propiedad.

No es una tasación ni un ACM. No da "el valor de tu propiedad": da el mapa del mercado y el motivo para reunirse.

## 2. Qué leer

*Fuente: instrucciones del proyecto (copia exacta).*

Si te pido un "pre-ACM", leé y seguí:
- pre-ACM/01_Instrucciones_preACM.md
- pre-ACM/02_Diseno_hoja.md
- pre-ACM/03_Rango_y_argumentos.md
- pre-ACM/04_Formato_de_datos.md
- Y usá pre-ACM/generar_preacm.py (importa ACM/generar_acm.py: guardá los dos
  scripts en la misma carpeta).
- Si no queda claro cuál de los dos quiero, preguntame.

Casos hechos: `pre-ACM/casos/` (hoy, `Benjamin_Colegiales.md`, `Martin_Almagro.md` y `Pablo_VillaMartelli.md`).

Diseño común a todas las piezas: `Diseno/sistema-diseno.md`.

*Fuente: decisión de Cris del 2 de octubre de 2026 (anotada en `Diseno/sistema-diseno.md`, sección 8).*

**Decisión de Cris (2-oct-2026): el pre-ACM va en 2 hojas A4** (`generar_preacm.py` v1.2 y siguientes), con las medidas del ACM y más aire entre bloques.
- Hoja 01: título, datos, rango y "Para tener en cuenta".
- Hoja 02: tarjetas, remate, equipo, contacto con botón de WhatsApp y aclaración.
- Donde `01_Instrucciones_preACM.md` y `02_Diseno_hoja.md` dicen "una sola hoja", vale esto.

## 3. Fuentes

**Decisión de Cris (2-oct-2026): se buscan avisos en todos los portales, no solo en Zonaprop y Argenprop.** Mismo orden que el ACM, copiado tal cual de `ACM/01_Instrucciones_ACM_v2.md`:

**Fuentes, en orden de prioridad:** Zonaprop, Argenprop, MercadoLibre Inmuebles, **Red Suma** (https://propiedades.redsuma.com.ar/ — propiedades de la red, verificadas por asesores; búsqueda con el patrón `/propiedades/venta/<tipo>/<localidad>`), Properati, RE/MAX, Inmuebles Clarín, Buscainmueble. Como complementarias: Cabaprop, sitios de otras redes (Coldwell Banker, Century 21), el Índice Zonaprop y los informes de Reporte Inmobiliario o UCEMA para la tendencia.

*Fuente: `pre-ACM/01_Instrucciones_preACM.md`, Paso 2 (copia exacta; el primer punto queda ampliado por la decisión de arriba).*

- Zonaprop y Argenprop: misma localidad, misma tipología y ambientes, **usados** (los a estrenar van aparte o se excluyen y se aclara).
- Mínimo 5 avisos, ideal 10 a 15. Sacá duplicados entre portales (misma dirección, precio y m²).
- De cada uno: dirección, precio, m², piso y 1 o 2 notas (cochera, balcón, antigüedad, a refaccionar), fuente y link.
- Buscá un **"mismo edificio / mismo complejo"** con 2 o más avisos de precios distintos: es el argumento más fuerte.
- Opcional: un índice de USD/m² de la zona (Roomix, Índice Zonaprop) para el chat.

**Decisión de Cris (2-oct-2026): CRM de Red Suma (admin.redsuma.com.ar), se usa siempre**, como una fuente más, con el mismo acceso que usa el ACM.
- Acceso, copiado tal cual de `ACM/01_Instrucciones_ACM_v2.md`: Cris ya inició sesión en el navegador integrado de Claude (cuenta Google de la empresa). El CRM tiene un módulo **ACM** que trae avisos activos (Zonaprop/RE/MAX) y **ventas cerradas de la red con precio real de cierre**, en un radio alrededor de la dirección.
- Pedile OK a Cris antes de crear el ACM en el CRM, porque es un registro en su cuenta. Solo lectura: no marcar favoritos ni editar o borrar nada salvo que Cris lo pida. (Igual que en el ACM.)
- Si en la conversación no hay navegador para entrar al CRM, avisale a Cris al principio y pedile que pegue los datos.
- **Avisos activos del CRM:** suman al rango "se publican entre" igual que los de los portales, sacando duplicados.
- **Ventas cerradas del CRM:** van en un **bloque aparte del PDF, debajo del rango** (`generar_preacm.py` v1.3): "Ventas cerradas en [zona]. Las que ya se vendieron, se cerraron entre USD X y USD Y", el promedio de diferencia con lo publicado ("-6,5% del valor publicado") y cuántas ventas y de qué meses. Con menos de 2 cierres el bloque no sale y el dato va al chat. No entran en el rango de publicación, así la hoja sigue diciendo con verdad "se publican entre". Se cargan en el JSON en `cerradas` (dirección, precio publicado, precio de cierre, fecha de cierre y fuente); las direcciones no se imprimen.
- **Línea chica del final del PDF:** dice de dónde salen los avisos ("Referencia orientativa: 15 avisos de …"). Ahí se nombran todas las fuentes que se usaron en ese pre-ACM, por ejemplo "Zonaprop, Argenprop, MercadoLibre, Properati y Red Suma".

## 4. Pasos

*Fuente: `pre-ACM/01_Instrucciones_preACM.md` (títulos copiados tal cual; el detalle de cada paso está en ese archivo).*

- Paso 0 — Herramientas (en silencio)
- Paso 1 — Leer el pedido
- Paso 2 — Relevar avisos (rápido)
- Paso 3 — OK de Cris
- Paso 4 — Generar
- Paso 5 — Entrega

Mostrá la tabla de avisos (incluidos y excluidos con motivo) y el rango. **Esperá su OK** antes de mandar el PDF al cliente (si pidió todo junto, generalo como borrador y avisá que falta su OK).

## 5. Formato aprobado y entregables

*Fuente: memoria del proyecto (copia exacta).*

Formato aprobado del pre-ACM (oct-2026): título "Punto de partida.", subtítulo "Un primer análisis con los pocos datos que tengo de tu propiedad.", rango de la zona protagonista, 3 tarjetas ("Publicar no es vender." · "10 m² pueden llegar a variar USD X." · "En un mismo complejo existen precios distintos."), remate "¿Cuánto vale el tuyo? Eso no sale de un formulario. Sale de verlo.", bloque "No tomo todas las propiedades. Por eso vendo las que tomo." + "Conmigo se trabaja en equipo" (VOS / YO) y botón a WhatsApp "Coordinemos la visita" con mensaje "agendemos una reunión…".

Los textos aprobados completos están en `pre-ACM/03_Rango_y_argumentos.md` ("Textos aprobados por Cris").

*Fuente: `pre-ACM/01_Instrucciones_preACM.md`, Paso 5 (copia exacta).*

- **PDF** para el cliente.
- **En el chat** (nunca en el PDF): tabla de avisos, números (rango, mediana, P25–P75, USD/m², impacto de 10 m²), el aviso más parecido, una estimación interna orientativa si Cris la pide, el **mensaje de WhatsApp** para acompañar el PDF y 2 o 3 respuestas a objeciones ("decime un número igual", "no tengo tiempo", "ya me tasaron").

## 6. Reglas propias del modo

*Fuente: `pre-ACM/01_Instrucciones_preACM.md`, Reglas (copia exacta).*

- El PDF muestra **rangos de publicación**, nunca "tu propiedad vale X".
- Nada de honorarios, comisiones ni descuentos en el PDF.
- En el PDF no van direcciones de otros avisos: los ejemplos son genéricos.
- La fecha del informe es la de **Argentina** (el script la toma en hora de Buenos Aires; si se carga a mano, usar la fecha argentina).

*Fuente: `pre-ACM/02_Diseno_hoja.md`, Criterio de lectura (copia exacta).*

- Una idea por línea, frases cortas, la frase fuerte arriba y en negrita.
- Cada tarjeta: una cifra o afirmación grande y como máximo 2 líneas debajo.
- **Nunca nombrar direcciones de otros avisos en el PDF** (la publicación puede cambiar o bajarse). Los ejemplos van genéricos ("en un mismo complejo"); las direcciones quedan en el chat.
- Nada de reto al cliente ("no estás vendiendo zapatillas"): firme, pero siempre con el porqué.
