# PRE-ACM — Hoja de referencia inicial (Cristian Stedtfeld · Red Suma)

## Para qué sirve

Es la respuesta a quien pide "un valor por arriba" y no deja ver la propiedad. En **una sola hoja A4** con la marca de Cris:

1. Le da algo concreto: el **rango de publicación** de su tipología en su zona ("Hoy en Villa Martelli, los 4 ambientes usados se publican entre X y Y").
2. Le muestra en 3 tarjetas **lo que un número al aire no le dice** (publicar no es vender · 10 m² pueden variar USD X · en un mismo complejo hay precios distintos).
3. Marca la actitud de Cris (**"No tomo todas las propiedades. Por eso vendo las que tomo." · Conmigo se trabaja en equipo**) y cierra con un **botón a WhatsApp** para coordinar la visita.

No es una tasación ni un ACM. No da "el valor de tu propiedad": da el mapa del mercado y el motivo para reunirse.

## Documentos de esta carpeta

- `pre-ACM/02_Diseno_hoja.md`: cómo se ve la hoja (sigue `ACM/02_Manual_de_marca_reportes.md`).
- `pre-ACM/03_Rango_y_argumentos.md`: cómo se arma el rango y la biblioteca de argumentos.
- `pre-ACM/04_Formato_de_datos.md`: el JSON que alimenta al generador.
- `pre-ACM/generar_preacm.py`: el generador. **Importa logos, tipografías, header y pie de `ACM/generar_acm.py`**, así que hay que guardar los dos scripts en la misma carpeta.
- `pre-ACM/casos/`: casos hechos.

## Flujo

### Paso 0 — Herramientas (en silencio)
Guardá `ACM/generar_acm.py` y `pre-ACM/generar_preacm.py` en la misma carpeta. Los números salen del script.

### Paso 1 — Leer el pedido
Del formulario o del mensaje sacá: tipo, dirección y barrio, ambientes/dormitorios, piso, extras (balcón, cochera), motivo y nombre.
- Si la descripción es ambigua (por ejemplo, "3 habitaciones" puede ser 3 dormitorios = 4 ambientes, o 3 ambientes), elegí la lectura más probable, **decíselo a Cris en el chat** y ponela en "Según tu descripción" para que el cliente la corrija.
- Nunca inventes m², estado ni antigüedad. Si no están, la hoja dice "A confirmar".

### Paso 2 — Relevar avisos (rápido)
- Zonaprop y Argenprop: misma localidad, misma tipología y ambientes, **usados** (los a estrenar van aparte o se excluyen y se aclara).
- Mínimo 5 avisos, ideal 10 a 15. Sacá duplicados entre portales (misma dirección, precio y m²).
- De cada uno: dirección, precio, m², piso y 1 o 2 notas (cochera, balcón, antigüedad, a refaccionar), fuente y link.
- Buscá un **"mismo edificio / mismo complejo"** con 2 o más avisos de precios distintos: es el argumento más fuerte.
- Opcional: un índice de USD/m² de la zona (Roomix, Índice Zonaprop) para el chat.

### Paso 3 — OK de Cris
Mostrá la tabla de avisos (incluidos y excluidos con motivo) y el rango. **Esperá su OK** antes de mandar el PDF al cliente (si pidió todo junto, generalo como borrador y avisá que falta su OK).

### Paso 4 — Generar
`python3 generar_preacm.py datos.json` → `PreACM_<direccion>.pdf` + `.calculos.json` + resumen interno por consola. Mirá el PDF como imagen: tiene que entrar en una hoja, sin cortes.

### Paso 5 — Entrega
- **PDF** para el cliente.
- **En el chat** (nunca en el PDF): tabla de avisos, números (rango, mediana, P25–P75, USD/m², impacto de 10 m²), el aviso más parecido, una estimación interna orientativa si Cris la pide, el **mensaje de WhatsApp** para acompañar el PDF y 2 o 3 respuestas a objeciones ("decime un número igual", "no tengo tiempo", "ya me tasaron").

## Reglas
> Las reglas generales (no inventar nada, preguntar antes de resolver, OK de Cris, números del script, no cambiar textos aprobados) están en las instrucciones del proyecto. Acá van solo las propias del pre-ACM.
- El PDF muestra **rangos de publicación**, nunca "tu propiedad vale X".
- Nada de honorarios, comisiones ni descuentos en el PDF.
- En el PDF no van direcciones de otros avisos: los ejemplos son genéricos.
- La fecha del informe es la de **Argentina** (el script la toma en hora de Buenos Aires; si se carga a mano, usar la fecha argentina).
