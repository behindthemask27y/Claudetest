# Rango y argumentos del Pre-ACM

## Números (los calcula `generar_preacm.py`)

| Dato | Cómo sale | Dónde va |
|---|---|---|
| Rango | Mínimo y máximo de los avisos incluidos (precio publicado) | PDF (protagonista) |
| Mediana | Mediana de precios | PDF (tira) |
| Mitad central | Percentiles 25 y 75 | PDF (banda azul) y chat |
| USD/m² | Mediana de precio/m² de los avisos con m² | PDF (KPI y argumento 02) |
| Impacto de 10 m² | USD/m² mediana de los avisos con m² × 10, redondeado a 1.000. Es un promedio de publicación: los portales mezclan m² cubiertos y totales, por eso se dice "pueden llegar a variar" | PDF (tarjeta 02) |
| Mismo edificio | Mín. y máx. de los avisos cuya dirección contiene `mismo_edificio.filtro` (2 o más) | PDF (argumento 03) |
| Promedio | Promedio de precios | Solo chat |

Criterios: mínimo 5 avisos (el script corta si hay menos). Se excluyen a estrenar, duplicados y avisos con datos inconsistentes (`"incluir": false` + `nota`). No se ajusta nada: es nivel publicación.

## Textos aprobados por Cris (base del script, v1.1)

**Tarjetas (dato grande + una línea):**
1. **Publicar no es vender.** Vender es un trabajo: lleva tiempo, planificación e inversión.
2. **10 m² pueden llegar a variar {impacto_10m2}.** No alcanza con un "creo que son 60". Se mide.
3. **En un mismo complejo existen precios distintos.** Deptos casi iguales se publican con hasta {ed_dif} de diferencia. El estado, el piso y la cochera suman o restan.
   - Sin un mismo complejo **confirmado** en la muestra → se mantiene el título aprobado y se saca el número: **En un mismo complejo existen precios distintos.** El estado, el piso, la orientación y la cochera suman o restan. (No repetir "formulario": ya está en el remate.)

**Remate:** ¿Cuánto vale el tuyo? Eso no sale de un formulario. Sale de verlo.

**Bloque "Conmigo se trabaja en equipo":**
> No tomo todas las propiedades. Por eso vendo las que tomo.
> VOS — Me dejás ver la propiedad y me das toda la información que necesite.
> YO — Analizo y te digo la verdad, y si la tomo, invierto y trabajo hasta venderla.
> Si no me dejás asesorarte, no puedo hacer mi trabajo. Y prefiero decírtelo antes que hacerte perder tiempo.

**Frases de actitud para WhatsApp y redes:** "Me ayudás a ayudarte." · "Trabajamos en equipo o no trabajamos." · "Sin información, no hay estrategia." · "Yo pongo el trabajo. Vos, la información." · "No te voy a dar un número lindo para quedarme con tu propiedad. Te voy a dar uno que la venda."
Evitar: "exijo", "obligatorio", un "si no, no" sin explicar el porqué.

**Alternativas para casos especiales** (cargarlas en `textos.tarjetas`):
- **Casas y PH:** "Lo construido y lo que dice el plano pueden no coincidir." Esa diferencia cambia el valor.
- **Dos unidades en un lote:** "Cada unidad se valúa por separado." Después se ve si conviene vender junto o separado.

## Mensaje de WhatsApp para acompañar el PDF (modelo)

> Hola [nombre], ¿cómo estás? Te paso una primera referencia de [zona] con los datos que me diste. Como vas a ver, el rango es amplio: [X] a [Y]. Para decirte cuánto vale **tu** departamento necesito verlo, medirlo y compararlo con ventas reales de la zona. ¿Te queda bien [día] a la tarde o [día] a la mañana?

## Objeciones típicas
- *"Decime un número igual."* → "Te puedo decir dónde se publica, eso ya lo tenés en la hoja. Un número sin ver la propiedad te puede hacer perder plata o meses. Con una visita te lo doy bien fundado."
- *"Ya me tasaron."* → "Buenísimo, traelo y lo comparamos con ventas cerradas. Si coincide, tenés una confirmación; si no, sabés por qué."
- *"No tengo tiempo."* → "Me adapto a tu horario. Con una visita corta tengo todo lo que necesito."
