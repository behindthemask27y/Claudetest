# Formato de datos del Pre-ACM (datos.json)

`python3 generar_preacm.py --ejemplo` escribe un ejemplo. Si un dato no existe, no pongas el campo (o ponelo en `null`): nunca un valor inventado.

```json
{
  "informe": {
    "fecha": "2026-10-01",              // opcional; por defecto hoy
    "preparado_para": "Pablo",          // opcional
    "titulo": "Punto de partida.",      // opcional
    "mostrar_kpis": false,              // opcional: agrega la fila Avisos · Precio por m² · Superficie
    "subtitulo": "Un primer análisis con los pocos datos que tengo de tu propiedad.",  // opcional
    "etiqueta": "Pre-ACM · Lectura de mercado"  // texto de la pill, opcional
  },
  "propiedad": {
    "direccion": "Necochea 470", "barrio": "Villa Martelli", "tipo": "Departamento",
    "descripcion": "1er piso · 3 dorm · balcón",  // lo que dijo el cliente, corto
    "m2": null                                    // si no lo dio: null → "A confirmar"
  },
  "segmento": {
    "zona": "Villa Martelli",                              // * "HOY EN …"
    "tipologia": "departamentos de 4 ambientes usados",    // * "Los … se publican entre"
    "fuentes": "Zonaprop y Argenprop",
    "excluye": "se excluyen los a estrenar"                // va en la aclaración
  },
  "mismo_edificio": {                    // opcional (tarjeta 03). La dirección NO se imprime en el PDF
    "filtro": "Venezuela 3",             // texto que tiene que aparecer en la dirección de los avisos (2 o más)
    "etiqueta": "Venezuela al 3100"      // solo para el chat
  },
  "avisos": [
    {"direccion": "Venezuela 3194, 1er piso", "precio": 97000, "m2": 70,
     "fuente": "Zonaprop", "link": "https://…", "nota": "1er piso con balcón, 50 años"},
    {"direccion": "Estanislao del Campo 800", "precio": 220000, "m2": 91,
     "incluir": false, "nota": "a estrenar"}          // excluido: sale solo en el chat
  ],
  "textos": {                            // todo opcional: si no está, usa los textos base
    "lead": "Los {tipologia} se publican entre",
    "aclaracion": "Es un rango amplio porque depende de muchos factores. <b>…</b>",
    "titulo_tarjetas": "Lo que un número al aire no te dice",
    "tarjetas": [{"titulo": "10 m² pueden variar {impacto_10m2}.", "texto": "…"}],  // 3 ítems
    "remate": "¿Cuánto vale el tuyo? Eso no sale de un formulario. Sale de verlo.",
    "equipo": {"frase": "…", "rotulo": "…", "vos": "…", "yo": "…", "cierre": "…"}  // cualquier clave
  },
  "cta": {"boton": "Coordinemos la visita", "whatsapp_msg": "Hola Cristian, agendemos una reunión para ver mi propiedad en …"  // por defecto usa la dirección}
}
```

**Variables para los textos:** `{zona}`, `{tipologia}`, `{min}`, `{max}`, `{mediana}`, `{n}`, `{usd_m2_med}`, `{impacto_10m2}`, `{ed_etiqueta}`, `{ed_min}`, `{ed_max}`, `{ed_dif}`, `{ed_n}`. Admiten `<b>`.

**Salidas:** `PreACM_<direccion>.pdf`, `.html` y `.calculos.json`; por consola, la tabla interna para el chat.
