#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GENERADOR DE PRE-ACM — Cristian Stedtfeld · Red Suma  (v1.4)
=============================================================
Dos hojas A4 (v1.2, oct-2026: medidas del ACM y más aire; v1.3: bloque de ventas cerradas; v1.4: flecha del botón en SVG) para quien pide "un valor por arriba" sin dejar ver la propiedad.
Muestra el rango de publicación de la zona, explica por qué ese número no alcanza
y lleva a coordinar la visita para hacer el ACM completo.

Reutiliza la marca del ACM: importa logos, tipografías, header, pie y formatos de
generar_acm.py (tiene que estar en la misma carpeta o en ../ACM/).

USO
    python3 generar_preacm.py datos.json              -> PreACM_<direccion>.pdf
    python3 generar_preacm.py datos.json -o salida.pdf
    python3 generar_preacm.py --ejemplo               -> escribe ejemplo_preacm.json
    python3 generar_preacm.py datos.json --solo-calculos
"""
import argparse, datetime as dt, json, os, statistics, sys, urllib.parse

AQUI = os.path.dirname(os.path.abspath(__file__))
for p in (AQUI, os.path.join(AQUI, "..", "ACM"), os.path.join(AQUI, "ACM")):
    if os.path.exists(os.path.join(p, "generar_acm.py")):
        sys.path.insert(0, p)
        break
import generar_acm as G  # noqa: E402

usd, miles, esc, pct = G.usd, G.miles, G.esc, G.pct

# ───────────────────────────────────────────────────────── TEXTOS BASE ──────
# Tarjetas "dato grande + una línea" (admiten variables {…}; ver 04_Formato_de_datos.md)
TARJETAS_BASE = [
    {"titulo": "Publicar no es vender.",
     "texto": "Vender es un trabajo: lleva tiempo, planificación e inversión."},
    {"titulo": "10 m² pueden llegar a variar {impacto_10m2}.",
     "texto": "No alcanza con un “creo que son 60”. Se mide."},
    {"titulo": "En un mismo complejo existen precios distintos.",
     "texto": "Deptos casi iguales se publican con hasta <b>{ed_dif}</b> de diferencia. "
              "El estado, el piso y la cochera suman o restan."},
]
# Si la muestra no tiene un mismo complejo con 2+ avisos, la tarjeta 3 pasa a ser esta:
TARJETA_3_ALT = {"titulo": "En un mismo complejo existen precios distintos.",
                 "texto": "El estado, el piso, la orientación y la cochera suman o restan."}
ICONOS = {  # íconos lineales (manual: trazo fino, dorado)
    "cartel": '<path d="M6 21V3"/><rect x="6" y="4" width="13" height="9" rx="1.2"/><path d="M9.5 8.5h6"/>',
    "regla": '<rect x="2.5" y="8" width="19" height="8" rx="1.2"/><path d="M6.5 8v3M10 8v4.5M13.5 8v3M17 8v4.5"/>',
    "edificio": '<rect x="5" y="3" width="14" height="18" rx="1.2"/><path d="M9 7h1.5M13.5 7H15M9 11h1.5M13.5 11H15M9 15h1.5M13.5 15H15M11 21v-3h2v3"/>',
    "casa": '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>',
}
ICONOS_BASE = ["cartel", "regla", "edificio"]

REMATE_BASE = "¿Cuánto vale el tuyo? Eso no sale de un formulario. Sale de verlo."

EQUIPO_BASE = {
    "frase": "No tomo todas las propiedades. Por eso vendo las que tomo.",
    "rotulo": "Conmigo se trabaja en equipo",
    "vos": "Me dejás ver la propiedad y me das toda la información que necesite.",
    "yo": "Analizo y te digo la verdad, y si la tomo, invierto y trabajo hasta venderla.",
    "cierre": "Si no me dejás asesorarte, no puedo hacer mi trabajo. "
              "Y prefiero decírtelo antes que hacerte perder tiempo.",
}

def hoy_ar():
    """Fecha de hoy en Argentina (el servidor puede estar en UTC y adelantarse un día)."""
    from zoneinfo import ZoneInfo
    return dt.datetime.now(ZoneInfo("America/Argentina/Buenos_Aires")).date()

# ───────────────────────────────────────────────────────── CÁLCULOS ────────
def calcular(d):
    av = [a for a in d.get("avisos", []) if a.get("incluir", True) and a.get("precio")]
    if len(av) < 5:
        raise SystemExit(f"ERROR: hay {len(av)} avisos válidos. Para un rango creíble hacen falta al menos 5.")
    precios = sorted(float(a["precio"]) for a in av)
    q = statistics.quantiles(precios, n=4, method="inclusive")
    con_m2 = [float(a["precio"]) / float(a["m2"]) for a in av if a.get("m2")]
    R = {
        "n": len(av), "n_m2": len(con_m2),
        "min": precios[0], "max": precios[-1], "mediana": statistics.median(precios),
        "promedio": statistics.mean(precios), "p25": q[0], "p75": q[2],
        "usd_m2_med": statistics.median(con_m2) if con_m2 else None,
        "usd_m2_min": min(con_m2) if con_m2 else None, "usd_m2_max": max(con_m2) if con_m2 else None,
        "precios": precios,
    }
    R["impacto_10m2"] = round(R["usd_m2_med"] * 10 / 1000) * 1000 if R["usd_m2_med"] else None
    ed = d.get("mismo_edificio") or {}
    if ed.get("filtro"):
        f = ed["filtro"].lower()
        grupo = [float(a["precio"]) for a in av if f in str(a.get("direccion", "")).lower()]
        if len(grupo) >= 2 and max(grupo) > min(grupo):
            R["ed"] = {"etiqueta": ed.get("etiqueta") or ed["filtro"], "n": len(grupo),
                       "min": min(grupo), "max": max(grupo), "dif": (max(grupo) / min(grupo) - 1) * 100}
    # Ventas cerradas (v1.3, opcional, "cerradas" en el JSON): bloque aparte, no entran en el rango de publicación.
    # Cada una: direccion, precio_publicado, precio_cierre, fecha_cierre ("2026-07"), fuente. Hacen falta 2 o más.
    ce = [c for c in d.get("cerradas", []) if c.get("incluir", True) and c.get("precio_cierre")]
    if len(ce) >= 2:
        pc = sorted(float(c["precio_cierre"]) for c in ce)
        br = [(float(c["precio_cierre"]) / float(c["precio_publicado"]) - 1) * 100
              for c in ce if c.get("precio_publicado")]
        fechas = sorted(str(c["fecha_cierre"]) for c in ce if c.get("fecha_cierre"))
        R["cerradas"] = {"n": len(ce), "min": pc[0], "max": pc[-1], "mediana": statistics.median(pc),
                         "brecha": statistics.mean(br) if br else None, "n_brecha": len(br),
                         "desde": fechas[0] if fechas else None, "hasta": fechas[-1] if fechas else None}
    return av, R

def variables(d, R):
    s = d.get("segmento") or {}
    v = {"zona": s.get("zona", ""), "tipologia": s.get("tipologia", ""),
         "min": usd(R["min"]), "max": usd(R["max"]), "mediana": usd(R["mediana"]),
         "usd_m2_med": G.um2(R["usd_m2_med"]) if R["usd_m2_med"] else "—",
         "impacto_10m2": usd(R["impacto_10m2"]) if R["impacto_10m2"] else "—", "n": R["n"]}
    if R.get("ed"):
        v.update({"ed_etiqueta": R["ed"]["etiqueta"], "ed_min": usd(R["ed"]["min"]),
                  "ed_max": usd(R["ed"]["max"]), "ed_n": R["ed"]["n"],
                  "ed_dif": usd(R["ed"]["max"] - R["ed"]["min"])})
    # que "USD 20.000" nunca se corte en dos renglones
    return {k: (x.replace("USD ", "USD\u00a0") if isinstance(x, str) else x) for k, x in v.items()}

# ────────────────────────────────────────────────────────────── HTML ───────
CSS_PRE = r"""
.ph-row{position:relative}
.pre-pill{position:absolute;right:0;top:2px;background:var(--navy);color:#fff;border-radius:20px;height:24px;padding:0 15px;
 display:flex;align-items:center;font-weight:700;font-size:8px;letter-spacing:.2em;text-transform:uppercase}
.pre-sub{font-weight:700;font-size:14px;color:var(--gold);margin-top:13px}
.pre-meta{display:flex;flex-wrap:wrap;gap:4px 18px;margin-top:9px;font-size:9.6px;color:var(--gray)}
.pre-meta b{color:var(--ink);font-weight:700;margin-left:5px}
.hero{margin-top:13px;background:#fff;border-radius:8px;padding:16px 24px 13px;border:1px solid #E4E4E4}
.hero .lead{font-size:14px;color:var(--ink);margin-top:7px;line-height:19px}
.hero .rng{font-weight:700;font-size:38px;line-height:43px;color:var(--navy2);margin-top:4px;letter-spacing:-.005em}
.hero .rng span{font-size:22px;color:var(--ink);font-weight:400;margin:0 6px}
.hero .why{font-size:12.5px;line-height:16px;color:var(--txt);margin-top:6px}
.hero .why b{color:var(--ink)}
.strip{position:relative;height:36px;margin:12px 6px 0}
.strip .trk{position:absolute;left:0;right:0;top:16px;height:9px;border-radius:5px;background:var(--card)}
.strip .band{position:absolute;top:16px;height:9px;border-radius:5px;background:var(--navy)}
.strip .bl{position:absolute;top:0;transform:translateX(-50%);font-size:8px;font-weight:700;letter-spacing:.12em;
 color:var(--navy);white-space:nowrap;text-transform:uppercase}
.strip .dot{position:absolute;top:15.5px;width:10px;height:10px;margin-left:-5px;border-radius:50%;background:#fff;
 border:1.8px solid var(--gold)}
.strip .med{position:absolute;top:11px;width:3.4px;height:19px;margin-left:-1.7px;background:var(--gold2)}
.scale3.pre{margin-top:2px}
.scale3.pre .g{font-size:14px;margin-top:5px}
.kp3{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:12px}
.kp3 .box{height:71px;padding:13px 14px 0}
.kp3 .val{font-size:18px;margin-top:6px}
.kp3 .small{margin-top:4px}
.h2.pre{font-size:13.5px;margin-top:20px}
.dcs{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:9px}
.dc{position:relative;background:var(--card);border-radius:5px;padding:11px 13px 12px}
.dc .ic{position:absolute;right:11px;top:8px;width:22px;height:22px}
.dc .nn{font-weight:700;font-size:10px;letter-spacing:.2em;color:var(--gold)}
.dc .hd{font-weight:700;font-size:16px;line-height:19px;color:var(--navy);margin-top:7px}
.dc .tx{font-size:10.6px;line-height:14px;color:var(--txt);margin-top:6px}
.dc .tx b{color:var(--navy)}
.remate{margin-top:10px;padding-left:12px;border-left:3.4px solid var(--gold2);font-weight:700;font-size:15px;line-height:20px;color:var(--ink)}
.team{margin-top:12px;background:#fff;border-radius:8px;border:1px solid #E4E4E4;padding:13px 20px 12px}
.team .fr{font-family:'Goodtime',sans-serif;font-size:20px;line-height:24px;color:var(--ink);word-spacing:-.12em}
.team .fr em{font-style:normal;color:var(--gold)}
.team .lbl.tm{margin-top:9px;color:var(--ink)}
.team .vy{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px}
.team .vy>div{border-radius:5px;padding:9px 14px 10px}
.team .v{background:var(--card)}
.team .y{background:var(--navy)}
.team .vy span{display:block;font-weight:700;font-size:13px;letter-spacing:.16em;text-transform:uppercase;color:var(--gold)}
.team .y span{color:#FBF0D9}
.team .vy p{font-size:11.3px;line-height:15px;color:var(--txt);margin-top:3px}
.team .y p{color:#fff}
.team .ci{margin-top:9px;font-size:11.5px;line-height:15.5px;color:var(--ink);font-weight:700}
.cta{margin-top:12px;background:var(--card);border-radius:5px;padding:11px 20px;display:flex;align-items:center;gap:18px}
.cta .n{font-family:'ChillaxCS',Chillax,sans-serif;font-weight:600;font-size:18px;color:var(--ink);letter-spacing:.01em}
.cta .r{font-size:9.8px;color:var(--gray);margin-top:2px}
.cta .d{font-size:9.8px;line-height:14px;color:var(--txt);margin-top:4px}
.cta .d b{color:var(--navy)}
.btn{margin-left:auto;flex:none;text-decoration:none;background:var(--navy);color:#fff;border-radius:30px;height:40px;padding:0 22px;
 display:flex;align-items:center;gap:10px;font-weight:700;font-size:10px;letter-spacing:.18em;text-transform:uppercase}
.btn .fl{flex:none;display:block}  /* flecha SVG centrada con las mayúsculas, igual que plantilla_base.py (Cris, 2-oct-2026) */
.disc{margin-top:7px;font-family:'InterCS',Inter,Arial,sans-serif;font-size:7.6px;line-height:11px;color:var(--gray)}
/* ── ESCALA TIPOGRÁFICA ÚNICA (6 tamaños + legal) ──────────────────────────
   38 rango · 31 título · 20 frase/nombre · 15 titulares · 11 cuerpo · 9,4 etiquetas · 7,7 legal */
.pre-sub{font-size:15px;line-height:19px}
.pre-meta{font-size:9.4px}
.hero .lead{font-size:15px;line-height:19px}
.hero .rng{font-size:38px;line-height:43px}
.hero .rng span{font-size:20px}
.hero .why{font-size:11px;line-height:15.5px}
.strip .bl{font-size:9.4px;letter-spacing:.2em}
.scale3.pre .g{font-size:15px}
.h2.pre{font-size:11px;letter-spacing:.2em;margin-top:22px}
.dc .nn{font-size:9.4px}
.dc .hd{font-size:15px;line-height:19px}
.dc .tx{font-size:11px;line-height:15.5px}
.remate{font-size:15px;line-height:19px}
.team .fr{font-size:20px;line-height:25px}
.team .lbl.tm{font-size:11px;letter-spacing:.2em;font-weight:700;color:var(--ink)}
.team .vy span{font-size:11px;letter-spacing:.2em}
.team .vy p{font-size:11px;line-height:15.5px}
.team .ci{font-size:11px;line-height:15.5px}
.cta .n{font-size:20px}
.cta .r,.cta .d{font-size:9.4px}
.btn{font-size:11px;letter-spacing:.16em}
.disc{font-size:7.7px}
.acl{margin-top:9px;padding:8px 16px 9px}
.acl .aits{margin-top:5px}
.h2.pre{margin-top:15px}
.hero{padding:13px 24px 11px}
.hero .lead{margin-top:5px}
.hero .rng{font-size:36px;line-height:40px;margin-top:2px}
.hero .why{margin-top:3px}
.strip{margin-top:6px;height:34px}
.dcs{margin-top:7px}
.dc{padding:10px 13px 11px}
.remate{margin-top:9px}
.team{margin-top:10px;padding:11px 20px 10px}
.team .lbl.tm{margin-top:7px}
.team .vy{margin-top:6px}
.team .vy>div{padding:8px 14px 9px}
.team .ci{margin-top:7px}
.cta{margin-top:10px;padding:9px 20px}
.cta .d{margin-top:2px}
.disc{margin-top:5px}
.scale3.pre>div:first-child>*{text-align:left}.scale3.pre>div:nth-child(2)>*{text-align:center}.scale3.pre>div:last-child>*{text-align:right}
"""

# Dos hojas A4 (v1.2): medidas del ACM (Diseno/sistema-diseno.md) y más aire entre bloques.
# Hoja 1: título, datos, rango y "Para tener en cuenta". Hoja 2: tarjetas, remate, equipo y contacto.
CSS_DOS_HOJAS = r"""
.pre-sub{font-size:15.2px;line-height:normal;margin-top:22px}
.pre-pill{height:27px;font-size:8.3px;padding:0 17px}
.h2.pre{font-size:16.5px;letter-spacing:.12em;margin-top:0}
.hero .why,.dc .tx,.team .vy p,.team .ci,.acl p{font-size:11.3px;line-height:17px}
.cta .n{font-size:19px}
.pre-meta{margin-top:18px}
.hero{margin-top:44px;padding:34px 32px 30px}
.hero .lead{margin-top:16px}
.hero .rng{margin-top:12px}
.hero .why{margin-top:14px}
.strip{margin-top:44px}
.scale3.pre .g{margin-top:8px}
.kp3{margin-top:44px}
.acl{margin-top:44px;padding:18px 20px 20px}
.acl .aits{margin-top:12px}
.dcs{margin-top:18px}
.dc{padding:16px 16px 18px}
.dc .hd{margin-top:10px}
.dc .tx{margin-top:9px}
.remate{margin-top:26px}
.team{margin-top:40px;padding:24px 26px 22px}
.team .lbl.tm{margin-top:18px}
.team .vy{margin-top:12px}
.team .vy>div{padding:14px 16px 16px}
.team .ci{margin-top:16px}
.cta{margin-top:40px;padding:20px 22px}
.cta .d{margin-top:4px}
.disc{margin-top:14px}
.sold{margin-top:20px;background:var(--card);border-radius:5px;padding:20px 32px 18px}
.sold .lead{font-size:15px;line-height:19px;color:var(--ink);margin-top:10px}
.sold .rng2{font-weight:700;font-size:20.5px;line-height:1.15;color:var(--navy);margin-top:8px}
.sold .rng2 span{font-size:15px;color:var(--ink);font-weight:400;margin:0 6px}
.sold .why{font-size:11.3px;line-height:17px;color:var(--txt);margin-top:8px}
.sold .why b.neg{color:var(--red)}
.sold .small{margin-top:6px}
"""


# Flecha del botón: SVG en vez del carácter "→", centrada con las mayúsculas (igual que Diseno/plantilla_base.py).
FLECHA = ('<svg class="fl" viewBox="0 0 14 10" width="14" height="10" aria-hidden="true">'
          '<path d="M1 5.25h11.2M8.2 1.65 12 5.25 8.2 8.85" stroke="currentColor" stroke-width="1.5" '
          'fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>')


def construir_html(d, av, R):
    inf, prop, seg = d.get("informe") or {}, d.get("propiedad") or {}, d.get("segmento") or {}
    T = d.get("textos") or {}
    hoy = dt.date.fromisoformat(inf["fecha"]) if inf.get("fecha") else hoy_ar()
    V = variables(d, R)
    fmt = lambda s: str(s).format_map(V)

    # Encabezado
    dirp = ", ".join(x for x in [prop.get("direccion"), prop.get("barrio")] if x)
    meta = [f'<span>Propiedad<b>{esc(dirp)}</b></span>']
    if prop.get("descripcion"):
        meta.append(f'<span>Según tu descripción<b>{esc(prop["descripcion"])}</b></span>')
    if inf.get("preparado_para"):
        meta.append(f'<span>Preparado para<b>{esc(inf["preparado_para"])}</b></span>')
    meta.append(f'<span>Fecha<b>{G.fecha_larga(hoy)}</b></span>')
    titulo = inf.get("titulo") or "Punto de partida."
    head = (f'<div class="ph-row"><h1 class="t">{esc(titulo)}</h1><div class="pre-pill">{esc(inf.get("etiqueta") or "Pre-ACM · Lectura de mercado")}</div></div>'
            f'<div class="pre-sub">{esc(inf.get("subtitulo") or "Un primer análisis con los pocos datos que tengo de tu propiedad.")}</div>'
            f'<div class="pre-meta">{"".join(meta)}</div>')

    # Hero: rango + tira de avisos
    lo, hi = R["min"], R["max"]
    span = (hi - lo) or 1
    pos = lambda v: (v - lo) / span * 100
    dots = "".join(f'<div class="dot" style="left:{pos(p):.2f}%"></div>' for p in R["precios"])
    p25, p75, med = pos(R["p25"]), pos(R["p75"]), pos(R["mediana"])
    strip = (f'<div class="strip"><div class="trk"></div>'
             f'<div class="band" style="left:{p25:.2f}%;width:{p75 - p25:.2f}%"></div>'
             f'<div class="bl" style="left:{(p25 + p75) / 2:.2f}%">La mitad de los avisos</div>'
             f'{dots}<div class="med" style="left:{med:.2f}%"></div></div>'
             f'<div class="scale3 pre"><div><div class="lbl">El más barato</div><div class="g">{usd(lo)}</div></div>'
             f'<div><div class="lbl">Precio típico</div><div class="g">{usd(R["mediana"])}</div></div>'
             f'<div><div class="lbl">El más caro</div><div class="g">{usd(hi)}</div></div></div>')
    lead = fmt(T.get("lead") or "Los {tipologia} se publican entre")
    why = fmt(T.get("aclaracion") or "¿Por qué tan amplio? <b>Porque depende de cómo sea tu depto.</b>")
    hero = (f'<div class="hero"><div class="lbl">Hoy en {esc(seg.get("zona", ""))}</div>'
            f'<div class="lead">{lead}</div>'
            f'<div class="rng">{usd(lo)}<span>y</span>{usd(hi)}</div>'
            f'<div class="why">{why}</div>{strip}</div>')

    # Ventas cerradas (bloque aparte, debajo del rango)
    cerr = ""
    if R.get("cerradas"):
        C = R["cerradas"]
        per = ""
        if C["desde"] and C["hasta"]:
            a_, b_ = G.mes_anio(C["desde"]), G.mes_anio(C["hasta"])
            per = f" entre {a_} y {b_}" if a_ != b_ else f" en {a_}"
        brecha = (f'<div class="why">En promedio, cerraron un <b class="neg">{pct(C["brecha"])}</b> '
                  f'del valor publicado.</div>') if C["brecha"] is not None and C["brecha"] < 0 else ""
        cerr = (f'<div class="sold"><div class="lbl">Ventas cerradas en {esc(seg.get("zona", ""))}</div>'
                f'<div class="lead">{esc(T.get("lead_cerradas") or "Las que ya se vendieron, se cerraron entre")}</div>'
                f'<div class="rng2">{usd(C["min"])}<span>y</span>{usd(C["max"])}</div>{brecha}'
                f'<div class="small">{C["n"]} ventas con precio real de cierre{per}.</div></div>')

    # KPIs
    sup = prop.get("m2")
    k3 = (f'<div class="box"><div class="lbl">Superficie de tu depto</div><div class="val">{miles(sup) + " m²" if sup else "A confirmar"}</div>'
          f'<div class="small">{"según lo que nos contaste" if sup else "es el dato que más mueve el valor"}</div></div>')
    kpis = (f'<div class="kp3">'
            f'<div class="box"><div class="lbl">Avisos analizados</div><div class="val">{R["n"]}</div>'
            f'<div class="small">{esc(seg.get("fuentes") or "publicaciones activas")}</div></div>'
            f'<div class="box"><div class="lbl">Precio por m²</div><div class="val">{G.um2(R["usd_m2_med"]) if R["usd_m2_med"] else "—"}</div>'
            f'<div class="small">mediana de publicación</div></div>{k3}</div>')

    # Tarjetas "dato grande + una línea"
    tar = [dict(x) for x in (T.get("tarjetas") or TARJETAS_BASE)]
    if not T.get("tarjetas") and not R.get("ed"):
        tar[2] = TARJETA_3_ALT  # misma referencia → ícono "casa"
    def ico(t, i):
        k = t.get("icono") or (ICONOS_BASE[i - 1] if not T.get("tarjetas") else None)
        return (f'<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="#988355" stroke-width="1.6" '
                f'stroke-linecap="round" stroke-linejoin="round">{ICONOS[k]}</svg>') if k in ICONOS else ""
    cards = "".join(f'<div class="dc">{ico(t, i)}<div class="nn">{i:02d}</div><div class="hd">{fmt(t["titulo"])}</div>'
                    f'<div class="tx">{fmt(t["texto"])}</div></div>' for i, t in enumerate(tar[:3], 1))
    porque = (f'<div class="h2 pre">{esc(T.get("titulo_tarjetas") or "Lo que un número al aire no te dice")}</div>'
              f'<div class="dcs">{cards}</div><div class="remate">{fmt(T.get("remate") or REMATE_BASE)}</div>')

    # Bloque "Conmigo se trabaja en equipo"
    E = dict(EQUIPO_BASE); E.update(T.get("equipo") or {})
    fr = esc(E["frase"])
    if ". " in fr:  # segunda oración en otra línea, en dorado
        a1, a2 = fr.split(". ", 1)
        fr = f'{a1}.<br><em>{a2}</em>'
    trabajo = (f'<div class="team"><div class="fr">{fr}</div>'
               f'<div class="lbl tm">{esc(E["rotulo"])}</div>'
               f'<div class="vy"><div class="v"><span>Vos</span><p>{fmt(E["vos"])}</p></div>'
               f'<div class="y"><span>Yo</span><p>{fmt(E["yo"])}</p></div></div>'
               f'<div class="ci">{fmt(E["cierre"])}</div></div>')

    # Llamado a la acción
    cta = d.get("cta") or {}
    num = "".join(ch for ch in G.MARCA["whatsapp"] if ch.isdigit())
    msg = cta.get("whatsapp_msg") or f"Hola Cristian, agendemos una reunión para ver mi propiedad en {dirp}."
    link = f"https://wa.me/{num}?text={urllib.parse.quote(msg)}"
    boton = esc(cta.get("boton") or "Coordinemos la visita")
    ctah = (f'<div class="cta"><div><div class="n">{G.MARCA["agente"]}</div>'
            f'<div class="r">{G.MARCA["cargo"]} · {G.MARCA["red"]}</div>'
            f'<div class="d">WhatsApp <b>{G.MARCA["whatsapp"]}</b> · {G.MARCA["email"]} · {G.MARCA["web"]}</div></div>'
            f'<a class="btn" href="{esc(link)}">{boton}{FLECHA}</a></div>')

    fuentes = seg.get("fuentes") or "portales inmobiliarios"
    disc = (f'<div class="disc">Referencia orientativa: {R["n"]} avisos de {esc(fuentes)}, '
            f'relevados el {hoy.strftime("%d/%m/%Y")}{" (" + esc(seg["excluye"]) + ")" if seg.get("excluye") else ""}. '
            f'No es una tasación.</div>')

    kp = kpis if inf.get("mostrar_kpis") else ""
    if cerr and kp:  # con ventas cerradas no entran los KPIs en la hoja 1: pasan arriba de la hoja 2
        hoja1 = head + hero + cerr + G.aclaraciones_html()
        hoja2 = kp.replace('class="kp3"', 'class="kp3" style="margin-top:0;margin-bottom:34px"') + porque + trabajo + ctah + disc
    else:
        hoja1 = head + hero + cerr + G.aclaraciones_html() + kp
        hoja2 = porque + trabajo + ctah + disc
    titulo_doc = f"Pre-ACM {dirp}"
    return (f'<!doctype html><html lang="es"><head><meta charset="utf-8"><title>{esc(titulo_doc)}</title>'
            f'<style>{G.css()}{CSS_PRE}{CSS_DOS_HOJAS}</style></head><body>{G.page("01", hoja1)}{G.page("02", hoja2)}</body></html>')

# ─────────────────────────────────────────────────── RESUMEN INTERNO ───────
def resumen_interno(d, av, R):
    L = ["### Avisos usados (interno)", "| # | Dirección | Precio | m² | USD/m² | Fuente | Nota |", "|---|---|---|---|---|---|---|"]
    for i, a in enumerate(av, 1):
        m2 = a.get("m2")
        link = f"[{a.get('fuente') or 'link'}]({a['link']})" if a.get("link") else (a.get("fuente") or "—")
        L.append(f"| {i} | {a.get('direccion')} | {usd(a['precio'])} | {miles(m2) if m2 else 'n/d'} | "
                 f"{miles(a['precio'] / m2) if m2 else '—'} | {link} | {a.get('nota') or ''} |")
    excl = [a for a in d.get("avisos", []) if not a.get("incluir", True)]
    L += ["", "### Números",
          f"- Rango publicado: {usd(R['min'])} – {usd(R['max'])} · mediana {usd(R['mediana'])} · promedio {usd(R['promedio'])}",
          f"- Mitad central (P25–P75): {usd(R['p25'])} – {usd(R['p75'])}",
          f"- USD/m²: mediana {miles(R['usd_m2_med'])} (rango {miles(R['usd_m2_min'])}–{miles(R['usd_m2_max'])}, {R['n_m2']} avisos con m²)"
          if R["usd_m2_med"] else "- USD/m²: sin datos de m²",
          f"- Impacto de 10 m²: ~{usd(R['impacto_10m2'])}" if R["impacto_10m2"] else ""]
    if R.get("ed"):
        e = R["ed"]
        L.append(f"- Mismo edificio ({e['etiqueta']}): {e['n']} avisos de {usd(e['min'])} a {usd(e['max'])} ({pct(e['dif'])})")
    for c in d.get("cerradas", []):
        L.append(f"- Cerrada: {c.get('direccion')} · publicada {usd(c['precio_publicado']) if c.get('precio_publicado') else 'n/d'} · "
                 f"cierre {usd(c['precio_cierre']) if c.get('precio_cierre') else 'n/d'} · {c.get('fecha_cierre') or ''} · {c.get('fuente') or ''}")
    for a in excl:
        L.append(f"- Excluido: {a.get('direccion')} {usd(a['precio']) if a.get('precio') else ''} — {a.get('nota') or ''}")
    return "\n".join(x for x in L if x is not None)

# ─────────────────────────────────────────────────────────── EJEMPLO ───────
EJEMPLO = {
    "informe": {"fecha": "2026-10-01", "preparado_para": "Familia Pérez"},
    "propiedad": {"direccion": "Calle 123", "barrio": "Martínez", "tipo": "Departamento",
                  "descripcion": "3 amb · 2do piso · balcón", "m2": None},
    "segmento": {"zona": "Martínez", "tipologia": "departamentos de 3 ambientes usados",
                 "fuentes": "Zonaprop y Argenprop", "excluye": "se excluyen los a estrenar"},
    "mismo_edificio": {"filtro": "Alvear 500", "etiqueta": "Alvear al 500"},
    "avisos": [
        {"direccion": "Alvear 500", "precio": 150000, "m2": 70, "fuente": "Zonaprop", "link": "https://..."},
        {"direccion": "Alvear 500", "precio": 132000, "m2": 68, "fuente": "Argenprop"},
        {"direccion": "Libertad 900", "precio": 140000, "m2": 65, "fuente": "Zonaprop"},
        {"direccion": "Pueyrredón 400", "precio": 165000, "m2": 75, "fuente": "Zonaprop"},
        {"direccion": "Santa Fe 1200", "precio": 128000, "m2": 62, "fuente": "Argenprop"},
        {"direccion": "Edificio nuevo", "precio": 240000, "m2": 72, "incluir": False, "nota": "a estrenar"},
    ],
}

# ──────────────────────────────────────────────────────────── MAIN ─────────
def main():
    ap = argparse.ArgumentParser(description="Generador de Pre-ACM — Cristian Stedtfeld · Red Suma")
    ap.add_argument("datos", nargs="?")
    ap.add_argument("-o", "--salida")
    ap.add_argument("--ejemplo", action="store_true")
    ap.add_argument("--solo-calculos", action="store_true")
    a = ap.parse_args()
    if a.ejemplo:
        json.dump(EJEMPLO, open("ejemplo_preacm.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print("Escrito ejemplo_preacm.json"); return
    if not a.datos:
        ap.error("falta el archivo de datos (o usá --ejemplo)")
    d = json.load(open(a.datos, encoding="utf-8"))
    av, R = calcular(d)
    print(resumen_interno(d, av, R))
    if a.solo_calculos:
        return
    html_txt = construir_html(d, av, R)
    base_dir = os.path.dirname(os.path.abspath(a.datos))
    pdf = a.salida or os.path.join(base_dir, f"PreACM_{G.slug(d['propiedad'].get('direccion', 'propiedad'))}.pdf")
    motor = G.a_pdf(html_txt, pdf)
    out = {k: v for k, v in R.items()}
    json.dump(out, open(os.path.splitext(pdf)[0] + ".calculos.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"\nPDF: {pdf if motor else '(no generado)'}  [motor: {motor}]")

if __name__ == "__main__":
    main()
