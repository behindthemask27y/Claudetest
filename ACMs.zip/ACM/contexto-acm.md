# Contexto: ACM

Se lee **solo** cuando Cris pide un ACM. Todo lo de este archivo está copiado tal cual de donde ya estaba; cada bloque dice de dónde sale. Las reglas generales (no inventar, OK de Cris, números del script, PDF para el cliente y cocina en el chat, español rioplatense, USD) están en las instrucciones del proyecto y no se repiten acá.

---

## 1. Cuándo se usa

*Fuente: memoria del proyecto (pedido de Cris).*

cuando diga "quiero hacer un pre-ACM", armar la hoja pre-ACM con el formato aprobado (docs y generar_preacm.py en la carpeta pre-ACM/ del proyecto); cuando diga "quiero hacer un ACM", hacer el ACM normal (carpeta ACM/).

## 2. Qué leer

*Fuente: instrucciones del proyecto (copia exacta).*

ANTES DE EMPEZAR, leé los documentos del proyecto y seguilos al pie de la letra:
- ACM/01_Instrucciones_ACM_v2.md → flujo completo (relevamiento, comparables, cálculos, entrega)
- ACM/02_Manual_de_marca_reportes.md → diseño del PDF
- ACM/03_Calculos.md → metodología de cálculo
- ACM/04_Formato_de_datos.md y ACM/generar_acm.py → cómo generar el PDF
Si algo de este cuadro contradice esos documentos, mandan los documentos.

Casos hechos o en curso: `ACM/casos/` (hoy, `Gutierrez_FVarela_en_curso.md`).

Diseño común a todas las piezas: `Diseno/sistema-diseno.md` (medido desde `generar_acm.py`, que es la referencia).

## 3. Fuentes

*Fuente: `ACM/01_Instrucciones_ACM_v2.md`, Paso 2 (copia exacta).*

**Fuentes, en orden de prioridad:** Zonaprop, Argenprop, MercadoLibre Inmuebles, **Red Suma** (https://propiedades.redsuma.com.ar/ — propiedades de la red, verificadas por asesores; búsqueda con el patrón `/propiedades/venta/<tipo>/<localidad>`), Properati, RE/MAX, Inmuebles Clarín, Buscainmueble. Como complementarias: Cabaprop, sitios de otras redes (Coldwell Banker, Century 21), el Índice Zonaprop y los informes de Reporte Inmobiliario o UCEMA para la tendencia.

**Fuente prioritaria: CRM de Red Suma (admin.redsuma.com.ar), si hay navegador disponible.** Cris ya inició sesión en el navegador integrado de Claude (cuenta Google de la empresa). El CRM tiene un módulo **ACM** que trae avisos activos (Zonaprop/RE/MAX) y **ventas cerradas de la red con precio real de cierre**, en un radio alrededor de la dirección.
1. Pedile OK a Cris antes de crear el ACM en el CRM (es un registro en su cuenta). Crearlo en *ACM → Nuevo ACM*: nombre "Cliente – Dirección", operación, tipo, zona por radio (buscar la dirección y confirmar el pin), criterios (dormitorios, superficie total ±30%, activas + cerradas).
2. Leer los comparables (8 páginas de 30 aprox.). Tomar de cada uno: precio publicado, precio de cierre y fecha si está "Cerrada", m², antigüedad, dirección, link y URL de la foto. Las coordenadas del sujeto salen del pin (lat/lng).
3. **Usar el conjunto de ventas cerradas de la zona para fijar la brecha publicación→cierre** (mediana e IQR) en `parametros.brecha_cierre_min/max` y citar la fuente en `brecha_fuente`.
4. Sumar a la lista para aprobar los cierres más parecidos a la propiedad (misma localidad/código postal, antigüedad y piso similares).
5. Solo lectura: no marcar favoritos, no editar ni borrar nada en el CRM salvo que Cris lo pida.

## 4. Pasos

*Fuente: `ACM/01_Instrucciones_ACM_v2.md` (títulos copiados tal cual; el detalle de cada paso está en ese archivo).*

- PASO 0 — PREPARAR HERRAMIENTAS (en silencio)
- PASO 1 — RELEVAMIENTO (siempre empezá acá)
- PASO 2 — COMPARABLES
- PASO 3 — CÁLCULOS
- PASO 4 — ENTREGA

No avances hasta tener como mínimo: operación, ubicación, tipología, m² y estado.

**Aprobación obligatoria:** antes de calcular, mostrale a Cris la lista de comparables en una tabla con link y datos clave. Él saca, agrega o te pide buscar más. **Nunca armes el ACM final con comparables que Cris no vio y aprobó.**

## 5. Formato aprobado y entregables

*Fuente: `ACM/02_Manual_de_marca_reportes.md`, sección 6 (copia exacta).*

| Pág. | Título | Contenido |
|---|---|---|
| 00 | Checklist. | **Anexo, siempre primero.** Preguntas de relevamiento por sección (titularidad y documentación, superficie y estado, servicios y gastos, situación y expectativas) + "Específicas de esta propiedad". Para completar con el cliente. |
| 01 | Reporte profesional. | "Análisis Comparativo de Mercado", regla dorada + pill, dirección y barrio, caja de muestra (solo en ejemplos) y tarjeta blanca con comparables analizados, rango de mercado, agente, zona, operación y tipo, "Preparado para", fecha e ID. |
| (opcional) | Foto del frente. | Solo si hay `foto_frente`: subtítulo dorado con la dirección, foto grande (664 × 430 px, radio de 15 px), crédito de la imagen y cajas KPI con los datos de la propiedad. |
| 02 | Reporte profesional. | Subtítulo con la cantidad de comparables, 5 KPIs (comparables, promedio de publicación, USD/m² homogeneizado, superficie promedio, rango), criterios de búsqueda y mapa de la zona. |
| 03 / 03.1 | Comparables. / Más comparables. | La propiedad del cliente primero, con badge "Tu propiedad", y después los comparables de la muestra. |
| 04 | Valor sugerido. | Publicación sugerida, rango de cierre, venta rápida, posicionamiento vs mercado, barra de rango, recuadro **"Para tener en cuenta"** (precios publicados ≠ venta · avisos con m² mal detallados) y nota legal. |
| 05 | Conclusiones. | Párrafos de conclusión, contexto de mercado (hasta 3 cajas) y contacto. |

Lo **interno** (tabla de ajustes, outliers, argumentos de venta, alerta de sobreprecio) **no se imprime nunca**. Va en el chat.

**Opciones del PDF (Cris, 6-oct-2026).** Si Cris pide el ACM sin decir nada más, sale **con checklist y con botones "Ver aviso"**. Solo se sacan si lo pide en ese pedido:
- "sin checklist" → `anexo.incluir: false`
- "sin botones" / "sin links" → `parametros.botones_aviso: false`

*Fuente: `ACM/01_Instrucciones_ACM_v2.md`, Paso 4 B (copia exacta).*

### B) Análisis interno en el chat (no va al PDF)
1. **Resumen ejecutivo** (5-6 líneas): valor sugerido, rango y conclusión principal.
2. **Tabla de comparables**: la que imprime el script, con dirección, plataforma y link, m², precio, USD/m², días publicada, ajustes y USD/m² ajustado.
3. **Análisis**: qué dice la muestra, la dispersión, los outliers descartados y por qué, y qué método central se usó y por qué.
4. **Valuación**: los tres precios con su justificación.
5. **Contexto de mercado**: tendencia de la zona, tiempo de venta estimado, crédito hipotecario y stock, con fuente.
6. **Argumentos para la charla**: 3-4 frases listas para usar con el propietario (captación) o con el comprador (negociación), sin tecnicismos.
7. **Alerta de precio**: si el pretendido está más de 10% arriba del valor de mercado, marcalo y sugerí cómo plantear la corrección.
8. **Advertencias**: qué datos faltan o no se pudieron verificar (m² sin confirmar, avisos dudosos, posibles duplicados). Lo de "publicado no es vendido" y "m² mal cargados" ya va en el PDF.

## 6. Reglas propias del modo

*Fuente: `ACM/01_Instrucciones_ACM_v2.md`, Reglas generales (copia exacta).*

- Ventas en **USD**; alquileres en **ARS** (o USD si la zona lo usa, aclarándolo). Formato argentino: USD 262.429 y -4,1%.
- Español rioplatense, tono profesional y directo.
- Citá la plataforma de cada comparable (en el PDF aparece como fuente en cada tarjeta).
- **Branding:** el PDF lleva siempre la marca de Cris ("CS." + Red Suma) y su pie legal. Nunca otra marca. Cualquier página o elemento nuevo sigue `02_Manual_de_marca_reportes.md`.
- Si Cris pide algo que el diseño no contempla, crealo respetando el manual (paleta, tipografías, componentes) y avisale qué agregaste.
- Mantené las preguntas simples, una idea por vez.

## 7. Notas de acceso a portales (5-oct-2026, desde la compu de Cris)

*Fuente: ACM de Solano López 3446. Ahorran pruebas de URL.*

- **Red Suma:** el patrón que anda es `https://propiedades.redsuma.com.ar/propiedades/venta/departamento/<barrio>` (tipo en singular; con "departamentos" da 404).
- **RE/MAX:** no acepta filtros por URL; mirar solo la primera página del barrio.
- **Properati:** bloquea el navegador ("Access Denied"). No perder tiempo ahí.
- **MercadoLibre:** suele tener la misma unidad que un dueño publica "sin precio" en Zonaprop, pero cargada por una inmobiliaria y con precio. Buscar siempre.
- **CRM:** en la compu de Cris, crear un "Nuevo ACM" (/acms/nueva) lo frena el control de permisos si Cris no lo autoriza explícitamente. Pedir "OK CRM" en el primer mensaje, o que Cris cree el ACM y pase el link.
- Antes de buscar, revisar si la propiedad ya está en `Dueno-vende/casos/` y reusar esos comparables.
- **CRM (6-oct-2026):** en *Nuevo ACM*, la zona "Barrios" (buscar el barrio y elegirlo) trae los cierres de todo el barrio; por defecto viene tildado solo "Operaciones cerradas". En cada tarjeta, "m²" es la superficie cubierta y "m² homog." suma los descubiertos ponderados. Para leer muchas tarjetas rápido: texto de `<main>` cortado por "Cerrada" (ver `pre-ACM/casos/Duenos_2026-10-06/`).
