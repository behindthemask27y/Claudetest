# Lógica de cálculos del ACM (v2.0)

Esto fusiona la metodología del prompt 1.0 de Cris (ajustes y mediana) con la de la skill de su compañero (promedios, homogeneización y cierres reales). **El script `generar_acm.py` hace todas las cuentas.** Este documento explica qué hace, para poder justificarlo y ajustar los parámetros.

## 1. Superficie de referencia

- **Por defecto: m² cubiertos.**
- **Ponderada** (`parametros.superficie_base = "ponderada"`): cubiertos + 50% de los semicubiertos + 33% de los descubiertos. Conviene en casas con jardín o en deptos con terrazas grandes. Tiene que aplicarse igual a la propiedad y a todos los comparables, y hay que aclararlo en el chat.

## 2. USD/m² de cada comparable

- En la tarjeta se muestra el **precio de cierre** si está vendida (si no, el publicado) dividido por los m².
- Para el análisis se trabaja a **nivel publicación**: precio publicado / m². En las vendidas se usa su último precio publicado. Así toda la muestra es comparable entre sí, y los cierres se usan aparte para calibrar la brecha (punto 5).

## 3. Ajustes (homogeneización)

Llevan cada comparable a las condiciones de la propiedad analizada. Si el comparable es **peor**, el ajuste es **positivo**; si es **mejor**, es **negativo**.

| Factor | Rango orientativo | Cómo se carga |
|---|---|---|
| Estado / refacción | ±5 a 15% | `{"concepto":"A refaccionar","pct":10}` |
| Antigüedad significativa | ±5 a 10% | `pct` |
| Cochera | valor de mercado de la cochera en la zona, en USD (no un %) | `{"concepto":"Sin cochera","usd":15000}` |
| Amenities / expensas altas | ±3 a 8% | `pct` |
| Piso, luminosidad, contrafrente, planta baja | ±3 a 7% | `pct` |
| Ambientes/dormitorios distintos (±1) | ±3 a 5% | `pct` |
| Baulera | USD, aprox. 20-30% del valor de una cochera | `usd` |

Fórmula: **precio ajustado = precio publicado × (1 + Σ%) + Σ USD** → **USD/m² ajustado = precio ajustado / m²**.

Si no hay un dato confiable (por ejemplo, el valor de la cochera en esa zona), preguntale a Cris su criterio o no ajustes y dejalo aclarado. Un número homogeneizado nunca se presenta como exacto: es una aproximación.

## 4. Outliers y valor central

- **Outliers:** se excluyen los que Cris o Claude marcan (`"outlier": true` + motivo) y, automáticamente, los que quedan fuera de 1,5 × el rango intercuartil del USD/m² ajustado (solo con 4 o más comparables). Se excluyen del cálculo **y del PDF**, y se informan en el chat.
- **Mínimo de 3 comparables válidos** para calcular. Con menos de 5 se avisa que la muestra es chica.
- **Mediana o promedio** (Cris pidió que Claude elija y lo explique):
  - Regla automática: **promedio** si hay 6 o más comparables, la dispersión (coeficiente de variación) es ≤10% y promedio y mediana difieren ≤3%. En cualquier otro caso, **mediana**, que resiste mejor los extremos.
  - Se puede forzar con `parametros.metodo_central` (`"mediana"` o `"promedio"`) y una `justificacion_metodo`.
  - El chat siempre muestra los dos valores y el motivo de la elección.

## 5. Brecha publicación → cierre

- **Supuesto de mercado: 5% a 8%** (contraoferta típica en venta en Argentina).
- Si la muestra tiene **2 o más cierres reales** (publicado y cierre conocidos), la brecha se calcula con ellos: promedio observado ±1,5 puntos, acotado entre 2% y 15%. Con un solo cierre se informa, pero se mantiene el supuesto.
- Se puede fijar a mano con `brecha_cierre_min` y `brecha_cierre_max` si hay datos de mercado más recientes (por ejemplo, un informe de escrituras del Colegio de Escribanos o de Reporte Inmobiliario).

## 6. Los tres precios

Con **V = USD/m² central × m² de la propiedad** (valor de mercado a nivel publicación):

| Precio | Fórmula | Idea |
|---|---|---|
| **Publicación sugerida** | V | Competitivo contra lo publicado, con el margen normal de negociación. |
| **Rango de cierre esperable** | V × (1 − brecha máx.) → V × (1 − brecha mín.) | Lo que realmente se firmaría. |
| **Venta rápida** | V × (1 − brecha máx. − 3%) | Para propietarios con urgencia: queda por debajo del cierre típico y se destaca en la búsqueda. |

Todos se redondean a USD 1.000 (`parametros.redondeo`). Si Cris decide otro número, se carga en `valuacion_override` y el script lo respeta y lo anota.

## 7. Indicadores del PDF

- **Promedio de publicación:** promedio simple de los precios publicados de la muestra (activas + vendidas).
- **Promedio de cierre:** solo sobre las vendidas con precio real. Si no hay, no se muestra (nunca se inventa).
- **USD/m² homogeneizado:** el valor central ajustado (mediana o promedio, según el punto 4).
- **Superficie promedio**, **rango (mínimo y máximo publicados)** y **antigüedad promedio** (esta última solo en el chat).
- **Sugerido vs promedio:** (publicación sugerida / promedio de publicación − 1), con signo.

## 8. Alerta de sobreprecio (solo en el chat)

Si el **precio pretendido** supera a V en más de 10%, se marca ⚠️ y se sugiere cómo plantear la corrección: comparables concretos, tiempo en el mercado de las publicaciones caras y el costo de oportunidad de publicar fuera de precio.

## 9. Cómo se expresa

- USD con punto de miles (USD 262.429). Porcentajes con coma y signo (+1,0% / -4,1%).
- El precio final es criterio del agente y del propietario. Se ajusta según consultas y visitas una vez publicado.
