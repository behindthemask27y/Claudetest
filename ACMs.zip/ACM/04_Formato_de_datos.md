# Formato de datos del generador (datos.json)

`python3 generar_acm.py --ejemplo` escribe un ejemplo completo. Los campos marcados con * son obligatorios. Si un dato no existe, no pongas el campo: nunca pongas un valor inventado.

```json
{
  "informe": {
    "fecha": "2026-09-27",            // opcional; por defecto, hoy
    "id": "ACM-2026-0412",            // opcional; se genera solo
    "preparado_para": "Familia Pérez", // opcional; aparece en la portada
    "contexto": "captacion",          // captacion | defensa | comprador (uso interno)
    "etiqueta": "Informe profesional", // texto de la pill de portada
    "es_muestra": false               // true solo para PDFs de ejemplo
  },
  "operacion": "Venta",
  "busqueda": {
    "zona": "Martínez",               // * aparece en portada y criterios
    "radio": "Radio 2 km",
    "muestra": "Activas + Cerradas",  // opcional; se deduce solo
    "filtros": ["4 ambientes", "110–150 m²"],  // opcional, hasta 2
    "localidad_geo": "San Isidro, Buenos Aires" // ayuda a ubicar direcciones en el mapa
  },
  "propiedad": {
    "direccion": "Libertad 300", "barrio": "Martínez", "tipo": "Casa",   // *
    "ambientes": 4, "dormitorios": 3, "banos": 1, "cocheras": 1,
    "m2_cubiertos": 125,                                               // *
    "m2_semicubiertos": 10, "m2_descubiertos": 80,
    "antiguedad": 30, "estado": "Muy bueno",
    "precio_pretendido": 350000,   // opcional, solo para análisis interno
    "precio_publicado": null,      // si ya está publicada, se muestra en su tarjeta
    "foto": "foto_propiedad.jpg",  // ruta local o URL
    "foto_frente": "frente.jpg",   // opcional: agrega la página "Foto del frente." después de la portada
    "foto_frente_credito": "Imagen: Google Street View",  // leyenda chica bajo la foto
    "lat": -34.4905, "lon": -58.5190
  },
  "comparables": [
    {
      "direccion": "Alsina 900", "barrio_tarjeta": null, "tipo": "Casa",
      "ambientes": 4, "dormitorios": 3, "banos": 1, "cocheras": 1,
      "m2_cubiertos": 120, "antiguedad": 25, "estado": "Bueno",
      "precio_publicado": 360000,                 // *
      "precio_cierre": null, "fecha_cierre": null, // si está vendida: "2026-07"
      "estado_aviso": "activa",                   // activa | vendida
      "dias_publicada": 60,                       // con 180 o más aparece el badge
      "fuente": "Zonaprop", "link": "https://...",
      "foto": "https://.../foto.jpg",
      "lat": -34.4830, "lon": -58.5285,
      "ajustes": [{"concepto": "Estado", "pct": -3}, {"concepto": "Sin cochera", "usd": 15000}],
      "outlier": false, "motivo_outlier": null
    }
  ],
  "parametros": {
    "superficie_base": "cubierta",   // cubierta | ponderada
    "metodo_central": "auto",        // auto | mediana | promedio
    "justificacion_metodo": null,
    "brecha_cierre_min": 5, "brecha_cierre_max": 8,  // si no se ponen, se calibran con 2 o más cierres reales
    "descuento_venta_rapida": 3,
    "redondeo": 1000,
    "auto_outliers": true,
    "geocodificar": true,
    "botones_aviso": true            // botón "Ver aviso" en los comparables publicados con link; false = sin botones
  },
  "anexo": {
    "incluir": true,                 // hoja "Checklist." al principio (página 00); false = sin checklist
    "preguntas_propiedad": [          // preguntas propias de ESTA propiedad (según lo que falte o genere dudas)
      "¿La azotea es de uso exclusivo? ¿El reglamento permite construir?"
    ],
    "lineas_notas": 5
  },
  "valuacion_override": {"publicacion": null, "cierre_min": null, "cierre_max": null, "venta_rapida": null},
  "textos": {
    "conclusiones": ["Párrafo 1 (admite <b>negrita</b>)", "Párrafo 2", "Párrafo 3"],
    "contexto_mercado": {
      "tendencia":    {"valor": "Estable", "nota": "Índice Zonaprop, ago-2026"},
      "tiempo_venta": {"valor": "4 a 6 meses", "nota": "Fuente"},
      "dato":         {"valor": "Crédito hipotecario activo", "nota": "Fuente"}
    }
  }
}
```

## Notas

- **Fotos:** si la URL no se puede bajar (porque la red de la sesión la bloquea), la tarjeta sale con un recuadro gris neutro. Solución: Cris adjunta capturas y en `foto` va la ruta del archivo.
- **Mapa:** necesita `lat` y `lon` en al menos 2 puntos, o que la geocodificación esté disponible. Con acceso a `basemaps.cartocdn.com` se dibuja el mapa real; si no, un esquema con la leyenda "Ubicación aproximada". Si no hay coordenadas, van chips con las direcciones.
- **Salidas:** `ACM_<direccion>.pdf`, `.html` (por si hay que imprimir desde el navegador) y `.calculos.json`. Por consola sale el resumen interno para el chat.
- Comentarios `//`: son solo explicativos. El JSON real no los lleva.

## Alquileres (modo ARS)

- Agregá `"operacion": "Alquiler"` y `"moneda": "ARS"` en la raíz del JSON. El PDF muestra montos en pesos ($ 2.450.000, $/m²), "Alquiler mensual sugerido", "Alquiler rápido", badge "Alquilada" en los cierres y un checklist de relevamiento para locación.
- Los comparables en USD se convierten a ARS antes de cargarlos (dólar oficial BNA vendedor del día, citado en el chat) y se redondean.
- Brecha de negociación: fijala a mano (`brecha_cierre_min/max`, p. ej. 3 y 8) con `brecha_fuente`. `redondeo` sugerido: 50000.
- `propiedad.m2_etiqueta` y `m2_nota` permiten mostrar la superficie como "135 m² tot." con el detalle por planta en la foto del frente.
- Sin `moneda` todo funciona igual que antes (venta en USD).

## Mapa de Google Maps (fondo externo)

- `parametros.mapa_fondo`: ruta a una imagen de mapa ya capturada; `parametros.mapa_fondo_credito`: leyenda (por defecto "Datos del mapa © Google").
- Al correr el script, la consola imprime `[mapa] centro LAT,LON · capturar a zoom Z en 1330x564 px`. La imagen tiene que tener ESE centro, ESE zoom y ese tamaño (2× del recuadro), sin controles ni marcadores: los pines los dibuja el script.
- Cómo capturarla (Claude, con el navegador integrado): viewport 665×282, un iframe `https://maps.google.com/maps?ll=LAT,LON&z=Z&t=m&hl=es&output=embed` de 1730×864 px, y 4 capturas desplazando el iframe a (-200,-150), (-865,-150), (-200,-432), (-865,-432). Se unen en una imagen de 1330×564.
- Sin `mapa_fondo` intenta CARTO/OpenStreetMap y, si la red lo bloquea, usa el esquema "Ubicación aproximada".
