# Manual de marca de reportes — Cristian Stedtfeld · Red Suma

Este manual define cómo se ven los reportes de Cris: el ACM y cualquier documento futuro que siga la misma línea (tasaciones, informes de gestión, fichas). Los valores salen de su diseño original de ACM (páginas 05 a 08 de su carpeta de presentación). **Todo elemento nuevo se construye con estas piezas, no con estilos inventados.**

El generador `generar_acm.py` ya implementa todo esto. Este documento sirve para crear páginas nuevas y revisar que nada se salga de marca.

---

## 1. Identidad

| Elemento | Especificación |
|---|---|
| Logo personal | **"CS."**: letras en negro `#171717` en Goodtime Grotesk, con trazo reforzado, y punto circular dorado `#988355`. Va arriba a la izquierda en todas las páginas. |
| Logo red | **RED SUMA · Conexión inmobiliaria**: "RED" en dorado `#988355`, "SUMA" y la bajada en negro. Es un vector trazado del logo oficial. Va arriba a la derecha. |
| Bajada del header | `AGENTE INMOBILIARIO` en Montserrat SemiBold, mayúsculas, tracking amplio (0,34 em), seguido de un "·" y el logo Red Suma. |
| Pie legal (fijo) | Línea dorada + "Los corredores públicos intermedian y concluyen todas las operaciones. Los agentes operan bajo el control y supervisión de un corredor público." + "Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609". En Inter. |
| Número de página | Goodtime Grotesk grande, a la derecha del pie. Se numera solo: `01`, `02`… y las continuaciones llevan `.1`, `.2` (por ejemplo, `03.1`). |
| Contacto | Nombre en Chillax Semibold · WhatsApp +54 9 11 6695-1945 · cstedtfeld@redsuma.com.ar · csrealestate.com.ar |

> El logo "CS." está recreado con tipografía. Si Cris manda el archivo original (SVG o PNG), se reemplaza en el generador.

## 2. Paleta

| Token | HEX | Uso |
|---|---|---|
| Azul marino | `#253C64` | Precios en tarjetas, valores KPI, pill de portada, barra de rango |
| Azul marino profundo | `#1F2A5C` | Los tres valores de "Valor sugerido" |
| Dorado | `#988355` | Subtítulos, USD/m², línea del pie, punto del logo, valores de criterios y de rango, bordes |
| Dorado cálido | `#AD8A48` | Separadores verticales de "Valor sugerido" y marcador del promedio en la barra |
| Dorado texto | `#8A6A2F` | Texto dentro de los badges crema |
| Crema | `#FBF0D9` | Fondo de los badges ("Vendida jul-2026", "Tu propiedad") |
| Rojo | `#FF5F5F` | Solo para diferencias negativas de precio ("-4,1% del valor publicado") |
| Negro títulos | `#171717` | Títulos, logo, encabezados de sección |
| Texto | `#2B2B34` | Direcciones, datos, párrafos |
| Gris texto | `#6A6A6A` | Etiquetas en mayúsculas, meta ("Venta · Casa"), notas |
| Gris tarjeta | `#DBDBDB` | Fondo de tarjetas y cajas KPI |
| Fondo de página | degradé radial: blanco al centro, `#ECECEC` en los bordes | Todas las páginas |
| Blanco | `#FFFFFF` | Tarjeta de datos de portada, pines del mapa |
| Pin propiedad | `#7D6531` | Pin de "Tu propiedad" en el mapa (texto blanco) |

**Reglas:** no hay otros colores. El verde no existe en la marca. El rojo se usa solo para variaciones negativas. El dorado nunca va en bloques grandes: es un acento (textos, líneas, bordes).

## 3. Tipografía

| Rol | Fuente | Detalle |
|---|---|---|
| Títulos de página | **Goodtime Grotesk** | Terminan siempre con punto: "Comparables.", "Valor sugerido.", "Conclusiones.". 31 px, negro. |
| Header | **Montserrat SemiBold** | Solo "AGENTE INMOBILIARIO". |
| Datos, precios, textos | **Arial** (en el generador, Liberation Sans, que es métricamente idéntica) | Bold para precios, direcciones y valores; regular para el cuerpo. |
| Etiquetas | Arial Bold, mayúsculas, tracking 0,2 em, 9,4 px, gris | "COMPARABLES ANALIZADOS", "PROMEDIO DE MERCADO". |
| Encabezados de sección | Arial Bold, mayúsculas, tracking 0,12 em, 16,5 px, negro | "POSICIONAMIENTO VS MERCADO", "ZONA ANALIZADA". |
| Pie legal | **Inter** Regular 7,7 px | Solo el pie. |

Tamaños de referencia en una página A4 de 794 × 1123 px: subtítulo dorado 15,2 px bold, precio de tarjeta 19,6 px, dirección 15 px, datos 12,2 px, valores KPI 20,5 px, cuerpo de texto 11,3 px con interlineado de 17 px.

> ⚠️ **Licencia:** Goodtime Grotesk es una versión **"Personal Use"** (MadeType). Un reporte que se entrega a clientes es uso comercial. Hay que comprar la licencia comercial (madetypeinfo@gmail.com / fontspring) o cambiarla por otra con licencia libre.

## 4. Grilla y página

- Formato **A4 vertical**, sin márgenes de impresión y con fondos impresos.
- Márgenes laterales de 65 px (~17 mm). El contenido ocupa 664 px de ancho.
- Header a 72 px del borde superior. El título de página arranca a 183 px.
- Pie: línea dorada a 1056 px, dos líneas de texto legal y número de página a la derecha.
- Espacios verticales: 22 px entre título y subtítulo, 12 px entre tarjetas, 30-35 px antes de cada encabezado de sección.

## 5. Componentes

**Título + subtítulo.** Título en Goodtime con punto final. Debajo, una frase en dorado bold que explica la página ("Propiedades en venta actualmente y operaciones concretadas en la zona.").

**Caja KPI.** Fondo `#DBDBDB`, radio de 5 px, etiqueta gris en mayúsculas arriba, valor en azul marino bold y nota gris chica opcional abajo. Se usan en grillas de 2 o 3 columnas con 6 px de separación.

**Tarjeta de propiedad.** Fondo gris con borde claro de 1 px y 122 px de alto. Foto a la izquierda (155 × 103 px, radio de 15 px, recorte que llena el espacio). A la derecha, en este orden: precio (azul marino), dirección (bold), meta en gris ("Venta · Casa · Zonaprop"), fila de datos ("4 amb  3 dorm  1 baño  1 coch  125 m²", con singular y plural correctos) y USD/m² en dorado. Se permiten hasta 5 tarjetas por página.

**Badge.** Rectángulo crema `#FBF0D9` con texto `#8A6A2F` bold, 153 × 31 px, arriba a la derecha de la tarjeta. Textos admitidos: "Tu propiedad", "Vendida mmm-aaaa", "Publicada hace N meses".

**Variación de precio.** Debajo del badge y centrada, en rojo bold y dos líneas: "-4,1% del valor / publicado".

**Pill.** Cápsula azul marino con texto blanco en mayúsculas espaciadas. Una sola por documento, en la portada.

**Caja con borde dorado.** Borde de 2,2 px en dorado, fondo blanco y texto dorado. Solo para avisos importantes (por ejemplo, "DOCUMENTO DE MUESTRA").

**Recuadro "Para tener en cuenta".** Borde dorado de 1,5 px, fondo blanco, etiqueta negra en mayúsculas y dos columnas: círculo dorado con "!" + frase en negrita negra + explicación en texto normal (11 px). Va en el ACM (página "Valor sugerido.") y en el pre-ACM (debajo del rango). Textos fijos en `aclaraciones()` de `generar_acm.py`.

**Valor destacado (3 columnas).** Caja gris grande con separadores verticales en dorado cálido de 3,4 px. Etiqueta en mayúsculas espaciadas y valor en azul marino profundo.

**Barra de rango.** Pista gris redondeada de 17 px con relleno azul marino hasta el promedio, marcador vertical en dorado cálido y, arriba, una flecha azul marino "SUGERIDO ±x%". Debajo lleva MÍNIMO, PROMEDIO y MÁXIMO en etiquetas grises, con los valores en dorado.

**Mapa.** Caja de 282 px de alto con esquinas redondeadas. Pines en cápsula blanca con borde dorado y precio "US$ 330k" en dorado oscuro. La propiedad del cliente va en cápsula `#7D6531` con texto blanco ("Tu propiedad"). Si no hay mapa real, se usa un esquema de grilla gris con la leyenda "Ubicación aproximada". Si no hay coordenadas, van chips con las direcciones.

**Tarjeta de contacto.** Caja gris, sin logo (el "CS." ya está en el header). Nombre en **Chillax Semibold** 19 px negro; debajo, "Agente inmobiliario · Red Suma" en gris; a la derecha, WhatsApp (en azul marino), email y web.

**Checklist (anexo).** Título "Checklist." con pill azul "ANEXO · RELEVAMIENTO" a la derecha. Línea de datos (propiedad, cliente, fecha). Dos columnas de secciones: encabezado dorado en mayúsculas con línea dorada; cada pregunta con casilla cuadrada de borde dorado (10 px) y una línea punteada gris para anotar. Al final, "NOTAS" con líneas punteadas.

## 6. Estructura del ACM

| Pág. | Título | Contenido |
|---|---|---|
| 00 | Checklist. | **Anexo, siempre primero.** Preguntas de relevamiento por sección (titularidad y documentación, superficie y estado, servicios y gastos, situación y expectativas) + "Específicas de esta propiedad". Para completar con el cliente. |
| 01 | Reporte profesional. | "Análisis Comparativo de Mercado", regla dorada + pill, dirección y barrio, caja de muestra (solo en ejemplos) y tarjeta blanca con comparables analizados, rango de mercado, agente, zona, operación y tipo, "Preparado para", fecha e ID. |
| (opcional) | Foto del frente. | Solo si hay `foto_frente`: subtítulo dorado con la dirección, foto grande (664 × 430 px, radio de 15 px), crédito de la imagen y cajas KPI con los datos de la propiedad. |
| 02 | Reporte profesional. | Subtítulo con la cantidad de comparables, 5 KPIs (comparables, promedio de publicación, USD/m² homogeneizado, superficie promedio, rango), criterios de búsqueda y mapa de la zona. |
| 03 / 03.1 | Comparables. / Más comparables. | La propiedad del cliente primero, con badge "Tu propiedad", y después los comparables de la muestra. |
| 04 | Valor sugerido. | Publicación sugerida, rango de cierre, venta rápida, posicionamiento vs mercado, barra de rango, recuadro **"Para tener en cuenta"** (precios publicados ≠ venta · avisos con m² mal detallados) y nota legal. |
| 05 | Conclusiones. | Párrafos de conclusión, contexto de mercado (hasta 3 cajas) y contacto. |

Lo **interno** (tabla de ajustes, outliers, argumentos de venta, alerta de sobreprecio) **no se imprime nunca**. Va en el chat.

## 7. Cómo crear una página o elemento nuevo

1. Reutilizá el esqueleto de página (header, título con punto, subtítulo dorado, pie) y numerala en orden.
2. Armá el contenido solo con los componentes de la sección 5. Si hace falta algo nuevo (por ejemplo, un gráfico de evolución de precios), usá azul marino para la serie principal, dorado para la de referencia, gris `#DBDBDB` para el fondo, etiquetas en mayúsculas grises y nada de sombras fuertes ni otros colores.
3. Textos: frases cortas, en segunda persona hacia el cliente ("tu propiedad") y sin tecnicismos.
4. Números: USD con punto de miles, porcentajes con coma decimal y signo (+1,0% / -4,1%).
5. Antes de entregar, revisá que nada se corte, que no queden páginas en blanco y que el pie sea idéntico en todas las páginas.

## 8. Voz

Profesional, cercana y directa. El reporte le habla al propietario ("tu propiedad"). La conclusión siempre cierra con que el precio final es decisión del propietario junto con el agente y que se ajusta según consultas y visitas.
