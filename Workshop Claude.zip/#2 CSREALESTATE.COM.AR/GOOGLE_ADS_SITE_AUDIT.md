# Auditoría técnica — csrealestate.com.ar (para implementación de Google Ads)

Auditoría **read-only**: no se modificó ningún archivo del proyecto. Se leyó
`CLAUDE.md` completo (histórico de decisiones del proyecto), el código fuente
de las 6 páginas del sitio (`index.html` + los 5 `form/*/index.html`),
`estilo.css`, `enviar-lead.php`, `propiedades.php`, y se verificó el
comportamiento **en vivo** contra `https://csrealestate.com.ar` (sólo
lecturas: GET, sin enviar ningún formulario de prueba nuevo).

Fecha de la auditoría: 2026-09-22.

---

## Resumen ejecutivo

- **El sitio está desplegado y funcionando en producción**, extremo a
  extremo, confirmado en vivo hoy: las 6 rutas (home + 5 formularios)
  responden `200`; `propiedades.php` devuelve las 4 propiedades reales;
  `enviar-lead.php` responde `405` a un `GET` (la validación de método
  funciona, PHP se ejecuta de verdad); y se encontraron **2 leads de
  prueba reales ya guardados** (`tasacion` y `comprar`), es decir que el
  flujo de guardado también fue probado con éxito. Esto **contradice y
  reemplaza** la última nota de `CLAUDE.md` ("todo da 404"), que quedó
  vieja — Cristian subió el zip correcto después de esa nota.
- 🔴 **Hallazgo crítico de seguridad, no relacionado con Ads pero urgente**:
  `https://csrealestate.com.ar/leads/leads.jsonl` **se puede leer
  directamente por HTTP** y devuelve **datos reales de contacto** (nombre,
  teléfono, email) de cada consulta recibida, a pesar de que el proyecto
  tiene un `leads/.htaccess` pensado exactamente para bloquear esto. Ver
  el detalle en "Riesgos" — **conviene resolver esto antes de escalar
  inversión en campañas**, porque cada lead nuevo que entre por los
  anuncios va a quedar expuesto de la misma forma.
- `generate_lead` **ya existe y está bien implementado** en el código de
  los 5 formularios: se dispara sólo tras la confirmación `200 {ok:true}`
  del backend, nunca al abrir/tocar el formulario, y **no manda nombre,
  teléfono ni email** — sólo `lead_type` y `form_name`. Es decir, el lado
  del sitio está **listo** para que este evento se marque como conversión
  principal en Google Ads; falta confirmar si ese paso ya se hizo del lado
  de GTM/GA4/Ads (la sección 15 de "Analytics" en `CLAUDE.md`, escrita por
  Cristian, lo marca como "objetivo futuro" — puede que ya haya avanzado
  desde que se escribió esa nota).
- **No hay páginas propias por propiedad ni por desarrollo** — todo el
  detalle (fotos, precio, características) vive en un `<dialog>` de
  JavaScript sobre la home, sin URL individual. Esto limita qué se puede
  usar como landing page de una campaña específica (ver "Landings
  faltantes").
- Los 5 formularios (`/form/*/`) son técnicamente sólidas landings de
  conversión (multi-step, validación, sin CAPTCHA agresivo, "Gracias"
  claro), pero **ninguna tiene `<h1>` ni meta description** — no es un
  problema de tráfico pago en sí, pero sí de Ad Quality Score /
  Landing Page Experience si Google las rastrea.
- El certificado y el forzado de HTTPS **ya funcionan** (`http://` redirige
  solo a `https://`, y `www.` converge a la versión sin `www`) — dos
  pendientes de `CLAUDE.md` que hoy están resueltos.
- Tracking: arquitectura GTM → GA4 → Google Ads ya está instalada en las
  6 páginas. Ver tabla completa en la sección 6. Un detalle real: los
  íconos de WhatsApp/Email del pie **en los 5 formularios no están
  trackeados** (sí lo están en la home) — no tienen `data-evento` ni el
  script delegado que lo procesa.
- **Cero implementación de `gclid`/`gbraid`/`wbraid`/UTMs** — el sitio no
  lee, guarda ni reenvía ningún parámetro de atribución hoy. Ver sección 7.

---

## Rutas disponibles

| Ruta | Objetivo | Formulario | `lead_type` |
|---|---|---|---|
| `/` | Home / hub central | No (deriva a los 5 de abajo) | — |
| `/form/tasacion/` | Conocer el valor de la propiedad | Sí | `tasacion` |
| `/form/vender/` | Vender una propiedad | Sí | `vender` |
| `/form/alquilar-mi-propiedad/` | Alquilar una propiedad (propietario) | Sí | `alquilar_propiedad` |
| `/form/comprar/` | Comprar una propiedad | Sí | `comprar` |
| `/form/buscar-alquiler/` | Buscar alquiler (inquilino) | Sí | `buscar_alquiler` |

No existen más rutas. No hay `/gracias` como URL propia (es un estado
inline, ver sección 8), no hay páginas por propiedad/desarrollo, no hay
`/privacidad` (es un modal, ver sección 13).

## Formularios

Los 5 comparten motor (validación, multi-step, envío) y endpoint
(`enviar-lead.php`) — ver detalle completo en la sección 4. Los tres
campos de contacto (nombre, WhatsApp, email) son **siempre obligatorios**
en los 5, y **nunca** viajan al `dataLayer` — sólo al backend propio.

## Conversion tracking

| Evento GA4 | Se dispara cuando... | ¿Es lead real? |
|---|---|---|
| `click_whatsapp` | clic en cualquier botón/ícono de WhatsApp | No — intención |
| `click_form` | clic en cualquiera de los 5 botones que abren un formulario | No — intención |
| `click_ver_propiedades` / `ver_desarrollos` | se abre el detalle de una tarjeta del carrusel | No — interés |
| `ver_mimetodo` | se abre el bloque "Mi método" | No — interés |
| **`generate_lead`** | el backend confirma que guardó la consulta (`{ok:true}`) | **Sí — el único que lo es** |

`generate_lead` es el único evento del sitio que representa un lead
confirmado. Detalle completo, con archivo y línea, en la sección 5.

## Landings utilizables

- **Home (`/`)** — sirve para una campaña de marca/genérica ("servicios
  inmobiliarios"), o como landing de respaldo. Tiene `<h1>`, meta
  description y `og:*` completos.
- **Los 5 `/form/*/`** — cada una es la landing natural de una campaña
  específica (tasación, vender, alquilar, comprar, buscar alquiler),
  porque el `lead_type` ya las distingue una a una en el tracking. Antes
  de escalar spend hacia ellas, conviene sumarles `<h1>` y meta
  description (ver "Riesgos").

## Landings faltantes

- **Ninguna propiedad ni desarrollo tiene URL propia** — no se puede armar
  un anuncio que lleve directo a "esta propiedad" o "este desarrollo": el
  máximo alcance posible es linkear a la home (que igual requiere
  scrollear hasta el carrusel).
- **No hay landing por zona** (Zona Norte, Pilar, CABA — mencionadas sólo
  en la meta description de la home, ver sección 11) para separar
  campañas geográficas.
- **No hay landing por tipo de propiedad** (oficinas, locales comerciales,
  terrenos) — esas categorías sólo existen como una opción más dentro de
  un `<select>` de los formularios, nunca como una página propia.
- **No hay landing de "Desarrollos"/inversión** aparte — vive dentro de la
  home, sección "Desarrollos destacados".

## Assets disponibles

Ver inventario completo con medidas reales en la sección 14. Resumen: hay
foto de portada, logo, ícono de matrícula y fotos de 3 desarrollos reales
— **no hay fotos reales de las 4 "Propiedades en venta" actuales** (esas
tarjetas muestran datos reales sincronizados, pero las fotos vienen de la
fuente externa, no son archivos propios del proyecto) y las 5 fotos de
stock (`propiedad-1.webp` a `propiedad-5.webp`) están **huérfanas: ya no
las usa ninguna página**.

## Riesgos / problemas encontrados

1. 🔴 **`leads/leads.jsonl` público vía HTTP** (crítico, no es sólo de
   Ads). Confirmado en vivo: `https://csrealestate.com.ar/leads/leads.jsonl`
   devuelve `200` con el contenido real del archivo — nombre, teléfono y
   email de cada consulta recibida, en texto plano. El archivo
   `leads/.htaccess` (con `Require all denied` / `Deny from all`) está
   presente en el proyecto y llegó a subirse — de hecho `GET /leads/`
   (listado del directorio) sí da `403 Forbidden` — pero el archivo
   puntual `leads.jsonl` **no queda bloqueado igual**. No se pudo
   determinar la causa exacta sin acceso al panel de Hostinger; las
   hipótesis más probables, de mayor a menor probabilidad:
   - El `.htaccess` protege el listado de directorio (comportamiento por
     defecto de muchos hostings) pero Hostinger no está aplicando sus
     directivas `Require`/`Deny` a archivos individuales en esta cuenta
     (posible restricción de `AllowOverride` del lado del servidor).
   - El archivo `leads/leads.jsonl` en el servidor es de un momento
     anterior a que existiera `leads/.htaccess`, y alguna extracción de
     zip no llegó a sumar el `.htaccess` a esa carpeta en el servidor
     (aunque sí está en el zip local más reciente).
   **Recomendación**: confirmar por FTP/administrador de archivos de
   Hostinger que `leads/.htaccess` existe realmente en el servidor: si
   está y aun así no protege, mover `leads.jsonl` fuera de `public_html`
   (a una carpeta hermana no pública) es la solución más robusta —
   no depender sólo de `.htaccess` para datos personales.
2. **5 formularios sin `<h1>`.** Ninguna de las páginas `/form/*/` tiene
   un `<h1>` — el título visible (“Quiero vender mi propiedad”, etc.) es
   un `<p class="form-header__marca">`. Tampoco hay `<h2>`: los títulos de
   cada paso son `<legend>`. No rompe nada para el usuario ni para el
   envío, pero es señal débil para Landing Page Experience si Google
   llega a rastrear esas URLs.
3. **5 formularios sin meta description** (ni `og:*`/`twitter:*`). Sólo
   la home los tiene completos.
4. **Íconos de WhatsApp/Email del pie, sin trackear, en los 5
   formularios.** En la home, el ícono de WhatsApp del pie lleva
   `data-evento="whatsapp-icono"`; en los 5 `/form/*/`, el mismo ícono
   **no tiene `data-evento`**, y además esas páginas no cargan el script
   delegado que lo procesaría aunque lo tuviera (ver sección 6). No es un
   bug — simplemente nunca se agregó — pero significa que un clic ahí no
   genera ningún evento hoy.
5. **Dos imágenes pesadas para su uso real**: `logo-redsuma.png` pesa
   123 KB pero se muestra a 14px de alto (el archivo real mide
   1954×408 px); `desarrollo-3.jpg` pesa 232 KB y es una foto vertical de
   699×2000 px mostrada en una tarjeta 4:3. Ninguna rompe la carga, pero
   son las dos más candidatas a comprimir/recortar si se quiere ganar
   velocidad de landing.
6. **Sin `robots.txt` ni `sitemap.xml`** en la raíz del sitio. No es un
   problema para tráfico pago en sí (Google Ads no los necesita para
   servir un anuncio), se anota sólo como dato de referencia.
7. Nada roto encontrado en: rutas (las 6 responden `200`), redirects
   (`http→https` y `www→sin-www` convergen bien, confirmado en vivo hoy),
   formularios (2 leads de prueba reales ya guardados con éxito),
   `generate_lead` (payload verificado sin PII en los 5), ni contenido
   duplicado real.

---

# Detalle técnico completo

## 1. Stack del proyecto

- **Framework**: ninguno. HTML/CSS/JS planos, sin build ni bundler ni
  `package.json` en ningún lado del proyecto.
- **Versión**: no aplica (no hay dependencias versionadas).
- **Sistema de routing**: por sistema de archivos — cada carpeta
  (`form/<nombre>/`) tiene su propio `index.html`, y Apache/Hostinger lo
  sirve nativamente al pedir esa carpeta (mismo mecanismo con el que
  `/` sirve el `index.html` de la raíz). No hay router de cliente
  (sin JS de navegación tipo SPA).
- **Hosting/deployment**: Hostinger, con PHP habilitado. El despliegue es
  **manual**: Cristian sube y descomprime `cristian-stedtfeld-web.zip`
  dentro de `public_html` — no hay CI/CD, no hay git en este proyecto.
- **Backend existente**: dos scripts PHP en la raíz, sin framework
  (`enviar-lead.php`, `propiedades.php`) — ver secciones 4 y 10.
- **APIs/serverless**: ninguna función serverless; los dos PHP de arriba
  son los únicos endpoints propios. No hay integración con APIs de
  terceros del lado del servidor, salvo que `propiedades.php` **lee**
  (por HTTP, no API con clave) las páginas públicas de
  `propiedades.redsuma.com.ar` para extraer su JSON-LD.
- **Sistema de envío de emails**: `mail()` nativo de PHP, sin proveedor
  externo (no hay SendGrid/SES/SMTP configurado) — best-effort, no
  condiciona la respuesta al usuario (ver sección 4).
- **Base de datos**: no hay. El almacenamiento es un archivo de texto
  (`leads/leads.jsonl`, una línea JSON por lead, con `flock()` para
  escritura segura) y un archivo de caché (`cache/propiedades.json`).
  Ninguno de los dos existe en el repo local — ambos los crea el propio
  PHP la primera vez que hace falta, directamente en el servidor.
- **Variables de entorno**: no se usa ningún mecanismo de env vars — los
  pocos valores sensibles del lado del servidor (el email de destino
  `cstedtfeld@redsuma.com.ar`) están hardcodeados directo en
  `enviar-lead.php`. No hay claves de API, tokens ni contraseñas en
  ningún archivo del proyecto.
- **Cómo se despliega producción**: Cristian genera (o pide) un
  `cristian-stedtfeld-web.zip` con todos los archivos públicos (quedan
  fuera `CLAUDE.md`, `serve.ps1`, `.claude/`), lo sube por el
  administrador de archivos/FTP de hPanel, y lo descomprime encima de
  `public_html`. No hay ambiente de staging.

## 2. Mapa completo del sitio

### `/` (home)

- **Título HTML**: "Cristian Stedtfeld | Servicios inmobiliarios"
- **Meta description**: "Servicios inmobiliarios adaptados a tus
  necesidades. Tasación, venta, alquiler y compra de propiedades en CABA,
  Zona Norte y Pilar."
- **H1**: "Cristian Stedtfeld"
- **H2 principales**: "¿Cómo puedo ayudarte?", "Propiedades en venta",
  "Desarrollos destacados"
- **Objetivo de la página**: hub central — presenta a Cristian y deriva a
  las 5 acciones de negocio, más contacto directo (WhatsApp/Email) y
  prueba de actividad (propiedades/desarrollos reales).
- **CTA principal**: los 5 botones de "¿Cómo puedo ayudarte?" (tasación,
  vender, alquilar, comprar, buscar alquiler) + "¡Hablemos por WhatsApp!"
- **CTA secundarios**: Email, "Mi método" (contenido, no conversión),
  tarjetas de propiedades/desarrollos (abren detalle), botón de matrícula
  (legal, no comercial)
- **Formulario presente**: no directamente — enlaza a los 5 de abajo
- **Tipo de usuario**: todos los segmentos (vendedor, comprador,
  propietario que alquila, inquilino, quien quiere tasar) — landing
  genérica

### `/form/tasacion/`

- **Título HTML**: "Quiero saber cuánto vale mi propiedad | Cristian Stedtfeld"
- **Meta description**: no tiene
- **H1**: no tiene (ver hallazgo #2 de Riesgos)
- **H2 principales**: no tiene — usa `<legend>` por paso ("Sobre la
  propiedad", "Contanos más", "Tus datos de contacto")
- **Objetivo**: captar lead de tasación
- **CTA principal**: "Continuar"/"Enviar" (multi-step, 3 pasos)
- **CTA secundarios**: "← Volver al inicio", WhatsApp/Email del pie,
  Política de Privacidad
- **Formulario presente**: sí — `lead_type: tasacion`
- **Tipo de usuario**: propietario que quiere conocer el valor de su
  propiedad (early-funnel, no necesariamente decidido a vender)

### `/form/vender/`

- **Título HTML**: "Quiero vender mi propiedad | Cristian Stedtfeld"
- **Meta description**: no tiene · **H1**: no tiene
- **Objetivo**: captar lead de venta (el más largo: 5 pasos, 14 preguntas)
- **CTA principal**: "Continuar"/"Enviar"
- **Formulario presente**: sí — `lead_type: vender`
- **Tipo de usuario**: propietario con decisión (o cerca) de vender

### `/form/alquilar-mi-propiedad/`

- **Título HTML**: "Quiero alquilar mi propiedad | Cristian Stedtfeld"
- **Meta description**: no tiene · **H1**: no tiene
- **Objetivo**: captar lead de propietario que quiere poner su propiedad
  en alquiler
- **Formulario presente**: sí — `lead_type: alquilar_propiedad`, 3 pasos
- **Tipo de usuario**: propietario (no inquilino)

### `/form/comprar/`

- **Título HTML**: "Quiero comprar una propiedad | Cristian Stedtfeld"
- **Meta description**: no tiene · **H1**: no tiene
- **Objetivo**: captar lead de comprador
- **Formulario presente**: sí — `lead_type: comprar`, 3 pasos
- **Tipo de usuario**: comprador

### `/form/buscar-alquiler/`

- **Título HTML**: "Encontrá tu próximo alquiler | Cristian Stedtfeld"
- **Meta description**: no tiene · **H1**: no tiene
- **Objetivo**: captar lead de quien busca alquilar (inquilino)
- **Formulario presente**: sí — `lead_type: buscar_alquiler`, 3 pasos
- **Tipo de usuario**: inquilino

Las 5 páginas de formulario comparten: `<html lang="es-AR">`,
`<meta name="robots" content="noindex,follow">` (deliberado — no se
busca que Google las indexe como contenido orgánico, son landings de
conversión), mismo GTM (`GTM-5JDWTPXN`), mismo footer (WhatsApp, Email,
logo, dirección, Política de Privacidad, copyright).

## 3. Servicios / intenciones comerciales

| Intención | ¿Existe contenido? | Landing usable hoy |
|---|---|---|
| Propietario que quiere vender | Sí — formulario completo (el más largo) | `/form/vender/` |
| Persona que quiere comprar | Sí — formulario completo | `/form/comprar/` |
| Propietario que quiere alquilar | Sí — formulario completo | `/form/alquilar-mi-propiedad/` |
| Persona que busca alquiler | Sí — formulario completo | `/form/buscar-alquiler/` |
| Conocer el valor de la propiedad (tasación) | Sí — formulario completo | `/form/tasacion/` |
| Desarrollos inmobiliarios | Sí — 3 desarrollos reales, sección propia | Sólo dentro de la home, sin URL propia |
| Propiedades en venta | Sí — 4 propiedades reales, sincronizadas | Sólo dentro de la home, sin URL propia |
| Propiedades en alquiler (listado real) | **No** — no hay ningún listado de propiedades en alquiler, sólo el formulario para *buscar* alquiler | No existe |
| Inversiones | Parcial — los desarrollos mencionan financiación/rentabilidad en su descripción, pero no hay un enfoque de "inversión" propio ni landing dedicada | No existe |
| Locales comerciales | Parcial — es una opción más dentro del `<select>` "tipo de propiedad" en vender/tasación/alquilar/comprar, sin contenido propio | No existe |
| Oficinas | **No** — no aparece ni como opción en ningún formulario ni como categoría | No existe |
| Terrenos | **No** — no aparece en ningún lado (ni como opción de los `<select>`, que van Departamento/Casa/PH/Local comercial/Otro) | No existe |
| Casas | Sí — opción en los `<select>` + 1 de las 4 propiedades reales es una casa | Dentro de home/formularios, sin landing propia por tipo |
| Departamentos | Sí — opción en los `<select>` + 3 de las 4 propiedades reales son deptos | Dentro de home/formularios, sin landing propia por tipo |

No se detectó contenido para "oficinas" ni "terrenos" en ningún lado del
código — no se inventa: si se necesitan como categoría de campaña, hoy no
tienen ningún contenido propio que usar como base.

## 4. Formularios nativos

Los 5 comparten exactamente el mismo motor (duplicado a propósito en cada
archivo, sin JS compartido — ver `CLAUDE.md`), el mismo endpoint
(`enviar-lead.php`, método `POST`, JSON) y la misma regla de anti-spam.
Detalle de cada uno:

### `vender` — `/form/vender/`

- **Objetivo**: captar propietario vendedor
- **lead_type**: `vender`
- **Pasos**: 5
- **Campos** (nombre técnico → pregunta visible → tipo):
  - `tipo_propiedad` → "¿Qué tipo de propiedad querés vender?" → radio: Departamento / Casa / PH / Local comercial / Otro — **obligatorio**
  - `localidad` → "¿En qué localidad se encuentra?" → texto — **obligatorio**
  - `estado_general` → "¿Cuál es su estado general?" → radio: Excelente / Muy buen estado / Buen estado / Requiere mejoras / A refaccionar / No sabría decirte — **obligatorio**
  - `situacion_actual` → "La propiedad está actualmente..." → radio: Vacía / Habitada / Otra situación — **obligatorio**
  - `motivo` → "¿Por qué estás pensando en vender?" → texto libre — opcional
  - `plazo` → "¿Para cuándo te gustaría tener vendida la propiedad?" → radio (6 opciones) — opcional
  - `valor_en_mente` → "¿Tenés un valor de venta en mente?" → radio (4 opciones) — opcional
  - `como_llego_valor` → "¿Cómo llegaste a ese valor?" → radio (4 opciones) — opcional
  - `publicada_actualmente` → "¿La propiedad está actualmente publicada a la venta?" → radio: Sí / No / Estuvo publicada anteriormente — **obligatorio**
  - `documentacion` → "¿Contás con la documentación de la propiedad?" → checkbox, mínimo 1 (Escritura, Plano, Reglamento de copropiedad, Últimas expensas, ABL/ARBA, No estoy seguro/a, Prefiero revisarlo con vos) — **obligatorio (≥1)**
  - `como_continuar` → "¿Cómo te gustaría continuar?" → radio (5 opciones) — **obligatorio**
  - `nombre` / `telefono` / `email` → datos de contacto — **obligatorios los 3**
- **Endpoint**: `../../enviar-lead.php` · **Método**: `POST` (JSON)
- **Al enviar**: valida el paso actual en el cliente, y si es el último
  paso llama a `enviar()`, que deshabilita los botones, hace el `fetch` y
  espera la respuesta.
- **Éxito**: `response.status === 200` y `datos.ok === true` → esconde el
  `<form>`, muestra `#pantalla-gracias`, hace foco en el `<h3>` y recién
  ahí dispara `generate_lead`.
- **Si falla**: cualquier otro caso (status distinto, red caída, JSON
  inválido) cae en el `.catch()` → muestra el mensaje "No pudimos enviar
  tu consulta. Revisá tu conexión e intentá de nuevo.", reactiva los
  botones — no se pierde nada de lo que la persona completó.
- **Envío de email**: `enviar-lead.php` intenta `mail()` a
  `cstedtfeld@redsuma.com.ar` — best-effort, no condiciona la respuesta.
- **A qué sistema llegan los datos**: `leads/leads.jsonl` en el servidor
  (fuente de verdad) + intento de email.
- **Mensaje de pantalla de éxito**: "¡Gracias!" / "Recibí tu consulta.
  Voy a contactarme con vos a la brevedad."
- **Ruta de thank-you**: no existe como URL — es el mismo `/form/vender/`
  con el `<form>` oculto y `#pantalla-gracias` visible (ver sección 8).

### `tasacion` — `/form/tasacion/`

- **Objetivo**: captar quien quiere conocer el valor de su propiedad
- **lead_type**: `tasacion` · **Pasos**: 3
- **Campos**: `tipo_propiedad` (radio, igual set que arriba, **obligatorio**) · `ubicacion` (texto, **obligatorio**) · `descripcion_breve` (textarea, **obligatorio**) · `motivo_tasacion` (textarea, **obligatorio**) · `ya_tasada` (radio: No / Sí de una inmobiliaria/agente / Sí más de una / Hice mi propia estimación, **obligatorio**) · `nombre`/`telefono`/`email` (**obligatorios**)
- Resto (endpoint, método, éxito/error, email, `generate_lead`) — **idéntico** al de `vender`, sólo cambia `lead_type`/`form_name` a `tasacion`.

### `alquilar_propiedad` — `/form/alquilar-mi-propiedad/`

- **Objetivo**: captar propietario que quiere alquilar su propiedad
- **lead_type**: `alquilar_propiedad` · **Pasos**: 3
- **Campos**: `tipo_propiedad` (radio, **obligatorio**) · `ubicacion` (texto, **obligatorio**) · `descripcion_breve` (textarea, **obligatorio**) · `situacion_actual` (radio: Vacía y disponible / Habitada / Próximamente disponible / Otra, **obligatorio**) · `disponibilidad` (radio, 4 opciones, opcional) · `que_es_importante` (checkbox ≥1: Encontrar buen inquilino, Alquilarla lo antes posible, Conseguir un buen valor, Asesoramiento con documentación/contrato, Alguien que gestione todo, Otro — **obligatorio**) · `nombre`/`telefono`/`email` (**obligatorios**)
- Resto idéntico al patrón de arriba.

### `comprar` — `/form/comprar/`

- **Objetivo**: captar comprador
- **lead_type**: `comprar` · **Pasos**: 3
- **Campos**: `tipo_propiedad` (radio, **obligatorio**) · `zona` (texto, **obligatorio**) · `ambientes` (texto libre, opcional) · `presupuesto` (texto libre, opcional) · `forma_compra` (radio: Fondos propios / Necesito vender otra propiedad primero / Con crédito hipotecario / Combinación / Todavía lo estoy definiendo, **obligatorio**) · `plazo_compra` (radio, 4 opciones, opcional) · `caracteristicas_indispensables` (textarea, opcional) · `algo_mas` (textarea, opcional) · `nombre`/`telefono`/`email` (**obligatorios**)
- Resto idéntico al patrón de arriba.

### `buscar_alquiler` — `/form/buscar-alquiler/`

- **Objetivo**: captar inquilino
- **lead_type**: `buscar_alquiler` · **Pasos**: 3
- **Campos**: `tipo_propiedad` (**checkbox**, no radio — puede elegir más de un tipo — **obligatorio ≥1**) · `zona` (texto, **obligatorio**) · `presupuesto_mensual` (texto libre, opcional) · `que_necesita` (textarea, **obligatorio**) · `para_cuando` (texto, **obligatorio**) · `como_respalda` (checkbox ≥1: Garantía propietaria, Seguro de caución, Recibos de sueldo/ingresos, Monotributo/Autónomo, Otro, Todavía necesito asesoramiento — **obligatorio**) · `mascotas` (texto, **obligatorio**) · `nombre`/`telefono`/`email` (**obligatorios**)
- Resto idéntico al patrón de arriba.

### Anti-spam (los 5, común, en `enviar-lead.php`)

- Campo trampa (`sitio_web`), invisible para una persona.
- `_ts`: hora de carga de la página — se rechaza si el envío llega en
  menos de 2.5 segundos.
- `Referer` laxo: sólo rechaza si viene un dominio ajeno explícito.
- **Sin CAPTCHA.**

### Confirmado en vivo hoy

Se encontraron **2 registros reales** ya guardados en
`leads/leads.jsonl` en producción — uno de tipo `tasacion` y uno de tipo
`comprar` — confirmando que el flujo de guardado (`enviar-lead.php`
→ `leads.jsonl`) funciona de punta a punta en el servidor real. (No se
reproduce el contenido acá por ser datos de contacto — ver el hallazgo de
seguridad en "Riesgos".)

## 5. `generate_lead`

**¿Existe? SÍ** — implementado igual en los 5 formularios.

| Archivo | Línea | `lead_type` / `form_name` |
|---|---|---|
| `form/vender/index.html` | 428 | `vender` |
| `form/tasacion/index.html` | 328 | `tasacion` |
| `form/alquilar-mi-propiedad/index.html` | 350 | `alquilar_propiedad` |
| `form/comprar/index.html` | 350 | `comprar` |
| `form/buscar-alquiler/index.html` | 347 | `buscar_alquiler` |

**Cuándo se dispara** (idéntico en los 5): dentro de la función `enviar()`,
en el `.then()` que procesa la respuesta del `fetch('../../enviar-lead.php')`,
únicamente cuando `response.status === 200 && datos.ok === true`. Ejemplo
real (`form/vender/index.html:418-428`):

```js
.then(function (res) {
  if (res.status === 200 && res.datos && res.datos.ok) {
    form.hidden = true;
    document.querySelector('.form-progreso').hidden = true;
    textoProgreso.hidden = true;
    pantallaGracias.hidden = false;
    pantallaGracias.querySelector('h3').setAttribute('tabindex', '-1');
    pantallaGracias.querySelector('h3').focus();

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: 'generate_lead', lead_type: 'vender', form_name: 'vender' });
  } else {
    throw new Error('respuesta invalida');
  }
})
```

**Parámetros enviados**: únicamente `event`, `lead_type`, `form_name`.
**Confirmado por lectura directa del código: no incluye nombre, email,
teléfono, WhatsApp, DNI, dirección ni ningún otro dato personal** — cumple
exactamente la especificación pedida.

**No se dispara** al abrir el formulario, al tocar "Enviar" antes de la
respuesta, ni si el `fetch` falla (cae al `.catch()`, que sólo muestra un
mensaje de error y reactiva los botones, sin tocar `dataLayer`).

No se implementó nada nuevo — esto es sólo el reporte de lo que ya existe.

## 6. Tracking actual

### Handler genérico (sólo existe en `index.html`, línea 936-967)

```js
document.addEventListener('click', function (e) {
  var origen = e.target.closest('[data-evento]');
  if (origen) {
    window.dataLayer.push({
      event: 'click_boton',
      boton_id: origen.dataset.evento,
      boton_texto: (origen.dataset.titulo || origen.textContent).trim(),
      destino: origen.href || ''
    });
    ...
  }
  ...
});
```

**Los 5 `/form/*/` NO tienen este script** — cada uno sólo trae el motor
del formulario y el manejo del modal de privacidad. Por eso cualquier
elemento con `data-evento` que se agregara ahí no haría nada por sí solo.

### Tabla de elementos con tracking

| Elemento / botón | Ruta | `event` | `boton_id` | `boton_texto` | Destino | Función que lo dispara |
|---|---|---|---|---|---|---|
| "📊 Quiero saber cuánto vale mi propiedad" | `/` | `click_boton` | `tasacion` | texto del botón | `form/tasacion/` | handler genérico |
| "🏠 Quiero vender mi propiedad" | `/` | `click_boton` | `vender` | texto del botón | `form/vender/` | handler genérico |
| "🔑 Quiero alquilar mi propiedad" | `/` | `click_boton` | `alquilar-mi-propiedad` | texto del botón | `form/alquilar-mi-propiedad/` | handler genérico |
| "🔎 Quiero comprar una propiedad" | `/` | `click_boton` | `comprar` | texto del botón | `form/comprar/` | handler genérico |
| "📍 Encontrá tu próximo alquiler" | `/` | `click_boton` | `buscar-alquiler` | texto del botón | `form/buscar-alquiler/` | handler genérico |
| "¡Hablemos por WhatsApp!" | `/` | `click_boton` | `whatsapp` | texto del botón | `wa.me/5491166951945?text=...` | handler genérico |
| Email | `/` | `click_boton` | `email` | "Email" (`data-titulo`) | `mailto:cstedtfeld@redsuma.com.ar` | handler genérico |
| "Mi método" | `/` | `click_boton` | `metodo` | "Mi método" (`data-titulo`) | (no navega — sólo despliega) | handler genérico |
| Botón de matrícula | `/` | `click_boton` | `matricula` | texto del botón | (abre modal `#aviso-legal`) | handler genérico |
| Ícono WhatsApp (pie) | `/` | `click_boton` | `whatsapp-icono` | *(vacío — sin `data-titulo` ni texto)* | `wa.me/5491166951945` | handler genérico |
| Ícono Email (pie) | `/` | `click_boton` | `email-icono` | *(vacío)* | `mailto:...` | handler genérico |
| Link "Política de Privacidad" | `/` | `click_boton` | `privacidad` | texto del link | `#privacy-policy` | handler genérico |
| Tarjeta de "Propiedades en venta" | `/` | `click_boton` | `ver-propiedades` | título de la propiedad | `''` (vacío, a propósito) | `abrirDetalle()` dentro de `crearCarrusel()`, push manual |
| Tarjeta de "Desarrollos destacados" | `/` | `click_boton` | `ver-desarrollos` | título del desarrollo | `''` | `abrirDetalle()`, push manual |
| "Consultar por WhatsApp" (detalle propiedad) | `/` | `click_boton` | `consulta-propiedad` | texto del botón | `wa.me/...?text=...` (con título/ubicación) | handler genérico (el link ya tiene `data-evento`) |
| "Consultar por WhatsApp" (detalle desarrollo) | `/` | `click_boton` | `consulta-desarrollo` | texto del botón | `wa.me/...?text=...` | handler genérico |
| Ícono WhatsApp (pie) | los 5 `/form/*/` | — | *(sin `data-evento`)* | — | `wa.me/5491166951945` | **ninguna — no trackeado** |
| Ícono Email (pie) | los 5 `/form/*/` | — | *(sin `data-evento`)* | — | `mailto:...` | **ninguna — no trackeado** |
| "Continuar"/"Enviar"/"Atrás" | los 5 `/form/*/` | — | — | — | — | no llevan `data-evento`; el envío exitoso se trackea aparte con `generate_lead` (sección 5), no con `click_boton` |
| **`generate_lead`** | los 5 `/form/*/` | `generate_lead` | — | — | — | `enviar()`, sólo en éxito confirmado — ver sección 5 |

Los `boton_id` que menciona el pedido (`whatsapp`, `whatsapp-icono`,
`consulta-desarrollo`, `consulta-propiedad`, `ver-propiedades`,
`ver-desarrollos`, `metodo`, `tasacion`, `vender`,
`alquilar-mi-propiedad`, `comprar`, `buscar-alquiler`) **están todos
presentes y confirmados** en el código, tal cual los documenta la sección
de Analytics de `CLAUDE.md` (escrita por Cristian). No se tocó ninguno.

## 7. Atribución Google Ads

Búsqueda de `gclid`, `gbraid`, `wbraid`, `utm_source`, `utm_medium`,
`utm_campaign`, `utm_term`, `utm_content`, `localStorage`,
`sessionStorage`, `document.cookie` en **todo** el proyecto (los 6 HTML,
`estilo.css`, los 2 PHP):

- **No se lee ningún parámetro de la URL** (`gclid`/`gbraid`/`wbraid` ni
  ningún `utm_*`) en ningún archivo — no hay una sola línea de JS que
  toque `location.search` o `URLSearchParams`.
- **No se guarda nada** — cero uso de `localStorage`, `sessionStorage` ni
  `document.cookie` en todo el sitio (verificado por búsqueda de texto).
- **No se envía nada** de esto con los formularios — el payload de cada
  `POST` a `enviar-lead.php` sólo lleva los campos propios de cada
  formulario (ver sección 4), nunca un `gclid` ni un UTM.
- La única mención real a `GCLID` en todo el proyecto está en
  `CLAUDE.md` (sección de Analytics, escrita por Cristian): dice que el
  **auto-tagging de Google Ads está activado** y que por eso "Google Ads
  puede utilizar GCLID y atribuir correctamente" — pero eso es
  atribución del lado de Google (vía el parámetro que Ads agrega solo a
  la URL y que GA4 lee internamente), **no** algo que el código de este
  sitio procese o guarde por su cuenta.

**No se implementó nada** — esto es sólo el reporte de que hoy no existe.
Si más adelante se quiere Enhanced Conversions (mencionado como "etapa
futura" en `CLAUDE.md`) o pasar `gclid` en el payload del lead para
atribución server-side, hoy no hay ninguna base construida para eso.

## 8. Thank-you / success state

**Idéntico en los 5 formularios** — no hay diferencias entre ellos en
este punto.

- **No cambia de página.** Sigue siendo la misma URL
  (`/form/<nombre>/`) — no hay navegación, ni `history.pushState`.
- **Cambia de componente**, dentro del mismo documento: se oculta el
  `<form>` completo (`form.hidden = true`) junto con la barra de progreso
  y su texto, y se muestra un `<div id="pantalla-gracias">` que estaba
  oculto (`hidden` → visible).
- **No es un modal** (no es un `<dialog>`) — es contenido normal del
  flujo de la página.
- **Texto de agradecimiento**: "¡Gracias!" (título) / "Recibí tu
  consulta. Voy a contactarme con vos a la brevedad." (idéntico en los 5).
- **URL resultante**: la misma de siempre (`/form/<nombre>/`), sin hash
  ni query string agregado.
- **¿Se puede recargar por accidente?** No hay riesgo de que un refresh
  vuelva a mostrar "Gracias" sola: al no haber ningún estado guardado
  (ni en la URL, ni en `localStorage`/`sessionStorage`, confirmado en la
  sección 7), un F5 recarga la página desde cero y muestra el formulario
  vacío otra vez — nunca la pantalla de gracias. Tampoco el botón
  "atrás" del navegador puede volver a mostrarla (no se navegó a
  ningún lado para llegar ahí).
- **¿Se podría disparar `generate_lead` dos veces?** No, por dos motivos
  combinados: (1) el botón "Enviar" se deshabilita (`disabled = true`)
  apenas se llama a `enviar()`, antes de que la petición siquiera salga,
  así que no se puede volver a hacer clic mientras se espera respuesta;
  (2) como no hay ningún estado persistido, un refresh no puede
  "reejecutar" el éxito anterior — cada carga de la página arranca de
  cero, sin memoria del envío previo.

## 9. WhatsApp

| Contexto | Ruta | Texto visible | `boton_id` | URL `wa.me` |
|---|---|---|---|---|
| WhatsApp general (botón principal) | `/` | "¡Hablemos por WhatsApp!" | `whatsapp` | `https://wa.me/5491166951945?text=Hola%20Cris!%20quer%C3%ADa%20hacerte%20una%20consulta...` (mensaje precargado) |
| WhatsApp flotante (ícono del pie) | `/` | *(sin texto, sólo ícono)* | `whatsapp-icono` | `https://wa.me/5491166951945` (sin texto precargado) |
| Consulta por una propiedad | `/` (detalle, dentro del `<dialog>`) | "Consultar por WhatsApp" | `consulta-propiedad` | `https://wa.me/5491166951945?text=Hola Cris! Te consulto por "{título}" ({ubicación})` — armado dinámicamente por `mensajeWhatsapp()` |
| Consulta por un desarrollo | `/` (detalle, dentro del `<dialog>`) | "Consultar por WhatsApp" | `consulta-desarrollo` | `https://wa.me/5491166951945?text=Hola Cris! Te consulto por el desarrollo "{título}" ({ubicación})` |
| WhatsApp del pie (sin trackear) | los 5 `/form/*/` | *(sin texto, sólo ícono)* | *(ninguno)* | `https://wa.me/5491166951945` |

El número (`5491166951945`) está repetido a mano en los 7 lugares de
arriba — es una decisión ya tomada y documentada en `CLAUDE.md`: Cristian
lo sabe y prefiere dejarlo así.

## 10. Propiedades y desarrollos

### Cómo se cargan

- **"Propiedades en venta"**: `index.html` pide `propiedades.php` por
  `fetch` al cargar la home. Ese PHP sirve un caché de 8 horas
  (`cache/propiedades.json`) o, si venció, vuelve a leer 4 páginas
  públicas de `propiedades.redsuma.com.ar` (por su JSON-LD, no HTML
  scraping) y arma el JSON de nuevo. **Confirmado en vivo hoy: responde
  `200` con las 4 propiedades reales** (Casa en Villa Devoto USD 430.000;
  3 amb. Villa Devoto USD 418.000; dos deptos 4 amb. hermanos del mismo
  edificio, USD 229.000 y USD 239.000).
- **"Desarrollos destacados"**: array fijo (`DESARROLLOS`) escrito a mano
  dentro de `index.html`, sin sincronización — 3 desarrollos reales
  (Midoki, AC · Av. Congreso, OZB · Olazábal), con datos que Cristian
  pasó y Claude completó leyendo las páginas públicas de
  `sumadesarrollos.com.ar` (`CLAUDE.md` recomienda que Cristian los
  revise, sobre todo precios/financiación).

### Dónde viven

- **Rutas**: ninguna — todo vive en secciones de la home (`/`), sin URL
  propia por ítem.
- **Sliders**: `#propiedades-pista` y `#desarrollos-pista`, mismo motor
  (`crearCarrusel()`), carrusel infinito con loop, drag con mouse, swipe
  nativo en mobile.
- **Modales**: `#propiedad-detalle` y `#desarrollo-detalle` (`<dialog>`),
  con foto ampliada (y galería de hasta 5 fotos + swipe, sólo en
  propiedades), título, ubicación, precio, características (sólo
  propiedades: ambientes/dormitorios/baños/m²) y descripción.
- **Páginas individuales**: no existen.
- **CTA utilizado**: "Consultar por WhatsApp" dentro de cada detalle (ver
  sección 9) — siempre al número de Cristian, nunca al agente/publicación
  original (a propósito, ver `CLAUDE.md`: son propiedades de otros
  agentes de Red Suma que Cristian tiene permiso de promocionar).
- **Datos disponibles** por propiedad: título, ubicación, precio, hasta 5
  fotos, ambientes/dormitorios/baños/m², descripción (escrita a mano por
  Cristian, no sincronizada). Por desarrollo: título, ubicación,
  estado/precio, 1 foto, descripción.
- **Tracking relacionado**: ver fila `ver-propiedades`/`ver-desarrollos`
  en la sección 6.

### ¿Sirven como landing de campaña?

**No, ninguna de las dos secciones puede ser landing de una campaña
específica hoy** — al no tener URL propia, lo máximo que se puede hacer
es linkear a la home entera (`/`), que además requiere scroll para
llegar a la sección. Esto aplica igual a compradores, desarrollos,
inversión y locales comerciales (estos dos últimos, además, no tienen
ningún contenido propio — ver sección 3).

## 11. Zonas geográficas mencionadas

| Zona/barrio | Dónde aparece |
|---|---|
| CABA, Zona Norte, Pilar | Meta description de la home (`<meta name="description">`) |
| Villa Devoto, CABA | Ubicación real de las 4 "Propiedades en venta" (vía `propiedades.php`) |
| Villa del Parque, CABA | Ubicación del desarrollo "Midoki" |
| Villa Urquiza, CABA | Ubicación de "AC · Av. Congreso" y "OZB · Olazábal" |
| Vicente López | Dirección de Red Suma en el pie de las 6 páginas ("General Justo José de Urquiza 405, Vicente López") |
| Belgrano, Núñez, Palermo | Sólo como **placeholder** de ejemplo dentro de los campos de texto libre "¿En qué zona/s estás buscando?" (formularios `comprar` y `buscar-alquiler`) — no son datos reales de ninguna propiedad, son sólo sugerencias de formato para quien completa |
| Ej: Belgrano, CABA / Palermo, CABA | Placeholders de ejemplo en `localidad`/`ubicación` (formularios `vender`, `tasacion`, `alquilar-mi-propiedad`) — mismo caso, son ejemplos de formato, no datos reales |

No se infiere ninguna zona de trabajo — esto es exactamente lo que
aparece en el código/texto, nada más.

## 12. Copy útil para Google Ads

Extraído textual, sin agregar nada:

- **Propuesta de valor / bio**: "Servicios inmobiliarios adaptados a tus
  necesidades" (h1/bio de la home); "Servicios inmobiliarios adaptados a
  tus necesidades. Tasación, venta, alquiler y compra de propiedades en
  CABA, Zona Norte y Pilar." (meta description).
- **Metodología ("Mi método")**:
  - "Una propiedad no se publica. Se lanza al mercado."
  - "Vender una propiedad se parece bastante a lanzar cualquier negocio o
    producto."
  - Lista de lo que se define antes de publicar: qué precio defender,
    cómo mostrarla, qué destacar, a quién llegar, dónde mostrarla, y qué
    hacer si la respuesta no es la esperada.
  - Destacado: "Subirla y esperar que aparezca alguien no es un plan."
  - "No quiero trabajar con vos, cobrar una comisión y que no nos
    volvamos a hablar."
  - Destacado/cita: "Mi negocio está en que me recomiendes." / "Una
    operación termina. Una buena relación puede durar muchos años."
- **Mensaje de confianza / legal**: "VL REALTOR — CUCICBA 7615 · CMCPSI
  6609", "Corredor responsable: Diego Enrique Mastrangelo", actividad
  dentro de Red Suma (ver sección 13 para el texto completo).
- **CTAs reales usados hoy**: "¡Hablemos por WhatsApp!", "Quiero saber
  cuánto vale mi propiedad", "Quiero vender mi propiedad", "Quiero
  alquilar mi propiedad", "Quiero comprar una propiedad", "Encontrá tu
  próximo alquiler".
- **Servicios** (los 5 formularios): tasación, venta, alquiler
  (propietario), compra, búsqueda de alquiler (inquilino).

**No hay** testimonios, cifras de "propiedades vendidas", años de
antigüedad/experiencia declarados, ni ningún resultado numérico en
ningún lugar del sitio — no se inventa nada de eso acá tampoco.

## 13. Información legal visible

- **Nombre de la inmobiliaria**: Red Suma (agente: Cristian Stedtfeld).
- **Corredor responsable / matrícula**: "VL REALTOR S.R.L." — "Corredor
  responsable: Diego Enrique Mastrangelo — CUCICBA 7615 · CMCPSI 6609."
- **Disclaimer legal completo** (modal `#aviso-legal`, botón de matrícula
  en la home, texto provisto por Cristian palabra por palabra — no
  parafraseable sin su autorización): "Mi actividad se limita a tareas
  comerciales, de promoción, coordinación y asistencia dentro de Red
  Suma. No ejerzo por cuenta propia actos de corretaje ni actos
  profesionales reservados. Los actos de corretaje e intermediación
  inmobiliaria son realizados exclusivamente por el corredor público
  matriculado responsable, conforme a la Ley 20.266 y modificatorias,
  Ley 2.340 de CABA, Ley 10.973 de la Provincia de Buenos Aires y demás
  normativa aplicable."
- **Política de Privacidad**: modal (`#privacy-policy`, no una página
  aparte), repetido igual en las 6 páginas, con link en el pie de todas.
  Cubre: quién trata los datos, qué se recopila, para qué, cómo se
  guardan, y derechos conforme a la Ley 25.326. Es un **borrador armado
  por Claude a pedido de Cristian** — `CLAUDE.md` deja anotado que
  conviene que alguien con conocimiento legal lo revise.
- **Términos**: no existe una página/sección de "Términos y condiciones"
  separada.
- **Consentimiento en los formularios**: cada uno, en el último paso,
  incluye "Al enviar este formulario aceptás que usemos estos datos para
  responder tu consulta." con link a la Política de Privacidad.
- **Rutas**: el disclaimer y la política son modales sobre la home
  (`/#aviso-legal`, `/#privacy-policy`) y se repiten dentro de cada
  `/form/*/` (sin hash propio ahí, se abren con JS al hacer clic).

## 14. Assets publicitarios

### Logos

| Archivo | Formato | Dimensiones reales | Aspect ratio | Fondo transparente |
|---|---|---|---|---|
| `logo-redsuma.png` | PNG | 1954 × 408 px | ~4.8:1 (isotipo horizontal) | **Sí** (confirmado con alfa real en las 4 esquinas) |
| `logo-redsuma.webp` | WEBP | 2000 × 1414 px | ~1.4:1 | **Sí** — es el archivo original sin recortar, con más margen alrededor; no lo usa la página, queda de respaldo |
| `icono-legal.png` | PNG | 539 × 539 px | 1:1 | **Sí** (blanco puro sobre transparente) |
| `icono-legal-original.png` | PNG | 512 × 512 px | 1:1 | **Sí** — versión sin recortar, de respaldo, no la usa la página |

### Imágenes

| Archivo | Uso | Resolución | Orientación | Peso |
|---|---|---|---|---|
| `foto.webp` | Foto de portada de Cristian (home) | 1600 × 2000 px | Vertical | 167 KB |
| `og.jpg` | Miniatura al compartir el link (WhatsApp/redes) | 1200 × 630 px | Horizontal | 81 KB |
| `desarrollo-1.jpg` | Portada real del desarrollo "Midoki" | 481 × 1308 px | Vertical (recorte 4:3 lo ancla abajo, ver `CLAUDE.md`) | 141 KB |
| `desarrollo-2.jpg` | Portada real de "AC · Av. Congreso" | 460 × 649 px | Vertical | 62 KB |
| `desarrollo-3.jpg` | Portada real de "OZB · Olazábal" | 699 × 2000 px | Vertical (muy alargada) | 232 KB |
| `propiedad-1.webp` … `propiedad-5.webp` | **Fotos de stock, huérfanas** — ya no las usa ninguna página (ver "Riesgos"/Assets) | 1448 × 1086 px (las 5, idénticas) | Horizontal 4:3 | 40-103 KB c/u |

**No hay fotos propias de las 4 "Propiedades en venta" actuales** — sus
fotos vienen del CDN externo de Red Suma (`imagedelivery.net`), no son
archivos de este proyecto, y no se puede garantizar su disponibilidad ni
licencia de uso fuera del sitio (por ejemplo, para subir como imagen de
un anuncio de Display/Performance Max).

### Videos

No se encontró ningún archivo de video en el proyecto.

## 15. Performance / landing pages — problemas relevantes para tráfico pago

- **Página sin H1**: los 5 formularios (`/form/*/`) — ver hallazgo #2 de
  "Riesgos".
- **Página sin title**: no aplica — las 6 páginas tienen `<title>`
  correcto y distinto entre sí.
- **Sin meta description**: los 5 formularios — ver hallazgo #3.
- **Imágenes grandes para su uso real**: `logo-redsuma.png` (123 KB,
  mostrado a 14px de alto) y `desarrollo-3.jpg` (232 KB, foto vertical de
  699×2000 mostrada en una tarjeta 4:3) — ver hallazgo #5.
- **CTA difícil de encontrar**: no se encontró ningún caso — los 5
  botones principales están arriba de todo, visibles sin scroll en
  mobile.
- **Formulario roto**: no se encontró ninguno — los 5 responden `200` en
  producción y se confirmaron 2 leads de prueba reales ya guardados con
  éxito.
- **Errores mobile**: no se re-testearon en esta auditoría (ya se probó
  extensivamente en sesiones anteriores, documentado en `CLAUDE.md`); no
  se encontró nada nuevo que lo contradiga.
- **Rutas inexistentes**: ninguna — las 6 rutas documentadas responden
  `200`, y no se encontró ningún link roto hacia una ruta que ya no
  existe (por ejemplo, restos de la vieja carpeta `formularios/` o de
  `privacidad/index.html`, ambas eliminadas hace tiempo).
- **Redirects**: `http://` → `https://` **funciona** (confirmado en
  vivo hoy — resuelve un pendiente que `CLAUDE.md` marcaba como "no
  confirmado"); `https://www.csrealestate.com.ar/` converge también a la
  versión sin `www` (confirmado en vivo). Ningún redirect innecesario
  encontrado.
- **Contenido duplicado**: no se encontró un caso real — `www`/`http`
  convergen a una única versión canónica.
- **`robots.txt`/`sitemap.xml`**: no existen — dato de referencia, no es
  un bloqueante para tráfico pago.
- 🔴 Ver también el hallazgo de seguridad de `leads/leads.jsonl`
  (hallazgo #1) — no es un problema de "landing" en sí, pero si se va a
  invertir en tráfico pago hacia estos formularios, es el primer punto a
  resolver: cada lead nuevo generado por los anuncios va a quedar
  expuesto de la misma forma hasta que se corrija.

---

*Fin de la auditoría. No se modificó ningún archivo del proyecto — sólo
se creó este documento.*
