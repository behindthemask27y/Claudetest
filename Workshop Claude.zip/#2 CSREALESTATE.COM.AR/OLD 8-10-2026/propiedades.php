<?php
/**
 * Sincroniza "Propiedades en venta" con propiedades.redsuma.com.ar.
 *
 * Cada publicación de esa web trae datos estructurados schema.org
 * (<script type="application/ld+json">, @type incluye "Product") con
 * precio, dirección, ambientes, fotos, etc. — se leen de ahí, nunca por
 * scraping de HTML/CSS, tal como se pidió.
 *
 * A propósito NO se expone acá `sourceUrl` ni el `broker` de cada
 * publicación: Cristian tiene permiso de los agentes dueños de estas
 * publicaciones para promocionarlas y cobrar su propia comisión si
 * consigue comprador — mostrar el link original o el contacto del otro
 * agente le haría perder esa consulta. El botón de WhatsApp del detalle
 * (armado aparte, en index.html) sigue yendo siempre al numero de Cristian.
 *
 * Cache con TTL: evita golpear las 4 páginas externas en cada visita.
 * Si el fetch en vivo falla (web caída, cambio de estructura, lo que sea),
 * se sirve el último cache válido en vez de romper el slider — sólo se
 * devuelve vacío si nunca hubo un cache exitoso.
 *
 * Título y descripción NO se sincronizan — Cristian los escribe él mismo
 * (ver $TITULOS_Y_DESCRIPCIONES más abajo): son texto de marketing, no
 * datos objetivos, y así evita el problema de errores de tipeo/acentos
 * sueltos que tenía el texto libre de origen ("PAtio/JArdin", "lena" por
 * "leña"). Lo que sí se sincroniza cada $ttlSegundos: fotos, ubicación,
 * precio y características (ambientes/dormitorios/baños/m²) — todo
 * campo estructurado, sin ese riesgo.
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

// ---------- config: id estable (sku de origen) + URL de cada publicación ----------
$FUENTES = [
  ['id' => 'PR-019060', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-casa-lote-propio-3-amb-con-patiojardin'],
  ['id' => 'PR-020966', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-dpto-3-ambientes-villa-devoto-a-estrenar-cochera-balcon-y-parrilla-calidad-rs020966'],
  ['id' => 'PR-020944', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-departamento-4-ambientes-con-balcon-a-estrenar-villa-devoto-rs020944'],
  ['id' => 'PR-020934', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-departamento-4-ambientes-con-balcon-a-estrenar-villa-devoto-rs020934'],
  ['id' => 'PR-019885', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/ph-dos-ambientes-con-terraza-y-parilla'],
];

// título y descripción de cada propiedad, escritos por Cristian a mano.
$TITULOS_Y_DESCRIPCIONES = [
  'PR-019060' => [
    'titulo' => 'Casa en Lote Propio | Jardín, Cochera y Remodelada a Nuevo',
    'descripcion' => 'Una casa pensada para disfrutarla de verdad: ambientes cómodos, buena '
      . 'conexión entre interior y exterior, y ese espacio propio que hace la diferencia para '
      . 'vivir con más privacidad y tranquilidad.',
  ],
  'PR-020966' => [
    'titulo' => '3 Ambientes a Estrenar | Cochera, Balcón y Parrilla',
    'descripcion' => 'Diseño, privacidad y calidad en una propiedad donde cada detalle suma. Un '
      . 'hogar pensado para quienes valoran el confort y buscan un departamento que se diferencie '
      . 'de lo convencional.',
  ],
  'PR-020944' => [
    'titulo' => 'Departamento 4 ambientes con balcón a estrenar 1er Piso al Frente',
    'descripcion' => 'Un departamento a estrenar pensado para quienes buscan amplitud, luz y '
      . 'tranquilidad. Una propuesta moderna, dentro de un edificio de pocas unidades, que '
      . 'combina comodidad y privacidad en un entorno residencial de Villa Devoto.',
  ],
  'PR-020934' => [
    'titulo' => 'Departamento 4 ambientes con balcón a estrenar 2do Piso al Frente',
    'descripcion' => 'Un departamento a estrenar pensado para quienes buscan amplitud, luz y '
      . 'tranquilidad. Una propuesta moderna, dentro de un edificio de pocas unidades, que '
      . 'combina comodidad y privacidad en un entorno residencial de Villa Devoto.',
  ],
  'PR-019885' => [
    'titulo' => 'PH 2 ambientes | Terraza y Parilla',
    'descripcion' => 'Luminoso departamento tipo PH de 2 ambientes, ¡sin expensas! Excelente '
      . 'ubicación, a solo 3 cuadras del Parque Saavedra, 2 cuadras de Plaza Vicuña y 4 cuadras '
      . 'de la Fundación Hospitalaria. Se destaca por su cercanía a Av. Cabildo y por contar '
      . 'con múltiples líneas de transporte en la zona.',
  ],
];

$cacheArchivo = __DIR__ . '/cache/propiedades.json';
$ttlSegundos = 8 * 3600;

if (is_file($cacheArchivo) && (time() - filemtime($cacheArchivo)) < $ttlSegundos) {
  readfile($cacheArchivo);
  exit;
}

$resultado = [];
foreach ($FUENTES as $fuente) {
  $manual = $TITULOS_Y_DESCRIPCIONES[$fuente['id']] ?? ['titulo' => '', 'descripcion' => ''];
  $propiedad = obtenerPropiedad($fuente['sourceUrl'], $fuente['id'], $manual['titulo'], $manual['descripcion']);
  if ($propiedad !== null) $resultado[] = $propiedad;
}

/* ---------- Alquiler cargado a mano, sin sourceUrl todavía (2026-09-28) ----------
 * Cristian pasó estos datos directo por chat, sin link a una publicación
 * externa ("después lo vinculás a una web/publicación externa como las
 * demás tarjetas") — sin ese link no hay de dónde sincronizar, así que
 * esta entrada se agrega acá a mano, fuera del loop de $FUENTES de
 * arriba (no pasa por obtenerPropiedad(), no se refresca sola nunca).
 * CUANDO CRISTIAN PASE EL LINK REAL de esta publicación: sacar este
 * bloque entero y sumar su {id, sourceUrl} a $FUENTES + su
 * título/descripción a $TITULOS_Y_DESCRIPCIONES, como las demás.
 *
 * Es la primera propiedad en ALQUILER de este slider (las demás son
 * ventas en USD) — por eso el precio incluye "/mes" a mano. Las
 * expensas van en su propio campo, `expensas` — a pedido de Cristian,
 * index.html las muestra en su propia línea (chica, gris, sin negrita)
 * debajo del precio, tanto en la tarjeta como en el detalle; ver
 * "propiedad__expensas"/"propiedad-detalle__expensas" ahí.
 *
 * "especificaciones" es un campo nuevo, opcional: un local comercial no
 * tiene "ambientes" ni "dormitorios" en el sentido residencial de esos
 * campos (achica pisos/depósito sí, así que forzarlo en ese molde daría
 * una etiqueta incorrecta) — cuando está presente, pisa el cálculo
 * automático de specs en abrirDetalle() (ver index.html). No afecta a
 * ninguna propiedad sincronizada, que nunca manda este campo.
 */
$resultado[] = [
  'id' => 'MANUAL-local-pueyrredon',
  'titulo' => 'Local comercial en Esquina | 2 Plantas',
  'descripcion' => 'El Reglamento permite colocar cartel/marquesina en todo el frente del local. No se permite verdulería, pescadería o materiales inflamables.',
  'ubicacion' => 'Villa Pueyrredón, CABA',
  'precio' => '$ 2.630.000/mes',
  'expensas' => '$ 180.000 expensas',
  'foto' => 'local-pueyrredon.jpg',
  'fotos' => ['local-pueyrredon.jpg'],
  'especificaciones' => '2 plantas · 1 depósito subsuelo chico · 1 baño · 135 m²',
  'banos' => 1,
  'superficieM2' => 135,
  'disponible' => true,
];

if (count($resultado) > 0) {
  if (!is_dir(__DIR__ . '/cache')) mkdir(__DIR__ . '/cache', 0755, true);
  $json = json_encode($resultado, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  file_put_contents($cacheArchivo, $json);
  echo $json;
} elseif (is_file($cacheArchivo)) {
  // el fetch en vivo falló pero hay un cache viejo: mejor mostrar eso
  // (aunque esté desactualizado) que romper el slider.
  readfile($cacheArchivo);
} else {
  echo '[]';
}

/** Lee una publicación y la normaliza. null si no se pudo leer/parsear.
 *  Extrae del origen sólo campos estructurados (precio, fotos, ambientes,
 *  disponibilidad); título y descripción los pasa el llamador (son
 *  manuales, ver $TITULOS_Y_DESCRIPCIONES más arriba). */
function obtenerPropiedad(string $url, string $id, string $titulo, string $descripcion): ?array {
  $contexto = stream_context_create(['http' => [
    'timeout' => 8,
    'header' => "User-Agent: Mozilla/5.0 (compatible; csrealestate-sync/1.0)\r\n",
  ]]);
  $html = @file_get_contents($url, false, $contexto);
  if ($html === false) return null;

  if (!preg_match_all('#<script type="application/ld\+json">(.*?)</script>#s', $html, $bloques)) {
    return null;
  }

  $datos = null;
  foreach ($bloques[1] as $bloque) {
    $candidato = json_decode($bloque, true);
    if (!is_array($candidato)) continue;
    $tipo = $candidato['@type'] ?? null;
    if (is_array($tipo) && in_array('Product', $tipo, true)) { $datos = $candidato; break; }
  }
  if ($datos === null) return null;

  $precio = $datos['offers']['price'] ?? null;
  $moneda = $datos['offers']['priceCurrency'] ?? 'USD';
  $disponible = ($datos['offers']['availability'] ?? '') === 'https://schema.org/InStock';

  $localidad = (string)($datos['address']['addressLocality'] ?? '');
  $region = (string)($datos['address']['addressRegion'] ?? '');
  // La fuente no siempre usa la misma palabra para "Ciudad Autónoma de
  // Buenos Aires" al final de addressLocality — a veces "Capital Federal",
  // a veces "Buenos Aires" a secas (visto en la práctica: "Saavedra,
  // Buenos Aires") — y las dos son redundantes con addressRegion (que ya
  // llega como "CABA"). Se recortan esos alias conocidos, más el propio
  // valor de $region por si ya viniera repetido tal cual, antes de agregar
  // la región real — así cualquier propiedad nueva se ajusta sola en vez
  // de necesitar un arreglo puntual cada vez que la fuente use una palabra
  // distinta (pasó con "PR-019885": daba "Saavedra, Buenos Aires, CABA" en
  // vez de "Saavedra, CABA").
  foreach (['Capital Federal', 'Buenos Aires', $region] as $alias) {
    if ($alias === '') continue;
    $localidad = preg_replace('/,?\s*' . preg_quote($alias, '/') . '\s*$/i', '', $localidad) ?? $localidad;
  }
  if ($localidad !== '' && $region !== '') $localidad .= ', ' . $region;

  // hasta 5 fotos (la fuente puede traer 10+) — alcanza para la tarjeta
  // (usa la primera) y una galería chica en el detalle sin sobrecargar
  $fotos = array_values(array_filter((array)($datos['image'] ?? []), 'is_string'));
  $fotos = array_slice($fotos, 0, 5);

  $superficieM2 = $datos['floorSize']['value'] ?? null;

  return [
    'id' => $id,
    'titulo' => $titulo,
    'descripcion' => $descripcion,
    'ubicacion' => $localidad,
    'precio' => $precio !== null ? $moneda . ' ' . number_format((float)$precio, 0, ',', '.') : '',
    'foto' => $fotos[0] ?? '',
    'fotos' => $fotos,
    'ambientes' => $datos['numberOfRooms'] ?? null,
    'dormitorios' => $datos['numberOfBedrooms'] ?? null,
    'banos' => $datos['numberOfBathroomsTotal'] ?? null,
    'superficieM2' => $superficieM2,
    'disponible' => $disponible,
  ];
}
