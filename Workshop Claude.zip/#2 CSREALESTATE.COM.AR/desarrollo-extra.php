<?php
/**
 * Lo que sólo trae la FICHA de cada obra de sumadesarrollos.com.ar y que la lista
 * (desarrollos.php) no tiene: fotos, planos, texto "El edificio", memoria
 * descriptiva, avance de obra, créditos. Lo usa la ficha de nuestra web
 * (desarrollos/ficha/?o=<obra>). Las unidades, precios y el simulador salen de
 * desarrollos.php (planillas); acá va sólo lo que hay que leer de la página.
 *
 * Es "mejor esfuerzo" a propósito: sus 20 fichas son páginas distintas y pueden
 * cambiar sin avisar. Reglas (pedidas por Cristian: "que funcione solito"):
 *  - Nunca se inventa nada. Si un bloque no se puede leer, ese bloque no viene
 *    (la ficha lo omite) y el resto sigue.
 *  - No se ejecuta nada de lo que se baja: se lee texto y direcciones de imágenes
 *    con un parser de HTML; las fotos y planos se muestran desde su servidor.
 *  - Copia de 8 h por obra en cache/ficha-<obra>.json. Vencida, se responde YA con
 *    la copia y se refresca por detrás. Si el refresco falla se sigue mostrando la
 *    última copia buena (a diferencia de los precios, un plano o un texto viejo no
 *    hace daño) y se reintenta cada 15 min. Si lo leído viene vacío (cambiaron la
 *    estructura) no se pisa la copia buena.
 *  - Mail a Cristian (tope 1 por día en total) si una ficha falla seguido o si deja
 *    de leerse por completo.
 *  - Sólo responde por obras que están en la lista sincronizada (desarrollos.json),
 *    así no sirve para pedirle cualquier dirección a otro sitio.
 */

declare(strict_types=1);

require_once __DIR__ . '/desarrollos-lib.php'; // SUMA_BASE, http_get, leer_json, escribir_json, avisar

const FICHA_TTL = 8 * 3600;
const FICHA_ESPERA_REINTENTO = 900;
const FICHA_TOPE_AVISO = 86400;

/* ==================== lectura de la ficha ==================== */

function ficha_texto(?DOMNode $n): string {
  return $n ? trim((string)preg_replace('/\s+/u', ' ', $n->textContent)) : '';
}

/** Resultado de un XPath como lista (vacía si la consulta falla). */
function ficha_xp(DOMXPath $x, string $consulta, ?DOMNode $ctx = null): array {
  $r = $ctx ? @$x->query($consulta, $ctx) : @$x->query($consulta);
  return $r ? iterator_to_array($r) : [];
}

/** `//*[contains(@class,'x')]` pero por clase completa. */
function ficha_clase(string $clase): string {
  return "contains(concat(' ', normalize-space(@class), ' '), ' $clase ')";
}

/** Dirección absoluta de una imagen de la ficha (null si no sirve: data:, vacía, rara). */
function ficha_url(string $ref, string $base): ?string {
  $ref = trim($ref);
  if ($ref === '' || stripos($ref, 'data:') === 0 || stripos($ref, 'javascript:') === 0) return null;
  if (preg_match('#^https?://#i', $ref)) return $ref;
  $p = parse_url($base);
  if (!$p || empty($p['host'])) return null;
  $origen = ($p['scheme'] ?? 'https') . '://' . $p['host'];
  if (str_starts_with($ref, '//')) return ($p['scheme'] ?? 'https') . ':' . $ref;
  if (str_starts_with($ref, '/')) return $origen . $ref;
  $dir = rtrim((string)preg_replace('#[^/]*$#', '', (string)($p['path'] ?? '/')), '/');
  $partes = $dir === '' ? [] : explode('/', ltrim($dir, '/'));
  foreach (explode('/', $ref) as $seg) {
    if ($seg === '..') array_pop($partes);
    elseif ($seg !== '.' && $seg !== '') $partes[] = $seg;
  }
  return $origen . '/' . implode('/', $partes);
}

const FICHA_NO_FOTO = '/logo|red-?suma|civitas|estudio-|sello|favicon|icono|mapa|croquis/i';
const FICHA_ES_PLANO = '#plano|planta|(^|/)gen-|(^|/)pl-|/u-[a-z]\.(png|jpe?g|webp)#i';

/** Convierte un literal de JavaScript (objetos con claves sin comillas, comentarios) a JSON. */
function ficha_js_a_json(string $js): string {
  $out = '';
  $n = strlen($js);
  $i = 0;
  while ($i < $n) {
    $c = $js[$i];
    if ($c === '"' || $c === "'") {
      $q = $c; $s = ''; $i++;
      while ($i < $n && $js[$i] !== $q) {
        if ($js[$i] === '\\' && $i + 1 < $n) { $s .= $js[$i] . $js[$i + 1]; $i += 2; } else { $s .= $js[$i]; $i++; }
      }
      $i++;
      if ($q === "'") $s = str_replace(["\\'", '"'], ["'", '\\"'], $s);
      $out .= '"' . $s . '"';
      continue;
    }
    if ($c === '/' && ($js[$i + 1] ?? '') === '*') { $f = strpos($js, '*/', $i + 2); $i = $f === false ? $n : $f + 2; continue; }
    if ($c === '/' && ($js[$i + 1] ?? '') === '/') { $f = strpos($js, "\n", $i); $i = $f === false ? $n : $f; continue; }
    if (ctype_alpha($c) || $c === '_' || $c === '$') {
      $j = $i;
      while ($j < $n && (ctype_alnum($js[$j]) || $js[$j] === '_' || $js[$j] === '$')) $j++;
      $ident = substr($js, $i, $j - $i);
      $k = $j;
      while ($k < $n && ctype_space($js[$k])) $k++;
      if (($js[$k] ?? '') === ':') $out .= '"' . $ident . '"';
      else $out .= in_array($ident, ['true', 'false', 'null'], true) ? $ident : '"' . $ident . '"';
      $i = $j;
      continue;
    }
    $out .= $c;
    $i++;
  }
  return (string)preg_replace('/,(\s*[}\]])/', '$1', $out);
}

/** El literal `{ ... }` que sigue a `$ancla` (con llaves balanceadas, sin contar las de los textos). */
function ficha_literal(string $js, string $ancla): ?string {
  $p = strpos($js, $ancla);
  if ($p === false) return null;
  $i = strpos($js, '{', $p);
  if ($i === false) return null;
  $n = strlen($js);
  $nivel = 0;
  for ($j = $i; $j < $n; $j++) {
    $c = $js[$j];
    if ($c === '"' || $c === "'") {
      $q = $c; $j++;
      while ($j < $n && $js[$j] !== $q) { if ($js[$j] === '\\') $j++; $j++; }
      continue;
    }
    if ($c === '{') $nivel++;
    elseif ($c === '}' && --$nivel === 0) return substr($js, $i, $j - $i + 1);
  }
  return null;
}

/** El avance de obra de esta obra, de /js/avance.js (un solo archivo para todas sus obras). */
function ficha_avance(string $js, string $id): ?array {
  $obras = ficha_literal($js, 'var OBRAS');
  $def = ficha_literal($js, 'var INFORME');
  if ($obras === null) return null;
  $o = json_decode(ficha_js_a_json($obras), true);
  if (!is_array($o) || !isset($o[$id]) || !is_array($o[$id])) return null;
  $d = $def !== null ? (json_decode(ficha_js_a_json($def), true) ?: []) : [];
  $x = $o[$id];
  $hitos = [];
  foreach ((array)($x['hitos'] ?? []) as $h) {
    if (is_array($h) && count($h) >= 2) $hitos[] = ['que' => (string)$h[0], 'estado' => (string)$h[1]];
  }
  if (!$hitos) return null;
  $fotos = [];
  foreach ((array)($x['fotos'] ?? []) as $f) {
    if (!is_array($f) || !isset($f[0])) continue;
    $u = ficha_url((string)$f[0], SUMA_BASE . $id . '/');
    if ($u) $fotos[] = ['url' => $u, 'alt' => (string)($f[1] ?? '')];
  }
  return [
    'etapa' => (string)($x['etapa'] ?? ''),
    'hitos' => $hitos,
    'fuente' => (string)($x['fuente'] ?? $d['fuente'] ?? ''),
    'fecha' => (string)($x['fecha'] ?? $d['fecha'] ?? ''),
    'fotos' => $fotos,
  ];
}

/** Lee la ficha: devuelve los bloques que pudo leer (los que no, no vienen). */
function ficha_parsear(string $html, string $id, ?string $avanceJs): array {
  $base = SUMA_BASE . $id . '/';
  $r = [];

  if (!class_exists('DOMDocument')) return $r; // sin la extensión DOM del servidor: sólo lo de las planillas
  $dom = new DOMDocument();
  libxml_use_internal_errors(true);
  $dom->loadHTML('<?xml encoding="utf-8"?>' . $html);
  libxml_clear_errors();
  $x = new DOMXPath($dom);

  // héroe, marca y frase de venta
  try {
    $img = ficha_xp($x, '//header//img[@src]')[0] ?? null;
    if ($img) $r['hero'] = ficha_url((string)$img->getAttribute('src'), $base);
    $m = ficha_xp($x, '//*[' . ficha_clase('mark') . ']')[0] ?? null;
    if ($m) $r['marca'] = ficha_texto($m);
    $c = ficha_xp($x, '//*[' . ficha_clase('claim') . ']')[0] ?? null;
    if ($c) $r['claim'] = ficha_texto($c);
  } catch (\Throwable $e) {}

  // (la franja de arriba de su ficha — entrega, plan, unidades — no se lee a propósito: esos
  // datos salen de las planillas, que son lo que se actualiza; leer también su texto fijo
  // podía mostrar dos cifras distintas para lo mismo)

  // "El edificio"
  try {
    $sec = ficha_xp($x, '//section[' . ficha_clase('edificio') . ']')[0] ?? null;
    if ($sec) {
      $e = [];
      $t = ficha_xp($x, './/*[' . ficha_clase('body') . ']', $sec)[0] ?? null;
      if ($t) $e['texto'] = ficha_texto($t);
      $datos = [];
      foreach (ficha_xp($x, './/li', $sec) as $li) {
        if ($li->hasAttribute('hidden')) continue;
        $et = ficha_texto(ficha_xp($x, './span', $li)[0] ?? null);
        $v = trim(preg_replace('/^' . preg_quote($et, '/') . '/u', '', ficha_texto($li)) ?? '');
        if ($et !== '' && $v !== '') $datos[] = ['etiqueta' => $et, 'valor' => $v];
      }
      if ($datos) $e['datos'] = $datos;
      if ($e) $r['edificio'] = $e;
    }
  } catch (\Throwable $e) {}

  // memoria descriptiva
  try {
    $sec = ficha_xp($x, '//section[' . ficha_clase('memoria') . ']')[0] ?? null;
    if ($sec) {
      $items = [];
      foreach (ficha_xp($x, './/*[' . ficha_clase('memo') . ']/div', $sec) as $d) {
        $tit = ficha_texto(ficha_xp($x, './/h3', $d)[0] ?? null);
        $txt = ficha_texto(ficha_xp($x, './/p', $d)[0] ?? null);
        if ($tit !== '' && $txt !== '') $items[] = ['titulo' => $tit, 'texto' => $txt];
      }
      if ($items) {
        $r['memoria'] = [
          'titulo' => ficha_texto(ficha_xp($x, './/h2', $sec)[0] ?? null) ?: 'Memoria descriptiva',
          'items' => $items,
          'pie' => ficha_texto(ficha_xp($x, './/*[' . ficha_clase('pie') . ']', $sec)[0] ?? null),
        ];
      }
    }
  } catch (\Throwable $e) {}

  // créditos / aclaraciones del pie de su ficha
  try {
    $pie = ficha_texto(ficha_xp($x, '//footer')[0] ?? null);
    if (mb_strlen($pie) > 700) {
      $corte = mb_substr($pie, 0, 700);
      $punto = mb_strrpos($corte, '. ');
      $pie = $punto !== false && $punto > 300 ? mb_substr($corte, 0, $punto + 1) : rtrim($corte) . '…';
    }
    if ($pie !== '') $r['creditos'] = $pie;
  } catch (\Throwable $e) {}

  // planos y fotos
  try {
    $planos = [];   // url => titulo
    $textoScripts = '';
    foreach (ficha_xp($x, '//script[not(@src)]') as $s) $textoScripts .= "\n" . $s->textContent;
    $textoScripts = (string)preg_replace('#data:[a-z/+.-]+;base64,[A-Za-z0-9+/=]+#i', 'data:', $textoScripts);

    // títulos que el propio código le pone a cada plano ({img:"..", cap:".."})
    $caps = [];
    if (preg_match_all('/img\s*:\s*["\']([^"\']+)["\']\s*,\s*cap\s*:\s*["\']([^"\']+)["\']/u', $textoScripts, $pares, PREG_SET_ORDER)) {
      foreach ($pares as $p) $caps[$p[1]] = $p[2];
    }
    if (preg_match_all('/cap\s*:\s*["\']([^"\']+)["\']\s*,\s*img\s*:\s*["\']([^"\']+)["\']/u', $textoScripts, $pares, PREG_SET_ORDER)) {
      foreach ($pares as $p) $caps[$p[2]] = $p[1];
    }
    // las imágenes que cita el código son los planos de cada unidad
    if (preg_match_all('/["\']([^"\'\s]{1,140}\.(?:png|jpe?g|webp))["\']/i', $textoScripts, $lits)) {
      foreach (array_unique($lits[1]) as $ref) {
        if (preg_match('/logo|hero|red-?suma|sello|avance/i', $ref)) continue;
        $u = ficha_url($ref, $base);
        if ($u) $planos[$u] = $caps[$ref] ?? '';
      }
    }

    $fotos = [];    // url => alt
    $heroUrl = $r['hero'] ?? null;
    foreach (ficha_xp($x, '//img[@src]') as $im) {
      if (ficha_xp($x, 'ancestor::footer', $im) || ficha_xp($x, 'ancestor::*[' . ficha_clase('suma-cinta') . ']', $im)) continue;
      $ref = (string)$im->getAttribute('src');
      $u = ficha_url($ref, $base);
      if (!$u) continue;
      $alt = trim((string)$im->getAttribute('alt'));
      if (preg_match(FICHA_ES_PLANO, $ref) && !preg_match('/logo|red-?suma/i', $ref)) {
        if (!isset($planos[$u]) || $planos[$u] === '') $planos[$u] = $alt;
        continue;
      }
      if (preg_match(FICHA_NO_FOTO, $ref) || $u === $heroUrl) continue;
      $fotos[$u] = $alt;
    }

    $lista = [];
    $n = 0;
    foreach ($planos as $u => $t) { $n++; $lista[] = ['url' => $u, 'titulo' => $t !== '' ? $t : 'Plano ' . $n]; if ($n >= 24) break; }
    if ($lista) $r['planos'] = $lista;
    $lista = [];
    foreach (array_slice($fotos, 0, 14, true) as $u => $a) $lista[] = ['url' => $u, 'alt' => $a];
    if ($lista) $r['fotos'] = $lista;
  } catch (\Throwable $e) {}

  // condiciones del simulador de ESTA ficha, si las declara (anticipoPct / comisionPct / cuotas)
  try {
    $txt = '';
    foreach (ficha_xp($x, '//script[not(@src)]') as $s) $txt .= "\n" . $s->textContent;
    $txt = (string)preg_replace('#data:[a-z/+.-]+;base64,[A-Za-z0-9+/=]+#i', 'data:', $txt);
    $cfg = [];
    if (preg_match('/anticipoPct\s*:\s*([0-9.]+)/', $txt, $m) && (float)$m[1] > 0) $cfg['anticipo_pct'] = (float)$m[1];
    if (preg_match('/comisionPct\s*:\s*([0-9.]+)/', $txt, $m)) $cfg['comision_pct'] = (float)$m[1];
    if (preg_match('/\bcuotas\s*:\s*(\d+)/', $txt, $m)) $cfg['cuotas'] = (int)$m[1];
    if ($cfg) $r['config'] = $cfg;
  } catch (\Throwable $e) {}

  // avance de obra
  try {
    if ($avanceJs !== null) {
      $av = ficha_avance($avanceJs, $id);
      if ($av) $r['avance'] = $av;
    }
  } catch (\Throwable $e) {}

  return $r;
}

/** Descarga y lee la ficha de una obra. null si la página no respondió. */
function ficha_leer(string $id, ?string &$motivo): ?array {
  $html = http_get(SUMA_BASE . $id . '/', 15, 3);
  if ($html === null) { $motivo = 'No respondió la ficha ' . SUMA_BASE . $id . '/'; return null; }
  $avance = http_get(SUMA_BASE . 'js/avance.js', 10, 2); // si falla, la ficha sale sin avance de obra
  $datos = ficha_parsear($html, $id, $avance);
  $bloques = array_values(array_intersect(['hero', 'edificio', 'memoria', 'planos', 'fotos', 'avance'], array_keys($datos)));
  if (!$bloques) { $motivo = 'La ficha ' . $id . ' respondió pero no se pudo leer nada (¿cambió la estructura de la página?)'; return null; }
  return $datos;
}

/* ==================== respuesta ==================== */

function ficha_responder(array $cuerpo): void {
  header('Content-Type: application/json; charset=utf-8');
  // respuesta buena: se reusa 5 minutos en el navegador (fotos, planos y textos casi no cambian);
  // cualquier error, nunca se guarda (ver la misma nota en desarrollos.php)
  header('Cache-Control: ' . (!empty($cuerpo['ok']) ? 'public, max-age=300, stale-while-revalidate=600' : 'no-cache, must-revalidate'));
  header('X-Content-Type-Options: nosniff');
  echo json_encode($cuerpo, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function ficha_ok(string $id, array $datos, int $generado): void {
  ficha_responder(['ok' => true, 'id' => $id, 'actualizado' => date('c', $generado)] + $datos);
}

/* ==================== flujo principal ==================== */

$dirCache = __DIR__ . '/cache';
$id = PHP_SAPI === 'cli' ? (string)($argv[1] ?? '') : (string)($_GET['o'] ?? '');
if (!preg_match('/^[a-z0-9][a-z0-9-]{0,60}$/', $id)) {
  http_response_code(400);
  ficha_responder(['ok' => false, 'estado' => 'obra_invalida']);
  exit;
}

// sólo obras de la lista sincronizada
$lista = leer_json($dirCache . '/desarrollos.json');
$conocidas = [];
foreach ((array)($lista['datos']['obras'] ?? []) as $o) $conocidas[(string)($o['id'] ?? '')] = true;
if (!isset($conocidas[$id])) {
  ficha_responder(['ok' => false, 'estado' => 'obra_desconocida']);
  exit;
}

$archivo = $dirCache . '/ficha-' . $id . '.json';
$archivoEstado = $dirCache . '/ficha-' . $id . '.estado.json';
$ahora = time();
$cache = leer_json($archivo);
$edad = ($cache && isset($cache['generado'])) ? $ahora - (int)$cache['generado'] : PHP_INT_MAX;

// 1) copia vigente
if ($cache && $edad < FICHA_TTL) {
  ficha_ok($id, $cache['datos'], (int)$cache['generado']);
  exit;
}

$estado = leer_json($archivoEstado) ?? ['ultimo_intento' => 0, 'fallos' => 0];
$hacePoco = ($ahora - (int)$estado['ultimo_intento']) < FICHA_ESPERA_REINTENTO;

// 2) se intentó hace poco y falló: no se vuelve a pegar todavía
if ($hacePoco && (int)$estado['fallos'] > 0) {
  if ($cache) ficha_ok($id, $cache['datos'], (int)$cache['generado']);
  else ficha_responder(['ok' => false, 'estado' => 'no_disponible']);
  exit;
}

// 3) refrescar, un solo proceso a la vez
@mkdir($dirCache, 0755, true);
$lock = @fopen($dirCache . '/ficha-' . $id . '.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
  if ($cache) ficha_ok($id, $cache['datos'], (int)$cache['generado']);
  else ficha_responder(['ok' => false, 'estado' => 'actualizando']);
  exit;
}
ignore_user_abort(true);
@set_time_limit(60);

// con copia, se responde YA y se refresca después de contestar
$respondido = false;
if ($cache) {
  ficha_ok($id, $cache['datos'], (int)$cache['generado']);
  if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); $respondido = true; }
  elseif (function_exists('litespeed_finish_request')) { @litespeed_finish_request(); $respondido = true; }
  elseif (PHP_SAPI === 'cli') { $respondido = true; }
}

$motivo = null;
$datos = ficha_leer($id, $motivo);

if ($datos !== null) {
  escribir_json($archivo, ['generado' => $ahora, 'datos' => $datos]);
  escribir_json($archivoEstado, ['ultimo_intento' => $ahora, 'fallos' => 0]);
  if (!$respondido) ficha_ok($id, $datos, $ahora);
} else {
  $fallos = (int)$estado['fallos'] + 1;
  escribir_json($archivoEstado, ['ultimo_intento' => $ahora, 'fallos' => $fallos, 'motivo' => $motivo]);
  // aviso por mail: a partir del 2º fallo seguido, y como mucho 1 por día entre todas las fichas
  $archivoAviso = $dirCache . '/ficha-aviso.json';
  $aviso = leer_json($archivoAviso) ?? ['ultimo' => 0];
  if ($fallos >= 2 && ($ahora - (int)$aviso['ultimo']) >= FICHA_TOPE_AVISO) {
    escribir_json($archivoAviso, ['ultimo' => $ahora]);
    avisar('Desarrollos: no se pudo leer la ficha de ' . $id,
      "Hace $fallos intentos seguidos que no se puede leer la ficha de la obra \"$id\" de sumadesarrollos.com.ar.\n\nMotivo: $motivo\n\n"
      . ($cache ? "Mientras tanto la web sigue mostrando la última copia buena (fotos, planos y textos)."
                : "Mientras tanto la ficha se muestra sin fotos, planos ni textos (siguen funcionando las unidades y el simulador).")
      . "\nSe vuelve a intentar sola cada 15 minutos. Si dura, puede que ellos hayan cambiado la estructura de esa página.");
  }
  if (!$respondido) ficha_responder(['ok' => false, 'estado' => 'no_disponible']);
}
flock($lock, LOCK_UN);
fclose($lock);
