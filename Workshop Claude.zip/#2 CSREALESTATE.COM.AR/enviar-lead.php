<?php
/**
 * Endpoint compartido para los formularios propios del sitio (reemplazan a
 * los Google Forms externos — ver CLAUDE.md, sección de formularios).
 *
 * Los 5 formularios (vender, tasacion, alquilar_propiedad, comprar,
 * buscar_alquiler) llaman a este mismo endpoint, cada uno con su propio
 * lead_type — ver $TIPOS_VALIDOS y el switch más abajo.
 *
 * Guarda cada lead como una línea JSON en leads.jsonl y además intenta
 * avisar por email — el archivo es la fuente de verdad (si el email falla
 * o cae en spam, el lead no se pierde).
 *
 * UBICACIÓN DE LEADS.JSONL: fuera de public_html (ver LEADS_DIR más abajo)
 * — antes vivía en leads/leads.jsonl, DENTRO de public_html, protegido
 * sólo por leads/.htaccess. GOOGLE_ADS_SITE_AUDIT.md encontró que ese
 * archivo se podía leer igual por HTTP en producción (Hostinger no
 * estaba aplicando el .htaccess a ese archivo puntual, aunque sí al
 * listado del directorio) — es decir que nombre/teléfono/email de cada
 * consulta quedaban expuestos. La carpeta `leads/` y su `.htaccess`
 * quedan igual (por si alguna vez algo vuelve a escribir ahí sin
 * querer), pero YA NO es donde se guardan los leads nuevos.
 */

declare(strict_types=1);

date_default_timezone_set('America/Argentina/Buenos_Aires');
header('Content-Type: application/json; charset=utf-8');

/* Un nivel arriba de la carpeta que contiene este archivo. Como
 * enviar-lead.php vive en la raíz de lo que se sube a Hostinger (que se
 * descomprime dentro de public_html), __DIR__ acá ES public_html — así
 * que dirname(__DIR__) es su carpeta padre, que en la estructura
 * estándar de Hostinger (y de cPanel en general) NO es pública: no hay
 * ninguna URL que la sirva, sin importar .htaccess. Si la cuenta de
 * Hostinger de Cristian tuviera una estructura distinta (por ejemplo,
 * un dominio addon con public_html anidado más profundo), esta única
 * línea es la que habría que ajustar — ver la verificación post-deploy
 * en el informe de esta tarea. */
define('LEADS_DIR', dirname(__DIR__) . '/leads_privados');

function responder(int $codigo, array $cuerpo): void {
  http_response_code($codigo);
  echo json_encode($cuerpo);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  responder(405, ['ok' => false, 'error' => 'metodo_no_permitido']);
}

header('X-Content-Type-Options: nosniff');

$crudo = file_get_contents('php://input');
// un formulario completo pesa unos pocos KB; algo de más de 64 KB no es una consulta
if (strlen($crudo ?: '') > 65536) {
  responder(413, ['ok' => false, 'error' => 'demasiado_grande']);
}
$datos = json_decode($crudo ?: '', true);
if (!is_array($datos)) {
  responder(400, ['ok' => false, 'error' => 'json_invalido']);
}

// ---------- anti-spam ----------
// honeypot: campo invisible para una persona; un bot que completa "todo" lo llena
if (!empty(trim((string)($datos['sitio_web'] ?? '')))) {
  responder(400, ['ok' => false, 'error' => 'rechazado']);
}
// nadie llena 14 preguntas en menos de 2.5s desde que cargó la página.
// "_ts" es la hora que marcaba el RELOJ DEL CELULAR/COMPU al cargar la página (Date.now() del
// formulario), y acá se compara con la del servidor: si el reloj de la persona está adelantado
// (pasa: relojes mal configurados) la diferencia da NEGATIVA, y antes eso se rechazaba como "bot"
// — una consulta real perdida sin que nadie se enterara. Por eso sólo se rechaza si la diferencia
// es positiva y chica (0 a 2,5 s); una negativa se acepta (un bot no gana nada falseándola: el
// honeypot de arriba y el Referer ya lo filtran).
$ts = (float)($datos['_ts'] ?? 0);
$transcurrido = microtime(true) * 1000 - $ts;
if ($ts <= 0 || ($transcurrido >= 0 && $transcurrido < 2500)) {
  responder(400, ['ok' => false, 'error' => 'rechazado']);
}
// si viene Referer, tiene que ser del propio sitio (no lo exigimos si falta:
// algunos navegadores/config de privacidad lo omiten en pedidos legítimos)
$referer = $_SERVER['HTTP_REFERER'] ?? '';
if ($referer !== '' && stripos($referer, $_SERVER['HTTP_HOST']) === false) {
  responder(400, ['ok' => false, 'error' => 'rechazado']);
}

// ---------- helpers de saneo ----------
function texto($valor, int $maxLargo = 500): string {
  $s = trim(strip_tags((string)$valor));
  $s = preg_replace('/[\r\n]+/', ' ', $s) ?? $s; // por si se usa en headers de email
  return mb_substr($s, 0, $maxLargo);
}
function lista($valor, int $maxItems = 20): array {
  if (!is_array($valor)) return [];
  $out = [];
  foreach (array_slice($valor, 0, $maxItems) as $v) {
    if (is_string($v) && trim($v) !== '') $out[] = texto($v, 200);
  }
  return $out;
}

// ---------- tipos de lead conocidos y sus campos propios ----------
// (los 5 formularios comparten nombre/telefono/email, obligatorios siempre)
$TIPOS_VALIDOS = ['vender', 'tasacion', 'alquilar_propiedad', 'comprar', 'buscar_alquiler'];

$tipo = texto($datos['lead_type'] ?? '', 40);
if (!in_array($tipo, $TIPOS_VALIDOS, true)) {
  responder(400, ['ok' => false, 'error' => 'tipo_invalido']);
}

// ---------- contacto (obligatorio en todos los formularios) ----------
$nombre = texto($datos['nombre'] ?? '', 100);
$telefono = texto($datos['telefono'] ?? '', 30);
$email = texto($datos['email'] ?? '', 150);

$errores = [];
if (mb_strlen($nombre) < 2) $errores[] = 'nombre';
$telefonoLimpio = preg_replace('/[\s\-()]/', '', $telefono) ?? '';
if (!preg_match('/^\+?\d{8,15}$/', $telefonoLimpio)) $errores[] = 'telefono';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = 'email';

// ---------- campos propios de "vender" ----------
$lead = [
  'lead_type' => $tipo,
  'fecha' => date('c'),
  'nombre' => $nombre,
  'telefono' => $telefono,
  'email' => $email,
];

if ($tipo === 'vender') {
  $lead['tipo_propiedad'] = texto($datos['tipo_propiedad'] ?? '', 60);
  $lead['localidad'] = texto($datos['localidad'] ?? '', 150);
  $lead['estado_general'] = texto($datos['estado_general'] ?? '', 60);
  $lead['situacion_actual'] = texto($datos['situacion_actual'] ?? '', 60);
  $lead['motivo'] = texto($datos['motivo'] ?? '', 1000);
  $lead['plazo'] = texto($datos['plazo'] ?? '', 60);
  $lead['valor_en_mente'] = texto($datos['valor_en_mente'] ?? '', 80);
  $lead['como_llego_valor'] = texto($datos['como_llego_valor'] ?? '', 80);
  $lead['publicada_actualmente'] = texto($datos['publicada_actualmente'] ?? '', 60);
  $lead['documentacion'] = lista($datos['documentacion'] ?? []);
  $lead['como_continuar'] = texto($datos['como_continuar'] ?? '', 120);

  foreach (['tipo_propiedad', 'localidad', 'estado_general', 'situacion_actual', 'publicada_actualmente', 'como_continuar'] as $campo) {
    if ($lead[$campo] === '') $errores[] = $campo;
  }
  if (count($lead['documentacion']) < 1) $errores[] = 'documentacion';
}

if ($tipo === 'tasacion') {
  $lead['tipo_propiedad'] = texto($datos['tipo_propiedad'] ?? '', 60);
  $lead['ubicacion'] = texto($datos['ubicacion'] ?? '', 150);
  $lead['descripcion_breve'] = texto($datos['descripcion_breve'] ?? '', 1000);
  $lead['motivo_tasacion'] = texto($datos['motivo_tasacion'] ?? '', 1000);
  $lead['ya_tasada'] = texto($datos['ya_tasada'] ?? '', 80);

  foreach (['tipo_propiedad', 'ubicacion', 'descripcion_breve', 'motivo_tasacion', 'ya_tasada'] as $campo) {
    if ($lead[$campo] === '') $errores[] = $campo;
  }
}

if ($tipo === 'alquilar_propiedad') {
  $lead['tipo_propiedad'] = texto($datos['tipo_propiedad'] ?? '', 60);
  $lead['ubicacion'] = texto($datos['ubicacion'] ?? '', 150);
  $lead['descripcion_breve'] = texto($datos['descripcion_breve'] ?? '', 1000);
  $lead['situacion_actual'] = texto($datos['situacion_actual'] ?? '', 80);
  $lead['disponibilidad'] = texto($datos['disponibilidad'] ?? '', 80);
  $lead['que_es_importante'] = lista($datos['que_es_importante'] ?? []);

  foreach (['tipo_propiedad', 'ubicacion', 'descripcion_breve', 'situacion_actual'] as $campo) {
    if ($lead[$campo] === '') $errores[] = $campo;
  }
  if (count($lead['que_es_importante']) < 1) $errores[] = 'que_es_importante';
}

if ($tipo === 'comprar') {
  $lead['tipo_propiedad'] = texto($datos['tipo_propiedad'] ?? '', 60);
  $lead['destino_compra'] = texto($datos['destino_compra'] ?? '', 60);
  $lead['zona'] = texto($datos['zona'] ?? '', 150);
  $lead['ambientes'] = texto($datos['ambientes'] ?? '', 60);
  $lead['presupuesto'] = texto($datos['presupuesto'] ?? '', 80);
  $lead['forma_compra'] = texto($datos['forma_compra'] ?? '', 80);
  $lead['credito_preaprobado'] = texto($datos['credito_preaprobado'] ?? '', 80);
  $lead['plazo_compra'] = texto($datos['plazo_compra'] ?? '', 60);
  $lead['visitando'] = texto($datos['visitando'] ?? '', 80);
  $lead['caracteristicas_indispensables'] = texto($datos['caracteristicas_indispensables'] ?? '', 1000);
  $lead['algo_mas'] = texto($datos['algo_mas'] ?? '', 1000);

  // OJO: destino_compra y plazo_compra son obligatorios en el formulario
  // (el frontend los exige), pero acá a propósito NO se validan: durante
  // un deploy, alguien con la versión vieja del formulario todavía abierta
  // (o en caché) manda el POST sin esos campos — si el servidor los exigiera,
  // esa consulta real se rechazaría y se perdería un lead. Un lead sin esas
  // respuestas es mejor que ningún lead.
  foreach (['tipo_propiedad', 'zona', 'forma_compra'] as $campo) {
    if ($lead[$campo] === '') $errores[] = $campo;
  }
}

if ($tipo === 'buscar_alquiler') {
  // "modalidad" (Tradicional / Temporario) es obligatoria en el formulario,
  // pero acá no se valida — mismo motivo que destino_compra/plazo_compra en
  // 'comprar' (no rechazar un lead real enviado desde la versión vieja del
  // formulario durante un deploy).
  $lead['modalidad'] = texto($datos['modalidad'] ?? '', 40);
  $lead['tipo_propiedad'] = lista($datos['tipo_propiedad'] ?? []);
  $lead['zona'] = texto($datos['zona'] ?? '', 150);
  $lead['presupuesto_mensual'] = texto($datos['presupuesto_mensual'] ?? '', 80);
  $lead['que_necesita'] = texto($datos['que_necesita'] ?? '', 1000);
  $lead['para_cuando'] = texto($datos['para_cuando'] ?? '', 150);
  $lead['como_respalda'] = lista($datos['como_respalda'] ?? []);
  $lead['mascotas'] = texto($datos['mascotas'] ?? '', 150);

  foreach (['zona', 'que_necesita', 'para_cuando', 'mascotas'] as $campo) {
    if ($lead[$campo] === '') $errores[] = $campo;
  }
  if (count($lead['tipo_propiedad']) < 1) $errores[] = 'tipo_propiedad';
  if (count($lead['como_respalda']) < 1) $errores[] = 'como_respalda';
}

// ---------- atribución de Google Ads / UTMs (opcional, no bloquea el envío) ----------
// El frontend guarda gclid/gbraid/wbraid/utm_* en localStorage al detectarlos
// en la URL (ver el bloque "Atribución" en el <script> de cada formulario) y
// los manda acá junto con el resto del payload. Ninguno es obligatorio — un
// lead sin campaña de origen sigue guardándose igual, sólo sin estos campos.
// A propósito NO participan de $errores ni de ningún otro chequeo: son
// metadata de origen, no datos que la persona haya completado a mano.
foreach (['gclid', 'gbraid', 'wbraid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'] as $campo) {
  $valor = texto($datos[$campo] ?? '', 200);
  if ($valor !== '') $lead[$campo] = $valor;
}

if ($errores) {
  responder(400, ['ok' => false, 'error' => 'faltan_datos', 'campos' => $errores]);
}

// ---------- guardar (fuente de verdad) ----------
$carpetaLeads = LEADS_DIR;
if (!is_dir($carpetaLeads)) {
  mkdir($carpetaLeads, 0755, true);
}
$archivo = $carpetaLeads . '/leads.jsonl';
$linea = json_encode($lead, JSON_UNESCAPED_UNICODE) . "\n";

$fp = fopen($archivo, 'a');
if (!$fp) {
  responder(500, ['ok' => false, 'error' => 'no_se_pudo_guardar']);
}
flock($fp, LOCK_EX);
fwrite($fp, $linea);
flock($fp, LOCK_UN);
fclose($fp);

// ---------- avisar por email (best-effort, no condiciona la respuesta) ----------
// El cuerpo del mail usa etiquetas legibles en vez de los nombres crudos
// del payload (antes era "motivo_tasacion: ...", ahora "Motivo: ..."), y
// recorre una lista FIJA de preguntas por lead_type (no las claves que
// haya en $lead) para que las que quedaron sin responder aparezcan igual,
// con valor vacío, en vez de desaparecer del mail — Cristian lo usa como
// guión al llamar al cliente, y una pregunta que no aparece es una
// pregunta que se olvida de hacer en la llamada. Esto sólo cambia cómo se
// arma $cuerpo: $lead (lo que se guarda en leads.jsonl) no se toca.
$NOMBRES_FORMULARIO = [
  'vender' => 'Vender',
  'tasacion' => 'Tasación',
  'alquilar_propiedad' => 'Alquilar propiedad',
  'comprar' => 'Comprar',
  'buscar_alquiler' => 'Buscar alquiler',
];

// Una entrada por cada campo propio de ese lead_type (ver los bloques
// "if ($tipo === '...')" más arriba) — mismo orden en que aparecen en el
// formulario real, para que el mail se lea como una entrevista, no como
// una lista desordenada de datos.
$CAMPOS_EMAIL = [
  'vender' => [
    'tipo_propiedad' => 'Tipo de propiedad',
    'localidad' => 'Localidad',
    'estado_general' => 'Estado general',
    'situacion_actual' => 'Situación actual',
    'motivo' => 'Motivo',
    'plazo' => 'Plazo para vender',
    'valor_en_mente' => '¿Tiene un valor en mente?',
    'como_llego_valor' => '¿Cómo llegó a ese valor?',
    'publicada_actualmente' => '¿Está publicada actualmente?',
    'documentacion' => 'Documentación disponible',
    'como_continuar' => 'Cómo quiere continuar',
  ],
  'tasacion' => [
    'tipo_propiedad' => 'Tipo de propiedad',
    'ubicacion' => 'Ubicación',
    'descripcion_breve' => 'Descripción breve',
    'motivo_tasacion' => 'Motivo',
    'ya_tasada' => '¿Ya fue tasada?',
  ],
  'alquilar_propiedad' => [
    'tipo_propiedad' => 'Tipo de propiedad',
    'ubicacion' => 'Ubicación',
    'descripcion_breve' => 'Descripción breve',
    'situacion_actual' => 'Situación actual',
    'disponibilidad' => 'Disponibilidad',
    'que_es_importante' => 'Qué es lo más importante',
  ],
  'comprar' => [
    'tipo_propiedad' => 'Tipo de propiedad',
    'destino_compra' => '¿Es para vivienda o inversión?',
    'zona' => 'Zona/s de interés',
    'ambientes' => 'Ambientes',
    'presupuesto' => 'Presupuesto',
    'forma_compra' => 'Forma de compra',
    'credito_preaprobado' => '¿Crédito preaprobado?',
    'plazo_compra' => 'Plazo para comprar',
    'visitando' => '¿Ya visitó propiedades?',
    'caracteristicas_indispensables' => 'Características indispensables',
    'algo_mas' => 'Algo más a saber',
  ],
  'buscar_alquiler' => [
    'modalidad' => 'Modalidad',
    'tipo_propiedad' => 'Tipo de propiedad',
    'zona' => 'Zona/s de interés',
    'presupuesto_mensual' => 'Presupuesto mensual',
    'que_necesita' => 'Qué necesita sí o sí',
    'para_cuando' => 'Para cuándo necesita mudarse',
    'como_respalda' => 'Cómo respalda el alquiler',
    'mascotas' => 'Mascotas',
  ],
];

// Atribución de Ads (ver sección más arriba) — sólo se listan si vinieron
// con el lead, al final del mail; no son preguntas del formulario, así
// que no aplican al criterio de "mostrar vacío si falta" de arriba.
$ATRIBUCION_EMAIL = [
  'gclid' => 'GCLID',
  'gbraid' => 'GBRAID',
  'wbraid' => 'WBRAID',
  'utm_source' => 'UTM Source',
  'utm_medium' => 'UTM Medium',
  'utm_campaign' => 'UTM Campaign',
  'utm_term' => 'UTM Term',
  'utm_content' => 'UTM Content',
];

function valorParaEmail($valor): string {
  return is_array($valor) ? implode(', ', $valor) : (string)$valor;
}

$destino = 'cstedtfeld@redsuma.com.ar';
$nombreFormulario = $NOMBRES_FORMULARIO[$tipo] ?? $tipo;
$asunto = 'Nueva consulta: ' . $nombreFormulario . ' — ' . $nombre;
// $lead['fecha'] queda en formato ISO 8601 para leads.jsonl (no se toca);
// acá sólo se formatea una copia legible para el mail.
$fechaLegible = date('d/m/Y - H:i', strtotime($lead['fecha'])) . 'hs';

$cuerpo = "Nuevo lead desde csrealestate.com.ar\n\n";
$cuerpo .= "Formulario: {$nombreFormulario}\n";
$cuerpo .= "Fecha: {$fechaLegible}\n";
$cuerpo .= "Nombre: {$nombre}\n";
$cuerpo .= "Teléfono: {$telefono}\n";
$cuerpo .= "Email: {$email}\n";
foreach ($CAMPOS_EMAIL[$tipo] as $campo => $etiqueta) {
  $cuerpo .= $etiqueta . ': ' . valorParaEmail($lead[$campo] ?? '') . "\n";
}
$hayAtribucion = false;
foreach ($ATRIBUCION_EMAIL as $campo => $etiqueta) {
  if (!empty($lead[$campo])) {
    if (!$hayAtribucion) { $cuerpo .= "\n"; $hayAtribucion = true; }
    $cuerpo .= $etiqueta . ': ' . $lead[$campo] . "\n";
  }
}

// El asunto lleva tildes y una raya ("Tasación — Luis"): los encabezados de un mail sólo admiten
// ASCII, así que se codifica (RFC 2047); sin esto algunos clientes de correo lo muestran con
// símbolos raros ("TasaciÃ³n â€” Luis").
$asuntoCodificado = '=?UTF-8?B?' . base64_encode($asunto) . '?=';
$headers = "From: CS Real Estate <no-reply@csrealestate.com.ar>\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";
$headers .= "Content-Transfer-Encoding: 8bit\r\n";
if (!@mail($destino, $asuntoCodificado, $cuerpo, $headers)) {
  // el lead ya está guardado arriba; esto sólo deja una pista de que el AVISO por mail no salió
  @file_put_contents($carpetaLeads . '/mail-errores.log', date('c') . " mail() devolvio false (lead {$tipo}, {$email})\n", FILE_APPEND | LOCK_EX);
}

responder(200, ['ok' => true]);
