﻿$root = $PSScriptRoot
$port = 8791
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()
Write-Host "Sirviendo $root en http://localhost:$port/"

$mime = @{
    ".html"  = "text/html; charset=utf-8"
    ".htm"   = "text/html; charset=utf-8"
    ".css"   = "text/css; charset=utf-8"
    ".js"    = "application/javascript"
    ".webp"  = "image/webp"
    ".jpg"   = "image/jpeg"
    ".jpeg"  = "image/jpeg"
    ".png"   = "image/png"
    ".svg"   = "image/svg+xml"
    ".ico"   = "image/x-icon"
    ".woff2" = "font/woff2"
    ".json"  = "application/json"
}

# Datos de prueba para /propiedades.php: este servidor sirve archivos
# estáticos nomás, no ejecuta PHP de verdad -- sin esto, el fetch de la
# home a propiedades.php recibe el código fuente del .php (no es JSON),
# falla, y la sección "Propiedades en venta" se esconde sola (a propósito,
# ver index.html) aunque el sitio real en Hostinger sí la muestre bien.
# Son los datos reales de las 4 propiedades de Cristian (mismo formato que
# devuelve el PHP real), sólo para poder previsualizar el carrusel acá.
$propiedadesDePrueba = @(
    @{ id="PR-019060"; titulo="Casa en Lote Propio | Jardín, Cochera y Remodelada a Nuevo"; descripcion="Una casa pensada para disfrutarla de verdad: ambientes cómodos, buena conexión entre interior y exterior, y ese espacio propio que hace la diferencia para vivir con más privacidad y tranquilidad."; ubicacion="Villa Devoto, CABA"; precio="USD 430.000"; foto="https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/1a4e0668-8081-4239-f4ac-d62c3d58ff00/public"; fotos=@("https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/1a4e0668-8081-4239-f4ac-d62c3d58ff00/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/2af0946c-a5f8-4f28-1533-ba81c311d200/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/7be75732-9d7d-4d5e-d8c0-2686f43f5200/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/0628192f-f1d3-4fb1-38ea-987b705cdf00/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/15c43120-e2df-43e6-3bb4-024a3839c200/public"); ambientes=3; dormitorios=3; banos=2; superficieM2=150; operacion="Venta"; tipo="Casa"; reservado=$false; caracteristicas=@(@{etiqueta="Ambientes"; valor="3"}, @{etiqueta="Dormitorios"; valor="3"}, @{etiqueta="Baños"; valor="2"}, @{etiqueta="Cocheras"; valor="1"}, @{etiqueta="Estado"; valor="Excelente"}, @{etiqueta="Orientación"; valor="Oeste"}, @{etiqueta="Disposición"; valor="Frente"}, @{etiqueta="Luminosidad"; valor="Muy luminoso"}, @{etiqueta="Antigüedad"; valor="56 años"}); superficies=@(@{etiqueta="Cubierta"; valor="150 m²"}, @{etiqueta="Descubierta"; valor="50 m²"}, @{etiqueta="Terreno"; valor="173 m²"}); etiquetas=@(); comodidades=@("Agua Corriente","Electricidad","Alarma","Gas","Desagüe Cloacal","Internet","Televisión por Cable","Habitación de Servicio","Comedor","Terraza","Lavadero","Dormitorio","Living","Jardín","Cocina","Living/Comedor","Vestidor","Baño","Balcón","Dormitorio en Suite","Calefacción","Portón Automático","Aire Acondicionado","Chimenea","Desayunador","Permite Mascotas","Parrilla","Placard"); disponible=$true },
    @{ id="PR-020966"; titulo="3 Ambientes a Estrenar | Cochera, Balcón y Parrilla"; descripcion="Diseño, privacidad y calidad en una propiedad donde cada detalle suma. Un hogar pensado para quienes valoran el confort y buscan un departamento que se diferencie de lo convencional."; ubicacion="Villa Devoto, CABA"; precio="USD 418.000"; foto="https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/c13187f2-56c8-454b-0625-52d3aa675f00/public"; fotos=@("https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/c13187f2-56c8-454b-0625-52d3aa675f00/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/bff1aa5b-4566-46aa-fb1c-7a0e26400800/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/1e08a0c4-4aed-4196-ca77-6372bceec400/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/bc88db00-4b17-4655-4bb8-95518e6db200/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/74d6dbec-3eb5-47d2-b33f-fdbca741a500/public"); ambientes=3; dormitorios=2; banos=2; superficieM2=100.2; operacion="Venta"; tipo="Departamento"; reservado=$false; caracteristicas=@(@{etiqueta="Ambientes"; valor="3"}, @{etiqueta="Dormitorios"; valor="2"}, @{etiqueta="Baños"; valor="2"}, @{etiqueta="Cocheras"; valor="1"}, @{etiqueta="Estado"; valor="A estrenar"}, @{etiqueta="Orientación"; valor="Noreste"}, @{etiqueta="Disposición"; valor="Frente"}, @{etiqueta="Luminosidad"; valor="Muy luminoso"}, @{etiqueta="Antigüedad"; valor="A estrenar"}); superficies=@(@{etiqueta="Cubierta"; valor="100,2 m²"}, @{etiqueta="Semicubierta"; valor="12,6 m²"}, @{etiqueta="Descubierta"; valor="8,2 m²"}); etiquetas=@(); comodidades=@("Parrilla","Placard","Desayunador","Agua Corriente","Desagüe Cloacal","Electricidad","Gas","Balcón","Baño","Cocina","Dormitorio en Suite","Living","Living/Comedor","Toilette","Vestidor","Aire Acondicionado","Ascensor","Calefacción","Losa Radiante","Portón Automático"); disponible=$true },
    @{ id="PR-020944"; titulo="Departamento 4 ambientes con balcón a estrenar 1er Piso al Frente"; descripcion="Un departamento a estrenar pensado para quienes buscan amplitud, luz y tranquilidad. Una propuesta moderna, dentro de un edificio de pocas unidades, que combina comodidad y privacidad en un entorno residencial de Villa Devoto."; ubicacion="Villa Devoto, CABA"; precio="USD 229.000"; foto="https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/4fd20aae-d486-42b0-d9eb-b2503fb74d00/public"; fotos=@("https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/4fd20aae-d486-42b0-d9eb-b2503fb74d00/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/e31f0ed1-b20d-49df-2980-63cba75d4900/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/ebb879ad-3653-43b3-386b-f7d8ac8be200/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/6894de85-c7d4-4ddc-e039-fed3d907a000/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/b3c19615-30b8-4fe8-67f9-48b7a1c25d00/public"); ambientes=4; dormitorios=3; banos=2; superficieM2=74.86; expensas="`$ 140.000 expensas"; operacion="Venta"; tipo="Departamento"; reservado=$false; caracteristicas=@(@{etiqueta="Ambientes"; valor="4"}, @{etiqueta="Dormitorios"; valor="3"}, @{etiqueta="Baños"; valor="2"}, @{etiqueta="Estado"; valor="A estrenar"}, @{etiqueta="Orientación"; valor="Noroeste"}, @{etiqueta="Disposición"; valor="Frente"}, @{etiqueta="Luminosidad"; valor="Muy luminoso"}, @{etiqueta="Antigüedad"; valor="A estrenar"}); superficies=@(@{etiqueta="Cubierta"; valor="74,86 m²"}, @{etiqueta="Semicubierta"; valor="9,86 m²"}); etiquetas=@(); comodidades=@("Balcón","Baño","Cocina","Dormitorio en Suite","Dormitorio","Escritorio","Living/Comedor","Terraza","Ascensor","Caldera","Parrilla","Permite Mascotas","Placard","Agua Corriente","Desagüe Cloacal","Electricidad","Gas","Internet","Teléfono","Televisión por Cable"); disponible=$true },
    @{ id="PR-020934"; titulo="Departamento 4 ambientes con balcón a estrenar 2do Piso al Frente"; descripcion="Un departamento a estrenar pensado para quienes buscan amplitud, luz y tranquilidad. Una propuesta moderna, dentro de un edificio de pocas unidades, que combina comodidad y privacidad en un entorno residencial de Villa Devoto."; ubicacion="Villa Devoto, CABA"; precio="USD 239.000"; foto="https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/e31f0ed1-b20d-49df-2980-63cba75d4900/public"; fotos=@("https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/e31f0ed1-b20d-49df-2980-63cba75d4900/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/ebb879ad-3653-43b3-386b-f7d8ac8be200/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/25fd39f3-cd74-40d9-0e11-8bfc7fb9af00/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/242f1047-a543-4f03-e414-fed92a2ce600/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/b37893aa-969e-42b4-1596-5d027197bf00/public"); ambientes=4; dormitorios=3; banos=2; superficieM2=77.94; expensas="`$ 140.000 expensas"; operacion="Venta"; tipo="Departamento"; reservado=$false; caracteristicas=@(@{etiqueta="Ambientes"; valor="4"}, @{etiqueta="Dormitorios"; valor="3"}, @{etiqueta="Baños"; valor="2"}, @{etiqueta="Estado"; valor="A estrenar"}, @{etiqueta="Orientación"; valor="Noroeste"}, @{etiqueta="Disposición"; valor="Frente"}, @{etiqueta="Luminosidad"; valor="Muy luminoso"}, @{etiqueta="Antigüedad"; valor="A estrenar"}); superficies=@(@{etiqueta="Cubierta"; valor="77,94 m²"}, @{etiqueta="Semicubierta"; valor="9,86 m²"}); etiquetas=@(); comodidades=@("Balcón","Baño","Cocina","Dormitorio en Suite","Dormitorio","Escritorio","Living/Comedor","Terraza","Ascensor","Caldera","Parrilla","Permite Mascotas","Placard","Agua Corriente","Desagüe Cloacal","Electricidad","Gas","Internet","Teléfono","Televisión por Cable"); disponible=$true },
    @{ id="PR-019885"; titulo="PH 2 ambientes | Terraza y Parilla"; descripcion="Luminoso departamento tipo PH de 2 ambientes, ¡sin expensas! Excelente ubicación, a solo 3 cuadras del Parque Saavedra, 2 cuadras de Plaza Vicuña y 4 cuadras de la Fundación Hospitalaria. Se destaca por su cercanía a Av. Cabildo y por contar con múltiples líneas de transporte en la zona."; ubicacion="Saavedra, CABA"; precio="USD 132.000"; foto="https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/df3d4458-53ca-41d0-cb27-2584f59a8200/public"; fotos=@("https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/df3d4458-53ca-41d0-cb27-2584f59a8200/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/43df02fb-7573-497c-ee65-4c1d76412300/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/0fa7afaa-a7ee-4451-80f6-c6c9dff0f800/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/1e758d2c-e072-4ae1-8689-52e1f775b500/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/f9cc7f39-635f-465a-0afd-8b8c7261a900/public"); ambientes=2; dormitorios=1; banos=1; superficieM2=44.04; operacion="Venta"; tipo="PH"; reservado=$true; caracteristicas=@(@{etiqueta="Ambientes"; valor="2"}, @{etiqueta="Dormitorios"; valor="1"}, @{etiqueta="Baños"; valor="1"}, @{etiqueta="Estado"; valor="Excelente"}, @{etiqueta="Disposición"; valor="Contrafrente"}, @{etiqueta="Luminosidad"; valor="Muy luminoso"}, @{etiqueta="Antigüedad"; valor="15 años"}); superficies=@(@{etiqueta="Cubierta"; valor="44,04 m²"}, @{etiqueta="Semicubierta"; valor="0,95 m²"}, @{etiqueta="Descubierta"; valor="23,2 m²"}); etiquetas=@("Apto crédito","Apto profesional"); comodidades=@("Agua Corriente","Electricidad","Gas","Calefacción","Aire Acondicionado","Comedor","Terraza","Cocina/Comedor","Lavadero","Dormitorio","Living","Cocina","Living/Comedor","Patio","Baño","Amoblado","Permite Mascotas","Parrilla","Placard","Apto Turístico"); disponible=$false },
    # Alquiler (local comercial en Villa Pueyrredón), ya vinculado a su publicación
    # PR-025813 en propiedades.php. Mismos datos que devolvería el PHP real
    # (precio en pesos con "/mes", expensas, datos de portal, fotos del CDN).
    @{ id="PR-025813"; titulo="Local comercial en Esquina | 2 Plantas"; descripcion="2 plantas · 1 depósito subsuelo chico (acceso por la entrada del edificio) · 1 toilette · 135 m²`n`nEl Reglamento permite colocar cartel/marquesina en todo el frente del local. No se permite verdulería, pescadería o materiales inflamables."; ubicacion="Villa Pueyrredón, CABA"; precio="`$ 2.630.000/mes"; expensas="`$ 180.000 expensas"; foto="https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/5cd0c1ae-e5e0-4ba8-6513-50fc08085e00/public"; fotos=@("https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/5cd0c1ae-e5e0-4ba8-6513-50fc08085e00/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/410f6f7d-6640-4e36-f7df-82149d107400/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/c8b08d66-8b5c-4f7a-ad2e-000ba981a500/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/60bd7c4c-0af0-45db-f356-46ecfd2ba900/public","https://imagedelivery.net/wZKwAPiXsru4cg1fQnVInQ/16c5a74d-f97b-46b8-b311-23850c18c100/public"); ambientes=4; superficieM2=135; operacion="Alquiler"; tipo="Local comercial"; reservado=$false; caracteristicas=@(@{etiqueta="Ambientes"; valor="4"}, @{etiqueta="Estado"; valor="Muy bueno"}, @{etiqueta="Disposición"; valor="Esquina"}); superficies=@(@{etiqueta="Cubierta"; valor="135 m²"}); etiquetas=@("Apto comercial"); comodidades=@("Toilette","Sala de reuniones","Escritorio","Estudio","Lobby","Sótano"); disponible=$true }
)
# Igual que propiedades.php: cada propiedad lleva `propia` (acá, sólo el local de
# Cristian lo es) y las propias van primero, antes de las que promociona de otros agentes.
foreach ($p in $propiedadesDePrueba) { $p.propia = ($p.id -eq "PR-025813") }
$propiasDePrueba = @($propiedadesDePrueba | Where-Object { $_.propia })
$restoDePrueba = @($propiedadesDePrueba | Where-Object { -not $_.propia })
$propiedadesDePrueba = @($propiasDePrueba + $restoDePrueba)
$propiedadesJson = ConvertTo-Json $propiedadesDePrueba -Depth 5

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $req = $context.Request
    $res = $context.Response
    try {
        $path = $req.Url.LocalPath
        if ($path -eq "/propiedades.php") {
            $textoProp = $propiedadesJson
            # Para ver el botón "Ver todas las propiedades" de la home (que sólo aparece si hay
            # más de 7): crear un archivo vacío propiedades-muchas.flag en la raíz y recargar;
            # suma 3 tarjetas de prueba VACÍAS, con "Próximamente" donde va la foto y sin click
            # (borrar el archivo para volver a la normalidad).
            if (Test-Path (Join-Path $root "propiedades-muchas.flag")) {
                $masDePrueba = foreach ($i in 1..3) {
                    @{ id = "PRUEBA-$i"; proximamente = $true; propia = $false; titulo = ""; ubicacion = ""; precio = ""; foto = ""; fotos = @() }
                }
                $textoProp = ConvertTo-Json @($propiedadesDePrueba + $masDePrueba) -Depth 5
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($textoProp)
            $res.ContentType = "application/json; charset=utf-8"
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
            continue
        }
        # /desarrollos.php: igual que propiedades.php, este servidor no ejecuta PHP; para
        # poder ver la página de desarrollos se sirve una copia de lo que devuelve el
        # sincronizador real (desarrollos-prueba.json, guardada de una corrida con PHP).
        # Para probar el aviso de "web caída" alcanza con crear un archivo vacío
        # llamado desarrollos-caida.flag en la raíz (y borrarlo para volver a la normalidad).
        # /desarrollo-extra.php?o=<obra>: lo que lee el PHP real de la ficha de cada obra (fotos, planos,
        # textos, avance). Para probar la ficha se sirve una copia guardada de una corrida real, una
        # por obra, en desarrollos-extra-prueba/<obra>.json (fuera del zip). Sin archivo: "no disponible".
        if ($path -eq "/desarrollo-extra.php") {
            $obraId = [string]$req.QueryString["o"]
            $archivoExtra = Join-Path (Join-Path $root "desarrollos-extra-prueba") ($obraId + ".json")
            if ($obraId -match '^[a-z0-9][a-z0-9-]{0,60}$' -and (Test-Path $archivoExtra)) {
                $textoExtra = [System.IO.File]::ReadAllText($archivoExtra, [System.Text.Encoding]::UTF8)
            } else {
                $textoExtra = '{"ok":false,"estado":"no_disponible"}'
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($textoExtra)
            $res.ContentType = "application/json; charset=utf-8"
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
            continue
        }
        if ($path -eq "/desarrollos.php") {
            $archivoDev = Join-Path $root "desarrollos-prueba.json"
            $banderaCaida = Join-Path $root "desarrollos-caida.flag"
            if ((Test-Path $banderaCaida) -or -not (Test-Path $archivoDev)) {
                $textoDev = '{"ok":false,"estado":"caida","mensaje":"prueba local"}'
            } else {
                $textoDev = [System.IO.File]::ReadAllText($archivoDev, [System.Text.Encoding]::UTF8)
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($textoDev)
            $res.ContentType = "application/json; charset=utf-8"
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
            continue
        }
        $filePath = Join-Path $root ($path.TrimStart("/"))
        if (Test-Path $filePath -PathType Container) {
            $filePath = Join-Path $filePath "index.html"
        }
        if (Test-Path $filePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($filePath)
            $contentType = $mime[$ext]
            if (-not $contentType) { $contentType = "application/octet-stream" }
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $res.ContentType = $contentType
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $res.StatusCode = 404
            $msg = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $res.OutputStream.Write($msg, 0, $msg.Length)
        }
    } catch {
        $res.StatusCode = 500
    } finally {
        $res.OutputStream.Close()
    }
}
