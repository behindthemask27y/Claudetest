<?php
/**
 * Utilidades compartidas por desarrollos.php (la lista de obras) y
 * desarrollo-extra.php (lo que sólo trae la ficha de cada obra): lectura de
 * páginas ajenas con reintentos, archivos JSON con escritura atómica y avisos
 * por mail a Cristian. No hace nada por sí solo.
 */

declare(strict_types=1);

date_default_timezone_set('America/Argentina/Buenos_Aires');

const SUMA_BASE = 'https://sumadesarrollos.com.ar/';
const AVISO_A = 'cstedtfeld@redsuma.com.ar';

// Sólo para pruebas desde la línea de comandos (nunca desde la web): permite
// apuntar a un HTML local o a una URL inválida para simular fallas, y manda los
// mails a un archivo en vez de enviarlos.
$ES_PRUEBA = (PHP_SAPI === 'cli') && getenv('CSRE_PRUEBA') === '1';

/* ==================== utilidades de red y archivos ==================== */

/** Un GET con curl (si está). null si falla. */
function get_curl(string $url, int $timeout): ?string {
  if (!function_exists('curl_init')) return null;
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 4,
    CURLOPT_CONNECTTIMEOUT => 6,
    CURLOPT_TIMEOUT => $timeout,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; csrealestate-sync/1.0)',
    CURLOPT_ENCODING => '',
  ]);
  $r = curl_exec($ch);
  $codigo = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return (is_string($r) && $r !== '' && $codigo >= 200 && $codigo < 300) ? $r : null;
}

/** Un GET con el método de streams de PHP (el mismo que usa propiedades.php). null si falla. */
function get_stream(string $url, int $timeout): ?string {
  $ctx = stream_context_create(['http' => [
    'timeout' => $timeout,
    'header' => "User-Agent: Mozilla/5.0 (compatible; csrealestate-sync/1.0)\r\n",
  ]]);
  $r = @file_get_contents($url, false, $ctx);
  return (is_string($r) && $r !== '') ? $r : null;
}

/** GET con reintentos; si un método falla prueba el otro. null si no se pudo. */
function http_get(string $url, int $timeout = 12, int $intentos = 3): ?string {
  for ($i = 1; $i <= $intentos; $i++) {
    $cuerpo = get_curl($url, $timeout) ?? get_stream($url, $timeout);
    if ($cuerpo !== null) return $cuerpo;
    if ($i < $intentos) usleep(600000 * $i);
  }
  return null;
}

function leer_json(string $ruta): ?array {
  if (!is_file($ruta)) return null;
  $t = @file_get_contents($ruta);
  if ($t === false) return null;
  $j = json_decode($t, true);
  return is_array($j) ? $j : null;
}

function escribir_json(string $ruta, array $datos): void {
  $dir = dirname($ruta);
  if (!is_dir($dir)) @mkdir($dir, 0755, true);
  $tmp = $ruta . '.' . getmypid() . '.tmp';
  if (@file_put_contents($tmp, json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) !== false) {
    @rename($tmp, $ruta);
  }
}

/* ==================== avisos por mail ==================== */

function avisar(string $asunto, string $cuerpo): void {
  global $ES_PRUEBA;
  if ($ES_PRUEBA) {
    @file_put_contents(__DIR__ . '/cache/aviso-mail.txt', "ASUNTO: $asunto\n$cuerpo\n=====\n", FILE_APPEND);
    return;
  }
  $h = "From: CS Real Estate <no-reply@csrealestate.com.ar>\r\nContent-Type: text/plain; charset=utf-8\r\n";
  @mail(AVISO_A, $asunto, $cuerpo, $h);
}
