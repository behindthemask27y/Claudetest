<?php
/**
 * Sincroniza "Propiedades disponibles" con propiedades.redsuma.com.ar.
 *
 * Cada publicación de esa web trae datos estructurados schema.org
 * (<script type="application/ld+json">, @type incluye "Product") con
 * precio, dirección, ambientes, fotos, etc. — se leen de ahí, nunca por
 * scraping de HTML/CSS, tal como se pidió (lo poco que el JSON-LD no trae,
 * como las expensas, sale de propiedades-extra.php, que falla en silencio).
 *
 * QUÉ PROPIEDADES SALEN Y EN QUÉ ORDEN (2026-10-08):
 *   1) Las PROPIAS de Cristian: se detectan solas leyendo su perfil público
 *      del portal (URL_PERFIL, lista ItemList del JSON-LD). Si mañana publica
 *      una más, aparece sin tocar nada acá.
 *   2) Las PROMOVIDAS ($PROMOVIDAS, más abajo): publicaciones de otros agentes
 *      que Cristian promociona con su permiso. Se agregan pasándole el link a
 *      Claude ("sincronizá este link") y salen en el orden en que están en la
 *      lista; para destacar una, se sube de lugar en esa lista.
 *   La respuesta trae TODAS (propias primero). La home muestra sólo las
 *   primeras 7 y, si hay más, un botón "Ver todas las propiedades" a
 *   propiedades/index.html, que las muestra completas (ver index.html).
 *
 * A propósito NO se expone acá `sourceUrl` ni el `broker` de cada
 * publicación: Cristian tiene permiso de los agentes dueños de las
 * promovidas para mostrarlas y cobrar su propia comisión si consigue
 * comprador — mostrar el link original o el contacto del otro agente le
 * haría perder esa consulta. El botón de WhatsApp del detalle (armado
 * aparte, en index.html) va siempre al número de Cristian. Por lo mismo, el
 * texto de una propiedad que viene del portal pasa por limpiarDescripcion(),
 * que saca líneas con teléfonos, mails o links.
 *
 * Título y descripción: si la propiedad tiene una entrada en
 * $TITULOS_Y_DESCRIPCIONES (texto que Cristian escribió a mano), se usa esa.
 * Si no, se usa el nombre y la descripción de la propia publicación del
 * portal (limpiados). Los textos manuales NO se sincronizan.
 *
 * Cache con TTL de 8 horas, sin hacer esperar a nadie: cuando vence, se
 * responde YA con la copia vieja y se refresca después de cerrar la
 * respuesta (si el servidor lo permite; si no, el visitante espera esa vez).
 * Reglas de "funciona solo":
 *   - Una publicación que el portal da por inexistente (404/410) se saca.
 *   - Cualquier otra falla (timeout, 5xx, página rara) NO borra nada: se
 *     conserva la última versión buena de esa propiedad y se reintenta en
 *     15 minutos.
 *   - Si el perfil no se puede leer, se conservan las propias de la copia
 *     anterior.
 *   - Si el resultado queda vacío pero había copia, se conserva la copia.
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
// La respuesta buena se puede reusar 2 minutos en el navegador (la home y /propiedades/ piden este
// mismo JSON); los datos se renuevan cada 8 h. El único caso que NO se guarda es "[]" (nunca se
// pudo armar la copia): ver más abajo.
header('Cache-Control: public, max-age=120, stale-while-revalidate=600');
header('X-Content-Type-Options: nosniff');

// Datos "de portal" (expensas, estado, orientación, superficies...) que el
// JSON-LD no trae — ver propiedades-extra.php. Cargado dentro de un
// try/catch y sólo si el archivo existe: si falta o tiene un error, todo
// lo demás sigue andando con los datos de siempre.
$archivoExtra = __DIR__ . '/propiedades-extra.php';
if (is_file($archivoExtra)) {
  try {
    require_once $archivoExtra;
  } catch (\Throwable $e) {
    // sin extras: obtenerPropiedad() chequea function_exists() antes de usarlos
  }
}

// ---------- config ----------
const URL_PERFIL = 'https://propiedades.redsuma.com.ar/a/cristian-stedtfeld';
const TOPE_PROPIAS = 30;

// Propiedades de OTROS agentes que Cristian promociona, en el orden en que
// salen después de las suyas. `id` es el sku de la publicación (se usa para
// conservar la última versión buena si el portal falla un rato).
$PROMOVIDAS = [
  ['id' => 'PR-019060', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-casa-lote-propio-3-amb-con-patiojardin'],
  ['id' => 'PR-020966', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-dpto-3-ambientes-villa-devoto-a-estrenar-cochera-balcon-y-parrilla-calidad-rs020966'],
  ['id' => 'PR-020944', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-departamento-4-ambientes-con-balcon-a-estrenar-villa-devoto-rs020944'],
  ['id' => 'PR-020934', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/venta-departamento-4-ambientes-con-balcon-a-estrenar-villa-devoto-rs020934'],
  ['id' => 'PR-019885', 'sourceUrl' => 'https://propiedades.redsuma.com.ar/ph-dos-ambientes-con-terraza-y-parilla'],
];

// título y descripción escritos por Cristian a mano (opcional por propiedad,
// la clave es el sku). Las propiedades que NO están acá usan el texto del portal.
$TITULOS_Y_DESCRIPCIONES = [
  'PR-019060' => [
    'titulo' => 'Casa en Lote Propio | Jardín, Cochera y Remodelada a Nuevo',
    'descripcion' => 'Una casa pensada para disfrutarla de verdad: ambientes cómodos, buena '
      . 'conexión entre interior y exterior, y ese espacio propio que hace la diferencia para '
      . 'vivir con más privacidad y tranquilidad.',
  ],
  'PR-020966' => [
    'titulo' => '3 Ambientes a Estrenar | Cochera, Balcón y Parrilla',
    'descripcion' => 'Diseño, privacidad y calidad en una propiedad donde cada detalle suma. Un '
      . 'hogar pensado para quienes valoran el confort y buscan un departamento que se diferencie '
      . 'de lo convencional.',
  ],
  'PR-020944' => [
    'titulo' => 'Departamento 4 ambientes con balcón a estrenar 1er Piso al Frente',
    'descripcion' => 'Un departamento a estrenar pensado para quienes buscan amplitud, luz y '
      . 'tranquilidad. Una propuesta moderna, dentro de un edificio de pocas unidades, que '
      . 'combina comodidad y privacidad en un entorno residencial de Villa Devoto.',
  ],
  'PR-020934' => [
    'titulo' => 'Departamento 4 ambientes con balcón a estrenar 2do Piso al Frente',
    'descripcion' => 'Un departamento a estrenar pensado para quienes buscan amplitud, luz y '
      . 'tranquilidad. Una propuesta moderna, dentro de un edificio de pocas unidades, que '
      . 'combina comodidad y privacidad en un entorno residencial de Villa Devoto.',
  ],
  'PR-019885' => [
    'titulo' => 'PH 2 ambientes | Terraza y Parilla',
    'descripcion' => 'Luminoso departamento tipo PH de 2 ambientes, ¡sin expensas! Excelente '
      . 'ubicación, a solo 3 cuadras del Parque Saavedra, 2 cuadras de Plaza Vicuña y 4 cuadras '
      . 'de la Fundación Hospitalaria. Se destaca por su cercanía a Av. Cabildo y por contar '
      . 'con múltiples líneas de transporte en la zona.',
  ],
  // propia de Cristian (el local en alquiler de Villa Pueyrredón). Comillas dobles
  // a propósito: el "\n\n" tiene que ser un salto de línea real (el detalle muestra
  // la descripción con white-space:pre-line)
  'PR-025813' => [
    'titulo' => 'Local comercial en Esquina | 2 Plantas',
    'descripcion' => "2 plantas · 1 depósito subsuelo chico (acceso por la entrada del edificio) · 1 toilette · 135 m²\n\n"
      . 'El Reglamento permite colocar cartel/marquesina en todo el frente del local. '
      . 'No se permite verdulería, pescadería o materiales inflamables.',
  ],
];

$carpetaCache = __DIR__ . '/cache';
// "-v2": el formato cambió (campo `propia`, orden propias-primero); un nombre
// nuevo hace que una copia vieja de un deploy anterior se ignore sola, sin
// tener que borrarla a mano desde hPanel.
$cacheArchivo = $carpetaCache . '/propiedades-v2.json';
$urlsArchivo = $carpetaCache . '/propiedades-urls.json';
$lockArchivo = $carpetaCache . '/propiedades.lock';
$ttlSegundos = 8 * 3600;
$reintentoSegundos = 900;

// ---------- 1) copia vigente: se responde directo ----------
$edad = is_file($cacheArchivo) ? time() - (int)filemtime($cacheArchivo) : null;
if ($edad !== null && $edad < $ttlSegundos) {
  readfile($cacheArchivo);
  exit;
}

// ---------- 2) copia vencida o inexistente ----------
if (!is_dir($carpetaCache)) @mkdir($carpetaCache, 0755, true);
$lock = @fopen($lockArchivo, 'c');

if ($edad !== null) {
  // hay copia vieja: se responde YA con ella y se refresca después de cerrar
  // la respuesta (un solo proceso a la vez; los demás se van)
  readfile($cacheArchivo);
  cerrarRespuesta();
  if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) exit;
} else {
  // sin copia: este visitante espera; si otro proceso ya está armándola, se
  // espera a que termine y se usa su resultado
  if ($lock !== false) flock($lock, LOCK_EX);
  clearstatcache();
  if (is_file($cacheArchivo)) {
    readfile($cacheArchivo);
    exit;
  }
}

ignore_user_abort(true);
@set_time_limit(120);

// otro proceso pudo haber refrescado mientras se esperaba el lock
clearstatcache();
if ($edad !== null && is_file($cacheArchivo) && (time() - (int)filemtime($cacheArchivo)) < $ttlSegundos) exit;

[$resultado, $huboErrores] = sincronizar($PROMOVIDAS, $TITULOS_Y_DESCRIPCIONES, $cacheArchivo, $urlsArchivo);

if (count($resultado) > 0) {
  $json = json_encode($resultado, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if ($json !== false) {
    $tmp = $cacheArchivo . '.tmp';
    if (@file_put_contents($tmp, $json) !== false) @rename($tmp, $cacheArchivo);
    // con errores sueltos (una publicación que no respondió, el perfil caído...)
    // la copia se da por "casi vencida": vuelve a intentarlo en 15 minutos
    if ($huboErrores) @touch($cacheArchivo, time() - $ttlSegundos + $reintentoSegundos);
    if ($edad === null) echo $json;
  }
} elseif ($edad !== null) {
  // el refresco no trajo nada pero hay copia: se conserva y se reintenta pronto
  @touch($cacheArchivo, time() - $ttlSegundos + $reintentoSegundos);
} else {
  header('Cache-Control: no-cache, must-revalidate'); // todavía no salió nada: se pisa el "reusar 2 minutos"
  echo '[]';
}
exit;

// ---------------------------------------------------------------------------

/** Cierra la conexión con el visitante para seguir trabajando "por detrás". */
function cerrarRespuesta(): void {
  if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
  } elseif (function_exists('litespeed_finish_request')) {
    litespeed_finish_request();
  }
  // si el servidor no lo permite, el visitante espera el refresco esa vez
}

/** GET con tope de espera. estado = código HTTP final (0 si no hubo respuesta). */
function leerUrl(string $url): array {
  $contexto = stream_context_create(['http' => [
    'timeout' => 8,
    'ignore_errors' => true,
    'header' => "User-Agent: Mozilla/5.0 (compatible; csrealestate-sync/1.0)\r\n",
  ]]);
  $cuerpo = @file_get_contents($url, false, $contexto);
  $estado = 0;
  foreach ((array)($http_response_header ?? []) as $linea) {
    if (preg_match('#^HTTP/\S+\s+(\d{3})#', (string)$linea, $m)) $estado = (int)$m[1]; // la última gana (redirecciones)
  }
  return ['estado' => $estado, 'cuerpo' => is_string($cuerpo) ? $cuerpo : ''];
}

/** URLs de las propiedades del perfil de Cristian (en orden), o null si el perfil no se pudo leer. */
function urlsDelPerfil(string $html): ?array {
  if (!preg_match_all('#<script type="application/ld\+json">(.*?)</script>#s', $html, $bloques)) return null;
  foreach ($bloques[1] as $bloque) {
    $dato = json_decode($bloque, true);
    if (!is_array($dato) || ($dato['@type'] ?? null) !== 'ItemList') continue;
    $urls = [];
    foreach ((array)($dato['itemListElement'] ?? []) as $elemento) {
      $url = is_array($elemento) ? (string)($elemento['url'] ?? '') : '';
      if ($url !== '' && !in_array($url, $urls, true)) $urls[] = $url;
    }
    return array_slice($urls, 0, TOPE_PROPIAS);
  }
  return null;
}

/**
 * Arma la lista completa: propias (perfil) + promovidas, sin repetidos.
 * Devuelve [lista, huboErrores].
 */
function sincronizar(array $promovidas, array $manuales, string $cacheArchivo, string $urlsArchivo): array {
  // última versión buena de cada propiedad, para no perderla por una falla pasajera
  $previas = [];
  if (is_file($cacheArchivo)) {
    $copia = json_decode((string)@file_get_contents($cacheArchivo), true);
    foreach ((array)$copia as $p) {
      if (is_array($p) && isset($p['id'])) $previas[(string)$p['id']] = $p;
    }
  }
  $mapaUrls = [];
  if (is_file($urlsArchivo)) {
    $m = json_decode((string)@file_get_contents($urlsArchivo), true);
    if (is_array($m)) $mapaUrls = $m;
  }

  $huboErrores = false;
  $trabajos = []; // [url, id conocido ('' si no se sabe), propia]

  $perfil = leerUrl(URL_PERFIL);
  $urlsPropias = $perfil['estado'] === 200 ? urlsDelPerfil($perfil['cuerpo']) : null;
  if ($urlsPropias === null) {
    // perfil caído o con otro formato: se conservan las propias de la copia anterior
    $huboErrores = true;
    foreach ($previas as $p) {
      if (!empty($p['propia'])) $trabajos[] = ['', (string)$p['id'], true];
    }
  } else {
    foreach ($urlsPropias as $url) $trabajos[] = [$url, (string)($mapaUrls[$url] ?? ''), true];
  }
  foreach ($promovidas as $fuente) {
    $trabajos[] = [(string)$fuente['sourceUrl'], (string)$fuente['id'], false];
  }

  $resultado = [];
  $vistos = [];
  foreach ($trabajos as [$url, $idConocido, $propia]) {
    $propiedad = null;
    if ($url === '') {
      $propiedad = $previas[$idConocido] ?? null; // propia conservada sin volver a pedirla
    } else {
      $r = traerPropiedad($url, $idConocido, $manuales);
      if ($r['estado'] === 'ok') {
        $propiedad = $r['propiedad'];
        $mapaUrls[$url] = $propiedad['id'];
      } elseif ($r['estado'] === 'gone') {
        unset($mapaUrls[$url]); // el portal dice que ya no existe: se saca
        continue;
      } else {
        $huboErrores = true;
        $propiedad = $previas[$idConocido] ?? null; // falla pasajera: se conserva la última versión buena
      }
    }
    if ($propiedad === null || isset($vistos[$propiedad['id']])) continue;
    $vistos[$propiedad['id']] = true;
    $propiedad['propia'] = $propia;
    $resultado[] = $propiedad;
  }

  @file_put_contents($urlsArchivo, json_encode($mapaUrls, JSON_UNESCAPED_SLASHES));
  return [$resultado, $huboErrores];
}

/** Trae una publicación: ['estado' => 'ok'|'gone'|'error', 'propiedad' => ...]. */
function traerPropiedad(string $url, string $idConocido, array $manuales): array {
  $r = leerUrl($url);
  if ($r['estado'] === 404 || $r['estado'] === 410) return ['estado' => 'gone'];
  if ($r['estado'] !== 200 || $r['cuerpo'] === '') return ['estado' => 'error'];
  $propiedad = obtenerPropiedad($r['cuerpo'], $idConocido, $manuales);
  // una página que responde 200 pero sin datos de propiedad es más probable que
  // sea un problema pasajero del portal que una baja: no se borra por eso
  return $propiedad === null ? ['estado' => 'error'] : ['estado' => 'ok', 'propiedad' => $propiedad];
}

/** Normaliza una publicación ya descargada. null si no se pudo leer/parsear.
 *  Extrae del origen los campos estructurados del JSON-LD (precio, fotos,
 *  ambientes, comodidades, disponibilidad/reservada, operación y tipo) y,
 *  como complemento "de portal", los que sólo están en el HTML (expensas,
 *  estado, orientación, superficies...; ver propiedades-extra.php). */
function obtenerPropiedad(string $html, string $idConocido, array $manuales): ?array {
  if (!preg_match_all('#<script type="application/ld\+json">(.*?)</script>#s', $html, $bloques)) {
    return null;
  }

  // dos bloques de JSON-LD interesan: el "Product" (datos de la propiedad) y
  // el "BreadcrumbList" (de ahí salen la operación — Venta/Alquiler — y el
  // tipo de propiedad). No se corta el loop en el primero que aparezca.
  $datos = null;
  $migas = null;
  foreach ($bloques[1] as $bloque) {
    $candidato = json_decode($bloque, true);
    if (!is_array($candidato)) continue;
    $tipo = $candidato['@type'] ?? null;
    if ($datos === null && is_array($tipo) && in_array('Product', $tipo, true)) { $datos = $candidato; continue; }
    if ($migas === null && $tipo === 'BreadcrumbList') { $migas = $candidato; }
  }
  if ($datos === null) return null;

  $id = trim((string)($datos['sku'] ?? ''));
  if ($id === '') $id = $idConocido;
  if ($id === '') return null;

  // texto: el de Cristian si lo escribió, si no el de la propia publicación
  $manual = $manuales[$id] ?? null;
  $titulo = is_array($manual) && isset($manual['titulo'])
    ? (string)$manual['titulo']
    : limpiarTitulo((string)($datos['name'] ?? ''));
  $descripcion = is_array($manual) && isset($manual['descripcion'])
    ? (string)$manual['descripcion']
    : limpiarDescripcion((string)($datos['description'] ?? ''));

  $precio = $datos['offers']['price'] ?? null;
  $moneda = $datos['offers']['priceCurrency'] ?? 'USD';
  $disponibilidad = (string)($datos['offers']['availability'] ?? '');
  $disponible = $disponibilidad === 'https://schema.org/InStock';
  // La fuente marca "Reservada" con LimitedAvailability (verificado: la misma
  // publicación muestra el cartel "Reservada" en su página y trae este valor).
  $reservado = $disponibilidad === 'https://schema.org/LimitedAvailability';

  // operación (posición 2 de las migas: "Venta" / "Alquiler") y tipo de
  // propiedad (sale del slug de la posición 3, ej. .../alquiler/local-comercial/...)
  $operacion = '';
  $tipoPropiedad = '';
  if (is_array($migas) && is_array($migas['itemListElement'] ?? null)) {
    foreach ($migas['itemListElement'] as $miga) {
      if (!is_array($miga)) continue;
      $posicion = (int)($miga['position'] ?? 0);
      if ($posicion === 2) $operacion = trim((string)($miga['name'] ?? ''));
      if ($posicion === 3 && preg_match('#/propiedades/[^/]+/([^/]+)#', (string)($miga['item'] ?? ''), $mm)) {
        $tipoPropiedad = nombreTipoPropiedad($mm[1]);
      }
    }
  }

  $localidad = (string)($datos['address']['addressLocality'] ?? '');
  $region = (string)($datos['address']['addressRegion'] ?? '');
  // La fuente no siempre usa la misma palabra para "Ciudad Autónoma de
  // Buenos Aires" al final de addressLocality — a veces "Capital Federal",
  // a veces "Buenos Aires" a secas (visto en la práctica: "Saavedra,
  // Buenos Aires") — y las dos son redundantes con addressRegion (que ya
  // llega como "CABA"). Se recortan esos alias conocidos, más el propio
  // valor de $region por si ya viniera repetido tal cual, antes de agregar
  // la región real — así cualquier propiedad nueva se ajusta sola en vez
  // de necesitar un arreglo puntual cada vez que la fuente use una palabra
  // distinta (pasó con "PR-019885": daba "Saavedra, Buenos Aires, CABA" en
  // vez de "Saavedra, CABA").
  foreach (['Capital Federal', 'Buenos Aires', $region] as $alias) {
    if ($alias === '') continue;
    $localidad = preg_replace('/,?\s*' . preg_quote($alias, '/') . '\s*$/i', '', $localidad) ?? $localidad;
  }
  if ($localidad !== '' && $region !== '') $localidad .= ', ' . $region;

  // hasta 5 fotos (la fuente puede traer 10+) — alcanza para la tarjeta
  // (usa la primera) y una galería chica en el detalle sin sobrecargar
  $fotos = array_values(array_filter((array)($datos['image'] ?? []), 'is_string'));
  $fotos = array_slice($fotos, 0, 5);

  $superficieM2 = $datos['floorSize']['value'] ?? null;

  // Precio como lo muestra el portal: "$ 2.630.000" para pesos, "USD 132.000"
  // para dólares; los alquileres mensuales llevan "/mes".
  $simbolo = $moneda === 'ARS' ? '$ ' : $moneda . ' ';
  $textoPrecio = $precio !== null ? $simbolo . number_format((float)$precio, 0, ',', '.') : '';
  if ($textoPrecio !== '' && strcasecmp($operacion, 'Alquiler') === 0) $textoPrecio .= '/mes';

  // Comodidades (agua, gas, parrilla, balcón...) — vienen estructuradas en el
  // JSON-LD como amenityFeature; sin repetidos.
  $comodidades = [];
  foreach ((array)($datos['amenityFeature'] ?? []) as $comodidad) {
    if (!is_array($comodidad)) continue;
    $nombre = trim((string)($comodidad['name'] ?? ''));
    if ($nombre === '' || ($comodidad['value'] ?? true) === false) continue;
    $comodidades[$nombre] = $nombre;
  }
  $comodidades = array_slice(array_values($comodidades), 0, 40);

  // Lo que el JSON-LD no trae (expensas, estado, orientación, antigüedad,
  // superficies detalladas, "Apto crédito"...) sale del HTML de la
  // publicación, con propiedades-extra.php. Si ese archivo no cargó o el
  // portal cambió de estructura, $extra queda vacío y la tarjeta muestra
  // simplemente menos datos.
  // (la propia función ya atrapa sus errores; el try/catch de acá es una
  // segunda red por si algo falla fuera de su control — ej. memoria o un
  // tipo inesperado — y la propiedad igual se arma con los datos del JSON-LD)
  $extra = [];
  if (function_exists('csre_extraer_del_html')) {
    try {
      $extra = csre_extraer_del_html($html);
    } catch (\Throwable $e) {
      $extra = [];
    }
  }

  return [
    'id' => $id,
    'titulo' => $titulo,
    'descripcion' => $descripcion,
    'ubicacion' => $localidad,
    'precio' => $textoPrecio,
    'expensas' => (string)($extra['expensas'] ?? ''),
    'operacion' => $operacion,
    'tipo' => $tipoPropiedad,
    'reservado' => $reservado || !empty($extra['reservada']),
    'foto' => $fotos[0] ?? '',
    'fotos' => $fotos,
    'ambientes' => $datos['numberOfRooms'] ?? null,
    'dormitorios' => $datos['numberOfBedrooms'] ?? null,
    'banos' => $datos['numberOfBathroomsTotal'] ?? null,
    'superficieM2' => $superficieM2,
    'caracteristicas' => $extra['caracteristicas'] ?? [],
    'superficies' => $extra['superficies'] ?? [],
    'etiquetas' => $extra['etiquetas'] ?? [],
    'comodidades' => $comodidades,
    'disponible' => $disponible,
  ];
}

/** Título de la publicación del portal: una sola línea, sin espacios de más. */
function limpiarTitulo(string $texto): string {
  $texto = trim(preg_replace('/\s+/u', ' ', $texto) ?? $texto);
  if (preg_match('/^.{1,140}/su', $texto, $m)) $texto = $m[0];
  return $texto;
}

/**
 * Descripción de la publicación del portal, lista para mostrar. Saca las
 * líneas con teléfonos, mails o links (para no mostrar el contacto de otro
 * agente: ver el comentario del principio), junta saltos de línea de más y
 * la corta en ~2200 caracteres.
 */
function limpiarDescripcion(string $texto): string {
  $texto = str_replace(["\r\n", "\r"], "\n", $texto);
  $salida = [];
  foreach (explode("\n", $texto) as $linea) {
    $linea = trim($linea);
    if ($linea !== '') {
      $esLink = preg_match('#@|https?:|www\.|\b[a-z0-9-]+\.(?:com|net|org)(?:\.ar)?\b#i', $linea) === 1;
      $esTelefono = preg_match('/(?<!\d)(?:\+?54[\s.-]*9?[\s.-]*)?\(?(?:0?11|15)\)?[\s.-]*\d{4}[\s.-]*\d{4}(?!\d)/', $linea) === 1;
      if ($esLink || $esTelefono) continue;
    }
    $salida[] = $linea;
  }
  $texto = trim(implode("\n", $salida));
  $texto = preg_replace("/\n{3,}/", "\n\n", $texto) ?? $texto;
  if (preg_match('/^.{2201,}/su', $texto)) {
    preg_match('/^.{1,2200}/su', $texto, $m);
    $corte = $m[0];
    // se corta en el último salto de párrafo/línea si queda razonablemente lejos del final
    $pos = strrpos($corte, "\n");
    if ($pos !== false && $pos > 1400) $corte = substr($corte, 0, $pos);
    $texto = rtrim($corte) . '…';
  }
  return $texto;
}

/** "local-comercial" -> "Local comercial", "ph" -> "PH". */
function nombreTipoPropiedad(string $slug): string {
  $conocidos = [
    'ph' => 'PH',
    'departamento' => 'Departamento',
    'casa' => 'Casa',
    'local-comercial' => 'Local comercial',
    'oficina' => 'Oficina',
    'terreno' => 'Terreno',
    'cochera' => 'Cochera',
    'galpon' => 'Galpón',
  ];
  if (isset($conocidos[$slug])) return $conocidos[$slug];
  return ucfirst(str_replace('-', ' ', $slug));
}
