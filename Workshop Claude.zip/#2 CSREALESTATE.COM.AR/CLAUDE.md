# Página de links — Cristian Stedtfeld (reemplazo de Linktree)

Sitio estático (sin build, sin frameworks) que reemplaza `linktr.ee/csrealestate.ba`.
El motivo del cambio: Linktree no permite insertar tags de medición, y sin eso
no se pueden medir conversiones en las campañas de Google Ads.

Arrancó como un único `index.html` con todo embebido — hoy sigue siendo esa
misma página, más un puñado de páginas nuevas (formularios propios, política
de privacidad) que comparten sus tokens/estilos vía `estilo.css` y un único
endpoint PHP (`enviar-lead.php`) para guardar leads. Ver la sección
"Formularios propios" más abajo para el detalle. Sigue sin build ni
dependencias externas — "sin build" no significa "un solo archivo para
siempre", significa que cualquier archivo nuevo sigue siendo HTML/CSS/JS
plano, editable a mano, sin `npm install` de por medio.

Dominio final: **csrealestate.com.ar**. Va a Hostinger (con PHP — confirmado
al implementar los formularios propios, ver esa sección).

Idioma de trabajo: español rioplatense. Los nombres de clases, variables y
comentarios del código están en español a propósito.

**Dónde vive el proyecto (2026-10-04):** `G:\Workshop Claude\#2 CSREALESTATE.COM.AR`
— Cristian pidió moverlo ahí (y renombrar la carpeta) desde
`C:\Users\eNig'matiK\Downloads\contexto-proyecto-cristian-stedtfeld`, que
ya no es el lugar de trabajo. La copia se verificó archivo por archivo
(60 de 60, hashes idénticos). La carpeta vieja de Downloads se mandó a la
Papelera el 2026-10-08 (recuperable desde ahí si hiciera falta; Windows no
la había soltado antes porque la sesión todavía trabajaba adentro). Si
alguna vez reaparece una copia en Downloads, es un duplicado sobrante: no
editar ahí.
Todo este documento habla de rutas relativas (`serve.ps1`, `fonts/`,
`form/`), así que sigue valiendo igual. `G:\Workshop Claude\` es además el
espacio de trabajo de ACM de Cris y tiene su propio `CLAUDE.md` (analista de
ACM, no del sitio) que Claude Code también carga como contexto por estar en
una carpeta superior — para el sitio web manda ESTE documento. El nombre del
zip de deploy (`cristian-stedtfeld-web.zip`) no cambió.

## Archivos

- `index.html` — la home completa (portada, botones, "Mi método", carruseles,
  pie). JS embebido, sin build, sin dependencias. El CSS que comparte con las
  páginas nuevas vive en `estilo.css`; lo exclusivo de la home (portada,
  `.mi-metodo*`, carrusel) sigue embebido acá — ver "Formularios propios"
  más abajo para el porqué de la separación.
- `estilo.css` — tokens de diseño (`:root`), `@font-face`, resets globales,
  fondo ambiente, `.envoltorio`, botón "glass" (`.boton`), tarjeta "glass"
  (`.aviso`, la usan tanto los `<dialog>` de la home como las tarjetas de
  los formularios), pie (`.redes`/`.legal`/`.copyright`) y los componentes
  nuevos de formulario (`.form-*`). Antes todo esto estaba embebido en
  `index.html`; se separó para que los 5 `formularios/*/index.html` lo
  compartan sin copiar y pegar CSS. Las URLs
  relativas de este archivo (`fonts/...`) se resuelven respecto de él
  mismo, no de la página que lo linkea — por eso sigue andando igual desde
  cualquier profundidad de carpeta, mientras `estilo.css` quede en la raíz
  junto a `fonts/`.
- `form/<nombre>/index.html` — los 5 formularios propios (`vender`,
  `tasacion`, `alquilar-mi-propiedad`, `comprar`, `buscar-alquiler`), cada
  uno reemplaza al Google Form del mismo nombre. La carpeta se llamó
  `formularios/` en un primer momento; Cristian pidió acortarla a `form/`
  para que la URL quede más compacta (`csrealestate.com.ar/form/vender/`).
  Ver la sección "Formularios propios" más abajo para todo el detalle.
- `enviar-lead.php` — endpoint único que reciben los 5 formularios. Ver
  esa misma sección.
- `leads/.htaccess` — bloquea el acceso HTTP directo a `leads/leads.jsonl`
  (donde `enviar-lead.php` va agregando cada consulta recibida). El
  `.jsonl` no existe en el repo local — lo crea el propio PHP en el
  servidor la primera vez que alguien envía un formulario.
- `propiedades.php` — sincroniza "Propiedades en venta" con publicaciones
  reales de propiedades.redsuma.com.ar (con caché en `cache/propiedades.json`,
  que tampoco existe en el repo local hasta que PHP lo genera). Ver la
  sección "Sincronización de Propiedades en venta" más abajo. La Política
  de Privacidad **ya no es una página aparte** (`privacidad/index.html` se
  borró) — es un `<dialog>` repetido en cada página, ver esa misma sección
  de formularios para el porqué.
- `propiedades-extra.php` — (2026-10-08) lee del HTML de cada publicación los
  datos "de portal" que el JSON-LD no trae (expensas, estado, orientación,
  superficies, etiquetas tipo "Apto crédito"). Lo carga `propiedades.php`
  dentro de un try/catch y está hecho para fallar en silencio. **Tiene que
  ir en el zip.** Ver "Datos de portal en tarjeta y detalle" más abajo.
- `propiedades/index.html` — (2026-10-08) página "Ver todas las propiedades": el
  listado completo en formato feed, con su propio detalle (fotos con scroll
  nativo, cartelitos, grillas de portal, WhatsApp). Lee el mismo `propiedades.php`
  que el slider de la home. `noindex` por ahora. **Tiene que ir en el zip.** Ver
  "Slider de 7 propiedades..." más abajo.
- `desarrollos.php`, `desarrollos-lib.php`, `desarrollo-extra.php`, `desarrollos/index.html`,
  `desarrollos/ficha/index.html` — (2026-10-08/09) la sincronización con
  sumadesarrollos.com.ar y las dos páginas de "Desarrollos" (lista y ficha de cada obra).
  **Van en el zip** (las tres `.php` juntas), pero **todavía no están enlazadas desde la home**
  (etapa 4 pendiente). Ver "Fuente de los desarrollos: sumadesarrollos.com.ar", etapas 1 a 3.
  Archivos de prueba local que **no** van en el zip: `desarrollos-prueba.json`,
  `desarrollos-extra-prueba/`, `desarrollos-caida.flag` (sólo mientras se prueba).
- `htaccess-cache-bloque.txt` — (2026-10-08) bloque de 5 líneas para **pegar al
  final** del `.htaccess` que ya existe en `public_html` (con `Cache-Control:
  no-cache` para `.html/.css/.js`, para que el navegador siempre revise si hay una
  versión nueva — soluciona "subí el zip y no veo el cambio"). **NO va en el zip y
  NO se sube como archivo**: el `.htaccess` del servidor ya tiene el "Forzar HTTPS"
  (se comprobó que `http://` redirige 301 a `https://`) y reemplazarlo lo sacaría.
  Autorizado por Cristian el 2026-10-08. Después de pegarlo, verificar con un GET
  que la cabecera `Cache-Control: no-cache` aparece en `/` y en `/estilo.css`.
- `serve.ps1` / `.claude/launch.json` — servidor estático local (PowerShell,
  sin dependencias) para previsualizar el sitio completo con rutas e
  incluye resolución de `carpeta/` → `carpeta/index.html`, igual que un
  hosting real. No ejecuta PHP de verdad: `enviar-lead.php` responde con
  su código fuente crudo si se le pide desde acá (para probar el envío
  real de un formulario hace falta Hostinger o PHP: desde el 2026-10-08
  hay un PHP portable en `G:\Workshop Claude\Programas Claude\PHP 8.3.35\`,
  ver "PHP local para probar" más abajo), pero **`propiedades.php` sí tiene una respuesta de
  prueba especial** (con los datos reales de las 4 propiedades de
  Cristian) para poder ver "Propiedades en venta" funcionando en este
  preview sin necesitar PHP — es sólo para visualizar, el archivo real
  `propiedades.php` que se sube a Hostinger no se toca ni depende de esto.
  Excluido del zip, como el resto de `.claude/` y `CLAUDE.md`.
  **Ojo con acentos en este archivo**: Windows PowerShell 5.1 lee un
  `.ps1` sin BOM usando el codepage ANSI del sistema, no UTF-8 — un
  acento escrito bien en el archivo (confirmado con la herramienta
  `Read`) puede salir mal en tiempo de ejecución ("balcón" → "balcÃ³n")
  aunque el archivo en disco esté perfecto. Se le agregó un BOM UTF-8
  explícito (`[System.Text.UTF8Encoding]::new($true)`) para que esto no
  vuelva a pasar — si se edita este archivo con una herramienta que
  reescriba el archivo entero (no un editor que preserve el BOM
  existente), conviene volver a chequear.
- `foto.webp` — **(2026-10-09: reducida a 1000×1250, 65 KB; el original de 1600×2000 / 164 KB está en
  `OLD 8-10-2026\foto.webp`. Sólo se achicó el tamaño —misma imagen, mismo canal alfa, diferencia media de
  0,6/255 contra el original sobre fondo negro, gris y blanco—; se muestra a 342 px de alto como mucho.)**
  Antes: foto de portada, 1600×2000, ~164 KB. **Es el archivo tal cual lo
  mandó Cristian, sin ningún procesamiento propio** — ya venía con canal alfa
  perfecto (fondo transparente prolijo, no blanco). **No volver a correrle un
  flood-fill ni ningún recorte de fondo "por las dudas"**: la vista previa de
  Claude muestra la transparencia como blanco sólido, lo cual en un momento se
  confundió con un fondo blanco real a remover, y ese reprocesamiento innecesario
  (buscaba blanco para hacerlo transparente donde ya era transparente) terminó
  rellenando de negro opaco toda la zona transparente — bug que se vio recién
  varias sesiones después, porque se probó sobre fondo casi negro y no se notaba.
  Antes de tocar esta imagen de nuevo: comprobar con `getImageData` si el archivo
  ya tiene alfa real antes de asumir que hace falta quitarle un fondo. Encuadrada
  de cabeza a la cintura; el recorte final a la altura del pecho lo hace el
  `object-fit:cover` de `.portada`, no la imagen.
- `og.jpg` — 1200×630, miniatura para previews al compartir el link (WhatsApp,
  Instagram, iMessage, Facebook, X). Generada con la foto y la tipografía
  reales del sitio (Chillax + Inter, mismo degradado oscuro con brillo bronce),
  no es un recorte de pantalla — se armó con un `<canvas>` que dibuja fondo,
  foto (con fundido a la izquierda, mismo criterio que `.portada`) y texto.
  Si se cambia `foto.webp`, `og.jpg` NO se actualiza solo: hay que rehacerla
  a mano (o pedirle a Claude que la regenere con la foto nueva).
- `fonts/inter-latin.woff2`, `fonts/chillax-500.woff2` — las tipografías
  auto-hospedadas (ver la sección de Decisiones de diseño para el porqué y
  de dónde salen). Si Hostinger no sirve `.woff2` con el content-type
  correcto por defecto, revisar/agregar la regla en `.htaccess` (hoy no
  hay ninguno en el proyecto).
- `logo-redsuma.png` — isotipo "REDSUMA" recortado a su bounding box real (el archivo
  que pasó Cristian tenía muchísimo margen transparente alrededor). Se muestra en
  `.legal` en su gris original (rgb 63,63,63) — a propósito, porque Cristian lo mandó
  en ese tono para que combine con el color de "Agente inmobiliario" — sólo con
  `filter:brightness(1.4)` para que pese igual que el texto de alrededor, sin
  convertirlo a blanco. `vertical-align:-4px` en `.legal__logo` baja el logo para
  que el renglón grande ("REDSUMA") quede alineado con la base de "Agente
  inmobiliario"; el renglón chico ("CONEXIÓN INMOBILIARIA") queda más abajo,
  a propósito, sin alinear.
- `icono-legal.png` — el ícono original de documento + mazo que pasó Cristian para
  el botón de matrícula (reemplazó a una versión dibujada a mano en SVG que no
  convencía). Recortado a un cuadrado centrado en el centro real del dibujo
  (no en el bounding box crudo, que quedaba con aire de más abajo y lo hacía
  ver descentrado) y pasado a blanco puro con canvas. Usa el mismo tamaño y
  posición que WhatsApp/Email (`.boton__icono`, 34×34) — no tiene ningún
  ajuste especial, a propósito, para que los tres queden parejos.
- `logo-redsuma.webp` / `icono-legal-original.png` — los archivos tal cual los
  mandó Cristian, sin recortar. Quedan como respaldo por si hay que reprocesarlos;
  no los usa la página.

## Estado: **el sitio ya está publicado** en `csrealestate.com.ar` (Hostinger)

Ya no es "antes de publicar" — está en producción y los cambios se van
puliendo ahí en vivo. Cada vez que Claude edita `index.html`, hay que volver
a subirlo a Hostinger (descomprimir `cristian-stedtfeld-web.zip` en
`public_html`) para que el cambio se vea realmente.

### Verificar siempre que el deploy llegó de verdad (hallazgo del 2026-10-08)

**No dar por publicado un cambio sólo porque se subió el zip.** El 2026-10-08,
Cristian subió el zip y reportó "no observo ningún cambio dentro de los
formularios". Se comparó lo que sirve el sitio en vivo (GET con `?cb=<random>`
para saltar cachés, mirando `Last-Modified` y buscando textos que sólo existen
en la versión nueva) y apareció que: la home (`/`), `propiedades.php`,
`propiedades-extra.php` y `enviar-lead.php` **sí** eran los nuevos, pero **los 5
formularios `form/*/index.html` seguían siendo la versión del 2026-09-22**
(`Last-Modified` 13:54 GMT de ese día, igual para los 5): sin las preguntas
nuevas, **y tampoco con ninguno de los arreglos posteriores a esa fecha**: el
del bug de radios (`valorDe`), la atribución gclid/UTM (`csre_atribucion`), el
seguimiento del ícono de WhatsApp del pie y el `<h1>`. Es decir que, según lo
que se ve, **los archivos dentro de carpetas nunca se actualizaron con los zips
posteriores al primer deploy; sólo los de la raíz.** Consecuencias a vigilar
(las campañas `#Search_1/2/3` activas apuntan a `/form/vender/`,
`/form/tasacion/` y `/form/alquilar-mi-propiedad/`): los leads reales de esos
formularios pueden estar guardando la PRIMERA opción de cada grupo de radios en
vez de la elegida, y no estar guardando gclid/UTM. La causa exacta no se pudo
determinar desde afuera (descartado: caché del navegador, caché del CDN —
`X-Hcdn-Cache-Status: DYNAMIC`—, extracción en subcarpeta y archivos con `\`
en el nombre). Hipótesis: el extractor de Hostinger no pisa archivos dentro de
carpetas ya existentes (permisos/propietario distintos desde el primer deploy),
o el deploy se hizo copiando archivos sueltos sin la carpeta `form/`.
- **RESUELTO el mismo día (2026-10-08, ~17:32 hora local)**: Cristian subió
  `formularios-solamente.zip` y se confirmó en vivo que los 5 formularios son
  **idénticos byte a byte** a los locales (con las preguntas nuevas, el arreglo
  de radios, la atribución gclid/UTM, el ícono de WhatsApp y el `<h1>`), y que
  `index.html`, `estilo.css` y las dos fuentes también lo son. La causa de
  fondo del deploy fallido no se llegó a determinar (el zip con carpetas
  explícitas y `/` funcionó); por eso, **verificar siempre en vivo** después
  de cada deploy. Pendiente de Cristian: revisar si los leads reales que
  entraron entre el 22/09 y hoy por vender/tasación/alquilar/comprar quedaron
  con la primera opción de cada grupo de radios en vez de la elegida
  (`leads_privados/leads.jsonl`), porque esos leads se guardaron con el bug.
  *Ojo al comparar*: `Invoke-WebRequest` puede decodificar el cuerpo como
  Latin-1 si el servidor no manda `charset` (el largo en caracteres sale
  igual al largo en bytes y los acentos se ven rotos); comparar siempre los
  **bytes crudos** (`$r.RawContentStream`) contra `ReadAllBytes` del archivo.
- **Cómo verificar** (se puede hacer desde acá, sin pedirle nada a Cristian):
  `Invoke-WebRequest https://csrealestate.com.ar/form/comprar/?cb=<random>` y
  buscar una marca de la versión nueva (`Flipping`, `csre_atribucion`,
  `elementos.length === 1`); comparar `Last-Modified`.
- **Zips**: `cristian-stedtfeld-web.zip` (todo, ahora con entradas de carpeta
  explícitas y separador `/`; antes salía de `Compress-Archive`, que en PS 5.1
  usa `\`) y `formularios-solamente.zip` (sólo `form/`, para probar el deploy
  de carpetas aislado; se puede borrar cuando se resuelva). Ambos excluidos del
  deploy mismo. Si pisar no funciona, el plan B es renombrar la carpeta `form`
  del servidor a `form_viejo` desde el File Manager, extraer el zip, verificar,
  y borrar `form_viejo` (ojo: entre un paso y otro las landings de Ads dan 404).

## Pendientes

1. ~~Reemplazar `GTM-XXXXXXX`~~ / ~~`TUDOMINIO.com.ar`~~ — **hecho**.
2. ~~Subir a Hostinger~~ — **hecho**, el dominio ya resuelve y sirve el sitio.
3. **HTTPS**: el certificado SSL funciona (`https://csrealestate.com.ar` carga
   bien), pero **`http://` (sin la "s") también responde y no redirige solo**
   — por eso el sitio a veces aparece como "No seguro" si alguien entra sin
   escribir el protocolo. Falta que Cristian active **"Forzar HTTPS"** en el
   panel SSL de Hostinger (hPanel). No confirmado todavía si ya lo hizo.
4. ~~Cambiar la URL final en las campañas de Google Ads~~ — **hecho**,
   las 10 campañas de Search ya apuntan a sus rutas correspondientes (ver
   "Google Ads — campañas, presupuesto y reglas de producción"). Sigue
   pendiente el link de la bio de Instagram — no confirmado.
5. ~~En GTM crear el activador/etiqueta de conversión~~ — **hecho**,
   `generate_lead` ya está armado de punta a punta (GTM → GA4 → Google
   Ads, como conversión PRINCIPAL) — ver la misma sección de arriba.
6. Validar la preview del link (ver sección "Preview al compartir el link" más
   abajo) con el Facebook Sharing Debugger antes de mandar el link por WhatsApp
   masivamente — si no, WhatsApp puede cachear una preview vieja/rota para siempre.
   No confirmado si ya se hizo.
7. **Probar en producción los 5 formularios nuevos** (`enviar-lead.php`) y
   la sincronización de propiedades (`propiedades.php`) recién subidos —
   no se pudo probar ninguno de los dos contra un servidor PHP real en
   esta sesión (ver las secciones "Formularios propios" y "Sincronización
   de Propiedades en venta" más abajo, cada una tiene la lista completa
   de qué confirmar). Mientras esto no se confirme, considerar ambos "no
   probados en producción" aunque el frontend de los dos esté verificado
   a fondo.
   ~~**Chequeado en vivo (2026-09-22, temprano)**: daban 404~~ — **esa
   nota quedó vieja dentro de la misma sesión**: más tarde, el mismo día,
   se volvió a chequear en vivo (como parte de la auditoría de
   `GOOGLE_ADS_SITE_AUDIT.md`) y esta vez sí estaba todo desplegado y
   funcionando — `enviar-lead.php` responde `405` a un `GET` (valida
   método correctamente), `propiedades.php` devuelve las propiedades
   reales, y los 5 `/form/*/` responden `200`, con **2 leads de prueba
   reales ya guardados** confirmando que el guardado funciona de punta a
   punta. Cristian subió el zip correcto entre medio. Dar por **probado
   en producción** ambos endpoints — sigue pendiente únicamente lo que
   dice el punto 4 de "Pendientes reales" en "Preparación para Google
   Ads" (confirmar dónde quedó `leads_privados/` en el servidor).

## Decisiones de diseño ya tomadas

Replica la tipografía exacta del Linktree original, medida sobre la página real:

| Elemento | Fuente | Tamaño | Peso | Interlineado |
|---|---|---|---|---|
| `h1` nombre | Chillax | 40px | 500 | 48px |
| `.bio` | Inter | 16px | 500 | 24px |
| `h2` "¿Cómo puedo ayudarte?" | Inter | 14px | 700 | 21px |
| `.boton` | Inter | 14px | 500 | 16.8px (tracking −0.2px) |

Botones: 66px de alto, `border-radius` 16px, borde de 1px.

Desviaciones deliberadas respecto del original:
- El nombre (`h1`) va en peso 500 en vez de 600, a pedido de Cristian (se veía "muy bold").
- El botón de WhatsApp ya no se destaca ni por color ni por tipografía (a pedido de
  Cristian): mismo tamaño/peso de fuente y mismo fondo que el resto de los botones.
  Lo único que lo distingue es un reflejo diagonal en loop (`@keyframes reflejo-whatsapp`)
  que lo cruza cada ~5s, sin recurrir a un color o tamaño distinto.
- Se eliminaron los parámetros `utm_source=linktree` de los links salientes (ya no aplican,
  y Google Forms no los lee de todos modos).
- Los botones son más transparentes que en la primera versión (`--btn-fondo` bajó de
  .045 a .022, `--btn-borde` de .14 a .11), a pedido de Cristian.

**Fondo ambiente** (`.fondo-ambiente`, div fijo justo después de `<body>`, no
pseudo-elemento — así se puede tocar/depurar por separado del resto).
Primera versión: dos luces en las esquinas (bronce arriba a la derecha, borgoña
abajo a la izquierda). Se descartó porque esta página se ve casi siempre en
celular, en una sola columna que ocupa casi todo el ancho — un degradado
pegado a las esquinas queda tapado por los propios botones y no se ve.
Versión actual: **un único foco cálido, grande y centrado arriba** (como luz
de estudio sobre la cabecera/foto), que ilumina toda la columna de contenido
y se apaga en negro limpio hacia abajo; un segundo resplandor borgoña, mucho
más tenue, aparece recién al final de la página. Encima va un grano
fotográfico finísimo (`::after` con un `feTurbulence` en SVG inline,
`mix-blend-mode:overlay`). La opacidad se fue subiendo a pedido de Cristian
en varias pasadas — arrancó en 5%, y terminó en **45%** (`.fondo-ambiente::after{opacity:.45}`)
porque a menos que eso no se notaba lo suficiente. Ese grano lleva una **máscara "en negativo"** (mismas
formas y radios que los dos brillos, con `mask-composite:add,subtract,subtract`)
que lo excluye justo de las zonas de bronce y borgoña — a pedido de Cristian,
para que el grano quede parejo sobre el negro sin ensuciarle el color a esas
dos zonas. `-webkit-mask-image` sin `-webkit-mask-composite` como respaldo:
en Safaris viejos que no soportan `mask-composite`, el grano simplemente se ve
en toda la superficie (degradación segura, no rompe nada). Paleta en `:root` (`--bronce` `#A67C45`, `--borgona`
`#4A0D0D`, `--rojo-profundo` `#6B1010`, `--marron-calido` `#2A1C16`, más los
negros `--neg-profundo`/`--neg-carbon`/`--gris-oscuro`). Nada de
`filter:blur()` en el contenedor — diluía demasiado el color; los
`radial-gradient` con paradas largas ya son suficientemente suaves solos. Es
`position:fixed`, no scrollea con el contenido (es "iluminación del viewport",
no del documento — se ve igual sin importar qué tan abajo se haya scrolleado).

**Botones "glass" (vidrio esmerilado tipo iOS/Control Center)**, a pedido de
Cristian: `.boton`, `.aviso`, `.aviso__ok` y `.redes a` llevan
`backdrop-filter:blur(...) saturate(150%)` (con `-webkit-` para Safari) sobre
`--btn-fondo` semitransparente (subida de opacidad .022→.08 para que el
desenfoque se note), más `box-shadow: inset` arriba en blanco tenue (el "filo"
de luz del vidrio) e inset abajo en negro (para que no se vea plano). Por eso
el fondo ambiente de arriba importa: sin algo de variación detrás, el glass no
tiene nada que refractar y se ve como un rectángulo gris común.

**Fuentes: auto-hospedadas** (`fonts/inter-latin.woff2`, `fonts/chillax-500.woff2`)
— antes se cargaban desde Fontshare/Google Fonts por `<link>`, se cambió a
pedido de Cristian para no depender de una carga externa antes de poder
mostrar texto (mejor para Core Web Vitals, y una cosa menos que se puede
caer si el CDN de turno tiene un mal día). `inter-latin.woff2` es el
archivo variable que Google sirve para el subset "latin" del CSS2 API
(`family=Inter:wght@400;500;600;700`) — los 4 pesos que pide esa URL
apuntan al mismo archivo (es una sola fuente variable con eje de peso), por
eso alcanza con un único `@font-face` con `font-weight:400 700` (rango) en
vez de 4 archivos — confirmado sirviendo: los 4 pesos miden distinto
(`ctx.measureText` con cada peso da un ancho creciente de 400 a 700, no el
mismo valor las 4 veces). El subset "latin" (`U+0000-00FF`) cubre todos los
acentos del español (áéíóúñ¿¡), no hace falta el "latin-ext". Chillax sólo
se usa en el peso 500, un solo archivo directo del API de Fontshare (no es
variable). Los `<link rel="preload">` en el `<head>` reemplazan a los
`<link rel="preconnect">`/`<link rel="stylesheet">` de antes. Si en algún
momento hay que regenerar estos archivos (por ejemplo si se suma un peso
nuevo de Inter que no esté ya cubierto por el rango 400-700), los URLs
reales salen de pedir la hoja de estilos de Google Fonts/Fontshare
(`https://fonts.googleapis.com/css2?family=Inter:wght@...` /
`https://api.fontshare.com/v2/css?f[]=chillax@...`) y bajar el `.woff2`
del bloque `latin` (para Inter) que devuelven.

Portada: la foto se funde con el negro mediante una máscara radial (no lineal) tipo
"spotlight" — cara y torso protagonistas, hombros y costados apagándose hacia los
cuatro bordes, además del fade hacia abajo detrás del nombre. Se calcó la lógica
visual del Linktree original (`linktr.ee/csrealestate.ba`), que usa ese mismo
esquema. Al ser una máscara CSS y no un retoque manual del archivo, cualquier foto
nueva que se ponga en `foto.webp` hereda el mismo tratamiento automáticamente.

El alto de la portada vive en una sola variable, `--portada-alto` (hoy
`clamp(243px, 72vw, 342px)`, bajada dos veces a pedido de Cristian desde el
`clamp(340px,101vw,480px)` original — cada vez ~10-20% menos, misma
proporción). `.portada img` usa `width:auto` (no `width:100%` +
`object-fit:cover`) en **todos** los tamaños de pantalla, no sólo en
desktop: así la imagen nunca se recorta, sólo escala su alto/ancho real
manteniendo la proporción del archivo — es lo que garantiza que se vea
exactamente igual en mobile y en desktop (antes, en mobile la imagen iba
borde a borde con `cover`, y al achicar sólo el alto sin achicar ese ancho
la caja de recorte se volvía "panorámica" y hacía zoom sobre la cara). El
`margin-top` de `.identidad` (la superposición del nombre sobre la foto)
está calculado como `calc(var(--portada-alto) / 380 * -160)` — 160/380 es la
proporción validada con Cristian a foto grande (380px de alto), aplicada al
alto real en cualquier pantalla, para que el nombre quede siempre en el
mismo lugar relativo (sobre la camisa) sin importar cuánto se achique la
foto. **Si se vuelve a tocar el tamaño de la foto, alcanza con cambiar
`--portada-alto`** — el resto se reacomoda solo.

Al scrollear, la portada (`.portada`) baja levemente y se desvanece con `transform`
+ `opacity`, y el brillo dorado de arriba del fondo se apaga mientras el borgoña de
abajo se intensifica (opacity de `.fondo-ambiente__brillo-arriba`/`-abajo`, sobre
`scrollY / (scrollHeight - innerHeight)`, o sea 0% = recién llegado, 100% = al final
de la página). Los dos efectos comparten un único loop de scroll con suavizado tipo
"lerp" (cada frame recorre un 18% de la distancia al valor real) para que se sientan
fluidos aunque el scroll físico llegue a saltos (trackpad, mouse) — a pedido de
Cristian ("que el scroll sea más smooth"). También se agregó `scroll-behavior:smooth`
en `html` (con `scroll-behavior:auto` bajo `prefers-reduced-motion`, junto con el resto
de las animaciones ya desactivadas ahí). El nombre (`h1`) lleva un `text-shadow` muy
sutil para no perder borde cuando pasa por encima de la camisa blanca de la foto.
Los íconos de los botones (WhatsApp, Email, VL Realtor) usan `.boton__icono` (posición
absoluta a la izquierda) para quedar los tres en la misma posición.

**Medidas fluidas en mobile.** Cristian notó que en el celular los botones ocupaban
toda la pantalla y por eso todo "se sentía más grande" que en la versión de escritorio,
donde el `max-width:580px` de `.envoltorio` deja aire a los costados. La solución no
fue tocar el layout (seguiría siendo una sola columna a lo ancho) sino escalar hacia
abajo, con `clamp()`, todo lo que participa de esa sensación de tamaño: alto de botón
(`--boton-alto`), padding horizontal (`--boton-pad-x`), tamaño de fuente de los botones
(`--boton-fs`), tamaño y posición de sus íconos (`--boton-icono`, `--boton-icono-left`,
`--boton-pad-icono`), tamaño de `h2` (`--h2-fs`), separación entre botones
(`--botones-gap`) y tamaño de los círculos/íconos del pie (`--redes-size`,
`--redes-icono`, `--redes-gap`). Todas están definidas en `:root` y llegan a sus
valores de siempre (66px/14px/etc., iguales a los de esta tabla) a partir de
~480-580px de ancho — o sea que el desktop no cambió en nada, sólo el mobile se
achicó proporcionalmente. La única excepción a propósito es `.boton--matricula`,
que mantiene su `font-size:14px` fijo (Cristian pidió específicamente no tocarlo).

**Dirección en el pie.** Debajo de "Agente inmobiliario · REDSUMA" (`.legal`),
una línea nueva `.legal__direccion` con la dirección de Red Suma ("General
Justo José de Urquiza 405, Vicente López.") — misma tipografía (hereda
Inter del `body`, no define `font-family` propia), 1px menos que `.legal`
(10.5px contra 11.5px) y el mismo blanco un toque más oscuro
(`rgba(255,255,255,.28)` contra el `.34` de `.legal`) — mismo criterio de
"achicar y apagar" que ya usaba `.copyright` un escalón más abajo.
`.copyright{margin-top:36px}` (subido en dos pasadas: primero a 20px,
después Cristian pidió "80% más" → 36px) para que quede separado como
bloque aparte de la dirección, no pegado.

## Preview al compartir el link

Lo que se ve al pegar el link en WhatsApp/Instagram/iMessage/Facebook/X sale de
los metatags `og:*` y `twitter:*` en el `<head>` — no tiene nada que ver con
cómo se ve la página en sí:

| Metatag | Contenido actual |
|---|---|
| `og:title` / `twitter:title` | "Cristian Stedtfeld \| Servicios inmobiliarios" |
| `og:description` / `twitter:description` | "Servicios inmobiliarios adaptados a tus necesidades." |
| `og:image` / `twitter:image` | `og.jpg` (1200×630) |
| `og:site_name` | "Cristian Stedtfeld · Red Suma" |
| `og:locale` | `es_AR` |

**Importante para probarlo:** estas plataformas necesitan bajarse `og.jpg` desde
una URL pública — no se puede validar la preview real en local ni antes de que
el dominio esté publicado. Una vez que `csrealestate.com.ar` esté online:

1. Pegar la URL en el **[Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/)**
   y darle "Scrape Again" — esto además sirve para forzar que Facebook/Instagram/WhatsApp
   (comparten el mismo caché) refresquen la preview si ya la habían visto antes con
   datos viejos.
2. Para X/Twitter, el **Card Validator** (`https://cards-dev.twitter.com/validator`,
   a veces requiere estar logueado).
3. Si cambia el texto o la imagen más adelante y alguien ya compartió el link antes,
   **hay que volver a scrapear** con la herramienta de Facebook — si no, mucha gente
   va a seguir viendo la preview vieja indefinidamente (el caché de WhatsApp es el
   más terco).

## Tracking

**Se pasó a usar Google Tag Manager** (decisión de Cristian, revierte lo que
decía antes esta sección). Historia completa por si hace falta entenderla:
al principio Google Ads le había pedido a Cristian instalar `gtag.js` directo
en el `<head>` **sin** pasar por GTM ("no añadir más de una etiqueta de
Google por página"), así que el sitio arrancó con ese tag suelto
(`AW-18445706531`) y sin GTM. Cristian después cambió de idea/etiqueta y
pidió reemplazarlo por un contenedor de GTM — se sacó el `gtag.js` suelto
por completo (sin dejar residuos: se verificó con grep que no quedó ningún
rastro de `AW-18445706531` en el archivo) y se puso el contenedor
`GTM-5JDWTPXN`, con el snippet estándar de Google en los dos lugares de
siempre:

```html
<!-- en el <head>, lo más arriba posible -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5JDWTPXN');</script>

<!-- justo después de <body> -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5JDWTPXN"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
```

**Si en algún momento hay que instalar el tag de Google Ads (`AW-...`) o
cualquier otro tag de Google**, ahora corresponde configurarlo *dentro* del
contenedor de GTM (una etiqueta "Google Ads Conversion Tracking" o "Google
tag" en la interfaz de GTM), no volviendo a pegar un `gtag.js` suelto en el
`<head>` — hacer las dos cosas a la vez es exactamente lo que Google pedía
evitar la primera vez ("no más de una etiqueta de Google por página").

Cada elemento con `data-evento` empuja al `dataLayer` al hacer clic:

```js
{ event: 'click_boton', boton_id, boton_texto, destino }
```

IDs en uso: `tasacion`, `vender`, `alquilar-mi-propiedad`, `comprar`,
`buscar-alquiler`, `whatsapp`, `email`, `matricula`, `whatsapp-icono`,
`email-icono`, `metodo` (el botón "Mi método"). Además, `abrirDetalle()`
dentro de `crearCarrusel()` empuja a mano (sin `data-evento`, ver la
sección de "Mi método"/carrusel más abajo) un evento con `boton_id:
'ver-propiedades'` o `'ver-desarrollos'` cuando se abre el detalle de una
tarjeta.

**Con GTM instalado, este `dataLayer.push` de `click_boton` ya no es
tracking "fantasma"** — es exactamente el diseño para el que se armó desde
el principio (`CLAUDE.md` histórico: "quedó del diseño original pensado
para GTM"). Para convertir cualquiera de estos clics en una conversión
medible: en GTM, crear un **activador de evento personalizado** con nombre
de evento `click_boton` (opcionalmente filtrado por `boton_id` con la
variable de capa de datos `boton_id`), y una **etiqueta de conversión de
Google Ads** (o Meta Pixel, si se agrega su tag en GTM) que se dispare con
ese activador. No hace falta tocar `index.html` para esto — todo se
configura del lado de GTM.

### Limitación conocida e importante

Los formularios viven en Google Forms (`forms.gle`), un dominio ajeno donde no se
puede instalar tracking propio. Por lo tanto **la conversión medible es el clic al
formulario, no el envío**. Sirve para Google Ads, pero el próximo salto de calidad
es migrar los formularios a la propia página con una URL de gracias (`/gracias`),
y ahí sí medir el lead real (con un `gtag('event','conversion',...)` en esa página).

## Analytics / Tracking — estado actual del proyecto (detallado, pegado por Cristian)

*Esta sección la escribió Cristian tal cual, después de terminar de configurar
GTM/GA4/Ads del lado de Google — es la referencia autoritativa y más
actualizada sobre tracking, por encima de la sección "Tracking" de más
arriba (que documenta la historia de la decisión, pero no todo este
detalle). No resumir ni editar el contenido de acá sin que Cristian lo pida.
**Actualizada a su vez por "Google Ads — campañas, presupuesto y reglas
de producción (2026-09-22)" más abajo** — ante cualquier contradicción
puntual entre esta sección y esa (por ejemplo, algo que acá se describe
como "objetivo futuro" y ahí ya aparece configurado/hecho), tiene
prioridad esa sección, por ser la más nueva.*

IMPORTANTE:
La medición de Analytics y Google Ads ya fue configurada y probada.

El tracking forma parte de la funcionalidad de producción del sitio.

NO eliminar, renombrar, "limpiar", simplificar ni refactorizar código relacionado
con Google Tag Manager, dataLayer o eventos analíticos sin revisar primero este documento.

Si existe duda sobre si algo está siendo utilizado por Analytics:
NO modificarlo silenciosamente.

---

### 1. Infraestructura actual

Sitio:
https://www.csrealestate.com.ar

Google Tag Manager:
GTM-5JDWTPXN

Google Analytics 4:
G-4LDVRLTWFC

Google Ads:
AW-18445706531

Google tag asociada:
GT-WPT9PPBN

Nombre visible de la Google tag:
CS | Real Estate GTM

Cuenta de Google Ads vinculada:
CS Real Estate
ID: 921-755-2199

Arquitectura elegida:

WEBSITE
→ Google Tag Manager
→ Google Analytics 4
→ Google Ads

Google Tag Manager es el administrador central del tracking.

NO instalar otro GTM.
NO duplicar gtag.js.
NO agregar GA4 directamente a componentes.
NO agregar conversiones de Google Ads directamente al código sin autorización.
NO cambiar IDs existentes.

### 2. Google Tag Manager

La etiqueta base activa es:

Etiqueta de GA4
→ Google tag
→ G-4LDVRLTWFC
→ Initialization - All Pages

Existe otra etiqueta:

Etiqueta de Google ADS
→ AW-18445706531

Esta etiqueta está PAUSADA intencionalmente.

NO reactivarla automáticamente.

Actualmente la estrategia de conversiones es:

GTM
→ GA4
→ Google Ads

y no:

GTM
→ Google Ads directamente.

### 3. Contrato del dataLayer

La web ya envía interacciones importantes mediante:

```js
window.dataLayer = window.dataLayer || [];

window.dataLayer.push({
  event: 'click_boton',
  boton_id: 'IDENTIFICADOR',
  boton_texto: 'TEXTO'
});
```

Este contrato es crítico.

Los nombres:

event
boton_id
boton_texto

NO deben cambiar.

### 4. Variables que Google Tag Manager espera

Existen dos Data Layer Variables:

DLV - boton_id
→ Data Layer Variable
→ Version 2
→ variable: boton_id

DLV - boton_texto
→ Data Layer Variable
→ Version 2
→ variable: boton_texto

También se utiliza:

Page URL

Los parámetros enviados posteriormente a GA4 son principalmente:

button_id
button_text
page_location

NOTA:
En el dataLayer se llaman `boton_id` y `boton_texto`.
En GA4 se envían como `button_id` y `button_text`.

No confundirlos.

### 5. Evento base del sitio

La mayoría de los CTAs relevantes generan:

event = click_boton

Google Tag Manager identifica luego la acción concreta según:

boton_id

Ejemplo:

```js
dataLayer.push({
  event: 'click_boton',
  boton_id: 'whatsapp',
  boton_texto: '¡Hablemos por WhatsApp!'
});
```

La web NO debe depender de que GTM lea el HTML o el href para saber qué ocurrió.

Siempre que sea posible, mantener la comunicación explícita por dataLayer.

### 6. Tracking de WhatsApp

Actualmente existen distintos botones/contextos de WhatsApp.

boton_id reconocidos:

whatsapp
whatsapp-icono
consulta-desarrollo
consulta-propiedad

Todos terminan enviando a GA4:

click_whatsapp

El contexto se conserva mediante:

button_id
button_text
page_location

Ejemplos:

```
event: click_boton
boton_id: whatsapp

event: click_boton
boton_id: whatsapp-icono

event: click_boton
boton_id: consulta-desarrollo

event: click_boton
boton_id: consulta-propiedad
```

IMPORTANTE:
Aunque todos puedan terminar en wa.me, sus `boton_id` NO deben unificarse
ni cambiarse arbitrariamente porque permiten saber desde qué parte del sitio
se originó el contacto.

El ícono flotante puede tener `boton_texto` vacío.
Eso es válido.

### 7. Tracking de navegación / interés

Existen además los siguientes IDs:

boton_id: ver-propiedades
→ GA4 event: click_ver_propiedades

boton_id: ver-desarrollos
→ GA4 event: ver_desarrollos

boton_id: metodo
→ GA4 event: ver_mimetodo

Estos eventos son señales de navegación/interés.

Actualmente NO son conversiones principales de Google Ads.

NO renombrarlos sin actualizar coordinadamente:

- código web
- GTM
- GA4
- Google Ads si eventualmente se utilizan allí

### 8. Tracking de formularios actual

Actualmente los formularios están alojados en Google Forms.

La web mide solamente el clic que abre cada formulario.

boton_id existentes:

tasacion
vender
alquilar-mi-propiedad
comprar
buscar-alquiler

Todos envían actualmente a GA4:

click_form

Ejemplo:

```
event: click_boton
boton_id: vender
→ GTM
→ GA4 event: click_form
```

IMPORTANTE:

click_form significa:

"El usuario hizo clic para abrir el formulario."

NO significa:

"El usuario envió el formulario."

Por lo tanto:

click_form != generate_lead

Nunca tratar automáticamente click_form como un lead confirmado.

### 9. Eventos GA4 actuales

Actualmente GTM envía, entre otros:

click_whatsapp
click_form
click_ver_propiedades
ver_desarrollos
ver_mimetodo

Los eventos personalizados incluyen normalmente:

button_id
button_text
page_location

No eliminar estos parámetros.

### 10. Configuración de GA4

GA4 Measurement ID:

G-4LDVRLTWFC

La medición mejorada automática de GA4 fue DESACTIVADA intencionalmente.

Motivo:
Se prefirió controlar explícitamente los eventos desde GTM y evitar:

- clicks automáticos difíciles de interpretar
- duplicaciones
- form_start automáticos
- form_submit automáticos
- eventos generados sin control

También fueron eliminados eventos personalizados antiguos que se habían creado
directamente dentro de GA4 a partir del evento automático `click`.

La fuente principal de tracking personalizado debe ser GTM.

NO volver a activar Enhanced Measurement ni recrear eventos automáticos
sin revisar primero el impacto.

### 11. Dimensiones personalizadas de GA4

Se crearon:

Button ID
Ámbito: Evento
Parámetro: button_id

Button Text
Ámbito: Evento
Parámetro: button_text

Esto permite analizar los CTAs según contexto sin crear un evento diferente
para cada botón.

### 12. Eventos clave de GA4

Actualmente fueron configurados como eventos clave:

click_whatsapp
click_form

`purchase` también puede aparecer como evento clave predeterminado de GA4.
No es utilizado actualmente por este sitio.

### 13. Vinculación GA4 ↔ Google Ads

La propiedad GA4 está vinculada correctamente con:

Google Ads
Cuenta: CS Real Estate
ID: 921-755-2199

El auto-tagging de Google Ads está ACTIVADO.

Por lo tanto Google Ads puede utilizar GCLID y atribuir correctamente tráfico
proveniente de anuncios.

### 14. Conversiones actuales en Google Ads

Se crearon conversiones provenientes de GA4 para:

click_whatsapp
click_form

Fuente:
Google Analytics 4

Ambas deben mantenerse como:

SECUNDARIAS

y no como acciones principales.

Motivo:

click_whatsapp
= intención de iniciar contacto

pero no necesariamente:
= contacto real

click_form
= intención de abrir formulario

pero no:
= formulario enviado

Configuración deseada:

click_whatsapp
- secundaria
- recuento: una conversión
- atribución: basada en datos

click_form
- secundaria
- recuento: una conversión
- atribución: basada en datos

Estas conversiones sirven para observación y análisis.

NO deben ser la señal principal usada para optimización de campañas.

### 15. Objetivo futuro principal: generate_lead

El próximo objetivo del proyecto es medir un lead REAL.

Evento previsto:

generate_lead

Debe dispararse ÚNICAMENTE cuando un formulario haya sido enviado
correctamente y la aplicación haya confirmado el envío.

NO dispararlo al:

- abrir el formulario
- hacer clic en enviar
- comenzar a completar
- enfocar un campo

Debe dispararse después de una confirmación real de éxito.

Arquitectura objetivo:

Usuario
→ formulario
→ envío correcto
→ backend/API confirma
→ dataLayer.push(generate_lead)
→ GTM
→ GA4
→ Google Ads

### 16. Futura migración de Google Forms

Actualmente existen cinco Google Forms externos.

La idea futura es migrarlos a formularios propios dentro de:

csrealestate.com.ar

Posibles tipos:

vender
comprar
alquilar_propiedad
buscar_alquiler
tasacion

La web debería poder enviar algo equivalente a:

```js
window.dataLayer.push({
  event: 'generate_lead',
  lead_type: 'vender'
});
```

Ejemplos posibles:

lead_type = vender
lead_type = comprar
lead_type = alquilar_propiedad
lead_type = buscar_alquiler
lead_type = tasacion

IMPORTANTE:
El dataLayer.push de generate_lead debe ejecutarse SOLO después de recibir
confirmación de que los datos fueron guardados/enviados correctamente.

### 17. Google Ads — objetivo futuro

Cuando `generate_lead` esté funcionando:

GA4:
generate_lead
→ marcar como evento clave

Google Ads:
generate_lead
→ crear conversión
→ PRINCIPAL
→ recuento: una conversión

La intención es que Google Ads termine optimizando hacia:

LEADS REALES

y no hacia:

clics en botones.

### 18. Enhanced Conversions

Todavía NO fue implementado.

Será una etapa posterior.

Cuando los formularios sean propios de la web, se evaluará implementar
Enhanced Conversions for Leads utilizando datos propios del formulario,
por ejemplo:

- email
- teléfono

No implementar hasta terminar correctamente `generate_lead`.

### 19. Reglas para modificar botones

Antes de modificar cualquier CTA existente:

1. Buscar si tiene `dataLayer.push`.
2. Identificar el `event`.
3. Identificar `boton_id`.
4. Identificar `boton_texto`.
5. Preservar exactamente la semántica.
6. Mantener tracking después del cambio.
7. Probar con GTM Preview / Tag Assistant.

Un cambio visual NO autoriza cambiar tracking.

Ejemplos de cambios que NO deben romper Analytics:

- cambiar estilos
- cambiar componente
- cambiar layout
- agregar animaciones
- mover el botón
- refactorizar JSX/HTML
- reutilizar componentes
- cambiar iconografía

### 20. Reglas para nuevos botones

Si se agrega un nuevo CTA comercial importante, considerar agregar:

```js
window.dataLayer = window.dataLayer || [];

window.dataLayer.push({
  event: 'click_boton',
  boton_id: 'identificador-estable',
  boton_texto: 'Texto visible'
});
```

Los nuevos boton_id deben ser:

- descriptivos
- minúsculas
- estables
- sin depender del copy visible
- consistentes con IDs existentes

Antes de crear uno nuevo, verificar si existe ya una categoría equivalente.

### 21. Caché / debugging

Durante la implementación se detectó que caché vieja puede hacer parecer
que una modificación de GTM no funciona.

Antes de modificar tracking por un supuesto error:

1. limpiar caché
2. cerrar sesión Preview anterior
3. iniciar nueva sesión de GTM Preview
4. probar nuevamente
5. revisar Tag Assistant
6. revisar GA4 DebugView

No asumir inmediatamente que el código está mal.

### 22. Testing obligatorio

Después de cualquier cambio relacionado con tracking:

Google Tag Manager:
→ Vista previa

Tag Assistant:
→ verificar click_boton
→ verificar boton_id
→ verificar etiqueta activada

GA4:
→ DebugView
→ verificar evento recibido
→ verificar parámetros

No publicar modificaciones de tracking sin probar.

### 23. Backup

Existe un export JSON del contenedor de Google Tag Manager.

Contenedor:
GTM-5JDWTPXN

Versión exportada:
2

Nombre:
Tracking 1.0

Ese JSON debe conservarse como respaldo de la configuración funcional.

Idealmente mantener futuras exportaciones dentro del repositorio:

docs/analytics/

o equivalente.

### 24. Regla crítica para Claude

Analytics tracking is production functionality.

Nunca considerar código de analytics como:

- dead code
- cleanup
- telemetry innecesaria
- código redundante

sin verificar previamente cómo lo utiliza GTM.

Si Claude considera que una llamada a:

dataLayer
click_boton
boton_id
boton_texto
generate_lead

puede eliminarse o modificarse, debe informar primero y solicitar autorización.

NO modificar silenciosamente.

## Google Ads — campañas, presupuesto y reglas de producción (2026-09-22)

*Mergeado desde `CLAUDE_GOOGLE_ADS_TRACKING_UPDATE_2026-09-22.md`, un
archivo aparte que Cristian preparó tras terminar de armar la estructura
de campañas de Search en Google Ads. Junto con la sección "Analytics /
Tracking — estado actual del proyecto" de más arriba, es la referencia
autoritativa sobre Google Ads/Analytics/tracking/formularios/landings —
**por ser la más nueva de las dos, esta sección tiene prioridad ante
cualquier contradicción puntual** (por ejemplo, algo que la sección de
Analytics describe como "objetivo futuro" y acá ya aparece configurado).
No resumir ni editar el contenido de acá sin que Cristian lo pida.*

**Regla general, igual que en la sección de Analytics de más arriba**:
Google Ads/GTM/GA4/formularios/tracking son funcionalidad de producción,
no algo descartable como "dead code" o "cleanup" — ver esa sección para
el detalle completo de qué no tocar sin avisar primero.

### Estructura de campañas en Google Ads

10 campañas de Search nuevas + 1 Performance Max histórica. El estado
Enabled/Paused real vive en Google Ads, no acá — esta tabla es la
intención al lanzar (2026-09-22), puede haber cambiado desde entonces.
**No activar/pausar campañas ni cambiar presupuestos desde código** —
son decisiones de Cristian, se toman en la interfaz de Google Ads.

| Campaña | Landing actual | Estado inicial | Presupuesto |
|---|---|---|---|
| `#Search_1_vendedores` | `/form/vender/` | Activa (prioritaria) | ARS 2.000/día |
| `#Search_2_valor_propiedad` | `/form/tasacion/` | Activa (prioritaria) | ARS 1.200/día |
| `#Search_3_propietarios_alquiler` | `/form/alquilar-mi-propiedad/` | Activa (prioritaria) | ARS 800/día |
| `#Search_4_compradores` | `/form/comprar/` | Pausada | — |
| `#Search_5_inquilinos` | `/form/buscar-alquiler/` | Pausada | — |
| `#Search_6_marca` | `/` (home) | Pausada | — |
| `#Search_7_locales_propietarios` (dueño de local que quiere vender/alquilarlo) | sin landing dedicada — usa los formularios generales | Pausada | — |
| `#Search_8_locales_busqueda` (quien busca comprar/alquilar un local) | sin landing dedicada — usa los formularios generales | Pausada | — |
| `#Search_9_desarrollos` | `/` (home) — sin landing dedicada | Pausada | — |
| `#Search_10_inversion` | `/` (home) — sin landing dedicada | Pausada | — |
| `Campaign #1` (Performance Max, histórica) | — | Pausada | — |

Total previsto de lanzamiento: **ARS 4.000/día (~ARS 121.600/mes)**,
sólo entre las 3 campañas prioritarias. Prioridad estratégica declarada:
**vendedores > valor de propiedad/tasación > propietarios que alquilan**
— es una hipótesis comercial inicial; una vez que haya datos reales
(gasto, CTR, CPC, términos de búsqueda, `generate_lead`, costo por lead,
calidad real del lead), las decisiones de dónde invertir más deben
basarse en eso, no en esta prioridad de arranque.

`#Search_7_locales_propietarios` y `#Search_8_locales_busqueda` están
separadas a propósito (propietario de un local ≠ quien busca comprar/
alquilar uno) — no fusionarlas. Ídem `#Search_9_desarrollos` y
`#Search_10_inversion`: quedan pausadas hasta tener una landing
específica (hoy no existe, ver "Landings faltantes" en
`GOOGLE_ADS_SITE_AUDIT.md`) o una decisión explícita de Cristian de
lanzarlas igual apuntando a la home. `Campaign #1` (Performance Max) es
la cuenta histórica previa a esta reestructuración — antes tenía un solo
grupo con ~98 keywords de intenciones mezcladas, Search Partners y AI Max
activados, y apuntaba al viejo formulario alojado en Google (Google-hosted
Lead Form) — no reactivarla sólo porque existe; antes de evaluarla de
nuevo, revisar `generate_lead`, calidad real de leads, assets, geografía
y el desempeño de las campañas de Search.

### Configuración de Search

```text
Red: Google Search (sin red de Search Partners, inicialmente OFF)
Display Network: OFF
AI Max: OFF inicialmente
Final URL Expansion: OFF
Broad Match: OFF inicialmente — palabras clave en Frase + Exacta
Estrategia de pujas: Maximizar conversiones
CPA objetivo: ninguno inicialmente
CPC manual: NO
```

No agregar puja manual (CPC/CPM/CPV) sólo para hacer desaparecer
warnings de Google Ads Editor.

### Ubicaciones

Las campañas de Search nuevas heredaron los dos radios de la campaña
Search original — no reemplazar por una geografía inferida del código o
de las direcciones que aparecen en el sitio:

```text
Radio 1: 6 km — lat -34.590022, long -58.484170
Radio 2: 6 km — lat -34.495426, long -58.483183
```

Método de ubicación: "Location of presence or Area of interest". La
Performance Max histórica tenía ubicaciones distintas — no mezclarlas
automáticamente con las de Search.

### Conversiones configuradas en Google Ads

**Principal** — ya configurada y en uso (esto era "objetivo futuro" en
la sección de Analytics de más arriba; ya está hecho):

```text
Evento: generate_lead
Categoría: Envío de formularios para clientes potenciales
Optimización: PRINCIPAL
Recuento: UNA
Fuente: Google Analytics (GA4)
Atribución: Basada en datos
```

`generate_lead` es la señal que debe usar Smart Bidding para optimizar
— no `click_whatsapp` ni `click_form`.

**Secundarias** (quedan así a propósito, no pasarlas a principal sólo
para sacar un warning — ver más abajo):

```text
click_whatsapp — SECUNDARIA, recuento UNA
click_form     — SECUNDARIA, recuento UNA
```

Motivo: un clic a WhatsApp es intención de contacto, no contacto
confirmado; un clic que abre un formulario es intención de completarlo,
no un envío real. Sirven para observación/análisis, no como señal
principal de optimización de campañas.

**Warnings esperables en Google Ads, que NO hay que "solucionar"
rompiendo la estrategia**:
- *"Configuración errónea"* en los objetivos "Contacto"/"Interacción" —
  pasa porque esos objetivos sólo contienen las conversiones secundarias
  y ninguna campaña puja por ellas todavía. No es un error real.
- *"Termina de configurar el seguimiento de conversiones"* — puede
  aparecer porque `generate_lead` es reciente y todavía puede no haber
  conversiones atribuidas a clics de anuncios (una prueba manual genera
  `generate_lead` en GA4, pero no necesariamente una conversión atribuida
  en Google Ads, si no vino de un clic real de un anuncio).

Antes de "arreglar" cualquier warning de Ads/Ads Editor: distinguir si es
un warning real o sólo una recomendación, si de verdad bloquea publicar
algo, y si contradice una decisión ya tomada a propósito (como las dos de
arriba). No perseguir el 100% de Optimization Score si empeora la
estrategia.

### GTM — variables y tag de `generate_lead`

Adicional a `DLV - boton_id` / `DLV - boton_texto` (ver sección de
Analytics de más arriba), ahora también existen:

```text
DLV - lead_type  → variable de capa de datos: lead_type
DLV - form_name  → variable de capa de datos: form_name
```

Con el activador `Custom Event - generate_lead` (event = `generate_lead`)
disparando la etiqueta `GA4 - generate_lead`, que manda a GA4:

```text
event_name = generate_lead
lead_type = {{DLV - lead_type}}
form_name = {{DLV - form_name}}
page_location = {{Page URL}}
```

### Mapa completo campaña → landing

```text
#Search_1_vendedores          → /form/vender/
#Search_2_valor_propiedad     → /form/tasacion/
#Search_3_propietarios_alquiler → /form/alquilar-mi-propiedad/
#Search_4_compradores         → /form/comprar/
#Search_5_inquilinos          → /form/buscar-alquiler/
#Search_6_marca               → / (home)
#Search_7_locales_propietarios → formularios generales (sin landing dedicada)
#Search_8_locales_busqueda    → formularios generales (sin landing dedicada)
#Search_9_desarrollos         → / (home, sin landing dedicada)
#Search_10_inversion          → / (home, sin landing dedicada)
```

Google Ads **ya apunta directamente a estas rutas** — no cambiarlas sin
avisar y coordinar: si hace falta, primero crear/probar la landing nueva
y recién después actualizar la URL en Google Ads (nunca al revés). Un
cambio de ruta sin coordinar rompe campañas activas.

### Bug de radio buttons — mencionado acá también, YA CORREGIDO

Este archivo (fechado 2026-09-22) describía como pendiente-a-verificar el
mismo bug de `valorDe()` con radios que ya está documentado y **arreglado**
más abajo, en "Preparación para Google Ads" → "Bug de `valorDe()` en
radios". La regla que deja este archivo sigue siendo válida hacia
adelante: antes de tocar la lógica de armado del payload de cualquier
formulario, confirmar que ese arreglo sigue presente (`[name]:checked`
para radios, no el primer elemento del grupo) y no revertirlo; si alguna
vez se detecta sin corregir, arreglarlo y probar explícitamente con una
opción que NO sea la primera de cada grupo, no sólo con la primera.

### Seguridad de leads y atribución UTM/gclid — mencionadas acá también, YA IMPLEMENTADAS

Este archivo también describe, como reglas a futuro, dos cosas que en
esta misma sesión de trabajo ya se implementaron (ver "Preparación para
Google Ads" más abajo para el detalle completo de cada una):

- **Que los leads no queden en un archivo accesible públicamente por
  URL** — hecho: `enviar-lead.php` guarda en `leads_privados/`, fuera de
  `public_html` (pendiente de confirmar en Hostinger que la carpeta se
  creó donde corresponde, ver esa sección).
- **Que la web lea/conserve `gclid`/`gbraid`/`wbraid` y los `utm_*` y los
  mande junto con el lead** — hecho: se guardan en `localStorage` (90
  días) y viajan en el `POST` de los 5 formularios, nunca al `dataLayer`.

La regla de este archivo sigue aplicando hacia adelante igual: si en el
futuro se toca esa lógica, no eliminarla, y si por algún motivo no
estuviera (no debería pasar, ya está hecho), tratarlo como mejora
pendiente a preguntar — nunca improvisar una implementación nueva en
medio de una tarea no relacionada.

### Negative keywords y archivos de Google Ads

Paquete final: `GoogleAds_CS_Real_Estate_Search_Package_FIXED.zip`, con
`01_UPDATE_Search_1_Vendedores.csv`, `02_NEW_Search_Campaigns.csv`,
`03_NEGATIVE_KEYWORDS_CORRECTED.csv` / `03_NEGATIVE_KEYWORDS_PASTE.txt`,
`04_CAMPAIGN_PLAN.txt`, `README_IMPORTACION_GOOGLE_ADS.txt` y
`CS_Real_Estate_Logo_1x1.png`. **Obsoletos, no usar**:
`03_NEGATIVE_KEYWORDS.csv` (versión vieja, Ads Editor había omitido 105
filas al importarla) ni `GoogleAds_CS_Real_Estate_Search_Package.zip`
(paquete sin el "FIXED"). Se agregaron ~105 keywords negativas a nivel
de campaña (`Criterion Type = Campaign negative`). Estos archivos viven
fuera de este proyecto (son de Google Ads, no del sitio) — se menciona
acá sólo como referencia si hace falta ubicarlos. Futuras negativas
deben salir de Search Terms reales (consultas irrelevantes, búsquedas de
empleo, cursos/carrera, software/CRM, verticales ajenas al negocio) — no
generarlas especulativamente desde código.

### Datos de negocio

- Nombre comercial en Google Ads: **CS Real Estate**.
- Logo: Cristian reemplazó el logo anterior de la cuenta de Google Ads
  por uno nuevo ("CS. REAL ESTATE") — esto es sólo un asset de la cuenta
  de Ads, no implica cambiar el branding del sitio en sí.
- Teléfono para el recurso de llamada de Google Ads: **011 6695-1945**
  (formato local argentino de discado — probablemente el mismo número de
  WhatsApp que ya usa el sitio, `+54 9 11 6695-1945` / `5491166951945`,
  escrito distinto para una llamada de voz en vez de un link de WhatsApp;
  no confirmado con Cristian si son estrictamente el mismo número).

### Remarketing y Enhanced Conversions / CRM — pendientes, no implementar todavía

- **Remarketing**: no implementado. No agregar scripts arbitrarios. Si se
  implementa en el futuro: revisar la política de Google Ads para el
  rubro (incluye vivienda), no usar atributos personales sensibles, usar
  sólo audiencias compatibles con esas políticas.
- **Enhanced Conversions / CRM**: no implementado. Objetivo a futuro,
  encadenar `generate_lead` → `qualified_lead` → `converted_lead`, y
  poder cruzar campaña/keyword/lead/calidad/captación/operación. Si se
  implementa: nunca mandar PII en parámetros normales de GA4, usar el
  mecanismo específico de Google para esto (hashing del lado del
  cliente/servidor, no un parámetro de evento suelto), y preservar
  consentimiento/privacidad. No implementar ninguna de las dos cosas
  hasta que Cristian lo pida explícitamente.

### Qué mirar antes/después de tocar una página que recibe tráfico de Ads

**Antes de editar**: identificar si la página recibe tráfico de una
campaña (ver el mapa de arriba), cuál es su formulario/CTA, buscar
`dataLayer`/`data-evento`/`boton_id`/`generate_lead` en su código,
identificar su `lead_type`, su endpoint, y cómo maneja éxito/error y los
parámetros de atribución.

**Después de editar**: probar desktop y mobile, probar el envío
completo, confirmar que el mail/almacenamiento sigue funcionando,
confirmar la pantalla de "¡Gracias!", confirmar que `generate_lead` se
sigue disparando (una sola vez, sin duplicarse), y que los query params
de campaña (utm/gclid) no rompen la página.

**Principio de continuidad** — antes de un cambio significativo,
preguntarse: ¿puede cambiar la landing que usa una campaña?, ¿puede
romper una conversión?, ¿puede romper un `boton_id`?, ¿puede romper el
`dataLayer`?, ¿puede romper `generate_lead`?, ¿puede perder atribución?,
¿puede exponer datos personales? Si la respuesta es "sí" o "no estoy
seguro": frenar, explicar el riesgo y pedir autorización antes de
implementar — mismo criterio que ya rige para todo el proyecto.

## Ads / Tracking — Guardrails (2026-09-23)

*Mergeado desde `CLAUDE_ADS_TRACKING_GUARDRAILS_2026-09-23.md`, un
archivo aparte que Cristian preparó. Junto con "Analytics / Tracking —
estado actual del proyecto" y "Google Ads — campañas, presupuesto y
reglas de producción (2026-09-22)" de más arriba, es la referencia
autoritativa sobre Ads/GTM/GA4/Meta/formularios/dataLayer/landings/
conversiones — **por ser la más nueva de las tres, esta sección tiene
prioridad ante cualquier contradicción puntual** con esas dos. No
resumir ni editar el contenido de acá sin que Cristian lo pida.*

**Regla general, misma de siempre**: tracking/Ads/GTM/GA4/Meta/
formularios son funcionalidad de producción, nunca "código muerto" a
limpiar — ver las dos secciones de arriba para el detalle ya
documentado. Esta sección agrega, sobre todo, **la pata de Meta Ads**
(que las dos secciones anteriores no cubrían) y deja más explícito el
protocolo de "avisar antes de tocar algo que pueda afectar tracking o
una landing de Ads".

### Meta Ads — pata nueva de la arquitectura

La arquitectura de tracking ya no es sólo "WEBSITE → GTM → GA4 → Google
Ads" (como dice la sección de Analytics de más arriba) — ahora GTM
también manda a Meta:

```text
WEB
→ GTM (GTM-5JDWTPXN)
   ├→ GA4 (G-4LDVRLTWFC) → Google Ads (cuenta CS Real Estate, 921-755-2199)
   └→ Meta Dataset "Datos web csrealestate.com.ar" (1586039593247372)
      → Meta Ads, cuenta "IG Real Estate" (2105334063528925)
```

Coincide con el Pixel de Meta que se agregó como tag "HTML personalizado"
dentro de este mismo contenedor de GTM (activador All Pages) — ver el
pedido de Cristian del 2026-09-22 y los pasos que se le dieron para
armarlo del lado de GTM (Claude no tiene acceso a esa cuenta para
configurarlo, así que esa parte la hizo Cristian). **No instalar una
segunda copia de GTM, GA4 o Meta Pixel** — mismo criterio que ya regía
para GTM/GA4 solos.

**Eventos que recibe Meta** (vocabulario propio, distinto del de GA4):

```text
PageView
Contact           ← desde los 4 boton_id de WhatsApp (ver más abajo)
Lead              ← el equivalente de generate_lead, la conversión real
click_form
click_ver_propiedades
ver_desarrollos
ver_mimetodo
```

`Lead` en Meta cumple el mismo rol que `generate_lead` en GA4/Google
Ads: la conversión real, disparada sólo tras la confirmación del
backend — **no usar `click_form` como sustituto de un lead real**, ni en
Meta ni en Google Ads, mismo principio que ya aplicaba de este lado
(`click_form != generate_lead`, ver sección de Analytics de más arriba).

**WhatsApp → Meta usa 4 activadores separados, uno por `boton_id`**
(`whatsapp`, `whatsapp-icono`, `consulta-propiedad`,
`consulta-desarrollo`), los 4 mandando `Contact` — no consolidarlos en
uno solo ni cambiar esta estructura salvo pedido explícito de Cristian y
prueba completa. Mismo espíritu que ya decía la sección de Analytics
para el lado de GA4 ("sus `boton_id` NO deben unificarse... permiten
saber desde qué parte del sitio se originó el contacto").

**Caché de Meta Events Manager**: durante la implementación, algunos
eventos tardaron en aparecer en Events Manager hasta limpiar la caché
del navegador — el tracking en sí funcionaba bien, era sólo demora de
visualización. **No agregar delays ni hacks de navegación por WhatsApp
sólo por esto** — mismo criterio que ya aplicaba para no "arreglar" un
falso problema de caché de GTM (ver "Caché/debugging" en la sección de
Analytics).

### `boton_id` — lista consolidada (une las de arriba + `privacidad`)

La sección de Analytics y la de campañas ya traían la mayoría de estos;
esta lista los une con `privacidad` (el link del pie que abre el modal
de Política de Privacidad, `data-evento="privacidad"`), que existía en
el código pero no estaba en ninguna lista consolidada hasta ahora:

```text
whatsapp, whatsapp-icono, consulta-propiedad, consulta-desarrollo,
ver-propiedades, ver-desarrollos, metodo,
tasacion, vender, alquilar-mi-propiedad, comprar, buscar-alquiler,
email, email-icono, matricula, privacidad
```

El texto visible (`boton_texto`) puede cambiar libremente; el `boton_id`
en sí NO, sin revisar primero cómo lo usa GTM/GA4/Meta.

### Protocolo reforzado: avisar ANTES de tocar tracking o una landing de Ads

**Cristian lo pidió también directo en el chat, no sólo en este
archivo**: de ahora en más, antes de cualquier modificación que pueda
afectar tracking o una landing usada por Ads, hay que **avisar qué se
puede romper y pedir confirmación antes de implementar** — no alcanza
con documentarlo acá, hay que efectivamente frenar y preguntar en el
momento, en cualquier sesión futura.

Antes de tocar cualquier página, revisar:
1. ¿Recibe tráfico de Google Ads o Meta Ads? (ver el mapa
   campaña→landing de la sección de arriba)
2. ¿Qué eventos dispara?
3. ¿Tiene `dataLayer.push`? ¿Qué `boton_id` usa?
4. ¿Tiene formulario? ¿Qué `lead_type` usa?
5. ¿Acepta query strings/UTMs/gclid?
6. ¿El cambio puede romper una conversión o la atribución?

Si la respuesta a la 6 es "sí" o "no estoy seguro": frenar, explicar el
riesgo y pedir autorización antes de implementar — esto ya estaba como
"Principio de continuidad" en la sección de arriba; esta actualización
lo reafirma como protocolo obligatorio, no sólo recomendado.

**Después de modificar**, además del testing ya documentado arriba
(desktop/mobile, envío completo, "¡Gracias!", `generate_lead`,
UTMs/gclid, GTM Preview, GA4 DebugView), agregar **Meta Test Events** a
la lista — no alcanza con confirmar sólo el lado de Google.

**No afirmar que el tracking sigue funcionando si no se probó** — ni
para Google ni para Meta.

**Al modificar tracking/rutas/formularios/eventos/Pixel/GTM/GA4/Ads/
atribución**, recordarle a Cristian: *"Este cambio afecta la
documentación de Ads/Tracking. Conviene exportar GTM y actualizar el
Master."* (el "Master" es este mismo `CLAUDE.md`, más el export de GTM
que ya se menciona en "Backup" de la sección de Analytics).

### No tocar sin autorización (lista ampliada)

Súmase a la lista ya vigente (`GTM-5JDWTPXN`, `G-4LDVRLTWFC`,
`AW-18445706531`, `GT-WPT9PPBN`, `generate_lead`, `lead_type`,
`form_name`, `boton_id`, las rutas de los 5 formularios): el dataset de
Meta, **`1586039593247372`**.

### Principio

Una mejora visual NO justifica romper medición. Una refactorización NO
justifica renombrar eventos. Si algo "parece redundante" pero participa
en GTM/GA4/Meta/Ads, tratarlo como dependencia externa hasta demostrar
lo contrario — mismo espíritu que el "Principio de continuidad" de la
sección de arriba, dicho más corto.

## Barra de scroll de las tarjetas (2026-10-08)

El `<dialog>` (clase `.aviso`: detalle de propiedad, matrícula, privacidad) hace
scroll por sí solo cuando el contenido no entra en pantalla, y su barra nativa
(gris-blanca en Windows/Chrome) resaltaba mucho sobre el vidrio oscuro — Cristian
pidió que fuera de colores de la web. En `estilo.css`, justo después de `.aviso`:
`scrollbar-width:thin; scrollbar-color:rgba(166,124,69,.55) transparent` (el
bronce de la marca a media opacidad, carril transparente). Se aplica también a
los `<textarea>` de los formularios (`.form-campo`). Para navegadores más viejos
que no entienden esas propiedades hay un respaldo `::-webkit-scrollbar` dentro de
`@supports not (scrollbar-color:auto)` (si se mezclan los dos, Chrome ignora los
pseudo-elementos — por eso están separados). En el celular las barras son
flotantes del sistema y esto no las cambia. **No se tocó** la barra de scroll de
la página entera (la del `<html>`), porque Cristian pidió sólo las de las
tarjetas; si también resalta, se puede estilar con `html{scrollbar-color:...}`.
Verificado en el navegador: el detalle de una propiedad scrollea con la barra
fina en bronce. Es sólo CSS: no toca tracking, ni formularios, ni Ads.

**Actualización 2026-10-09 (pedido de Cristian: "el scroll me lo seguís haciendo blanco; tiene que estar la
barra de cada parte de la página, igual en mobile y en desktop")**: la regla pasó a `*{scrollbar-width:thin;
scrollbar-color:rgba(166,124,69,.55) transparent}` en `estilo.css` (con el respaldo `*::-webkit-scrollbar` dentro
de `@supports not (scrollbar-color:auto)`), así cubre TODO: la página entera (`<html>`) en `/propiedades/`,
`/desarrollos/`, la ficha y los 5 formularios, los `<dialog>`, los `<textarea>`, la tira de fotos de la ficha, etc.
**La HOME también lleva la barra bronce**: se probó ocultársela (Cristian preguntó si en la home no debía haber
ninguna) y a los minutos pidió **"ponela de vuelta, por las dudas"** — está puesta de nuevo, igual que en el resto
(la home siempre tuvo la barra nativa gris-blanca hasta el 2026-10-09). **Regla: una sola definición, siempre el mismo
color y estilo "siempre que la uses"** — no repetir `scrollbar-color` en ningún otro lado (se sacó el duplicado de
`.fi-tira` en la ficha). Los sliders de la home y la galería de `/propiedades/` siguen sin barra a propósito
(`scrollbar-width:none` en su propia regla, que le gana a `*`). En el celular las barras son flotantes del sistema: la regla es la misma que en la compu, pero el color
final lo decide el navegador del teléfono (no se pudo ver en un teléfono real). Verificado en Chromium con las
barras visibles (`--hide-scrollbars` desactivado): en las 7 páginas probadas (home incluida) la barra de página, las
ventanas, los textareas y la tira de fotos dan exactamente la misma combinación `thin | rgba(166,124,69,.55)`. Ver también
`MANUAL-DE-DISENO.md`, sección 4.

## Scroll de fondo bloqueado mientras hay un `<dialog>` abierto

Cristian encontró que en mobile, con cualquier modal abierto (matrícula,
privacidad, detalle de propiedad/desarrollo), se podía seguir scrolleando
la página de atrás con el dedo — "queda raro". Es un comportamiento
conocido de `<dialog>`: `showModal()` bloquea foco/teclado del resto de
la página, pero **no bloquea solo el scroll táctil de fondo** en la
mayoría de los navegadores — hay que hacerlo a mano.

**Arreglo, en `estilo.css`** (una sola regla, sin tocar nada de JS):

```css
html:has(dialog[open]){overflow:hidden}
```

`:has()` reacciona solo al atributo `open` que `showModal()`/`.close()`
ya ponen y sacan — cubre los ~10 lugares del sitio que abren un dialog
(el delegado genérico de clicks con `data-abre`, el auto-open por hash,
`abrirDetalle()`, y el script de privacidad propio de cada uno de los 5
formularios) **sin tener que tocar ninguno de ellos**, y sin importar qué
`<dialog>` se agregue en el futuro. Al estar en `estilo.css`, aplica por
igual a `index.html` y a los 5 `form/*/index.html`.

No afecta el scroll interno del propio `<dialog>` si su contenido no
entra en una pantalla chica (es un contenedor de scroll aparte, la regla
sólo bloquea el `html` de atrás). Soporte de `:has()`: universal en
cualquier navegador mobile mínimamente actualizado a esta altura (Chrome/
Edge desde 2022, Safari desde 2022, Firefox desde fines de 2023) — no se
consideró necesario un fallback para navegadores más viejos.

**Probado**: con cada uno de los 4 `<dialog>` de `index.html` y con el de
privacidad de un formulario, un scroll simulado (rueda/wheel, más fiel a
un gesto real que `window.scrollTo()`, que en algunos casos no respeta
`overflow:hidden` igual de estricto) no mueve la página mientras el modal
está abierto, y vuelve a scrollear normal apenas se cierra.

## Link directo a un modal

Es bidireccional:
- **URL → modal**: entrar a `csrealestate.com.ar/#aviso-legal` abre la página
  con la ventana de matrícula ya abierta.
- **Botón → URL**: al abrir el modal haciendo clic en el botón (`data-abre`),
  la URL se actualiza sola a `.../#aviso-legal` con `history.replaceState`
  (sin esto, Cristian probó el botón, se abría el modal, pero el link de la
  barra de direcciones no cambiaba — no se podía copiar desde ahí).

En los dos casos, al cerrar el modal se limpia el `#aviso-legal` de la URL
(también con `replaceState`) para que un refresh no lo vuelva a abrir solo.
Mismo mecanismo genérico serviría para cualquier otro `<dialog>` que se agregue
más adelante — sólo hace falta que el `id` del dialog coincida con el hash, y
que el trigger tenga `data-abre="ese-id"`.

**Texto del modal**: es el disclaimer legal de la actividad de Cristian
dentro de Red Suma — Cristian mandó la redacción exacta (menciona al
corredor responsable matriculado y las leyes de corretaje aplicables), no
es un texto que se pueda parafrasear libremente si hay que retocarlo más
adelante. El `<h3 id="aviso-titulo">` (que además hace de título accesible
del modal, vía `aria-labelledby`) sigue siendo "VL REALTOR CUCICBA 7615 /
CSI 6609" — no se tocó, sólo cambiaron los párrafos de adentro.

## Panel de "¿Cómo puedo ayudarte?"

Los primeros 5 botones (tasación, vender, alquilar, comprar, buscar alquiler
— todos links a Google Forms) viven dentro de una tarjeta de vidrio propia
(`.menu-panel`, mismo criterio "widget" tipo iOS que el resto del sitio: un
contenedor que agrupa varias acciones relacionadas), separada del resto de
los botones (WhatsApp, Email, matrícula). "¿Cómo puedo ayudarte?" es el
título fijo de esa tarjeta, sin botón ni interacción — **se probó una
versión plegable (con flecha, click para abrir/cerrar) y no convenció, se
sacó**. Si en algún momento se vuelve a pedir un desplegable, la versión
plegable usaba la técnica CSS `grid-template-rows:1fr↔0fr` para animar un
"height:auto" real; quedó documentado acá por si hace falta retomarla.

Dentro del panel, los 5 botones son más transparentes y de borde más oscuro
que los de afuera (`.menu-panel .boton{background:rgba(255,255,255,.015);
border-color:rgba(255,255,255,.08)}`, contra el `--btn-fondo` .03 /
`--btn-borde` .15 de siempre) — a pedido de Cristian. El borde del panel en
sí también es más oscuro que `--btn-borde` (`rgba(255,255,255,.08)`). El
gap entre botones ahí adentro es más chico (8px fijo) que el
`--botones-gap` fluido de afuera, porque ya están contenidos en su propio
marco.

Los botones del panel además son 10% más angostos de cada lado que el
ancho del panel (`margin-inline:10%` en `.menu-panel .boton` — quedan al
80% de ancho, centrados). Se usó `%` y no `px` a propósito: como es
relativo al ancho del propio contenedor (que ya es fluido), el achique
queda en la misma proporción en cualquier tamaño de pantalla sin tener que
tocar nada más.

## "Mi método" (bubble desplegable)

Botón nuevo debajo de Email (mismo `<nav class="botones">`, mismo grupo que
WhatsApp/Email — no está dentro del `.menu-panel`). Muestra el enfoque de
trabajo de Cristian con clientes que venden — a pedido explícito de
Cristian, con instrucciones detalladas de que **no** pareciera una sección
nueva "pegada" al diseño: mismas tipografías, misma paleta, mismos radios,
mismo estilo de botón que el resto de la página. Sin popup ni `<dialog>`:
el contenido vive siempre en el flujo normal del documento (`display` real,
no `position:fixed/absolute` superpuesto), sólo se le da o se le saca alto.

**Estructura**: `.mi-metodo` es el contenedor con el look "glass" completo
(border/background/backdrop-filter/box-shadow — copiado 1:1 de `.boton`),
en vez de ponerle esos estilos al botón. Adentro van dos hijos: el
`<button class="mi-metodo__boton">` (sin fondo/borde propio — sólo texto y
layout, hereda visualmente el de `.mi-metodo`) y el
`.mi-metodo__contraccion` con el contenido. Así el conjunto se ve como una
sola tarjeta que "crece" hacia abajo al abrir, no como un botón con un
recuadro aparte debajo — es el mismo truco que ya usa `.aviso` (un único
contenedor con `overflow:hidden` para que las esquinas redondeadas corten
prolijo tanto al header como al contenido, sea cual sea su alto).

**Animación de alto real** con la técnica `grid-template-rows:0fr↔1fr` que
ya estaba documentada acá (se había probado para un "¿Cómo puedo
ayudarte?" plegable, se descartó ahí, pero quedó anotada para cuando
hiciera falta — acá hizo falta). `.mi-metodo__contenido` necesita
`overflow:hidden` para que la fila en `0fr` recorte de verdad el
contenido en vez de sólo achicar la fila del grid sin cortar el
desborde. Transición apagada bajo `prefers-reduced-motion` (mismo
criterio que el resto de las animaciones de la página).

**El símbolo "+"**: no son dos iconitos que se turnan — es un solo
carácter "+" con `transition:transform`, que rota 45° cuando el botón
tiene `aria-expanded="true"` (CSS puro, `[aria-expanded="true"] .mi-metodo__mas`).
Un "+" girado 45° se lee como una "×", que es justo el efecto "+ que se
transforma discretamente" que pidió Cristian, sin sumar SVGs ni pseudo-
elementos extra. Posicionado en el borde derecho a la misma distancia que
usan los íconos de la izquierda en los botones con ícono
(`--boton-icono-left`, reutilizada tal cual) — mismo padding a los dos
lados del botón (`--boton-pad-icono`) para que el texto quede centrado
como en WhatsApp/Email/matrícula, aunque el símbolo esté sólo de un lado.

**Jerarquía tipográfica adentro** (a pedido de Cristian: "que no parezca
una sección premium separada"), usando SÓLO tamaños/colores que la página
ya usa en algún lado, ninguno nuevo:
- Antetítulo (`.mi-metodo__ante`): mayúsculas, 11px, en `var(--bronce)` —
  el mismo acento de color que ya usa el precio de las tarjetas de
  propiedades, no un color nuevo.
- Título de cada bloque (`.mi-metodo__titulo`): 17px/600 — cae dentro del
  rango 14-18px que ya usa el resto de la página (botones 14px, `.aviso h3`
  14px, `h2` 15-18px, `.bio` 16px).
- Párrafos: 14px/1.6, `rgba(255,255,255,.72)` — el mismo tono exacto que
  ya usa `.aviso p` en el modal de matrícula.
- Lista ("Qué precio tiene sentido defender...", etc.): sin viñetas
  nativas, un guión en `var(--bronce)` por `::before` — mismo acento que
  el antetítulo, en vez de un color de viñeta nuevo.
- Frases destacadas ("Subirla y esperar que aparezca alguien no es un
  plan.", "Mi negocio está en que me recomiendes." + "Una operación
  termina..."): **no son tarjetas** (Cristian pidió explícitamente que no
  lo fueran) — sólo `font-weight:600` + `border-left:2px solid var(--bronce)`,
  mismo acento de siempre, como única marca visual de énfasis. La frase
  entre comillas del bloque 2 (`.mi-metodo__destacado-titulo`) se subió a
  16px a pedido de Cristian, un escalón por encima del resto del destacado
  (14px) — sigue dentro del rango 14-18px de siempre.
- Separador entre los dos bloques de texto: una línea de 1px en
  `rgba(255,255,255,.08)`, el mismo tono que ya usa el borde interno de
  `.menu-panel`.

**Bug real de especificidad CSS (encontrado por Cristian, arreglado).**
Los antetítulos ("PLAN DE MARKETING A MEDIDA", "UNA RELACIÓN A LARGO
PLAZO") no se veían en bronce a pesar de que `.mi-metodo__ante` sí lo
declaraba — Cristian lo detectó a simple vista y tuvo que insistir dos
veces para que se investigara en serio en vez de asumir que el código ya
estaba bien. Causa real: el antetítulo es un `<p>` como cualquier otro
dentro de `.mi-metodo__bloque`, y la regla `.mi-metodo__bloque p{...}`
(agregada más tarde, para la tipografía de los párrafos de cuerpo) tiene
**más especificidad** que `.mi-metodo__ante` sola (class+tipo vence a
class sola) — así que le pisaba tanto el `color` como el `font-size`
(el antetítulo se veía gris de cuerpo de texto y a 14px en vez de 11px).
El mismo problema afectaba, sin que nadie lo hubiera notado todavía, a las
frases destacadas (se veían grises en vez de blanco pleno).

**Solución**: `.mi-metodo__bloque p:not(.mi-metodo__ante)` para la regla
de párrafos de cuerpo (ya no matchea el antetítulo), y una regla aparte
con la misma "cantidad" de especificidad (2 clases + 1 tipo) para las
frases destacadas (`.mi-metodo__bloque p.mi-metodo__destacado`,
`.mi-metodo__bloque .mi-metodo__destacado p`), declarada después en la
hoja de estilos para ganarle el empate. **Ojo si se vuelve a tocar esta
sección**: `.mi-metodo__bloque p` es una regla ancha (matchea cualquier
párrafo del bloque) — cualquier elemento de texto nuevo que no deba
heredar su estilo de cuerpo genérico (gris, 14px) va a necesitar el mismo
tipo de exclusión o de regla-con-más-peso, si no va a perder en silencio
contra ella exactamente como pasó acá.

**Tracking**: el botón lleva `data-evento="metodo"` y
`data-titulo="Mi método"` (el `data-titulo` es necesario porque si no, el
handler genérico de clicks arma el texto del evento con
`origen.textContent`, que incluiría también el "+"/"×" del símbolo). No
lleva `data-abre` — a propósito, para no disparar el mecanismo genérico de
abrir un `<dialog>` (este botón no abre ningún modal, sólo alterna una
clase con JS propio).

**El copy es real, lo escribió/pidió Cristian tal cual** — no es texto de
relleno para probar el diseño (a diferencia de las 5 propiedades de
ejemplo del slider, que sí lo son). Tuvo una segunda pasada de edición
(Cristian reescribió varias frases de los dos bloques y el destacado de
cierre del primero, de "Publicar y esperar consultas no es una estrategia"
a "Subirla y esperar que aparezca alguien no es un plan") — si vuelve a
pedir cambios de texto, el contenido vive directo en el HTML entre
`<div class="mi-metodo__contenido">` y su cierre, no hay ningún array ni
plantilla de por medio.

**Cita destacada**: pasó por dos vueltas hasta llegar a la forma actual.
Originalmente eran dos piezas separadas: "Mi negocio está en que me
recomiendes." como título arriba del bloque (`<h3>`, justo después del
antetítulo) + "Una operación termina..." como destacado al final. Primera
vuelta: se unieron en un solo párrafo arriba, con comillas de apertura y
cierre rodeando las dos frases juntas — Cristian aclaró que no era eso lo
que pedía. **Forma final**: las dos frases se movieron juntas AL FINAL del
bloque (no al principio), dentro de un único `.mi-metodo__destacado` (la
misma línea lateral en bronce que ya usa "Subirla y esperar que aparezca
alguien no es un plan." en el bloque 1) — pero ahora ese destacado es un
`<div>` que envuelve DOS `<p>`, no un `<p>` suelto: la primera línea
("Mi negocio está en que me recomiendes.", con `font-weight:700` vía
`.mi-metodo__destacado-titulo`) funciona como "título" de la segunda
("Una operación termina...", `font-weight:600`, heredado del contenedor).
Sólo la primera línea lleva comillas (clase `.mi-metodo__cita`, sumada a
`.mi-metodo__destacado-titulo`) — la segunda no las lleva. Esto funciona
sin declarar de nuevo `font-size`/`line-height`/`color` en los `<p>` hijos
porque esas propiedades son heredables: un `<div class="mi-metodo__destacado">`
les pasa lo mismo a sus párrafos que un `<p class="mi-metodo__destacado">`
suelto (que es como sigue siendo el destacado del bloque 1, sin cambios).

Las comillas (`::before` `\201C` de apertura, colgando a la izquierda con
posición absoluta; `::after` `\201D` de cierre, en línea al final del
texto) van en `var(--bronce)`, el mismo acento de color de siempre, con
`Georgia,"Times New Roman",serif` **sólo para esos dos caracteres
puntuales** (no para texto real de la página) — una comilla tipográfica
se ve más "de cita" con una curva serif que en Inter, y como son fuentes
ya instaladas en cualquier sistema operativo, no hace falta cargar
ninguna fuente nueva para lograrlo.

**Link directo `#more-info`** (mismo espíritu que `#aviso-legal` del modal
de matrícula, pero sin ningún `<dialog>` de por medio — acá sólo hay una
clase CSS que se prende/apaga). Al abrir "Mi método" (clic manual o carga
con el hash puesto), la URL pasa a terminar en `#more-info`; al cerrar, se
le saca — mismo `history.replaceState` que ya usaba el modal, para no
ensuciar el historial con una entrada nueva por cada apertura/cierre.

Si alguien entra directo a `csrealestate.com.ar/#more-info` (por ejemplo,
un link que comparte Cristian), la página **primero scrollea hasta el
botón "Mi método" (todavía cerrado) y recién cuando ese scroll termina de
verdad dispara la apertura animada** — en ese orden a propósito: si se
abre primero, el contenido (mucho más alto que la pantalla) empuja el
botón bien arriba del viewport durante el scroll, y el título deja de
verse justo cuando más importa que se vea (Cristian lo pidió
explícitamente: "el título se tiene que ver, no importa si queda texto
por mostrar abajo").

*Dos bugs reales, uno atrás del otro, hasta llegar a esto*:

1. Primer intento: esperar al `transitionend` de `grid-template-rows`
   después de abrir, y ahí recién centrar el contenido con
   `scrollIntoView({block:'center'})`. Problema: con contenido más alto
   que la pantalla, "centrar el contenido" podía mandar el título bien
   arriba del viewport — justo lo que Cristian pidió que no pasara.
   Descartado por diseño (no por bug), a favor de "scrollear primero con
   el botón arriba, abrir después".

2. Segundo intento, ya con el orden correcto (scrollear primero): se
   probó decidir "¿ya terminó de scrollear?" esperando a que dejaran de
   llegar eventos `scroll` por 130ms (mismo patrón que usa el carrusel en
   `revisarLoop`). **No funcionó**: confirmado instrumentando con
   `console.log` en cada evento, el navegador a veces deja huecos de más
   de 130ms **entre eventos de scroll en medio de la misma animación**, no
   sólo al final — el debounce daba por terminado un scroll que en
   realidad seguía en curso, abría el contenido de golpe a mitad de
   camino, y esa apertura (que agranda el alto de la página) interrumpía
   la animación de scroll que todavía estaba en curso — el botón terminaba
   en cualquier posición, no arriba del todo.

   **Solución final**: en vez de inferir "¿terminó?" por el patrón de
   eventos, se mide la distancia real a la posición de destino en cada
   frame (`requestAnimationFrame`, comparando `window.scrollY` contra el
   `destino` calculado de antemano) — no importa cuán parejo o salteado
   sea el goteo de eventos de scroll, esto sabe con certeza cuándo se
   llegó de verdad (diferencia menor a 2px), con un tope de 1.5s por si
   alguna vez no se llega a llegar. El scroll en sí se dispara con
   `window.scrollTo({top: destino, behavior:'smooth'})` en vez de
   `scrollIntoView` (mismo resultado, pero da un `destino` numérico propio
   para comparar en el polling). El cálculo de `destino` además espera al
   evento `load` de la página (no arranca durante el parseo inicial):
   antes de eso, con fotos todavía acomodándose, la posición del botón
   podía correrse mientras el scroll ya estaba en camino hacia un destino
   viejo.

3. Al abrir en sí (después de que el scroll ya se asentó), sigue haciendo
   falta el doble `requestAnimationFrame` antes de agregar la clase
   `abierto` — si se agrega ya mismo, sin darle al navegador un frame
   pintado en el estado cerrado antes, no hay transición que animar
   (aparece expandido de una, sin animación, algo que ya se había visto
   como bug en una vuelta anterior).

Bajo `prefers-reduced-motion` nada de esto aplica: scroll instantáneo
(`behavior:'auto'`) directo al botón y apertura sin animar, sin esperar
ningún frame ni medir ninguna distancia.

## Motor genérico de carrusel (`crearCarrusel`)

"Propiedades en venta" y "Desarrollos destacados" son visual y
funcionalmente **idénticos** — por eso, en vez de duplicar el código, hay
una sola función `crearCarrusel(opciones)` en `index.html` que arma
cualquier carrusel de tarjetas, y se la llama una vez por cada slider
(al final del `<script>`), pasándole su propio array de datos, su propio
`<dialog>` de detalle y su propio mensaje de WhatsApp. Si en algún momento
se agrega un tercer slider, alcanza con un array + un `<dialog>` nuevo +
un llamado más a `crearCarrusel({...})` — no hay que reescribir la
mecánica.

Cada tarjeta es un objeto `{titulo, ubicacion, precio, foto, descripcion}`
(ver el detalle de cada campo en las secciones de cada slider, más abajo).

**Tamaño de la tarjeta:** `.propiedad{width:clamp(170px, 53vw, 307px)}` —
53% de 580 (el ancho de `.envoltorio`) da 307, mismo criterio de siempre
(la parte fluida `vw` y el techo del `clamp()` representan la misma
proporción del ancho de columna, para que la sensación de tamaño sea
consistente entre mobile y desktop). **Este es el tamaño "protagonista"
de siempre — Cristian pidió explícitamente no tocarlo** (ver el punto
siguiente).

**Cuánto se ve de la tarjeta lateral (el "peek") — por qué NO se puede
agrandar sin tocar el ancho de la tarjeta.** Con una tarjeta centrada, lo
que asoma de la vecina en cada costado es pura geometría:
`(ancho de la pista − ancho de tarjeta) / 2 − gap` (14px de gap). Esa
resta **no tiene ninguna otra variable** — el padding de la pista no
"crea" espacio en pantalla, sólo mueve el punto de scroll que centra cada
tarjeta; agrandarlo empuja el padding Y el `scrollLeft` de centrado por
igual, así que lo que se ve en pantalla no cambia un pixel. Con el ancho
actual (53%), el peek geométrico da ~34-37% del ancho de tarjeta — es el
límite real mientras la tarjeta ocupe ese porcentaje de la pista.

Hubo una vuelta con una función `extraPeek()` (aire extra sumado al
padding, sin tocar el ancho de tarjeta) que en su momento se midió como
"sube el peek de 37% a 71%" — esa medición estaba **mal**: medía
`padding/anchoDeTarjeta` en vez del ancho real y visible de la tarjeta
vecina en pantalla (`getBoundingClientRect`). Confirmado después
midiendo bien: con `extraPeek()` en 18%, la vecina se seguía viendo apenas
~34%, exactamente igual que sin él — de ahí que Cristian dijera "no veo
ningún cambio" (tenía toda la razón). Se probó por un momento achicar la
tarjeta a 43% para llegar a ~55-58% de peek real, pero Cristian pidió
revertirlo — **el ancho de tarjeta no se toca sin que él lo pida
explícitamente**, aunque sea la única variable que geométricamente mueve
el peek. `extraPeek()` se sacó del código (era efectivamente un no-op,
sólo agregaba complejidad).

Si en algún momento Cristian quiere más peek: la única conversación
posible es "¿querés una tarjeta central más chica a cambio de que se vea
más la vecina?" — no hay ningún truco de padding/scroll que lo evite.

**Mecánica del carrusel — tarjeta central en foco:** `.propiedades__pista`
usa `overflow-x:auto` + `scroll-snap-type:x mandatory`, cada tarjeta con
`scroll-snap-align:center` (no `start`) para que cualquier tarjeta pueda
quedar centrada, no sólo alineada a la izquierda. JS le agrega el padding
de arriba (`actualizarPadding()`) — así hasta la primera y la última
tarjeta pueden llegar al centro. Se recalcula en cada resize porque el
ancho de tarjeta es fluido.

**Loop infinito** (siempre tiene que haber una tarjeta centrada y una en
cada lateral, ni al principio ni al final se puede ver un hueco vacío de
un lado). Se arma repitiendo tarjetas de más al principio y al final de la
pista — `CLONES = Math.min(4, items.length)` (subido de 2 a 4, ver el bug
del loop trabado más abajo), el orden real de renderizado es `[últimos 4
ítems] + [todos los ítems reales] + [primeros 4 ítems]`. Un
clon es una tarjeta de DOM aparte que usa el mismo objeto de datos que su
original (no una copia), así un click en un clon abre el detalle correcto
igual. Al cargar, la pista arranca con `scrollLeft` puesto para centrar el
primer ítem real (no el primer clon). 130ms después de que el scroll se
frena (`revisarLoop()`, con un `setTimeout` que se reinicia en cada evento
de scroll), si la tarjeta centrada quedó dentro de la zona de clones de una
punta, se salta al instante (asignación directa a `scrollLeft`, que nunca
anima) al mismo punto pero del lado real — el salto no se nota porque las
tarjetas de los dos lados son idénticas. Qué tarjeta está centrada se mide
con `indiceCentrado()` (distancia real de cada tarjeta al centro de la
pista, no una división de `scrollLeft` entre el ancho de tarjeta — esa
cuenta se desincroniza si el ancho cambió entre medio, por ejemplo en un
resize).

**Tarjeta en foco (difuminado de las laterales).** Mientras se
scrollea/arrastra, `actualizarFoco()` mide qué tan lejos está el centro de
cada tarjeta del centro de la pista, y le aplica `opacity` +
`filter:brightness()/blur()` + `transform:scale()` en proporción — la
tarjeta en foco queda a `opacity:1 scale(1)` sin blur ni oscurecer; las de
los costados bajan hasta `opacity:.55 brightness(.7) blur(1.5px)
scale(.94)` en el borde. Se salta esto bajo `prefers-reduced-motion`.

*Por qué la escala casi no se toca* (`.94` a `1`, no `.8` a `1` como en una
versión anterior): `transform:scale()` achica la tarjeta hacia su propio
centro — combinado con que las laterales ya asoman apenas por los bordes
de la pista (para que la central pueda estar perfectamente centrada),
escalarlas fuerte hacía que ese pedacito visible se encogiera todavía más
hacia adentro y casi desaparecía. El "fundido con el fondo" sale de
opacidad+blur+brillo, no de achicarlas.

*Por qué `actualizarFoco()` lee todas las posiciones antes de escribir
cualquier estilo* (dos pasadas: primero un `for` que sólo llama
`getBoundingClientRect()` y guarda los resultados en un array, después un
segundo `for` que sólo escribe `style.opacity/transform/filter`): leer y
escribir intercalado, tarjeta por tarjeta, fuerza al navegador a
recalcular el layout en cada vuelta del loop ("layout thrashing"), que se
sentía como saltos/tirones durante el scroll — separar las dos pasadas lo
evita.

**Bug real: las fotos no se pintaban hasta soltar el dedo/el mouse
(arreglado).** Cristian notó que mientras estaba arrastrando con el mouse
o deslizando con el dedo en mobile, una foto que todavía no se había
mostrado quedaba en blanco (el degradado de relleno) hasta soltar — recién
ahí aparecía de golpe. Causa: `actualizarFoco()` reescribía `filter`
(brightness+blur) de **todas** las tarjetas en cada frame mientras dura el
gesto (arrastre o swipe, ambos disparan el evento `scroll` seguido).
`filter` — el blur en particular — obliga al navegador a re-rasterizar
todo el contenido pintado de la tarjeta, imagen incluida, en cada uno de
esos frames; con eso pasando sin parar durante todo el gesto, el navegador
terminaba postergando el trabajo de pintar una foto recién decodificada
hasta que el gesto se detenía, para no competir con mantenerlo fluido.
`opacity` y `transform:scale()` no tienen este problema (el compositor los
aplica directamente sobre el raster ya existente sin tener que rehacerlo),
por eso siguen actualizándose en vivo sin condición.

**Solución**: variable `dedoAbajo` (true entre `pointerdown` y
`pointerup`/`pointercancel`, sin filtrar por tipo de puntero — a
diferencia del arrastre con mouse de más abajo, acá interesa tanto mouse
como touch). Mientras es `true`, `actualizarFoco()` sigue actualizando
opacity/transform en cada frame pero **no toca `filter`** — el brillo/blur
queda congelado en su último valor durante todo el gesto. Al soltar
(`pointerup`), se llama una vez más a `actualizarFoco()` para que el
blur/brillo se ponga al día con la posición final. Trade-off aceptado: el
difuminado no seguirá la posición exacta mientras se arrastra (sólo
opacity/escala lo hacen en vivo), pero es imperceptible en el uso normal
y a cambio las fotos aparecen apenas terminan de cargar, sin esperar a
soltar.

**Pasada de optimización general** (a pedido de Cristian: "que ande fluido
y como una web profesional"), además de todo lo de arriba:

- Las tarjetas ya no se buscan con `pista.querySelectorAll('.propiedad')`
  cada vez que hace falta — `pasoTarjeta()`, `actualizarFoco()` e
  `indiceCentrado()` corren muy seguido durante el scroll/arrastre, así
  que repetir esa consulta al DOM en cada una era trabajo de más. Ahora se
  buscan una sola vez, al armar el carrusel, y se guardan en el array
  `tarjetas` del closure — el conjunto de tarjetas nunca cambia después de
  eso, no hace falta volver a consultarlo.
- `.propiedad{will-change:opacity, transform, filter}`: aviso al navegador
  de que esas tres propiedades se van a animar seguido, para que arme la
  capa de composición de la tarjeta de antemano en vez de tener que armarla
  recién en el primer frame que la necesita (mismo criterio que
  `.portada{will-change:transform,opacity}`, que ya estaba de antes).

**Corte en seco en los bordes → máscara de desvanecido.** Opacity/blur
atenúan la tarjeta entera, pero el recorte de `overflow-x` de la pista
siempre corta en seco justo en su borde. Se resolvió con una máscara en
toda `.propiedades__pista` (`mask-image:linear-gradient(...)`, con su
`-webkit-` para Safari) que desvanece a transparente los primeros/últimos
60px de la pista, para que cualquier tarjeta que llegue hasta ahí se apague
de forma pareja antes de tocar el borde.

**Actualización 2026-10-09 (Cristian: "en el home puedo ver los cortes, necesito que se pierdan más con la imagen";
le había gustado el difuminado de las fotos de la ficha)**: la máscara de `.propiedades__pista` (slider de
Propiedades y de Desarrollos de la home) ahora usa `--difuminado:clamp(64px,16vw,104px)` (64 px en un celular de
390, 104 px en la compu; antes 60 px fijos) y una caída suave de 4 pasos en cada borde (0 → .18 → .55 → 1 de
opacidad en 30 % / 62 % / 100 % del ancho del difuminado) en vez de una rampa lineal. Se aplica siempre a los dos
bordes porque el slider es un loop (siempre hay tarjetas de los dos lados). Es sólo CSS sobre la home (landing
de Ads): no toca tracking, ni el JS del carrusel, ni el tamaño de las tarjetas. Verificado en compu y celular.
Las flechas de las fotos de la ficha se agrandaron de 38 a 46 px (símbolo de 24 a 30 px).

**Sin cursor "grab" en la pista.** Tenía `.propiedades__pista{cursor:grab}`
como pista visual de que se podía arrastrar, pero eso hacía que al pasar
el mouse por el espacio entre dos tarjetas (el gap de 14px, o el padding de
los costados) apareciera una manito ahí también — Cristian no lo quería.
Se sacó: ahora el cursor en la pista es el normal (`auto`), y sólo cambia a
`pointer` al pasar directo sobre una tarjeta (`.propiedad{cursor:pointer}`
ya estaba, sigue igual).

**Arrastre con mouse, sin flechas** (`overflow-x:auto` ya deja deslizar con
el dedo — touch — y con gestos de trackpad, pero un mouse común no tiene
forma nativa de arrastrar un contenedor con scroll horizontal). Arrastre a
mano con Pointer Events (`pointerdown`/`pointermove`/`pointerup` en
`pista`, moviendo `pista.scrollLeft`), excluyendo `pointerType==='touch'`
a propósito para no pisar el scroll nativo del sistema. Si el puntero se
movió más de 3px, se cancela el click de la tarjeta (si no, soltar el
mouse después de arrastrar abriría el detalle sin querer). Sin flechas a
propósito: la única forma de navegar es arrastrando/deslizando.

El movimiento del mouse durante el arrastre (`mover()`) también se aplica
una vez por frame con `requestAnimationFrame` (no en cada evento
`pointermove`, que puede disparar mucho más seguido que la pantalla) —
mismo motivo que las dos pasadas de `actualizarFoco()`: menos escrituras
de layout de las necesarias, scroll más parejo.

**Tres bugs reales de scroll, encontrados y arreglados uno atrás del otro**
(los tres alrededor de `scroll-snap-type`, que resultó más delicado de lo
que parecía):

1. *El arrastre no movía nada y después saltaba bruscamente.* Con
   `scroll-snap-type:x mandatory` prendido todo el tiempo, cada asignación
   de `pista.scrollLeft` que hacía `mover()` en cada `pointermove` quedaba
   revertida sola, en el momento, al punto de snap más cercano (mover
   `scrollLeft` a mano no pasa por el sistema de gestos de scroll nativo
   del navegador, así que éste no tenía forma de saber "está en medio de
   un arrastre, no snapees todavía"). Confirmado instrumentando: con el
   snap prendido, `scrollLeft` quedaba igual en medio del arrastre por más
   que `mover()` lo reasignara. **Solución**: clase `.arrastrando`
   (`.propiedades__pista.arrastrando{scroll-snap-type:none}`) que JS
   agrega en `pointerdown` y saca recién cuando el scroll se asienta del
   todo (ver bug 2).

2. *El asentado final "saltaba" en vez de deslizarse.* Arreglado el bug 1,
   quedaba uno más sutil: al soltar sin llegar a cruzar del todo a la
   tarjeta siguiente, la tarjeta volvía a su lugar de un salto. La primera
   solución sacaba `.arrastrando` (reactivando el snap) y RECIÉN AHÍ
   llamaba a `centrarIndice()` para animar — pero se confirmó
   instrumentando que reactivar `scroll-snap-type` corrige `scrollLeft` al
   punto de snap más cercano **de forma sincrónica, en el mismo instante**,
   antes de que el `scrollTo({behavior:'smooth'})` de `centrarIndice()`
   llegara a arrancar. **Solución**: `.arrastrando` se mantiene puesta
   durante *toda* la animación de `centrarIndice()`, no sólo durante el
   arrastre — recién se saca en `revisarLoop()` (el mismo chequeo que ya
   corría 130ms después de que el scroll se asienta, reutilizado para
   esto). Si el click fue sin arrastre real (`movido` false), no hay nada
   que animar y `.arrastrando` se saca al toque en `soltar()`.

3. *"Varios saltos", scroll poco confiable en general.* `revisarLoop()`
   corre con un `setTimeout` de 130ms sin nuevos eventos de scroll — pero
   si alguien arrastra y hace una pausa larga sin soltar el mouse, ese
   timer disparaba igual: reactivaba el snap y, si la tarjeta centrada en
   ese momento caía en la zona de clones del loop, saltaba `scrollLeft` un
   largo completo de vuelta **mientras el mouse seguía apretado**. Ese
   salto invalidaba el punto de referencia que `mover()` había capturado
   al empezar el arrastre, y el resto del gesto quedaba corrido/errático.
   **Solución**: variable `arrastrando` compartida entre `habilitarArrastre()`
   y `revisarLoop()` — mientras es `true`, `revisarLoop()` no hace nada
   (ni reactiva el snap ni chequea el loop), sin importar cuánto tiempo
   pase sin eventos de scroll.

**Bug real: había que soltar el dedo/mouse para que el loop "siguiera"
(arreglado para mouse; mitigado para touch).** Cristian notó que si
arrastrabas/deslizabas lo bastante lejos en un solo gesto continuo (sin
soltar), el slider se quedaba "trabado" en la punta hasta soltar — recién
ahí saltaba al lado real y se podía seguir. Su pregunta era la correcta:
"¿por qué se tiene que volver a cargar algo? es como pasar fotos de una
carpeta, no hace falta recargar nada al dar la vuelta". Tenía razón — no
era una recarga de fotos, era que el salto de posición (`revisarLoop()`)
estaba **a propósito** pospuesto hasta que el scroll se asienta del todo
(por los bugs 1-3 de arriba: reactivar el snap a mitad de arrastre rompía
todo), así que si el arrastre agotaba los `CLONES` disponibles antes de
soltar, no había más tarjetas de ese lado hasta ese salto pospuesto.

**Arreglado para mouse** con `corregirLoopEnVivo()` (dentro de
`habilitarArrastre()`, llamada desde `aplicarArrastre()` en cada frame):
hace el mismo salto de `scrollLeft` que `revisarLoop()`, pero EN VIVO,
sin esperar a soltar y sin tocar el snap — y además corrige
`scrollArranque` (el punto de referencia que capturó `mover()` al empezar
el arrastre) en la misma medida, para que la cuenta `scrollArranque -
delta` siga dando el resultado correcto después del salto, como si nunca
hubiera pasado. Probado arrastrando el equivalente a 8 tarjetas seguidas
sin soltar el mouse (simulado por código): el índice centrado nunca entró
en la zona de clones, el salto pasó a mitad de camino sin trabarse ni un
frame.

**No se pudo arreglar igual para touch** (swipe en mobile): ese gesto es
scroll nativo del sistema, no lo controla nuestro JS con `scrollLeft` como
el mouse — reprogramar `scrollLeft` a mano en medio de un gesto táctil
activo, con `scroll-snap-type` prendido (necesario para que el touch
snapee solo), es terreno pisado por los mismos bugs 1-3 de arriba, y sin
un teléfono real para probarlo no se puede garantizar que no rompa algo.
**Mitigación**: se subió `CLONES` de 2 a 4 (`Math.min(4, items.length)`)
— agranda bastante el margen antes de llegar a la punta, así que un swipe
normal debería asentarse solo (disparando `revisarLoop()`) antes de
agotarlo. Si Cristian sigue viendo el problema en el celular después de
esto, el margen se puede subir más, pero en algún punto ese enfoque tiene
un techo — la solución completa para touch sería replicar la técnica de
`corregirLoopEnVivo()` sobre el scroll nativo (factible, pero necesita
probarse en un dispositivo real, no simulado).

**Click en una tarjeta lateral → la centra; click en la centrada → abre el
detalle.** Cada tarjeta se crea con `crearTarjeta(p, indice)`, donde
`indice` es su posición dentro de la pista (incluye los clones del loop).
Al clickearla, compara ese `indice` contra `indiceCentrado()`: si
coinciden, abre el detalle; si no, llama a `centrarIndice(indice)` (mismo
scroll suave que el asentado del arrastre) para traerla al medio, sin
abrir nada todavía — un segundo click, ya centrada, recién ahí abre el
detalle.

**Detalle:** abre el `<dialog>` correspondiente (reusa el mismo
diseño/CSS que el modal de matrícula, `.aviso`) con foto más grande,
título, ubicación, precio, descripción completa, y un botón "Consultar por
WhatsApp" con tracking automático (`data-evento`, lo levanta el mismo
handler genérico de clicks que ya trackeaba el resto de los botones).

**Tarjetas de alto irregular (bug real, arreglado).** Cristian notó que en
mobile las tarjetas de "Desarrollos destacados" no medían lo mismo entre
sí. Causa: `.propiedad__titulo` y `.propiedad__precio` no tenían un alto
fijo, así que un texto más largo ("En construcción · Entrega 2027") pasaba
a 2 líneas mientras uno corto ("A estrenar") quedaba en 1 — la tarjeta con
más texto quedaba más alta que sus vecinas. Se resolvió reservando siempre
el alto de 2 líneas en título y precio (`-webkit-line-clamp:2` +
`min-height:calc(1.Xem * 2)`, así entre en 1 línea o en 2 el espacio
reservado es el mismo) y truncando ubicación a una sola línea con "…"
(`text-overflow:ellipsis`) porque ese campo es corto siempre y no necesita
2 líneas. Con esto, `offsetHeight` (el alto real de layout, sin contar el
`transform:scale()` del efecto de foco) da idéntico en todas las tarjetas
de un mismo slider, sin importar cuánto texto tenga cada una — verificado
con las 3 de "Desarrollos destacados" en mobile y desktop.

*Nota aparte para no confundirse si se vuelve a medir esto*: comparar
alturas con `getBoundingClientRect()` en vez de `offsetHeight` puede dar
valores distintos entre tarjetas aunque el layout esté bien, porque
`actualizarFoco()` les aplica `transform:scale(.94 a 1)` según qué tan
lejos están del centro — eso cambia el tamaño *visual* (lo que devuelve
`getBoundingClientRect`) pero no el layout real (`offsetHeight`, que
ignora transforms). Para chequear si el diseño de la tarjeta es consistente,
`offsetHeight` es la medida correcta; `getBoundingClientRect` sirve para
saber la posición/tamaño en pantalla en un momento dado, no para comparar
el "diseño" entre tarjetas.

## Slider de propiedades en venta

**Título cambiado a "Propiedades disponibles" (2026-09-28).** Cristian va
a empezar a publicar también alquileres acá, no sólo ventas, así que "en
venta" dejó de ser preciso — se cambió el `<h2>` y el `aria-label` de la
`<section>` (los únicos dos lugares con el texto visible/accesible). El
`id`/nombre interno de la sección (`propiedades-pista`, `PROPIEDADES`,
`PROPIEDADES_ACTIVO`, `boton_id: ver-propiedades`, y el nombre de esta
misma sección del `CLAUDE.md`) no se tocó — son identificadores internos,
no texto de cara al usuario, y renombrarlos habría sido mucho más riesgo
(tocar tracking, `propiedades.php`, `serve.ps1`) sin ningún beneficio
real. Si en algún momento se agregan alquileres de verdad a este slider,
convendría revisar si además hace falta distinguir "en venta" vs. "en
alquiler" en la tarjeta o el detalle — no implementado todavía, no
pedido.

Debajo del botón de Email hay un `<section class="propiedades">` con
`#propiedades-pista`, armado con `crearCarrusel()` (ver arriba).

**Interruptor ON/OFF:** `var PROPIEDADES_ACTIVO = true;`, antes del array.
En `false` esconde toda la sección sin borrar nada.

**Para editar propiedades**: array `PROPIEDADES` al final del `<script>`.
Cada objeto:

```js
{
  titulo: 'Depto 2 ambientes a estrenar',
  ubicacion: 'Palermo, CABA',
  precio: 'USD 135.000',
  foto: 'propiedad-1.webp',  // nombre de archivo, o '' si no hay foto todavía
  descripcion: 'Texto largo, sólo se ve en el detalle al hacer click.'
}
```

Agregar una propiedad = agregar un objeto al array. Sacar una = borrar su
objeto — no hay que tocar HTML.

**Fotos — estado actual (temporal):** el array apunta hoy a
`propiedad-1.webp` … `propiedad-5.webp` — fotos de stock que pasó Cristian
**a propósito**, con
el cartel "Estamos preparando esta sección" superpuesto, como reemplazo
temporal de las 5 propiedades de ejemplo mientras consigue fotos reales.
Cristian pidió explícitamente pisar los archivos existentes directamente
(no usar sufijos tipo `-temp` ni mantener el archivo viejo de respaldo) —
**si se vuelve a reemplazar una foto de este slider, hacer lo mismo:
sobrescribir el archivo `propiedad-N.*` que ya está**, sin inventar
convenciones de nombre nuevas. La extensión de cada archivo depende de
qué formato mandó Cristian esa vez (algunas quedaron `.webp`, otras `.png`
o `.jpg`) — el campo `foto` de cada objeto tiene que coincidir con la
extensión real del archivo en la carpeta.

**Convención de nombres**: la propiedad Nº1 es `propiedad-1.<ext>`; si
tiene una segunda foto, `propiedad-1-1.<ext>` (equivalente a la "#1.1" con
la que se la nombró en el chat), la tercera `propiedad-1-2.<ext>`, etc.
Hoy el array sólo admite **una** foto por propiedad — una galería con
varias fotos no está implementada, sólo la convención de nombres de
archivo está pensada para eso desde ahora.

**Caché al pisar un archivo existente — resuelto purgando desde Hostinger,
no con versión en la URL.** Pasó en la práctica: Cristian reemplazó las
fotos de "Propiedades en venta" pisando `propiedad-N.webp` en el servidor
(subió el zip nuevo a Hostinger), y ni Ctrl+Shift+R, ni modo incógnito, ni
probar desde el celular alcanzaban para ver las fotos nuevas. Diagnosticado
en vivo: el servidor SÍ tenía las fotos nuevas (confirmado bajándolas
directo con `fetch(..., {cache:'no-store'})` y comparando el hash contra
los archivos nuevos — coincidían) — el problema es que Hostinger manda las
imágenes con `Cache-Control: public, max-age=604800` (7 días), y ese
cacheo no es sólo del navegador de quien visita: hay una capa intermedia
(CDN/proxy) que también puede quedarse con la versión vieja ese tiempo —
algo que ni el hard refresh ni el incógnito tocan, porque esos sólo
limpian la caché del propio navegador, no esa capa de más arriba.

Se probó agregar un `?v=N` a la URL de cada foto (`FOTOS_VERSION`) para
forzar que cualquier caché de por medio la pida de nuevo sin tener que
purgar nada — **funcionaba, pero Cristian prefirió sacarlo**: no quiere
sumar una variable más para acordarse de bumpear en cada reemplazo de
foto, prefiere directamente purgar la caché desde el panel de Hostinger
cuando haga falta. Se revirtió: `ponerFoto()` vuelve a usar `img.src =
urlFoto || FOTO_VACIA` sin ningún query string, y no queda ningún rastro
de `FOTOS_VERSION` en el código. **Si vuelve a pasar que una foto
reemplazada no se actualiza pese a Ctrl+Shift+R/incógnito, avisarle a
Cristian que purgue la caché desde hPanel** (Hostinger) en vez de tocar
el código de nuevo.

Si `foto` queda vacío o el archivo no carga, se ve un degradado de relleno
(`--marron-calido` → `--neg-carbon`) en vez de una imagen rota: el `<img>`
siempre carga algo, un gif transparente de 1×1 (`FOTO_VACIA`) si no hay
foto real, así el navegador considera que "cargó bien" en transparente.

## Slider de desarrollos destacados

Mismo `crearCarrusel()`, debajo de "Propiedades en venta". Array
`DESARROLLOS` + interruptor `DESARROLLOS_ACTIVO`, mismo criterio que
`PROPIEDADES`/`PROPIEDADES_ACTIVO` de arriba.

Las 3 tarjetas son desarrollos **reales** de sumadesarrollos.com.ar —
Cristian pasó los 3 links (Midoki, AC/Congreso, OZB/Olazábal) más las 3
fotos de portada de cada uno, y Claude leyó cada página
(`WebFetch`) para completar título/ubicación/estado de
obra/superficies/amenities/financiación en `descripcion`. Fotos guardadas
como `desarrollo-1.jpg` (Midoki), `desarrollo-2.jpg` (AC), `desarrollo-3.jpg`
(OZB) — mismo criterio de nombres que `propiedad-N` para las propiedades.
**Conviene que Cristian revise los datos** (sobre todo precios y
condiciones de financiación, que cambian con el tiempo y las páginas
originales pueden no estar 100% actualizadas tampoco).

Para agregar un cuarto desarrollo (o reemplazar alguno): pasar el link de
la página + la foto de portada, y Claude arma el objeto igual que estos 3.

### Fuente de los desarrollos: sumadesarrollos.com.ar (leída el 2026-10-08)

Cristian pasó su vidriera personalizada
(`https://sumadesarrollos.com.ar/?a=cristian-1166951945`, el `?a=` es su "link de
asesor": `/js/asesor.js` pone su WhatsApp en los botones de esa web) para mejorar
"Desarrollos destacados", que hoy son 3 tarjetas cargadas a mano (`DESARROLLOS`
en `index.html`). **Se puede leer todo.** Cómo está armada esa web (Netlify,
estática, sin API propia):
- Un array `PROJECTS` en el JS de la home con **20 obras** — cada una: número y calle,
  barrio, `url` de su ficha (`congreso/`, `olazabal/`, `midoki/`...), descripción,
  entrega, plan de pago (`fin`), un respaldo `fb` (texto de tipologías, cantidad,
  precio "desde") y la foto.
- La **disponibilidad real** (unidades "Disponible", tipologías, precio, anticipo,
  cuota) se lee en vivo de **8 Google Sheets publicadas como CSV** (maestro hoja 1
  y 2, Congreso, Cuore Palermo, La Boheme, Isolina, Monroe, JBJ) — hay un
  "consolidador" de Apps Script como respaldo — y se cruza con `PROJECTS` por
  una regex (`match`) contra la dirección. Si una planilla no responde, usa el
  respaldo `fb`. Midoki (`match:null`) y Blanco Encalada usan SIEMPRE el respaldo.
- Hoy: 20 obras definidas, 19 con unidades; Tronador 4056 sin unidades
  ("Consultar"). *(Corrección: el HTML crudo de esa web dice "Quince edificios",
  pero es un texto que su JS reemplaza al cargar; la página ya armada muestra
  "Veinte edificios", 20 obras y 239 unidades disponibles. No es un error de ellos.)*
- **¿Se puede mostrar adentro de nuestra web (iframe)? Sí, probado el 2026-10-08.**
  Ni la home ni las fichas (`congreso/`, `olazabal/`, `midoki/`, `monroe/`) mandan
  `X-Frame-Options` ni `Content-Security-Policy`, y su JS no tiene código para
  escaparse del marco. Se cargó a pantalla completa en un marco sobre
  `localhost` y anda todo: portada, lista, filtros, ficha de cada edificio con
  planos y simulador. Contraste con `propiedades.redsuma.com.ar`, que SÍ lo
  bloquea (`X-Frame-Options: DENY`). Si algún día ellos agregan esa cabecera, el
  marco quedaría en blanco: hace falta un enlace de respaldo "abrir en una
  pestaña nueva". Limitaciones: es **otro dominio**, así que nuestro GTM no ve
  nada de lo que pasa adentro (sólo se puede medir que se abrió el visor y
  cuánto estuvo abierto); y `asesor.js` de ellos dispara SUS propias
  conversiones (`gtag conversion` a su cuenta de Ads y `fbq Contact`) cuando
  alguien toca WhatsApp adentro — no las de Cristian. `asesor.js` lee `?a=` (y
  `?n=`), guarda el asesor en `localStorage` y reescribe todos los links
  `wa.me` de esa web al número del asesor, así que con `?a=cristian-1166951945`
  en el `src` del marco los botones de WhatsApp van a su número. Esa web usa una
  paleta clara en las fichas (fondo blanco) y otra tipografía: no calza con
  Vidrio & Bronce.
- **Medición con la web embebida (probado el 2026-10-08):** desde nuestra página
  NO se puede leer qué hay adentro de un marco de otro dominio (el navegador
  bloquea `contentDocument`: `TypeError`), así que "clic en tal elemento" de
  esa web no se puede medir por nuestra cuenta. Sí se puede: (a) medir que se
  abrió/cerró el visor y cuánto estuvo abierto; (b) detectar que la persona
  TOCÓ adentro del marco (sin saber qué) con el truco del foco: al tocar adentro,
  `window` dispara `blur` y `document.activeElement` pasa a ser el `<iframe>` —
  verificado en el navegador (1 evento por toque), pero puede ser poco confiable
  en iPhone/Safari táctil (sin probar); (c) clic por elemento SÓLO si esa web
  colabora: que sus scripts (ej. `asesor.js`, en los botones de WhatsApp y al
  entrar a una ficha) manden `window.parent.postMessage({...}, '*')` y nosotros
  escuchemos validando `event.origin === 'https://sumadesarrollos.com.ar'` y
  lo empujemos al `dataLayer` — así funcionan Calendly, Typeform, YouTube, etc.
  Lo mismo si el GTM de Cristian estuviera instalado DENTRO de esa web (no
  depende de nosotros). Cristian recuerda haber medido "clic en elementos" con
  una web embebida en otra ocasión: pendiente de que cuente qué web/herramienta
  era para saber cuál de estos casos fue.
- **Decisión de Cristian (2026-10-08): sincronizar TODOS los desarrollos e imitar
  esa web con nuestro diseño**, manteniendo las 3 tarjetas actuales y agregando
  debajo un botón chico "Ver todos los desarrollos". Lo que debe pasar solo: si
  borran una obra o se venden todas sus unidades, tiene que desaparecer/actualizarse.
  **Viabilidad probada desde afuera de un navegador** (como lo haría el PHP de
  Hostinger): las 8 planillas CSV responden HTTP 200 en ~1 s cada una (~35 KB en
  total), el consolidador de Apps Script devuelve JSON (`generado`, `hojas`,
  `listas`, `caidas`), y los 20 proyectos de `PROJECTS` se extraen con todos sus
  campos (`num`, `calle`, `barrio`, `url`, `desc`, `entrega`, `fin`, `match`, `fb`,
  `img`; cada proyecto está en UNA línea del código). Diseño propuesto, sin
  implementar (esperando decisiones de Cristian): un `desarrollos.php` con
  caché (~2 h, refresco sin hacer esperar al visitante), que porte `bloques()`/
  `resumen()`/`clasificar()` y lea `PROJECTS`; **regla de oro: nunca borrar por un
  error** — si la fuente falla o el resultado es anormal (ej. cae más de la mitad
  de las obras de golpe) se conserva la última copia buena; sólo se oculta una
  obra cuando la fuente responde bien y dice que no está o que no tiene unidades;
  cartel "Disponibilidad al <fecha>"; aviso por mail opcional si la sincronización
  falla >24 h; control de números duplicados (caso Monroe = Isolina). Decisiones
  pendientes: ocultar vs "Consultar" las obras sin unidades, fotos (copia propia
  vs links a su servidor), frecuencia, botón "ver unidades y planos" a su ficha con
  `?a=cristian-1166951945` (nuevo `boton_id`: requiere su OK) y si las 3 tarjetas
  de arriba también se sincronizan (Congreso hoy dice "A estrenar", mal).
- **Decisiones de Cristian (2026-10-08, segunda vuelta)**: replicar TODO con nuestro
  diseño, **incluida la ficha** (planos, tabla de unidades, simulador); obras sin
  unidades → desaparecen; fotos → siempre las de su servidor (sin copia local, para
  que se actualicen solas); refresco cada **8 horas**; las 3 tarjetas de arriba se
  sincronizan con sus proyectos (Midoki, AC/Congreso, OZB/Olazábal); si la web de
  ellos se cae → los desarrollos desaparecen o se muestra "web caída"; que funcione
  solo, sin que él monitoree.
- **Qué significa "sin unidades" (datos de las planillas, 2026-10-08)**: cada
  planilla lista TODAS las unidades de cada obra con un estado: `Disponible` (239),
  `Vendido`/`VENDIDO` (209), `No disponible` (19, JBJ: cocheras/bauleras no
  vendibles), `Reservado`/`RESERVADO` (3). Una obra "sin unidades" es una obra
  VENDIDA (Tronador 4056: 16 vendidas + 1 reservada; su última unidad se vendió el
  6/10/2026), no una obra que "todavía no se hizo". Su web la deja publicada con el
  cartel "No hay unidades disponibles" + botón "Avisame si se libera una unidad"
  (`agotado.js`: declara agotada sólo si fallan las dos señales — sin precios Y sin
  botones habilitados — criterio conservador a propósito).
- **Bug de SU web (Isolina)**: `PROJECTS` busca cada obra con una regex contra la
  dirección y Isolina usa `/belgrano/`, que también calza con "Monroe 1678/80,
  **Belgrano**, CABA" → su home le muestra a Isolina los números de Monroe. En la
  planilla real Isolina tiene 35 disponibles y 10 vendidas. **Nuestra
  sincronización tiene que leer cada obra de SU planilla/bloque (`fuente`), no por
  regex suelta**, así que mostraría el dato correcto (distinto del de su home).
- **Las 20 fichas NO son una plantilla única**: cada una es una página con su propio
  JS (hash distinto en las 20; ~9 estructuras: unas con `const CONFIG`
  `{anticipoPct, comisionPct:0.04, cuotas, csv, clave}`, otras con otro esquema;
  `RESPALDO` de unidades escrito a mano; `planoDe()` distinto en cada una —
  tablas `PLANOS` por pisos/letras, por superficie con tolerancia, por rangos de
  piso, etc.; Midoki y Blanco Encalada son estáticas, sin planilla). Lo uniforme y
  confiable: planillas de unidades (piso, UF, superficies, estado, ambientes, precio
  contado/financiado, anticipo, cuota), `PROJECTS` (entrega, plan, barrio, desc),
  fórmulas del simulador (anticipo = % × precio; comisión 4 % + IVA; cuota =
  (precio − anticipo) / cuotas; total = precio + comisión). Lo "mejor esfuerzo"
  (se lee de cada ficha, puede romperse sin aviso si ellos la rehacen): textos de
  "El edificio" y memoria descriptiva, galería de imágenes, planos y su asignación
  por unidad, y el avance de obra (`/js/avance.js`: informe mensual escrito a mano
  por ellos, un objeto por obra). Regla de diseño: **si un bloque no se puede leer,
  ese bloque no aparece (el resto sigue) y se avisa por mail; nunca se muestra algo
  inventado ni se rompe la página.** El "web caída" aplica cuando la fuente no
  responde: reintentos inmediatos y luego cada ~15 min (hoy una planilla de Google
  tardó >30 s una vez: las fallas momentáneas existen).
- **Tercera vuelta de decisiones (2026-10-08)**: refresco cada 8 h, aviso por mail
  cuando algo no se pueda leer, y **etapa 1 aprobada** (sincronizador). Estructura
  pedida: las 3 tarjetas de arriba (Midoki, AC/Congreso, OZB/Olazábal) en vez de
  abrir el popup con el botón de WhatsApp llevan a **la ficha de ese desarrollo
  dentro de nuestra web**, y debajo un botón chico **"Ver todos los desarrollos"**
  (maqueta aprobada en forma: pastilla de vidrio chica con flecha, ver
  `maqueta-botones-ver-todos.jpg` enviada a Cristian; **no está implementado**).
  "Web caída" (maqueta enviada, **no implementado**): tarjeta de vidrio con "!" en
  bronce, "Web de desarrollos no disponible", "Estamos sin conexión con la
  información de los edificios. Probá de nuevo en unos minutos." y un botón
  "Consultame por WhatsApp" para no perder el contacto (conservaría el
  `boton_id` `consulta-desarrollo`).
- **Tracking de lo anterior (aclarado a Cristian)**: hoy hay DOS `boton_id` en el
  slider de desarrollos: `ver-desarrollos` (se empuja a mano en `abrirDetalle()` al
  abrir una tarjeta → GA4 `ver_desarrollos`) y `consulta-desarrollo` (`data-evento`
  del botón "Consultar por WhatsApp" del popup → GA4 `click_whatsapp`, Meta
  `Contact`); lo mismo para propiedades con `ver-propiedades` /
  `consulta-propiedad`. **Plan para NO tener que re-trackear nada en GTM**: mantener
  esos mismos IDs — la tarjeta/ficha sigue empujando `ver-desarrollos` (con
  `boton_texto` = nombre de la obra), el WhatsApp dentro de la ficha conserva
  `consulta-desarrollo`, y el botón "Ver todos los desarrollos"/"Ver todas las
  propiedades" REUSA `ver-desarrollos`/`ver-propiedades` con otro `boton_texto`
  (en GA4 se distingue por la dimensión "Button Text"). Un `boton_id` nuevo sólo
  si Cristian quiere un evento propio (entonces hay que crear el activador en GTM
  de su lado). Las páginas nuevas (`/desarrollos/`, `/propiedades/`) necesitan el
  mismo snippet GTM-5JDWTPXN.
- **Diferencias de nuestra versión vs su home** (calculadas con una implementación
  de referencia en Python que reproduce EXACTAMENTE su home en 18 de las 20 obras):
  sólo (1) Isolina (Manuel Belgrano 4727): su home muestra los números de Monroe
  porque `/belgrano/` calza con ambas direcciones y `bloq.find` toma la primera
  planilla que terminó de cargar (orden no determinista — a veces sale bien);
  la planilla propia dice 27 unidades de vivienda (más 8 cocheras/bauleras que no
  cuentan), desde USD 65.450, entrega Julio 2028, "5 monoambientes · 14 de 2 amb. ·
  8 de 3 amb."; (2) Tronador 4056: su home la muestra como "Consultar" (0
  unidades), nosotros la ocultamos. Las otras 18 coinciden en unidades, precio y
  tipologías.
- **ETAPA 1 HECHA (2026-10-08): `desarrollos.php`** (en la raíz del proyecto; *desde el
  2026-10-09 está en el zip pero **no conectado a la home**, ver la etapa 3*). Sincroniza
  las 20 obras con la misma lógica que su home (`bloques`, `resumen`, `clasificar`,
  `plan`, `anticipoDe`, `cuotaDe`), leyendo `PROJECTS`, `CSV` y `FUENTES` de SU
  código (una planilla nueva que sumen se lee sola) y cada obra de SU planilla
  (corrige el bug de Isolina: gana el bloque de la planilla declarada en `fuente`
  y/o el que lleva el número de la calle). Devuelve JSON: `{ok, estado, actualizado,
  obras[], resumen{obras,barrios,unidades_libres,desde}}`; cada obra trae `id`
  (slug), `titulo`, `barrio`, `entrega`, `plan`, `imagen` (URL directa a su
  servidor), `origen` (`planilla` | `respaldo` — Midoki y Blanco Encalada no
  tienen planilla), `agotada`, `unidades_libres`, `desde`, `tipologias` ("Todas las
  unidades vendidas" si está agotada), `tipos`, `anticipo_desde`, `cuota_desde`,
  `cocheras {n, desde}` (cocheras/bauleras DISPONIBLES, que no cuentan como
  unidades: Monroe 5 desde USD 30.776, Isolina 8 desde USD 17.500), `conteo` por
  estado y `unidades[]` (piso, uf, tipo, m², estado normalizado, precio, anticipo,
  cuota) para la grilla/simulador de la ficha. **Decisiones de Cristian aplicadas**:
  una obra vendida APARECE igual con "Todas las unidades vendidas" y un
  "Consultar" (irá última y atenuada; hoy sólo Tronador 4056); las cocheras y
  bauleras disponibles se muestran en su propia línea.
  **Comportamiento probado con PHP real (9 escenarios)**: TTL 8 h con copia en
  `cache/desarrollos.json`; primera lectura ~8–13 s (9 fuentes en serie), después
  0,1 s; vencido el TTL se responde YA con la copia y se refresca después de
  contestar (`fastcgi_finish_request`/`litespeed_finish_request`, si el servidor
  las tiene; si no, el visitante espera); si el refresco falla se reintenta como
  mucho cada 15 min y la copia vieja se sigue mostrando sólo 1 hora de gracia
  (para que un tropiezo no apague todo) — pasada esa hora responde
  `{"ok":false,"estado":"caida"}` y la web debe mostrar el aviso "Web de desarrollos
  no disponible"; mail a `cstedtfeld@redsuma.com.ar` a partir del 2º intento
  fallido seguido (tope 1/día, sin repetir) y otro cuando se recupera; una lectura
  que trae menos de la mitad de las obras (o <3) se descarta como error de lectura
  y NO pisa la copia buena; cada obra falla sola. Si responden menos de la mitad de
  las planillas se considera caída la fuente; si falla una sola, esa obra usa el
  respaldo de su página. **En pruebas locales** se usan variables de entorno sólo
  en CLI: `CSRE_PRUEBA=1` (mails a `cache/aviso-mail.txt`), `CSRE_PRUEBA_URL`
  (apuntar a una URL inválida) y `CSRE_PRUEBA_HOME` (un HTML local mutado).
  Referencia en Python y guiones de prueba: `scratchpad` de la sesión
  (`referencia_desarrollos.py` reproduce su home en 18 de 20 obras; el PHP da 0
  diferencias contra esa referencia). **Limitaciones conocidas**: depende de que
  su código mantenga el formato (si cambian `PROJECTS`/`CSV`/`FUENTES` el
  sincronizador avisa y, pasada la hora de gracia, la web muestra "caída"); la
  "Vitrina" de obras de colegas (`CSV_VITRINA`, hoy vacía en su web) no se lee; el
  `curl` del PHP portable local no trae certificados, por eso `http_get` prueba
  `curl` y, si falla, los streams de PHP (los que usa `propiedades.php`).
- **ETAPA 2 HECHA (2026-10-08): maqueta funcional `desarrollos/index.html`** (página
  nueva, `csrealestate.com.ar/desarrollos/`; *desde el 2026-10-09 está en el zip pero
  **no enlazada desde la home**, y la ficha ya existe: ver la etapa 3*). Lee
  `../desarrollos.php`; diseño Vidrio & Bronce con el marco de las páginas de
  formulario (GTM-5JDWTPXN incluido, `noindex` por ahora). Muestra: cifras
  (obras/barrios/unidades/desde), panel "Filtrar y ordenar" (barrio, entrega,
  ambientes, anticipo hasta, cuota hasta, orden), tarjetas en 1 columna (celular) o
  2 (≥760 px) con foto de ellos (hotlink, `loading=lazy`, 16:10 con `position:absolute`
  para que una foto vertical no estire la tarjeta), barrio, título en Chillax,
  entrega, plan, unidades + tipologías, "Desde USD", anticipo/cuota desde,
  cocheras y bauleras, y "Ver unidades y planos →". Obra agotada: foto en grises,
  cartel "Agotada", "Todas las unidades vendidas", botón "Consultar" a WhatsApp
  (`consulta-desarrollo`), siempre última sea cual sea el orden. "Web caída": el
  aviso aprobado (con "Consultame por WhatsApp"). **Filtros verificados contra un
  cálculo independiente en 10 combinaciones (10/10)**: los de ambientes/anticipo/
  cuota se evalúan juntos sobre la MISMA unidad (como su home); las obras sin
  planilla (respaldo) filtran por `tipos`/`anticipo_desde`/`cuota_desde`. Orden
  verificado (precio ascendente, entrega con "próxima" primero, stock). Tracking:
  tarjeta → `ver-desarrollos` (texto = título); WhatsApp → `consulta-desarrollo`;
  ícono del pie → `whatsapp-icono` (todos IDs existentes, nada nuevo en GTM).
  **Soporte local de prueba**: `serve.ps1` sirve `/desarrollos.php` desde
  `desarrollos-prueba.json` (copia de una corrida real del PHP) y devuelve
  "caída" si existe el archivo vacío `desarrollos-caida.flag` en la raíz (crearlo y
  borrarlo para probar); ambos archivos quedan FUERA del zip. **Observación**:
  Monroe no muestra "Anticipo/Cuota desde" porque su planilla no trae esas
  columnas y su plan ("Anticipo + 30 cuotas") no dice qué porcentaje es (su home
  tampoco los muestra); lo resolverá la ficha si su código trae el dato.
  **Decisión de Cristian (2026-10-08): hacerlo igual que su página original**; si
  algo es raro en su origen, queda raro — no inventar ni calcular nada que ellos no
  muestren.
- **ETAPA 3 HECHA (2026-10-09): la ficha de cada obra** — `desarrollos/ficha/index.html`
  (URL `csrealestate.com.ar/desarrollos/ficha/?o=<obra>`, ej. `?o=olazabal`; `noindex`;
  GTM incluido), más `desarrollo-extra.php` y `desarrollos-lib.php`. **Está en el zip
  pero NO enlazada desde la home** (etapa 4, necesita el OK de Cristian por tocar una
  landing de Ads). El botón "Ver unidades y planos →" de cada tarjeta de `/desarrollos/`
  ya lleva a su ficha (era un cartel provisorio; se sacó).
  *Qué muestra*: portada (foto de su ficha o la de la lista, con cartel "Agotada"/
  "Próxima entrega"), cifras (entrega, unidades libres, desde, cuota desde) y el plan de
  pago; **"El edificio"** (frase y datos de su ficha + fotos en tira, tocar para ampliar);
  **"Elegí tu unidad"** (filtros de ambientes/anticipo/cuota evaluados juntos sobre la misma
  unidad, torre por pisos con el piso más alto arriba, unidades vendidas/reservadas
  punteadas, y el panel con el **simulador**: valor, anticipo %, comisión 4 % + IVA,
  desembolso al firmar, cuota × N y total — la misma cuenta que su ficha, verificada con un
  cálculo independiente); cocheras y bauleras disponibles en una línea; **Planos** (galería,
  tocar para ampliar); **"Así va la obra"** (avance de obra de su `/js/avance.js`);
  **memoria descriptiva** (acordeón); botón de WhatsApp general y **"Consultar por esta
  unidad"** (mensaje con unidad y piso); aclaraciones legales y créditos. Obra **agotada** o
  **sin planilla** (Midoki, Blanco Encalada): en vez de la torre, una tarjeta "Unidades y
  valores" con "Consultar". Obra inexistente → "Este desarrollo ya no está disponible";
  la lista caída → "Web de desarrollos no disponible"; si fallan las fotos/planos/textos,
  la ficha sale igual sin esos bloques.
  *De dónde sale cada cosa*: unidades, precios, anticipo, cuota, m² (**ahora también
  `cub`, `exp`, `incluye` y `plan_detalle {anticipo_pct, cuotas, comision_pct}`** en
  `desarrollos.php`) vienen de las planillas, igual que la lista. Lo que sólo está en la
  página de cada obra lo lee **`desarrollo-extra.php?o=<obra>`** con un parser DOM (no
  ejecuta nada de lo que baja): `hero`, `marca`, `claim`, `edificio {texto, datos[]}`,
  `memoria {titulo, items[], pie}`, `fotos[]`, `planos[]`, `avance {etapa, hitos[], fuente,
  fecha, fotos[]}`, `config`, `creditos`. Las imágenes salen de su servidor (hotlink). La franja
  de cifras de SU ficha (entrega/plan/unidades) **no se lee a propósito** (podía mostrar dos
  cifras distintas para lo mismo). Cobertura probada contra las 20 fichas reales: fotos y
  planos en las 20; memoria en 14; avance en 10 (`avance.js` sólo tiene 10 obras);
  "El edificio" (texto) sólo en las que usan su plantilla común (olazabal, besares,
  la-boheme, isolina, estados-unidos...); las demás muestran la descripción de la lista.
  **Límites a propósito**: (1) los planos son una **galería de la obra**, no el plano de
  *cada unidad* — su `planoDe()` es código distinto en cada ficha (if-chains, tablas por
  piso/letra, por superficie...) y no se ejecuta ni se porta; los títulos son los que ellos
  les ponen (`cap`/`alt`) o "Plano N". (2) No se copió su sección de preguntas frecuentes
  (texto general de ellos, igual en todas las fichas). (3) Los planos de Estados Unidos
  vienen embebidos en base64 en su código y se omiten los que no tienen archivo propio.
  *Funciona solo*: copia de 8 h por obra (`cache/ficha-<obra>.json`); vencida, responde YA con
  la copia y refresca por detrás; si el refresco falla se **sigue mostrando la última copia
  buena** (un plano o texto viejo no hace daño, a diferencia de un precio) y se reintenta cada
  15 min; si la página responde pero ya no se puede leer nada (cambiaron la estructura) **no se
  pisa la copia buena**; mail a Cristian a partir del 2º fallo seguido (tope 1/día entre todas
  las fichas). Sólo responde por obras de la lista sincronizada (no sirve para pedir cualquier
  URL). **Probado con PHP real**: `probar_extras.py` (las 20 fichas), `probar_extra_comportamiento.py`
  (copia vigente instantánea, id raro, obra desconocida, fuente caída → sigue la copia, 2º fallo
  → mail, obra sin copia → `no_disponible`, recuperación, estructura cambiada → copia intacta) y
  `probar_ficha.py` con Playwright (Chromium de `Programas Claude`; **bloquea GTM/GA/Meta** para no
  mandar eventos reales desde localhost): simulador exacto, filtros, elegir otra unidad, visor de
  planos, obras especiales (Midoki, Tronador 4056 agotada, Monroe sin anticipo —muestra sólo valor y
  comisión con "el plan se confirma por consulta"—, JBJ), extras caídos, lista caída; 0 errores de
  consola. También `probar_lista_a_ficha.py` (las 20 tarjetas enlazan a su ficha).
  *Refactor*: las utilidades de red/JSON/mail de `desarrollos.php` pasaron a
  `desarrollos-lib.php` (la usan `desarrollos.php` y `desarrollo-extra.php`; **van las dos en el
  zip**); se re-corrieron los 9 escenarios de `probar_desarrollos.py` y la comparación contra la
  referencia (0 diferencias) y todo da igual.
  *Tracking de la ficha (IDs existentes, nada nuevo en GTM)*: abrir la ficha desde la lista →
  `ver-desarrollos` (texto = título, destino = la ficha); "Consultar por esta unidad" / "Consultar
  por WhatsApp" / "Consultar" → `consulta-desarrollo`; ícono del pie → `whatsapp-icono`.
  *Soporte local*: `serve.ps1` sirve `/desarrollo-extra.php?o=<obra>` desde
  `desarrollos-extra-prueba/<obra>.json` (copias de una corrida real; fuera del zip) y
  `desarrollos-prueba.json` se regeneró con los campos nuevos.
- **ETAPA 4 HECHA (2026-10-09): la home** (implementada y probada en local; **no subida todavía**).
  Cristian dio el OK al plan ("lo demás me parece bien") después de que se le explicó qué cambiaba
  y de que preguntara por los `boton_id` (son los mismos de siempre). Qué cambió en `index.html`:
  (1) las **3 tarjetas de Desarrollos** ya no son un array escrito a mano: `DESARROLLOS_DESTACADOS`
  (`midoki` → "Midoki", `congreso` → "AC", `olazabal` → "OZB") se cruza con lo que devuelve
  `desarrollos.php`; cada tarjeta muestra `"<marca> · <calle y número>"`, el barrio, "Desde USD x"
  (de las planillas) y, en la línea gris chica de abajo, "Entrega <fecha>" (el campo se llama
  `expensas` en el código por las propiedades; acá se reusa); la foto sale de su servidor. Se
  sacaron el popup `#desarrollo-detalle` y las fotos locales `desarrollo-1..3.jpg` (**ya no entran
  en el zip**; los archivos siguen en la carpeta, sin uso, igual que `propiedad-1..5.webp`).
  (2) **Tocar la tarjeta central lleva a la ficha** (`desarrollos/ficha/?o=<obra>`) en vez de abrir
  el popup: `crearCarrusel()` ganó la opción `urlDetalle(p)` + la función `irAlDetalle()`, que empuja
  `click_boton`/`ver-desarrollos` (texto = título de la tarjeta, destino = URL completa) y navega.
  Una tarjeta lateral sigue centrándose primero, como siempre. (3) Botón chico **"Ver todos los
  desarrollos →"** (`#desarrollos-mas`, `data-evento="ver-desarrollos"`, `data-titulo="Ver todos los
  desarrollos"`) debajo del slider. (4) La sección arranca con `hidden` y **si `desarrollos.php` no
  responde o viene `ok:false`, queda oculta** (decisión de Cristian: si su web se cae, los desarrollos
  desaparecen); se probó con la lista caída y las propiedades siguen normales.
  **Tracking, sin tocar GTM**: el único cambio es *dónde* ocurre el clic de WhatsApp de un desarrollo
  (ahora en la ficha, con su URL como `page_location`, en vez de en el popup de la home); los
  `boton_id` son los mismos (`ver-desarrollos`, `consulta-desarrollo`, `whatsapp-icono`).
  **Correcciones de Cristian del mismo día (2026-10-09)**: (a) `/propiedades/`: tarjetas más chicas,
  **3 por hilera** desde 1000 px, 2 desde 640 px y 1 en celular (se scrollea hacia abajo);
  (b) **"← Volver..." siempre a la izquierda** (misma altura de siempre): `.form-header__volver` en
  `estilo.css` pasó a `display:block; width:fit-content; margin-right:auto` — **esa clase la usan
  también los 5 formularios** (landings de Ads; sólo cambia la posición del link, el JS y el
  tracking no se tocaron; se verificó que `/form/vender/` carga y que sus 5 pasos siguen) — y se
  agregó **otro "← Volver" al final** (`.volver-abajo`) en `/propiedades/`, `/desarrollos/` y la ficha;
  (c) **detalles de tarjeta más grandes**: nueva clase `.aviso--detalle` (ventana de 620 px en vez de
  470, foto de ~570×428, título 21 px, precio 20 px, datos 15 px) aplicada al detalle de propiedades de
  la home y al de `/propiedades/` (las ventanas de texto —matrícula, privacidad— no cambian); ojo: los
  tamaños de `.propiedad-detalle__*`/`.pf-detalle__*` llevan `.aviso--detalle` adelante porque
  `.aviso p` (estilo.css) tiene más especificidad que una clase sola y los pisaba; (d) **tarjetas
  "Próximamente"** (`proximamente: true` en un ítem): vacías, con el cartel donde va la foto y **sin
  click** (no abren detalle ni se centran); funcionan en el slider de la home (`div.propiedad--proximamente`,
  mismo alto que las demás) y en `/propiedades/` (no se cuentan ni salen con un filtro de operación). El
  modo de prueba local de `serve.ps1` (`propiedades-muchas.flag`) ahora suma 3 de éstas en vez de
  copias de propiedades reales. Pruebas: `probar_correcciones.py` (Playwright, bloquea GTM/GA/Meta).
  **MANUAL DE DISEÑO (2026-10-09): ver `MANUAL-DE-DISENO.md`** (raíz del proyecto, fuera del zip) — escala de
  títulos de 3 niveles que salen de UNA sola medida y guardan la proporción 30 : 22 : 20 en toda pantalla
  (`--titulo-pagina` = `clamp(23px,6.5vw,30px)` → 30 px compu / ~25 px celular; `--titulo-seccion` = 11/15 × página →
  22 / ~19 (era 24 / ~20; Cristian pidió achicarla "un poco más" el 2026-10-09); `--titulo-tarjeta` = 2/3 × página con piso de 17 px → 20 / 17; todo Chillax; en `:root` de `estilo.css`;
  clases `.titulo-pagina/.titulo-seccion/.titulo-tarjeta`), aire de los "← Volver"
  (`--aire-volver` 32 px debajo del de arriba, `--aire-volver-abajo` 48 px debajo del de abajo; **vale también en
  los 5 formularios**, sólo espacio), grillas de 3, tarjetas "Próximamente". Cristian pidió esa regla ("que los títulos
  midan lo mismo entre sí, tiene que haber una regla, un manual"): **no escribir nunca un `font-size` suelto en un
  título; usar un nivel**. **Excepciones decididas por Cristian el 2026-10-09** ("los títulos de la Home están bien,
  los del Form también, dejalos así"): los h2 de la home (18 px), el slider de la home (14 px) y el título de los 5
  formularios (19 px) **NO se pasan a la escala**. Es decir que la escala vale para `/propiedades/`, `/desarrollos/`
  y la ficha (ver sección 7 del manual).
  **Más correcciones de Cristian (mismo día, segunda tanda)**: (e) home: el botón de matrícula (VL REALTOR)
  quedaba pegado (~12 px) al "Ver todos los desarrollos"; ahora tiene el mismo aire que hay entre "Ver todas
  las propiedades" y el título "Desarrollos destacados" (36 px, medido: 36–37 px en escritorio y celular). Regla
  en `index.html`: `.propiedades:has(.propiedades__mas:not([hidden])) ~ .botones{margin-top:36px}` — sólo aplica
  si algún slider termina con su botón "Ver todos/as"; es sólo CSS, no toca tracking. (f) `/desarrollos/`: **3 por
  hilera desde 1000 px** (2 desde 760, 1 en celular), igual que `/propiedades/`. (g) ficha: encabezado más grande
  (barrio 13–15 px, antes 11). **Títulos de página, todos del mismo tamaño**: `/propiedades/` ("Propiedades"),
  `/desarrollos/` ("Desarrollos") y la ficha (nombre de la obra) llevan la clase `.titulo-pagina` de `estilo.css`
  (hoy **30 px** en la compu y ~25 px en un celular de 390 px, "a escala"; pasó por 19 → 34 → 30: Cristian
  pidió achicarla a 30 y que los tres queden iguales). Es una clase **aparte** de `.form-header__marca`, que
  siguen usando los 5 formularios con sus 19 px (verificado). **Esto se generalizó a la escala de 3 niveles del
  manual** (arriba): los títulos de sección de la ficha son de 22 / ~19 px y los de tarjeta/detalle de 20 / 17 px
  (antes 18, 21, 20 y 15 según la página). **Excepción pedida después: las tarjetas del listado `/propiedades/`
  volvieron a su título de 15 px Inter 600 (con tope de 2 líneas)** — "20 se ven muy grandes"; son textos largos del
  portal. El título del *detalle* de la propiedad y las tarjetas de `/desarrollos/` siguen en el nivel 3. Pruebas (Playwright, miden cada nivel en todas las páginas):
  `probar_escala.py`, `probar_titulos.py`, `medir_volver.py`, `probar_ajustes10.py`, `probar_lista3.py`.
  **Sliders de fotos de la ficha (2026-10-09)**: las dos tiras de fotos ("El edificio" y "Así va la obra") ahora son
  `.fi-carrusel` (función `armarCarrusel()` en `desarrollos/ficha/index.html`): bordes que se **difuminan hasta
  fundirse con el fondo** (máscara CSS con `--fade-i`/`--fade-d`, ancho `clamp(48px,13vw,84px)`; el lado sólo se
  difumina si hay más fotos de ese lado: clases `.puede-izq`/`.puede-der`), **flechas ‹ ›** (también en celular),
  **arrastre con el mouse** (un arrastre no abre el visor), sin barra de scroll, sin `scroll-snap`. **La rueda del
  mouse NO se toma a propósito** (seguiría scrolleando la página; Cristian marcó ese conflicto). Las 4 primeras fotos
  cargan ya y el resto al primer toque/scroll/flecha (en el celular las `lazy` no cargaban más que 2). Probado con
  Playwright (`probar_carrusel.py`: flechas, estados, arrastre, clic, final de la tira; `probar_carruseles_todas.py`:
  las 20 fichas sin errores de JS). Ver `MANUAL-DE-DISENO.md`, sección 5.
  **AUDITORÍA DE BUGS Y OPTIMIZACIÓN (2026-10-09, pedida por Cristian: "buscá bugs y optimizá todo lo que se pueda")**.
  Cómo se midió: Playwright con Chromium, celular simulado con conexión "Slow 4G" (1,6 Mbps, 150 ms) y CPU ×4
  (los scripts `rendimiento.py`, `cls_fuentes.py`, `auditoria_general.py`: 11 páginas × 5 tamaños de pantalla, sin
  GTM/GA/Meta para no mandar eventos); y contra el sitio publicado (cabeceras, compresión, archivos expuestos).
  *Sin hallazgos*: ni errores de JS/consola, ni desbordes horizontales (320 a 1920 px), ni ids repetidos, ni
  imágenes rotas, ni botones sin nombre, ni campos sin etiqueta; HTML bien cerrado en las 9 páginas; `php -l` limpio.
  *Hallazgos y arreglos (todo verificado):*
  1. **Fotos del portal pesadas** (home 3,9 MB; el slider pedía el original `/public` de 0,5–1 MB cada una):
     ahora se pide la variante del tamaño que hace falta (`/w=640,q=80` en tarjetas, `/w=720,q=80` en
     `/propiedades/`, `/w=1280,q=80` en los detalles; 42–150 KB; la red de imágenes —Cloudflare Images,
     `imagedelivery.net`— ya entrega AVIF/WebP sola) con **caída automática a la original** si la variante falla
     (`variante()`/`ponerFoto()` en `index.html`, `ponerFotoPortal()` en `propiedades/index.html`). Las de
     sumadesarrollos.com.ar no se pueden achicar (son sus archivos): ver pendientes.
  2. **Imágenes propias**: `logo-redsuma.png` 120 KB → 11,7 KB (se ve a 14 px de alto; 260 px de ancho alcanza a
     4×), `icono-legal.png` 26 → 5 KB, `foto.webp` 164 → 65 KB. Mismos nombres de archivo, así no se tocó ningún
     HTML. Originales en `OLD 8-10-2026\`. Además los sliders de la home piden sus fotos con
     `fetchPriority='low'` y `decoding='async'` (no le sacan ancho de banda a la portada) y se agregaron
     `<link rel="preconnect">` a imagedelivery.net y sumadesarrollos.com.ar.
  3. **Resultado (celular lento, mismo método)**: home **3 910 KB → 623 KB** y LCP **4,2 s → 1,7 s**;
     `/propiedades/` 675 → 296 KB y LCP 6,9 → 2,1 s; formularios 243 → 135 KB.
  4. **Saltos de diseño (CLS)** por contenido que llegaba después y empujaba el pie y el "← Volver" de abajo:
     ficha 0,84 → 0,02, `/desarrollos/` 0,52 → 0,03, `/propiedades/` 0,49 → 0 (mínimos "buenos": < 0,1). Se
     reservó el lugar: la zona de contenido ocupa una pantalla mientras carga, la frase de la obra, el panel de
     filtros, el resumen y el filtro Venta/Alquiler se ven desde el principio, y el panel de filtros de
     `/desarrollos/` se abre al cargar la página (antes, al llegar los datos).
  5. **BUG REAL en `enviar-lead.php`**: el antibot comparaba la hora del reloj del CELULAR (`_ts`) con la del
     servidor; con un reloj adelantado la diferencia daba negativa y la consulta se rechazaba como "bot" (lead
     perdido). Ahora sólo se rechaza una diferencia positiva y chica (0 a 2,5 s). Además: tope de 64 KB al cuerpo
     (413), asunto del mail codificado (RFC 2047: tenía tilde y raya, algunos clientes lo mostraban con
     símbolos raros), `MIME-Version`, `X-Content-Type-Options`, y si `mail()` falla queda una línea en
     `leads_privados/mail-errores.log` (el lead ya estaba guardado). Probado con PHP real en copia aislada
     (`probar_lead.py`, 19 chequeos: reloj adelantado/atrasado, bot, honeypot, Referer ajeno, 70 KB, campos, tipo, JSON roto, GET).
  6. **Zonas táctiles chicas** (el "← Volver" medía 17 px de alto, "Política de Privacidad" 13 px, "Limpiar
     filtros" 20 px): ahora ~37–41 px con relleno y margen negativo de la misma medida; **el texto no se movió ni
     1 px** (se midió en 9 páginas × 2 tamaños: 0 diferencias de posición, aire y altura de página).
  7. **Datos del servidor reusables unos minutos**: `propiedades.php` y `desarrollos.php` (2 min) y
     `desarrollo-extra.php` (5 min) mandan `Cache-Control: public, max-age=…, stale-while-revalidate=600` SÓLO en
     respuestas buenas (los errores/"caída" siguen `no-cache`), y las páginas dejaron de pedirlos con
     `cache:'no-store'`: home → lista → ficha no vuelven a bajar el mismo JSON. También `X-Content-Type-Options: nosniff`.
  8. **Archivos del servidor expuestos** (se vio en el sitio publicado): `cache/*.json` (copias y estado de la
     sincronización) se podía leer por URL → nuevo `cache/.htaccess` (`Require all denied`, igual que
     `leads/.htaccess`; **va en el zip**; PHP lo lee igual). `serve.ps1` (script de prueba, de un zip viejo) se puede
     leer en `csrealestate.com.ar/serve.ps1`: **Cristian lo tiene que borrar desde el administrador de archivos**
     (no lleva datos privados, pero no tiene por qué estar). El zip ya no lleva `icono-legal-original.png` ni
     `logo-redsuma.webp` (originales sin uso: siguen en la carpeta local).
  *Pruebas de no-regresión que pasaron después de todo*: `probar_ficha.py` (simulador, filtros, visor, obras
  especiales), `probar_correcciones.py` (3 por hilera, "volver", detalle, "Próximamente", home, **eventos
  `ver-propiedades`/`ver-desarrollos`/`consulta-*` intactos**), `probar_lista_a_ficha.py` (20 tarjetas),
  `probar_formularios.py` (los 5 formularios completos con servidor simulado: 1 POST y **1 solo `generate_lead`
  con su `lead_type`**), `probar_propiedades.py` (7) y `probar_desarrollos.py` (9 escenarios, PHP real).
  *PENDIENTE, necesita OK de Cristian*: (a) `htaccess-seguridad-bloque.txt` — 4 cabeceras de seguridad
  (nosniff, X-Frame-Options, Referrer-Policy, Permissions-Policy) para pegar al final del `.htaccess` (hoy el sitio
  no manda ninguna; HSTS queda aparte a propósito); (b) fotos de los desarrollos: son archivos de sumadesarrollos de
  hasta 626 KB (la tarjeta de Olazábal baja un `hero.jpg` de 626 KB para una tarjeta de 300 px) y no se pueden achicar
  sin copiarlas; opción: que `desarrollos.php` guarde miniaturas propias refrescadas junto con los datos cada 8 h
  (cambia la decisión "siempre las de su servidor"); (c) `www.csrealestate.com.ar` responde igual que el dominio
  sin www (sin redirigir; el `canonical` ya apunta al sin www).
  **RENDIMIENTO, 2.ª RONDA: CUADROS POR SEGUNDO (2026-10-09, pedido: "cómo optimizamos el tiempo de carga, los fps")**.
  Método: Chromium con celular simulado (390×844, DPR 2, CPU ×4), scroll/deslizado programático con `requestAnimationFrame` y
  medición de cada cuadro (fps, p95, % de cuadros > 20 ms), con A/B inyectando CSS para aislar cada efecto (scripts del
  scratchpad: `fps_home.py`, `fps_slider.py`, `fps_otras.py`, `fps_dialogo.py`, `fps_prop_detalle.py`, `perfil_carga.py`,
  `layout_ab.py`, `traza_layout.py`). **Hallazgos**: (1) el scroll de la página ya era 59–60 fps en todas las páginas;
  (2) **el `backdrop-filter` es lo más caro**: en el slider de la home (cada tarjeta, ~15 con los clones, llevaba
  `blur(20px) saturate(150%)`) daba 53 fps y 13 % de cuadros trabados → ahora **60 fps y 0 %** quitándolo de `.propiedad`
  (diferencia visual 0,48/255, imperceptible); (3) **la ventana de detalle de una propiedad** (`.aviso--detalle`, home y
  `/propiedades/`, tenía `blur(28px)` en la ventana y `blur(3px)` en el `::backdrop`) daba **24 fps al scrollear adentro, 29 al
  pasar fotos (39 en `/propiedades/`)** con casi todos los cuadros trabados → ahora **60 fps en los tres casos** con
  `background:rgba(22,22,22,.94)` y sin desenfoque (sólo quitar el blur deja ver "fantasmas" del texto de la página a través del
  panel; con el fondo al 94 % se ve prácticamente igual: diferencia 1,3–2,9/255). Las ventanas chicas de texto (matrícula,
  privacidad) y las tarjetas de formulario conservan el vidrio. Se probó además: sin grano de fondo, sin máscara de bordes, sin
  difuminado lateral de las tarjetas, sin sombra grande: ninguno de esos pesa de forma apreciable (el grano y la máscara
  quedan como están). **Carga (sitio publicado, 3 corridas, Slow 4G + CPU ×4)**: home FCP 1,2–1,4 s y LCP 1,3–1,6 s;
  formulario FCP 0,9–1,0 s; `/propiedades/` FCP 1,0 s y LCP 1,9–2,0 s; CLS 0 en todas. La home tiene ~450 ms de tareas largas en
  ese celular simulado, casi todo **layout** (JavaScript sólo ~15 ms): se buscó un culpable (sliders, "Mi método", line-clamp,
  scroll-snap, fondo, portada, sombras, emojis ~60 ms, fuentes web) y **no hay uno solo**, el costo está repartido (un formulario
  simple ya gasta ~230 ms de layout en la misma simulación): se dejó. **Lo que queda y necesita decisión**: las fotos de
  sumadesarrollos de la home pesan 1,1 MB (Olazábal 626 KB): miniaturas propias cortarían ~700 KB (cambia la decisión de
  "siempre las de su servidor"); y el peso de GTM/GA4/Meta no se puede medir acá (se bloquean en las pruebas): correr
  PageSpeed Insights (la API de Google dio 429 sin clave; que lo corra Cristian en pagespeed.web.dev; suma 1 visita a Analytics).
  **BUG DEL SLIDER BORROSO EN EL IPHONE (2026-10-09, reportado por Cristian: "las tarjetas aparecen con blur apenas carga el
  home, se arregla al deslizar y si lo dejás quieto se vuelve a blurear")**. Causa más probable (no se pudo reproducir: sólo hay
  Chromium para pruebas y allá la tarjeta se ve nítida): al sacar el `backdrop-filter` de `.propiedad` (optimización de fps) las
  tarjetas dejaron de estar siempre en su propia capa de la GPU; la tarjeta del medio seguía con `filter: blur(0.003px)` y
  `scale(0.99987)` (nunca exactamente neutros) y Safari la dibuja en menor resolución así; sólo se veía nítida mientras se
  scrolleaba porque `.en-movimiento` pone `will-change` temporalmente. **Arreglo en `actualizarFoco()`**: la tarjeta a menos
  de ~3 px del centro (`foco > 0.985`) queda LIMPIA (`filter:none`, sin escala, opacidad sin tocar) y TODAS llevan
  `translateZ(0)` en el transform (capa propia permanente, como cuando tenían el vidrio). Verificado en Chromium: tarjeta
  central `filter:none`, laterales con blur 1,5 px como siempre, igual después de deslizar; slider 60 fps; regresiones OK.
  **Si en el iPhone siguiera borroso**: probar a volver a poner un `backdrop-filter` MÍNIMO sólo en la tarjeta central (o
  `will-change:transform` permanente) y medir fps de nuevo; ver el A/B en la sección de rendimiento.
  **ESTILOS VIEJOS EN EL SERVIDOR (9-oct ~17:10)**: las páginas publicadas eran las nuevas (piden `estilo.css?v=5e9ba346`) pero el
  `estilo.css` publicado seguía siendo el viejo (huella e6396c80, de las 12:32): el extractor de Hostinger NO pisó ese archivo
  (igual que otras veces con otros archivos). Por eso **después de cada subida hay que verificar la huella de `estilo.css` en vivo**
  (script `hashes_vivo.ps1`: publicado vs. local) y, si no coincide, pedirle que borre `estilo.css` del servidor y vuelva a extraer.
  **PLAN DE SEGURIDAD (2026-10-09)** — ver `PLAN DE SEGURIDAD.txt` (raíz, fuera del zip; en lenguaje simple, con orden
  recomendado) y `htaccess-seguridad-bloque.txt` (cabeceras + HSTS a 1 semana, **sin aplicar, espera el OK**). Cristian
  agregó una biblioteca de 966 skills de ciberseguridad en `G:\Workshop Claude\.claude\skills` (la mayoría son de
  respuesta a incidentes/ataque; se leyeron directo, no aparecen en `ListSkills`): para el sitio sirven
  `performing-security-headers-audit`, `implementing-dmarc-dkim-spf-email-security`,
  `performing-ssl-tls-security-assessment`, `implementing-api-rate-limiting-and-throttling`,
  `performing-clickjacking-attack-test`, `analyzing-web-server-logs-for-intrusion`. **Regla: sólo diagnóstico
  pasivo sobre producción** (cabeceras, DNS, certificado, OPTIONS/TRACE, rutas conocidas); NO correr Nikto/sqlmap/ZAP
  ni nada intrusivo contra Hostinger sin pedirle OK. Diagnóstico del día: HTTPS bien (Let's Encrypt, vence 2026-12-17,
  TLS 1.2/1.3, 1.0/1.1 rechazados); carpetas privadas 403; `.env`/`.git` 403; TRACE 405; PHP responde prolijo a
  entradas raras; sin cabeceras de seguridad propias (sólo `CSP: upgrade-insecure-requests` de Hostinger); DNS en
  Hostinger (dns-parking), sin CAA; correo: SPF `include:_spf.mail.hostinger.com ~all`, DMARC `p=none` sin `rua`,
  DKIM hostingermail-a/b/c; `redsuma.com.ar` (Google Workspace) SPF `~all` y DMARC `p=none`; `www` y sin-www
  responden los dos. **Antes de endurecer DMARC hay que comprobar que los avisos de `enviar-lead.php`
  (no-reply@csrealestate.com.ar) pasan SPF/DKIM alineados (Gmail > "Mostrar original")**, si no se rechazarían
  los propios avisos. El único cambio con riesgo real para GTM es la CSP: va primero en `Report-Only`. Lo más
  delicado a nivel cuentas: quién puede PUBLICAR en el contenedor GTM-5JDWTPXN (inyecta JS en todas las
  páginas) y el 2FA de Hostinger/Google/Meta/NIC.
  **Cristian confirmó que instaló TODOS los skills en esa carpeta y que se tenga en cuenta siempre** (ver la memoria
  `reference-skills-ciberseguridad`): ante cualquier tema de seguridad, buscar el skill que corresponda ahí y seguir
  su método. **Pruebas hechas con esos skills**: inyección en el mail (`testing-for-email-header-injection`, 11 casos
  contra copia local de `enviar-lead.php`: ninguna inyección posible; script `probar_inyeccion_mail.py`) y
  clickjacking (`performing-clickjacking-attack-test`: home y formularios SE PUEDEN ENMARCAR hoy; lo arregla
  X-Frame-Options del bloque `htaccess-seguridad-bloque.txt`; volver a probar con `probar_marcos.py` después de pegarlo).
  **REVISIÓN DEL ZIP DE HOSTINGER (2026-10-09 ~15:40, Cristian bajó `_csrealestate.com.ar.zip` con TODO el servidor)**:
  se extrajo en una carpeta nueva y aislada (se borró al terminar: trae datos personales). Resultado: **sin código
  malicioso** (ni PHP ajeno, ni webshells, ni `<?php` escondido, ni ofuscación, sin `error_log`), los 3 `.htaccess` son los
  propios, las 6 páginas/PHP coinciden byte a byte con las mías (las 9 HTML sólo difieren en el `?v=` del CSS, que se sumó
  después). **Sobrantes en `public_html` (hay que borrarlos desde el administrador de archivos, yo no tengo acceso)**:
  `indexOLD.html` (90 KB) e `indexORIGINAL.html` (26 KB) — versiones viejas de la home con los links a Google Forms,
  públicas, sin `noindex` y con canonical a la home (contenido duplicado para Google; `indexOLD` además dispara GTM) —,
  `icono-legal-original.png` y `logo-redsuma.webp` (originales sin uso). El `.htaccess` de `public_html` mide 166 B: unas
  40 líneas en blanco + el bloque de `Cache-Control` (el HTTP→HTTPS lo hace Hostinger por fuera, no está en el `.htaccess`).
  **LEADS (`leads_privados/leads.jsonl`, 28 consultas del 22/09 14:33 al 07/10 20:44: tasación 16, vender 6, comprar 4,
  buscar alquiler 2; 2 de prueba; 0 con gclid/utm — el arreglo de atribución recién llegó el 8/10)**: **las 26 consultas de
  vender/tasación/comprar anteriores al arreglo del 8/10 17:32 tienen la PRIMERA opción en TODAS las preguntas de opción única**
  (tipo de propiedad, estado general, situación actual, plazo, valor en mente, cómo llegó al valor, publicada, cómo continuar,
  ya tasada, forma de compra, plazo de compra): esos datos NO son confiables (el bug de `valorDe()`); sí valen los datos de
  contacto, los textos libres y las casillas múltiples. Ninguna consulta nueva desde el 7/10 (al 9/10 no había entrado ninguna con el
  formulario ya arreglado: probar uno real y revisar que guarda la opción elegida + gclid).
  **iPhone con estilos viejos**: Cristian mandó una captura (HEIC) donde el "← Todos los desarrollos" de abajo de la ficha salía azul
  subrayado y "¿Hablamos?" en la letra vieja: el celular tenía guardado un `estilo.css` anterior (los archivos publicados estaban bien:
  se comprobó la dirección normal con User-Agent de iPhone). **Arreglo permanente: `armar-zip.ps1` (nuevo, en la raíz del proyecto,
  fuera del zip) sella la versión del CSS en las 9 páginas (`estilo.css?v=<8 primeros caracteres del SHA256 de estilo.css>`), arma el
  zip y lo verifica; correrlo SIEMPRE para armar el zip (reemplaza al `armar_zip.ps1` suelto de las sesiones).** Cambia sola cada vez
  que cambia `estilo.css`, así ningún navegador/CDN sirve estilos viejos con HTML nuevo. Probado: las 9 páginas cargan el CSS
  versionado, el link de abajo toma su diseño, formularios completos y regresiones OK. Sólo hay Chromium instalado para pruebas (sin WebKit/Safari).
  **Estado del 9-oct 12:06**: lo publicado era la versión de las
  04:04 (anterior a la auditoría); el zip de 381 KB (06:42) todavía no estaba subido.
  **Limpieza del 2026-10-09 (autorizada por Cristian, a la Papelera de Windows)**: se borraron
  `desarrollo-1..3.jpg`, `propiedad-1..5.webp`, `local-pueyrredon.jpg` y `formularios-solamente.zip` (sin uso). Se
  conservan a pedido suyo `icono-legal-original.png`, `logo-redsuma.webp`, `GOOGLE_ADS_SITE_AUDIT.md`,
  `htaccess-cache-bloque.txt` y `.claude/guia-gtm-ads.html`. Las `propiedad-N.webp` que ya estén en Hostinger
  quedan ahí hasta que él las borre desde el administrador de archivos (el zip ya no las lleva).
  **Archivos de texto de Cristian en la raíz del proyecto (fuera del zip)**: `MAPA WEB.txt` y `MAPA ADS.txt`
  (mapas mentales de cómo funciona la web y de cómo se conecta con las Ads, con fecha al inicio; hay que
  actualizarlos si cambia la estructura) y `MANUAL-DE-DISENO.md`.
- **CRM de Cristian (leído en modo solo lectura, 2026-10-08)**: `admin.redsuma.com.ar`
  → su catálogo tiene **1 propiedad**: `16953 · Nazca 4501 · Local · Alquiler ·
  Activa · Villa Pueyrredón · ARS 2.630.000 · 4 amb · 135 m²` (la del slider). Hay
  "Cambios rechazados: 1": el staff (Vanesa Timberini) le rechazó los últimos
  cambios hace ~8 h con el comentario **"Cristian, el video no se ve."** — **aclarado
  por Cristian (2026-10-08): no hay nada que corregir**: el cambio rechazado era un
  link de YouTube que quedó bloqueado por derechos de autor de una canción de Pixabay;
  ya apeló y espera la respuesta. El aviso sigue publicado en el portal. Las otras 5
  propiedades del slider NO están en su perfil (son de otros agentes).
- **Propiedades: reglas definitivas (2026-10-08)** — ver la sección "Slider de 7
  propiedades..." más abajo, que reemplaza a las ideas de "5 tarjetas", "`destacadas`
  y "`destacadas.txt`" que se barajaron antes: **siete en total, las propias de
  Cristian primero y el resto las que él agrega diciendo "sincronizá este link"**.
- **Datos sospechosos de su lado**: Isolina (Manuel Belgrano 4727, Caseros) y
  Monroe (Monroe 1678, Belgrano) devuelven números idénticos (21 unidades, mismo
  texto de tipologías, desde USD 119.791, "diciembre 2028") — casi seguro una
  planilla repetida en su origen; el respaldo de Isolina dice otra cosa (26
  unidades, desde USD 65.450, julio 2028). No copiar esos números sin confirmar.
- **Lo que está desactualizado de nuestras 3 tarjetas manuales**: Congreso 4111
  dice "A estrenar" y la obra es de entrega 2º semestre 2028.
- Para leerlo desde un navegador sirve `DATOS` (un `Map` global de esa página,
  con `d.n`, `d.desde`, `d.texto`, `ant`, `cuota`, `p.__origen`); desde PHP habría
  que replicar `bloques()`/`resumen()` sobre los CSV. Está **pendiente definir con
  Cristian** cuáles mostrar, si se sincroniza solo o a pedido, y si va un botón
  "Ver edificio" a su link personalizado (`.../<url>?a=cristian-1166951945`,
  nuevo `boton_id` → requiere su OK por el protocolo de tracking).

## Auditoría de bugs y optimización (pedida por Cristian)

Cristian pidió expresamente "buscá bugs y reportámelos antes de hacer
algo" — se hizo una revisión completa de `index.html` (8 ángulos de
búsqueda: correctitud, invariantes rotos, referencias cruzadas,
duplicación, simplificación, eficiencia, profundidad del fix, y reglas de
este mismo `CLAUDE.md`), cada hallazgo confirmado en el navegador antes de
tocar nada. De los 10 reportados, Cristian pidió arreglar 6 (los de abajo)
y dejar 4 como están — ver el porqué de cada uno:

**No se tocan, a propósito:**
- Número de WhatsApp repetido a mano en 4 lugares — Cristian lo sabe y
  prefiere dejarlo así ("el día que lo cambiemos hay que acordarse de
  cambiar todos").
- La apertura automática de `#more-info` puede, en una ventana muy corta,
  pisar un cierre manual — Cristian no lo ve como problema.
- Que abrir el modal de matrícula reemplace el hash `#more-info` en la URL
  (en vez de preservarlo) — **es el comportamiento buscado**: el hash es
  ante todo una señal simple para medir clics (Google Ads/Meta), no un
  mecanismo para reconstruir el estado exacto de la página.

**Arreglados en esta pasada:**

1. **Foto del detalle de un desarrollo, sin el recorte "ancla abajo".**
   `#desarrollo-detalle-foto{object-position:center bottom}` — el fix
   original sólo se había puesto en la miniatura del carrusel
   (`#desarrollos-pista .propiedad__foto`), no en `.propiedad-detalle__foto`
   (que reusan tanto propiedades como desarrollos, así que el selector
   apunta al id específico del desarrollo, no a la clase compartida).

2. **Línea de 1px siempre visible debajo de "Mi método".** El
   `border-top` de `.mi-metodo__contenido` se movió a
   `.mi-metodo__contraccion.abierto .mi-metodo__contenido` — un borde no
   se comprime a 0 aunque la fila del grid sí lo haga, así que puesto
   siempre dejaba un resabio incluso cerrado.

3. **Ícono de matrícula sin manejo de error.** Mismo
   `onerror="this.style.display='none'"` que ya usa la foto de portada,
   agregado a `icono-legal.png`.

4. **Clicks en tarjetas de Propiedades/Desarrollos ahora avisan al
   `dataLayer`** — a pedido de Cristian ("estaría bueno que si se clickea
   alguna tarjeta, me pueda avisar de alguna forma para poder crear un
   evento sobre eso"). Se agregó un `window.dataLayer.push({event:
   'click_boton', boton_id: 'ver-' + pista.id.replace('-pista',''),
   boton_texto: p.titulo, destino: ''})` dentro de `abrirDetalle()` (no
   `data-evento` en el botón de la tarjeta, a propósito: el mismo botón a
   veces sólo centra la tarjeta en vez de abrir el detalle, y ese
   "centrar" no es interés real que valga la pena trackear). `boton_id`
   sale de `ver-propiedades` o `ver-desarrollos` según el slider, sin
   necesidad de un campo nuevo en `opciones` de `crearCarrusel`. Para que
   esto genere una conversión medible en Google Ads/Meta, falta el mismo
   paso de siempre: crear la acción de conversión del lado de Google/Meta
   apuntando a este evento (ver sección "Tracking").

5. **`resize` del carrusel sin el mismo freno por frame que el `scroll` de
   al lado.** Se le agregó el mismo patrón `tickingX` + `requestAnimationFrame`
   que ya usa `pedirFoco()` — sin esto, arrastrar el borde de una ventana o
   rotar el celular disparaba un recálculo completo del carrusel por cada
   evento "resize" (pueden ser decenas por segundo).

6. **`will-change` permanente en las tarjetas del carrusel, ahora
   condicionado.** `.propiedad{will-change:...}` pasó a
   `.propiedades__pista.en-movimiento .propiedad{will-change:...}` — la
   clase `en-movimiento` la agrega JS en el mismo listener de `scroll` que
   ya dispara `pedirFoco()`, y la saca `revisarLoop()` (el mismo chequeo
   que ya corría 130ms después de que el scroll se asienta). Antes, con
   ~13 tarjetas por slider (ítems + clones) × 2 sliders, quedaban ~26
   capas de composición GPU reservadas toda la visita sin importar si se
   estaba scrolleando o no; ahora sólo se reservan mientras hay
   scroll/arrastre en curso. Probado arrastrando el carrusel completo
   (loop incluido) después del cambio: sigue funcionando idéntico.

   De paso, se sacó la duplicación de la cuenta del salto de loop:
   `revisarLoop()` y `corregirLoopEnVivo()` (arrastre en vivo con mouse)
   hacían el mismo cálculo "¿está en zona de clones? saltar
   items.length×paso" cada una por su cuenta — ahora las dos llaman a una
   sola `calcularSaltoLoop()` compartida, que sólo devuelve el delta (0 si
   no hace falta saltar); cada función sigue decidiendo cuándo llamarla y
   qué más hacer con el resultado (revisarLoop asigna scrollLeft directo,
   corregirLoopEnVivo además corrige `scrollArranque`). Esto no cambia
   ningún comportamiento — sólo evita que un futuro ajuste al límite de la
   zona de clones se aplique por error a una sola de las dos copias.

**No arreglado, quedó reportado pero no pedido:** los otros 3 hallazgos
del reporte (número de WhatsApp, carrera de `#more-info`, y el
comportamiento del hash con el modal de matrícula) — ver arriba, son a
propósito.

## Formularios propios (reemplazo de los Google Forms)

Cristian pidió reemplazar los 5 Google Forms externos por formularios
propios dentro del sitio, con el mismo look & feel, multi-step, y que sólo
disparen `generate_lead` cuando el backend confirme que guardó la consulta
(nunca al abrir el formulario ni al hacer clic en "Enviar" antes de la
confirmación) — ver la sección de Analytics más arriba para el porqué de
esa regla. **Los 5 están implementados**: primero se hizo sólo "vender" (a
pedido explícito de Cristian, para aprobarlo antes de replicar), y una vez
aprobado ("el formulario está OK") se armaron los otros 4
(`tasacion`, `alquilar-mi-propiedad` → `lead_type` `alquilar_propiedad`,
`comprar`, `buscar-alquiler` → `lead_type` `buscar_alquiler`) con el mismo
patrón exacto. Ninguno de los 5 botones de la home abre ya un Google Form.

### Antes de programar: dos decisiones que le tocaban a Cristian

El sitio no tenía backend de ningún tipo (HTML/CSS/JS estático, subido por
zip). Sin backend, la propia especificación de Cristian pedía **no agregar
nada sin avisar** — se le preguntó (no se asumió):

- **¿Cómo guardar los leads?** → eligió **PHP en Hostinger** (confirmó que
  su plan lo tiene) en vez de un servicio externo de formularios.
- **¿Hacía falta una Política de Privacidad?**, dado que ahora el sitio
  guarda datos personales en su propio servidor por primera vez (antes
  quedaban en Google Forms) → pidió que Claude la redactara. Es un
  borrador — conviene que alguien con conocimiento legal lo revise. Ver
  más abajo "Política de Privacidad: modal, no página" para dónde vive
  hoy (cambió de idea a los pocos días de creada).

### Extracción de las preguntas de cada Google Form

Todas las preguntas de los 5 formularios (`vender`: 14, `tasacion`: 7,
`alquilar-mi-propiedad`: 9, `comprar`: 11, `buscar-alquiler`: 9) se
extrajeron abriendo cada form público y leyendo su árbol de accesibilidad
(no se adivinó ninguna) — texto, tipo de campo (texto/radio/checkbox) y
cuáles son obligatorias, tal cual estaban. Cambios a propósito, informados
en vez de aplicados en silencio:

- **Email agregado como obligatorio** en `tasacion` y `buscar-alquiler`
  (no existía ese campo en esos dos Google Forms) y **Teléfono/WPP
  vuelto obligatorio** en `vender` y `alquilar-mi-propiedad` (existía pero
  no era obligatorio) — la especificación de Cristian pide que
  Nombre/WhatsApp/Email sean *siempre* obligatorios en los formularios
  nuevos, sin excepción por formulario.
- **`comprar`**: el original decía "Departamente" (typo) en la opción de
  tipo de propiedad — se corrigió a "Departamento".

Ningún otro texto, pregunta u opción se agregó, sacó o parafraseó.

### Arquitectura

- **Ruta real, no router de cliente**: cada `form/<nombre>/index.html`
  es un archivo más — Apache/Hostinger sirve `form/<nombre>/` con su
  `index.html` de carpeta de forma nativa, sin configuración adicional
  (mismo mecanismo que `csrealestate.com.ar/` sirve el `index.html` de la
  raíz). Carpetas: `vender`, `tasacion`, `alquilar-mi-propiedad`, `comprar`,
  `buscar-alquiler` (mismo nombre que el `boton_id` de cada botón en la home).
- Los 5 botones de la home cambiaron su `href` del Google Form a su ruta
  interna (`form/<nombre>/`) y se les sacó `target="_blank"
  rel="noopener"` (ya no son links externos). El `data-evento` de cada uno
  **no se tocó** — el handler genérico de clicks (el mismo de siempre, sin
  tocar) sigue empujando `{event:'click_boton', boton_id, boton_texto,
  destino: origen.href}` — `destino` ahora apunta solo a la URL interna
  nueva, sin que hiciera falta cambiar ese código.
- **GTM instalado en cada página nueva** (las 5 páginas de formulario
  llevan el mismo snippet `GTM-5JDWTPXN` en el head/body que `index.html`)
  — esto NO es "instalar otro GTM" (lo que la sección de Tracking pide
  evitar): es el mismo contenedor de siempre, repetido en cada página, que
  es como funciona GTM en cualquier sitio de más de una página. Sin este
  snippet, esas páginas no mandarían nada a GA4.
- `enviar-lead.php`, en la raíz, es el **único** endpoint — lo llaman
  los 5 formularios. Recibe JSON por `POST`, valida (nombre/teléfono/email
  obligatorios siempre + los campos propios de cada `lead_type`, con un
  arreglo `$TIPOS_VALIDOS = ['vender','tasacion','alquilar_propiedad',
  'comprar','buscar_alquiler']` y un bloque `if ($tipo === '...')` por
  cada uno — sumar un formulario nuevo el día de mañana es agregar su
  slug ahí y su propio bloque, nada más), sanea cada campo (`strip_tags` +
  recorte de largo + saca `\r\n` para que no se pueda inyectar un header
  de mail), guarda una línea JSON en `leads/leads.jsonl` (con `flock` para
  escritura segura) y recién después intenta avisar por email a
  `cstedtfeld@redsuma.com.ar` con `mail()` — el archivo es la fuente de
  verdad; si el mail falla o cae en spam, el lead no se pierde.
  `leads/.htaccess` bloquea cualquier acceso HTTP directo a esa carpeta.
- **Antispam liviano, sin CAPTCHA** (a pedido explícito: "no CAPTCHA
  agresivo sin necesidad"): un campo trampa invisible (`sitio_web`, que
  una persona nunca ve ni completa) + un campo `_ts` con la hora de carga
  de la página, rechazado si el envío llega en menos de 2.5s (nadie llena
  14 preguntas tan rápido) + chequeo laxo de `Referer` (sólo rechaza si
  viene un dominio ajeno explícito; si falta, no bloquea).
- **`generate_lead` sólo después de la confirmación real del servidor**:
  el frontend hace `fetch('../../enviar-lead.php', ...)`, y sólo si la
  respuesta es `200` con `{ok:true}` muestra la pantalla de "¡Gracias!" y
  recién ahí hace `dataLayer.push({event:'generate_lead', lead_type,
  form_name})` (mismo valor en los dos, uno por formulario — ver la lista
  de `$TIPOS_VALIDOS` arriba) — sin nombre/email/teléfono ni ningún otro
  dato personal, tal cual pide la sección de Analytics. Si falla (red
  caída, servidor con error, lo que sea), se muestra un mensaje de error,
  no se pierde nada de lo que la persona ya completó, y el botón vuelve a
  estar disponible para reintentar.
- **Multi-step con validación propia** (`novalidate` en el `<form>`, todo
  el mensaje de error se arma a mano), cantidad de pasos según cuántas
  preguntas tiene cada formulario (3 en `tasacion`/`comprar`/
  `buscar-alquiler`, 3 en `alquilar-mi-propiedad`, 5 en `vender` — el más
  largo): barra de progreso, "Atrás"/"Continuar", foco que se mueve al
  título de cada paso al cambiar (accesibilidad — lector de pantalla y
  navegación por teclado), grupos de radio/checkbox como `<fieldset>` con
  `<legend>` propio. El último paso, siempre, exige nombre/WhatsApp/email
  con validación de formato laxa (no bloquea con reglas estrictas, sólo
  detecta casos claramente inválidos).
- Reusa `estilo.css` (ver sección de Archivos) para no duplicar CSS: la
  tarjeta del formulario es literalmente `.aviso` (la misma clase del
  modal de matrícula), los botones "Continuar"/"Atrás"/"Enviar" son
  `.boton` de siempre — con un agregado: `.form-nav__siguiente` (el botón
  de avanzar/enviar en los 5 formularios, nunca "Atrás") lleva un tinte
  bronce leve (`rgba(166,124,69,.16)` de fondo, borde a juego), a pedido
  de Cristian ("levemente del color dorado que venimos usando") — mismo
  acento de siempre, no un botón sólido. Como está en `estilo.css`, se
  aplica solo a los 5 formularios sin tocar cada archivo. Lo demás nuevo
  son las clases `.form-*` (pasos, preguntas, opciones tipo chip con
  acento bronce vía `accent-color` + `:has(input:checked)`, mensajes de
  error).
- **Cada página de formulario es un archivo independiente**, sin
  compartir JS entre sí (mismo criterio que siempre: sin build, cada
  página embebe su propio script). El motor del multi-step (validación,
  navegación entre pasos, envío) está duplicado 5 veces a propósito — es
  poco código, cambia junto con las preguntas de cada formulario, y
  entretejerlo en un único archivo compartido hubiera obligado a
  parametrizar todo (cuántos pasos, qué campos, qué es obligatorio) en
  vez de simplemente escribirlo. Si algún día hay que cambiar el motor en
  sí (no las preguntas), hay que tocar los 5 archivos.

### Política de Privacidad: modal, no página

Cristian pidió el cambio después de ver la primera versión (una página
aparte, `privacidad/index.html`) por dos motivos: (1) Google pide un link
de Política de Privacidad, y quería uno tipo `csrealestate.com.ar/#algo`
en vez de una ruta nueva; (2) probando el formulario notó que si tocabas
"Política de Privacidad" desde el último paso, te sacaba del formulario a
otra página — y si después querías volver, "Volver al inicio" te llevaba
a la home, no de vuelta a donde estabas, así que en la práctica había que
empezar el formulario de nuevo.

**Solución:** la Política de Privacidad ahora es un `<dialog>` (`id=
"privacy-policy"`, misma clase `.aviso` que el resto de los modales del
sitio), no una página — igual que ya existía `#aviso-legal` en la home.
Se abre encima de la página actual, sin navegar a ningún lado, así que
cerrarla te deja exactamente donde estabas (mismo paso del formulario,
mismos datos ya cargados) — el problema de "cómo volver" desaparece
porque nunca se navega. `privacidad/index.html` se borró (el texto vive
ahora sólo en el/los `<dialog>`).

Como no hay forma de compartir un `<dialog>` entre páginas sin JS de por
medio (y estas páginas no comparten script), **el mismo modal está
repetido en las 6 páginas** (home + 5 formularios) — mismo contenido,
mismo id. En la home se abre con el delegado genérico de clicks que ya
existía (`data-evento="privacidad" data-abre="privacy-policy"`, en un
link nuevo agregado al pie); en cada formulario, que no tiene ese
delegado, se abre con un bloque de ~20 líneas escrito a mano (ver el
final del `<script>` de cualquier `form/*/index.html`). Todas las
páginas tienen además un link "Política de Privacidad" en el pie, no
sólo en el paso de contacto del formulario — así Google puede *encontrar*
el link crawleando, no sólo abrirlo si alguien ya sabe el hash de
memoria. Ese link va en su propio párrafo (`.legal__privacidad`),
**arriba** de `.copyright` — Cristian pidió esa separación específica
para que no quedara "colgando" pegado al texto de derechos reservados.

El mecanismo de "abrir sola al cargar si la URL trae el hash" que ya
tenía `#aviso-legal` **se generalizó** en `index.html`: antes era código
escrito a mano sólo para ese id, ahora es un bloque genérico
(`document.querySelectorAll('dialog[id]')...`) que abre cualquier
`<dialog>` cuyo id coincida con `location.hash` — con esto,
`csrealestate.com.ar/#privacy-policy` (o cualquier `<dialog>` que se
agregue después) funciona sin tocar ese bloque de nuevo.

*Nota de método, por si se vuelve a probar esto*: al testear
navegando repetidas veces entre `.../` y `.../#privacy-policy` **dentro
de la misma pestaña**, el resultado fue inconsistente — a veces abría
sola, a veces no. Con una pestaña nueva en cada prueba, siempre abrió
bien. Motivo: ir de una URL sin hash a la misma URL con hash puede
resolverse como navegación "dentro del mismo documento" (sólo cambia
`location.hash`, dispara `hashchange`, no re-ejecuta los `<script>` de la
página) en vez de una carga de página nueva — que es exactamente lo que
pasa siempre que alguien entra por primera vez a esa URL (compartida,
tipeada, o clickeada desde afuera), el único caso real que importa. No es
un bug del sitio, es una particularidad de repetir pruebas en la misma
pestaña.

### Dos bugs reales, encontrados y arreglados durante la implementación

1. **Un comentario CSS con una ruta de ejemplo tipo glob se cerraba solo.**
   El comentario de cabecera de `estilo.css` decía, a modo de ejemplo,
   `formularios/*/index.html` — esos tres caracteres `/`, `*`, `/`
   seguidos contienen, sin querer, la secuencia `*/` que cierra un
   comentario CSS. Resultado: el comentario se cerraba ahí en medio, todo
   el texto real que venía después (varias líneas de prosa) se intentaba
   parsear como CSS, fallaba, y el navegador descartaba en silencio desde
   ahí hasta la siguiente regla reconocible — **se perdía el bloque
   `:root{}` completo** (todos los tokens de color/tamaño) sin ningún
   error en consola. Se detectó comparando `document.styleSheets[0]
   .cssRules` (que no traía `:root`) contra el archivo servido (que se
   veía perfecto a simple vista) y bisectando el texto con
   `CSSStyleSheet.replaceSync()` hasta aislar el comentario como causa.
   **Lección para el futuro**: nunca escribir `*/` dentro de un comentario
   CSS, ni siquiera sin querer vía una ruta con `*` de comodín — si hace
   falta ejemplificar una ruta así, escribirla distinto (p. ej. "una
   carpeta por formulario, como formularios/vender/index.html").

2. **El atributo `hidden` de `#btn-atras` no ocultaba nada.** `.boton`
   define `display:flex` — como esa regla vive en la hoja de estilos del
   sitio (autor), le gana SIEMPRE a la regla `[hidden]{display:none}` del
   navegador (user agent), sin importar la especificidad: el origen de la
   regla pesa más que la especificidad en la cascada. El botón "Atrás"
   quedaba visible en el paso 1 aunque `btnAtras.hidden = true` se
   ejecutara bien. **Solución**: `[hidden]{display:none!important}`
   agregado como regla global en `estilo.css`. **Ojo si se agrega un
   elemento nuevo que se oculte con `.hidden`/`hidden` Y que además tenga
   una clase con `display` propio** (cualquier `.boton`, `.form-paso`,
   etc.) — sin esa regla `!important`, el `display` de la clase gana
   siempre y el elemento no se oculta.

### Qué se probó y qué falta probar

Probado en el navegador, con un servidor estático local (`serve.ps1`,
ver Archivos) en mobile y desktop, **para los 5 formularios**: todos los
pasos completos, validación de cada campo obligatorio/opcional (incluida
la de "al menos 1" en los checkbox), formato de email/teléfono,
foco/teclado, `Atrás` conservando lo ya completado, el camino de error
(falla real contra el servidor estático, que no ejecuta PHP) mostrando el
mensaje y sin romper nada, y el camino de éxito (simulado interceptando
`fetch` para devolver `{ok:true}`, para poder correr el código real de
éxito sin tener PHP local) — confirmado en cada uno que `generate_lead`
se dispara con el `lead_type`/`form_name` correcto, sin ningún dato
personal. También se probó el modal de Política de Privacidad desde el
paso de contacto y desde el pie en varios de los formularios, confirmando
que cerrarlo deja el formulario exactamente como estaba (mismo paso,
mismos datos).

**Lo que NO se pudo probar sin un servidor PHP real** (no hay PHP
instalado en esta máquina): la ejecución real de `enviar-lead.php` — que
guarde bien `leads/leads.jsonl` para cada uno de los 5 `lead_type`, que
el email llegue (y no caiga en spam), y que `leads/.htaccess` bloquee de
verdad el acceso directo. Tampoco se pudo probar `propiedades.php` contra
un PHP real (ver esa sección). **Cuando esto se suba a Hostinger, antes
de darlo por terminado**: mandar una consulta de prueba real desde cada
uno de los 5 formularios, confirmar que llegó el mail (revisar spam) y
que `leads/leads.jsonl` tiene las líneas nuevas (por FTP/administrador de
archivos — no por URL, `.htaccess` la bloquea a propósito), confirmar que
entrar directo a `csrealestate.com.ar/leads/leads.jsonl` da
error/prohibido, y correr una sesión de **GTM Preview** para confirmar
que `generate_lead` llega a GA4 con el `lead_type` correcto en cada caso
(regla de "Testing obligatorio" de la sección de Analytics).

### Formato del mail de aviso — etiquetas legibles, sin preguntas "desaparecidas" (2026-09-28)

Cristian usa el mail que le llega de cada lead como guión para llamar al
cliente después, y tenía un problema real: clientes que "no recuerdan" o
se confunden con lo que respondieron, y eso lo hacía quedar como que él
"no lee" la consulta. Pidió reformatear el cuerpo del mail (sólo el mail
— **la estructura interna, `$lead`, lo que se guarda en `leads.jsonl`,
`generate_lead`, el `dataLayer` y la validación no se tocaron en nada**,
como pidió explícitamente).

**Antes**: el mail recorría `$lead` con sus claves crudas del payload
(`motivo_tasacion: ...`, `ya_tasada: ...`).

**Ahora**, en `enviar-lead.php`, justo antes de armar `$cuerpo`:

- `$NOMBRES_FORMULARIO`: nombre lindo por `lead_type` (`tasacion` →
  "Tasación", etc.) — se usa tanto en el cuerpo (`Formulario: ...`) como
  en el asunto del mail (antes decía "Nueva consulta: tasacion — Luis",
  ahora "Nueva consulta: Tasación — Luis").
- `$CAMPOS_EMAIL`: un array por `lead_type` con **la lista fija y
  ordenada** de sus preguntas propias, `campo => Etiqueta legible` (ej.
  `'ya_tasada' => '¿Ya fue tasada?'`), en el mismo orden en que aparecen
  en el formulario real. El cuerpo recorre ESTA lista, no las claves que
  tenga `$lead` — así, si una pregunta opcional quedó sin responder,
  igual aparece en el mail con el valor vacío (`texto()` ya la deja como
  `''` en `$lead`), en vez de desaparecer — es a propósito: una pregunta
  que no aparece en el mail es una pregunta que Cristian se puede olvidar
  de hacer en la llamada.
- Encabezado fijo antes de esa lista: `Formulario`, `Fecha` (reformateada
  a `d/m/Y - H:i` + `hs`, ej. "28/09/2026 - 17:44hs" — `$lead['fecha']`
  sigue guardándose en ISO 8601 para `leads.jsonl`, esto es sólo una
  copia formateada para el mail), `Nombre`, `Teléfono`, `Email`.
- Atribución de Ads (`gclid`/`utm_*`, ver sección de arriba) sigue
  apareciendo al final del mail, sólo si vino con el lead — no forma
  parte de las preguntas del formulario, así que no aplica el criterio de
  "mostrar vacío si falta".

**Las etiquetas son las que eligió Cristian** (dio el ejemplo completo de
"tasación" en el chat) o, para los otros 4 formularios, una versión corta
y clara en el mismo tono, armada leyendo la pregunta real de cada campo
en su `form/<nombre>/index.html` — no son necesariamente el texto
literal de la pregunta del formulario (igual que Cristian acortó
"¿Por qué querés conocer su valor?" a simplemente "Motivo"). Si alguna
etiqueta no queda como Cristian quiere, están todas juntas en
`$CAMPOS_EMAIL`/`$NOMBRES_FORMULARIO`, fáciles de ajustar sin tocar nada
más.

**No probado contra un servidor PHP real** (mismo motivo que el resto de
`enviar-lead.php`, ver más arriba) — antes de darlo por bueno en
producción: mandar una consulta de prueba por cada uno de los 5
formularios, dejando alguna pregunta opcional sin responder a propósito,
y confirmar que el mail la muestra igual con valor vacío en vez de
saltearla.

### Preguntas nuevas en "comprar" y "buscar alquiler" (2026-10-08)

Cristian pidió subir la calidad de los leads de compra y distinguir el
alquiler temporario. Antes de tocar nada se le avisó qué podía romperse
(ambas son landings de Ads, `#Search_4_compradores` y
`#Search_5_inquilinos`, hoy pausadas) y dio el OK. **Qué NO cambió**: rutas,
`lead_type`, `form_name`, `generate_lead` (se dispara una sola vez, con los
mismos valores), `boton_id`, `dataLayer`, UTMs/gclid, `valorDe()` de
`comprar`. Sí cambió el payload (campos nuevos), la validación del frontend
y el mail.

**`form/comprar/`** (siguen siendo 3 pasos):
- "¿Qué tipo de propiedad buscás?" suma la opción **Flipping**, entre "Local
  comercial" y "Otro".
- **Nueva, obligatoria**: "¿Es para vivienda o inversión?" (`destino_compra`:
  "Para vivir" / "Para invertir"), paso 1 justo debajo del tipo. *(El texto de
  la pregunta se cambió el 2026-10-08, a pedido de Cristian, desde "¿Es para
  vivir o para invertir?" — para no repetir en la pregunta las mismas palabras
  que ya usan las respuestas. Sólo cambió el enunciado y la etiqueta del mail:
  las respuestas y el valor que se guarda, `Para vivir`/`Para invertir`, son los
  mismos; los leads guardados antes no se tocan.)*
- **"¿Para cuándo te gustaría comprar?"** (`plazo_compra`) pasó de opcional a
  **obligatoria** y suma la opción **"Solo estoy mirando"** (para que quien no
  tiene apuro se autofiltre sin tener que mentir).
- **Nueva, opcional**: "¿Ya estuviste visitando propiedades?" (`visitando`:
  "Sí, ya visité varias" / "Visité alguna" / "Todavía no, recién empiezo").
- **Nueva, condicional y opcional**: "¿Tenés el crédito preaprobado?"
  (`credito_preaprobado`: "Sí, ya está preaprobado" / "Lo estoy gestionando" /
  "Todavía no lo empecé"). Aparece **sólo** si en "¿Cómo realizarías la
  compra?" se eligió "Con crédito hipotecario" o "Combinación de las
  anteriores"; si la persona vuelve a otra forma de compra, se esconde **y
  se destilda** (un radio escondido pero tildado seguiría viajando en el
  payload). Lógica en `mostrarOcultarCredito()`.
- El presupuesto sigue **opcional** (no se tocó; era la otra sugerencia que
  se le hizo y no la pidió).

**`form/buscar-alquiler/`**:
- **Nueva, obligatoria, primera del paso 1**: "Tipo de modalidad" (`modalidad`,
  **radio**, una sola opción): "Tradicional" / "Temporario". Se lee con
  `valoresDe('modalidad')[0]` (que filtra por `:checked`) y NO con el
  `valorDe()` de ese archivo, que sigue siendo la versión vieja (devuelve el
  primer elemento de un grupo de radios sin mirar cuál está marcado — el bug
  que ya se corrigió en los otros 4 formularios; en éste nunca hizo falta
  porque todo eran checkboxes, pero **cualquier radio nuevo ahí necesita
  `valoresDe`** o arreglar `valorDe()`).

**`enviar-lead.php`**: guarda `destino_compra`, `credito_preaprobado`,
`visitando` (comprar) y `modalidad` (buscar_alquiler) en `$lead`, y los suma
al mail en `$CAMPOS_EMAIL` (`¿Es para vivienda o inversión?`, `¿Crédito
preaprobado?`, `¿Ya visitó propiedades?`, `Modalidad`, en el mismo orden que
el formulario; los vacíos salen igual con valor vacío). **A propósito el
servidor NO exige** las preguntas nuevas obligatorias (`destino_compra`,
`plazo_compra`, `modalidad`): las exige sólo el frontend. Motivo: durante un
deploy, alguien con la versión vieja del formulario abierta o en caché
manda el POST sin esos campos — si el servidor los exigiera, esa consulta
real se rechazaría y se perdería un lead. Un lead sin esas respuestas es
mejor que ningún lead. (Un bot que se saltee el frontend no es un riesgo
que esto empeore: ya tenía el antispam propio.)

**Probado** en el navegador, con `dataLayer.push` aislado y sólo
`enviar-lead.php` simulado (ver la lección de GTM en localhost más arriba),
eligiendo siempre la **última** opción de cada grupo: el payload coincidió
campo por campo en los dos formularios; sin `destino_compra` / `plazo_compra`
/ `modalidad` el formulario frena con "Elegí una opción."; la pregunta de
crédito aparece/desaparece/se limpia como corresponde; `modalidad` permite
una sola opción; `generate_lead` se disparó una vez con el `lead_type`/
`form_name` de siempre. **Después** se probó `enviar-lead.php` con PHP real
(ver "PHP local para probar"): los leads se guardan con los campos nuevos,
el mail trae las etiquetas nuevas (los vacíos salen igual con valor
vacío), un POST del formulario VIEJO (sin los campos nuevos) sigue
entrando con 200, y sin zona / con el honeypot lleno se rechaza igual que
antes. **No probado**: la llamada real a `mail()` (en la prueba se capturó
el cuerpo en un archivo; Hostinger es quien lo manda) ni GTM Preview /
Meta Test Events — esas son del lado de Cristian; conviene mandar una
consulta de prueba por cada formulario en producción y confirmar que llega
el mail. *Este cambio afecta la documentación de Ads/Tracking: conviene
exportar GTM y actualizar el Master.*

### PHP local para probar (2026-10-08)

Cristian autorizó instalar PHP para poder probar los `.php` sin depender de
Hostinger. Quedó en **`G:\Workshop Claude\Programas Claude\PHP 8.3.35\`**
(PHP 8.3.35 NTS x64, descargado de windows.php.net con el SHA256 oficial
verificado; portable — no se instaló nada en Windows ni se tocó el PATH;
`php.ini` ya trae `mbstring`/`openssl`/`curl`/`fileinfo` activados).
**Preferencia de Cristian: todo programa que se instale va dentro de
`G:\Workshop Claude\Programas Claude\`**, nunca en carpetas temporales ni
en el sistema. El mismo día pidió mover también lo que se había instalado
antes para otros proyectos (PDFs, transcripción de voz, video): Chromium de
Playwright, el modelo Whisper y los paquetes de Python de usuario pasaron
a esa carpeta, con un acceso especial ("junction") en el lugar original para
que nada se rompa, y **Python 3.12.10 se desinstaló y se reinstaló en
`Programas Claude\Python 3.12\`** (mismo número de versión, porque los
paquetes de usuario están compilados para 3.12; ver `Programas Claude\LEEME.md`
para el detalle, la verificación de que el ACM sigue dando lo mismo y el
aviso de reiniciar Claude para que tome el PATH nuevo). No borrar ni mover
esas carpetas sin avisar. Cómo se usa PHP:
- Sintaxis: `& 'G:\Workshop Claude\Programas Claude\PHP 8.3.35\php.exe' -l archivo.php`
- Probar `propiedades.php`/`enviar-lead.php`: **siempre en una copia
  aislada** (carpeta temporal), nunca desde la raíz del proyecto — ambos
  escriben en disco (`cache/propiedades.json`; `leads_privados/` un nivel
  ARRIBA del archivo) y ensuciarían el proyecto o la carpeta padre. Para
  `enviar-lead.php` se levantó `php -S 127.0.0.1:PUERTO -t carpeta -c php.ini`
  (**las rutas con espacios van entre comillas en `-ArgumentList`**, si no el
  servidor muere en silencio) y, en la copia de prueba, se reemplazó sólo la
  línea `@mail(...)` por un `file_put_contents` para poder leer el cuerpo.
- Lo que se probó el 2026-10-08: `php -l` limpio en los 3 archivos;
  `propiedades.php` contra el portal real devolvió las 6 propiedades con
  todos los datos nuevos (PH de Saavedra `reservado:true`, expensas de las
  dos de Villa Devoto y del local, 28 comodidades en la casa, 5 fotos cada
  una); y resiliencia: con `propiedades-extra.php` ausente, con un error de
  sintaxis, con una función que tira excepción y con una que devuelve un
  tipo incorrecto, `propiedades.php` sigue devolviendo las 6 propiedades
  (sin los datos de portal). **Esa prueba encontró un hueco real**: la
  llamada a `csre_extraer_del_html()` no estaba protegida contra
  excepciones — se le agregó su propio try/catch.

## Sincronización de "Propiedades en venta" con propiedades.redsuma.com.ar

Cristian pidió reemplazar los 5 datos de ejemplo de "Propiedades en venta"
por propiedades reales, sincronizadas desde publicaciones existentes de
Red Suma — sin tocar el diseño ni la mecánica del carrusel (loop infinito,
drag, foco/blur, etc.), sólo la fuente de los datos. Antes de tocar nada
se hizo una auditoría (array `PROPIEDADES` hardcodeado, `{titulo,
ubicacion, precio, foto, descripcion}`, sin backend) y se esperó a que
pasara los links reales — ver el pedido completo en el historial de chat
si hace falta releerlo.

### Fuente de datos: JSON-LD, no scraping

Cada publicación de `propiedades.redsuma.com.ar` trae un
`<script type="application/ld+json">` con `@type` incluyendo `"Product"`
(schema.org) — precio, dirección, ambientes/dormitorios/baños, m²,
fotos, disponibilidad, un `sku` estable, y el agente que la publicó. Es
justo lo que la especificación de Cristian pedía priorizar (datos
estructurados por sobre HTML/CSS) — no hizo falta ningún scraping de
selectores.

### Decisiones que le tocaban a Cristian (preguntadas, no asumidas)

Las 4 propiedades pasadas (`PR-019060` Villa Devoto casa, `PR-020966`
depto 3 amb, `PR-020944`/`PR-020934` PH 4 amb — estos dos últimos son
unidades hermanas del mismo complejo de 6, con distinto broker/piso)
pertenecen a **otros agentes de Red Suma**, no a Cristian — él tiene
permiso de esos agentes para promocionarlas y cobrar su propia comisión
si consigue comprador. Por eso:

- **No se muestra el nombre, teléfono ni link del agente/publicación
  original en ningún lado** — ni en la tarjeta, ni en el detalle, ni
  como "ver publicación original" (Cristian lo pidió explícitamente:
  mostrar ese link haría que el interesado contacte al otro agente
  directo, y Cristian perdería la consulta/comisión). El botón
  "Consultar por WhatsApp" del detalle sigue yendo siempre al número de
  Cristian, sin importar de qué agente sea la publicación real.
- **Campos del detalle**: ambientes/dormitorios/baños y m² sí se
  muestran (`.propiedad-detalle__specs`); la lista de amenities (hasta 28
  por propiedad en los datos) **no** se mostraba, a pedido de Cristian.
  **Superado el 2026-10-08**: Cristian pidió "la mayor cantidad de info
  posible, como un portal", y ahora las comodidades SÍ se muestran (ver
  "Datos de portal en tarjeta y detalle"). Lo que sigue sin mostrarse es
  el agente, el contacto, el link a la publicación y la dirección exacta.
- **Actualización**: PHP del lado del servidor con caché de **8 horas**
  (Cristian definió ese número explícitamente — antes había arrancado en
  6 sin pedírselo), no pegarle a la web externa en cada visita.

**Título y descripción — tres vueltas hasta llegar a la versión final.**
Primera vuelta: como el texto original tenía errores de tipeo/acentos
("PAtio/JArdin", "lena" por "leña"), se reescribieron las 4 descripciones
a mano una vez, guardadas en un array dentro de `propiedades.php`, dejando
el título tal cual lo extraía el JSON-LD de origen (`name`). Segunda
vuelta: Cristian pidió sacar la descripción del todo — no quiere depender
de revisar texto a mano cada vez que se sincronice una propiedad nueva,
porque **no va a estar haciendo ese control de calidad todo el tiempo**.
**Tercera y definitiva**: en vez de sacar el texto, **Cristian define él
mismo el título y la descripción de cada propiedad** — ya no son datos
"extraídos" de ningún lado, son contenido propio que él redacta, así que
el problema de errores de tipeo del origen deja de existir (no porque se
lo corrija nadie, sino porque ya no viene de ahí). Quedan en
`$TITULOS_Y_DESCRIPCIONES` dentro de `propiedades.php`, un array asociativo
por `id` (sku) — **NO se sincronizan cada 8 horas** como el resto de los
campos, sólo cambian si alguien edita ese array a mano. El resto
(ubicación, precio, fotos, ambientes/dormitorios/baños/m²) sí sigue
viniendo de la fuente externa en cada ciclo.

**Orden del detalle, a pedido de Cristian**: Fotos → Título → Ubicación →
Precio → Características → Descripción. La estructura de `abrirDetalle()`
en `index.html` ya seguía ese orden de casualidad (no hizo falta
reordenar nada) — sólo hubo que volver a activar el `<p>` de descripción,
que ya tenía el manejo de "esconder si está vacío" de la vuelta anterior.

**Galería de fotos en el detalle** (hasta 5 fotos, no las 10 que trae la
fuente): flechas simples (‹ ›) y un contador ("2/5") superpuestos a la
foto, sólo si hay más de una — con una sola, o en "Desarrollos" (que
nunca tuvo galería), se ve exactamente igual que antes. Sin librería nueva.

**Cambiar de foto ahora desliza con animación** (a pedido de Cristian:
"que sea smooth, prolijo y sin errores/bugs" — antes el cambio era un
salto seco, reemplazando el `src` de una única `<img>`). Se cambió la
mecánica de fondo, no sólo el CSS: `el.foto` (`#propiedad-detalle-foto` /
`#desarrollo-detalle-foto`) dejó de ser una `<img>` suelta y pasó a ser
una "pista" (`<div>`, mismo espíritu que `.propiedades__pista` pero
mucho más simple — acá nunca hay más de una foto visible a la vez): una
`<img>` por foto, puestas en fila con `display:flex` dentro de un
`.propiedad-detalle__foto-viewport` con `overflow:hidden`. Todas las
fotos se cargan una sola vez al abrir el detalle (`construirGaleria()`),
no recién al llegar a cada una — no hay "loading" a mitad de gesto.
Cambiar de foto es trasladar la pista con `transform:translateX()`, que
la transición CSS de `.propiedad-detalle__foto-pista` (`.32s`) anima
sola — no hace falta ningún JS de animación a mano, ni frenar clicks
rápidos: reasignar `transform` a mitad de una transición en curso hace
que el navegador redirija solo hacia el nuevo valor, de forma prolija
(confirmado probando "next" varias veces seguidas, con y sin esperar a
que termine la anterior).

**Dar la vuelta — YA NO EXISTE (2026-09-22), ver la actualización más
abajo (después del bug de "quedan cortadas").** A pedido de Cristian, la
galería dejó de dar la vuelta del todo — queda esta sección como historia
de la mecánica de `moverGaleria()`/`transform`/transición que sigue
vigente para moverse ENTRE fotos válidas, pero el salto instantáneo en
las puntas que describe acá abajo ya no pasa.

**Dar la vuelta (de la última foto a la primera, o viceversa) era
instantáneo, sin animar.** Se había decidido así a propósito, en vez de
replicar el sistema de "clones" del carrusel de tarjetas (loop infinito
real, con tarjetas de más en cada punta) — ese mecanismo le costó al
carrusel de tarjetas varios bugs reales (ver "Motor genérico de
carrusel" más arriba) para resolver algo que ahí importa mucho (el peek
de las tarjetas vecinas). Acá, con 5 fotos como mucho y una sola visible
por vez, el mismo esfuerzo no se justifica — "dar la vuelta" ocurre poca
frecuencia comparado con "pasar a la próxima", y saltar en seco justo
ahí es un costo bajo a cambio de mucho menos código y mucho menos
riesgo. Mecánicamente: `moverGaleria(animar)` desactiva la transición
(`transition:none`), aplica el `transform` nuevo, fuerza un reflow
(`el.foto.offsetHeight`) para que el navegador "asiente" ese cambio, y
recién ahí reactiva la transición (`transition:''`, vuelve a heredar la
de la clase) — sin el reflow forzado, reactivarla tan rápido hace que el
próximo cambio de foto (el que sí debería animar) también salga sin
animar, porque el navegador todavía no pintó el frame intermedio.

**Probado**: pasar fotos con los botones (varias seguidas, con y sin
esperar a que la anterior termine de animar), deslizar con mouse/touch
(swipe, mismo mecanismo de siempre — ver más abajo), dar la vuelta en
las dos direcciones (siguiente en la última foto, anterior en la
primera) confirmando que es instantáneo y que el paso siguiente vuelve a
animar normal, abrir un detalle nuevo encima de otro (la galería se
reconstruye entera, sin fotos de la propiedad anterior mezcladas),
"Desarrollos" (una sola foto) sigue exactamente igual que antes — sin
flechas, sin contador, sin ningún cambio visible —, y el recorte
"ancla abajo" de las fotos de desarrollos (`object-position:center
bottom`) sigue funcionando (la regla pasó de apuntar a
`#desarrollo-detalle-foto` directo a `#desarrollo-detalle-foto img`,
porque ese id ahora es la pista, no la `<img>`). Sin errores de consola
en ningún caso.

**Ajuste post-entrega: Cristian la sintió "trabada"** al probarla — se
mejoró en dos frentes, sin tocar la mecánica de arriba (transición CSS +
vuelta muda en las puntas, todo eso sigue igual):

1. **`will-change:transform`** en `.propiedad-detalle__foto-pista` (le
   faltaba — mismo criterio que ya usan `.propiedad`/`.portada` en este
   archivo). Sin esto, el navegador puede tener que recomponer/repintar
   el `backdrop-filter:blur(28px)` pesado del fondo de `.aviso` en cada
   frame de la animación en vez de mover la pista como una capa propia,
   aparte — eso es justo el tipo de trabajo de más que se siente como
   "trabado".
2. **La foto ahora sigue al dedo/mouse en vivo mientras se arrastra**, en
   vez de recién reaccionar al soltar (que es como estaba antes: nada se
   movía hasta soltar, y ahí arrancaba la animación de golpe — probablemente
   la razón real de fondo, más que el `will-change`, de por qué se sentía
   así). Mismo criterio que `habilitarArrastre()` de la pista de tarjetas,
   adaptado: `pointermove` traslada la pista con `transform:translateX(calc(...))`
   sumando el delta del gesto a la posición base (con la transición apagada
   mientras se arrastra, y un solo `requestAnimationFrame` por frame
   pintado, no uno por evento). Al soltar: si el arrastre superó los 40px
   de siempre, se dispara el mismo `click()` de "siguiente"/"anterior" que
   ya existía (que decide sola si es una vuelta o un paso normal); si no
   llegó a los 40px, `moverGaleria(true)` la vuelve a acomodar en su lugar
   con una animación corta, en vez de dejarla a mitad de camino.
   **Resistencia en las puntas**: arrastrar más allá de la primera o la
   última foto (revelaría espacio vacío, no hay ninguna imagen "antes" de
   la primera ni "después" de la última) se amortigua a un 35% del
   movimiento real — se puede tirar un poco igual, pero cuesta más, como
   el rebote típico de una lista al llegar al final.

**Re-probado**: el `transform` sigue el `pointermove` en vivo (confirmado
con valores intermedios reales, no sólo el resultado final), un arrastre
corto (por debajo del umbral) vuelve a acomodarse en su lugar en vez de
quedar a mitad de camino, la resistencia en las puntas amortigua el
movimiento a la fracción esperada, soltar más allá del umbral en una
punta sigue dando la vuelta de forma instantánea (ya arrastrando en vivo,
no sólo haciendo click), y `pointercancel` a mitad de gesto vuelve a
acomodar la foto en su lugar en vez de dejarla trabada donde estaba. Sin
errores de consola.

**Bug real, encontrado por Cristian después de subir esto** ("las
imágenes del slider muchas veces quedan cortadas con la que le sigue o
viceversa"): condición de carrera entre `pointerup` y el
`requestAnimationFrame` pendiente del último `pointermove`. El
`pointermove` sólo agenda un frame nuevo si no hay uno ya "en vuelo"
(`arrastreFotoTicking`) — con un swipe rápido y decidido (soltar apenas
después de mover), era común que ese frame agendado **todavía no se
hubiera pintado** cuando `pointerup` ya había asentado la posición final
limpia. Ese frame, al llegar tarde, pisaba esa posición limpia con
`trasladarPistaEnVivo()` usando el delta de arrastre viejo — dejando la
pista a mitad de camino entre dos fotos (de ahí "quedan cortadas").
**Arreglo**: el callback del `requestAnimationFrame` ahora chequea
`arrastreFotoActivo` antes de aplicar nada — si el gesto ya terminó
(soltado o cancelado) para cuando ese frame se pinta, no hace nada, en
vez de pisar la posición ya asentada. Confirmado que el bug real
necesitaba probarse con el timing exacto de un swipe rápido: las
pruebas anteriores esperaban a que cada `requestAnimationFrame` terminara
antes de soltar, lo que evitaba sin querer la carrera — quedó como
lección para probar este tipo de gestos con el timing más ajustado
posible, no el más cómodo de instrumentar. Re-probado disparando
`pointerdown`→`pointermove`→`pointerup` sin ninguna espera entre medio
(el peor caso para la carrera), 8 veces seguidas: las 8 terminaron en una
posición limpia (múltiplo exacto del ancho de la galería), nunca a mitad
de camino.

**Galería del detalle: ya no da la vuelta (2026-09-22).** Dos pedidos de
Cristian en el mismo mensaje: "que las tarjetas no te permitan hacer un
loop, si no hay más tarjetas del lado que deslizás, tenés que deslizar
para el lado contrario" + "sigue con bajos fps al deslizar... pero pasa
en desktop". *Nota para no repetir la confusión*: la primera vuelta de
este pedido se interpretó mal — se aplicó al carrusel de "Propiedades en
venta"/"Desarrollos destacados" (revertido por completo, ver "Motor
genérico de carrusel" más arriba, que sigue con su loop infinito de
siempre) — Cristian aclaró que se refería a ACÁ, a la galería de fotos
dentro del pop-up de detalle. Los dos sliders de tarjetas no se tocan
para este pedido.

- **Sin vuelta**: lo que antes hacía `moverGaleria()` con `%` (módulo,
  ver "Dar la vuelta" más arriba, ya no vigente) ahora es `irA(indice)` —
  si `indice` cae fuera de `[0, galeriaFotos.length)` no hace nada y
  devuelve `false`; si es válido, mueve la galería (siempre animado) y
  devuelve `true`. Los clicks de las flechas llaman `irA(galeriaIndice ±
  1)` directo. Al soltar un arrastre (`soltarFoto()`), si el gesto superó
  los 40px SE INTENTA avanzar con `irA`; si `irA` devuelve `false` (ya
  estaba en la punta hacia ese lado) o el gesto fue corto, se llama a
  `moverGaleria(true)` para reacomodar la foto en su lugar — sin este
  fallback, un arrastre largo justo en la punta se hubiera quedado a
  mitad de camino (con el rebote que aplica `trasladarPistaEnVivo`),
  porque ya no hay ningún `.click()` que "sí o sí" mueva algo como antes.
- **Flechas `disabled` en las puntas**: `moverGaleria()` pone
  `el.fotoPrev.disabled = galeriaIndice === 0` (e idéntico para
  `fotoSiguiente` en la última foto) cada vez que cambia el índice —
  nueva regla `.propiedad-detalle__foto-flecha:disabled{opacity:.3;
  cursor:default}` en el CSS. Es la señal en reposo de "no hay más de
  este lado"; mientras se arrastra, la señal es la resistencia (rebote al
  35%) que ya existía en `trasladarPistaEnVivo()`, sin cambios.

**FPS al arrastrar, sobre todo en desktop — probado, causó una regresión
visual y SE REVIRTIÓ (2026-09-22).** Se probó apagar
`.aviso{backdrop-filter:blur(28px) saturate(150%)}` (más
`.aviso::backdrop{backdrop-filter:blur(3px)}`) mientras dura el arrastre
de una foto (clase `.aviso.arrastrando-foto{backdrop-filter:none}`,
agregada en `pointerdown` sobre `el.dialogo` y sacada en
`soltarFoto()`/`pointercancel`), asumiendo que recomponer ese blur en
cada frame del gesto era la causa del reporte y que "el fondo casi no se
ve durante el gesto, no se va a notar". **Cristian notó el cambio de
inmediato** ("cada vez que apretás para deslizar... el fondo pierde
blur") — la suposición de que no se notaría estaba mal. Se sacó por
completo (la clase, las dos reglas CSS, y los tres
`classList.add/remove('arrastrando-foto')` del script) — `.aviso` vuelve
a tener su blur fijo siempre, sin condicionarlo al arrastre.

**El reporte de "bajos fps" en sí sigue sin una causa confirmada.** Ya
está `will-change:transform` en `.propiedad-detalle__foto-pista` (ver el
ajuste post-entrega más arriba). Si Cristian lo sigue notando, conviene
pedirle más detalle (¿en qué navegador/GPU exactamente? ¿se nota más al
principio del arrastre o durante todo el gesto? ¿también le pasa en el
carrusel de tarjetas de más arriba, que es arrastre similar pero sin
galería ni blur de por medio?) antes de probar otra hipótesis a ciegas —
no volver a tocar `backdrop-filter` sin confirmar antes que el cambio no
se note visualmente.

**Probado**: en los 5 slots de la galería (`propiedades-pista`, la única
con más de 1 foto), llegar a la última foto con clicks deshabilita
"siguiente" (queda opaco, clickearlo no hace nada, el contador no
avanza); simétrico en la primera foto con "anterior"; un arrastre fuerte
en la punta hacia el lado sin más fotos no da la vuelta y la foto vuelve
a acomodarse en su lugar. "Desarrollos" (sin galería, un solo `el.foto`
sin flechas) sigue exactamente igual que siempre. Sin errores de consola
en ningún caso real (sólo se vio un `NotFoundError` de
`setPointerCapture` al simular el arrastre con un `PointerEvent`
sintético en vez de un gesto real del navegador — no reproducible con un
dedo/mouse de verdad, que siempre tienen un puntero activo).

**Precio por m² — probado y sacado.** Se agregó un campo calculado
(precio ÷ superficie, ej. "USD 4.172/m²") en el detalle, pensado como
dato "sin riesgo de calidad de texto" para reemplazar a la descripción.
Cristian lo vio y pidió sacarlo: "es irrelevante para la tarjeta" — se
sacó del todo (ya no se calcula en `propiedades.php`, ni se muestra en
`index.html`, ni está en la respuesta de prueba de `serve.ps1`). Si se
vuelve a pedir, el cálculo era trivial: `precio / superficieM2`.

### Arquitectura

- **`propiedades.php`**, en la raíz: tiene la lista de las 4 fuentes
  (`{id: sku, sourceUrl}` — mismo `id` que el `sku` de origen, útil como
  identificador estable) y `$TITULOS_Y_DESCRIPCIONES` (ver arriba). Sirve
  `cache/propiedades.json` (TTL 8 horas) si existe y no está vencido; si
  no, vuelve a buscar las 4 páginas, extrae y normaliza el bloque
  `Product` de cada una (ubicación, precio, hasta 5 fotos,
  ambientes/dormitorios/baños/m², disponibilidad), le agrega el título y
  la descripción manuales de `$TITULOS_Y_DESCRIPCIONES`, guarda el cache
  nuevo y lo devuelve. Si el fetch en vivo falla (web caída, cambió de
  estructura) pero hay un cache viejo, sirve ese en vez de romper el
  slider — sólo devuelve `[]` si nunca hubo un cache exitoso (primer
  request de la vida del sitio, con la fuente externa caída en ese
  preciso momento).
- **`index.html`**: el array hardcodeado `PROPIEDADES` se sacó por
  completo. `PROPIEDADES_ACTIVO` se mantiene como interruptor manual
  (en `false`, ni siquiera pide los datos), pero ahora la llamada a
  `crearCarrusel()` para "Propiedades en venta" quedó async
  (`fetch('propiedades.php').then(...)`) — "Desarrollos destacados"
  sigue exactamente igual que antes (array fijo, síncrono), sin tocar.
  Si el fetch falla del todo (ni el propio servidor responde), se
  esconde la sección en vez de dejarla rota a medias.
- **Detalle enriquecido**: `<p id="propiedad-detalle-specs">` (sólo en
  el dialog de propiedades, no en el de desarrollos) que `abrirDetalle()`
  llena con "3 amb. · 2 dorm. · 2 baños · 100.2 m²" cuando esos datos
  existen, y se esconde solo si no hay datos (así "Desarrollos", que no
  tiene este campo, sigue viéndose igual que siempre — es opcional a
  propósito en `elementos`). La galería (`#propiedad-detalle-foto-prev`/`-siguiente`/
  `-contador`, envueltos en `.propiedad-detalle__galeria`) sigue el mismo
  patrón: sólo se muestra si `p.fotos.length > 1`; con una foto sola (o
  sin el campo `fotos`, como en "Desarrollos") no aparece ningún botón,
  se ve exactamente como antes. El índice de la foto actual
  (`galeriaIndice`) vive en el mismo closure que `abrirDetalle`, se
  resetea a 0 cada vez que se abre un detalle nuevo.

### Bug real encontrado (mismo patrón que el de `#btn-atras`, ver arriba)

Al probar con datos de prueba, `crearCarrusel()` no volvía a mostrar la
sección "Propiedades en venta" después de que un intento anterior la
hubiera escondido (por un fetch fallido) — porque la función sólo sabía
poner `seccion.hidden = true` en el camino de error, nunca `= false` en
el de éxito (no hacía falta antes: la sección nunca arrancaba escondida
en el HTML original). Se agregó `seccion.hidden = false` al principio del
camino exitoso de `crearCarrusel()`, así queda correcta sin importar en
qué estado haya quedado de un intento anterior.

### Qué se probó y qué falta

Probado con datos de prueba (`crearCarrusel()` llamado a mano con objetos
con la forma exacta que devuelve `propiedades.php`, incluidas fotos reales
del CDN de Red Suma, y también con la respuesta de prueba de `serve.ps1`
en el flujo real de la home): la tarjeta se arma igual que las de
"Desarrollos" (mismo tamaño, mismo recorte de texto), el detalle muestra
título/ubicación/precio/specs/descripción en el orden pedido, la galería
cicla entre fotos reales con las flechas (confirmado que `<img src>`
cambia de verdad, no sólo el contador), sin galería se ve igual que
"Desarrollos" (sin botones, una sola foto), el botón de WhatsApp apunta
al número de Cristian sin mencionar al agente original, y el camino de
fetch fallido (natural, porque el servidor local no ejecuta PHP) esconde
la sección sin romper nada — también se confirmó que "Desarrollos" sigue
exactamente igual que siempre (sin galería, con su descripción normal).
**No se pudo probar `propiedades.php` contra un PHP real** — cuando se
suba a Hostinger: confirmar que las 4 tarjetas aparecen con datos reales,
que el detalle muestra bien título/specs/descripción/galería, que
`cache/propiedades.json` se crea solo la primera vez, y volver a probar
después de 8 horas (o borrando el cache a mano) para confirmar que
refresca precio/disponibilidad si cambiaron en el origen.

### Para agregar una propiedad nueva (o sacar alguna)

Sumar/sacar un `{id, sourceUrl}` en el array `$FUENTES` de
`propiedades.php`, y su título/descripción en `$TITULOS_Y_DESCRIPCIONES`
(pedirle a Cristian el texto, igual que se hizo con las primeras 4 — ver
"Título y descripción" más arriba) — no hace falta tocar `index.html` ni
el CSS. Si se prueba en local con `serve.ps1`, hay que sumar el mismo
objeto (ya con los campos calculados, no crudos) a `$propiedadesDePrueba`
ahí, y reiniciar el servidor (arma el JSON una sola vez al arrancar, no
por request).

**Quinta propiedad agregada** (2026-09-22): `PR-019885`, "PH 2 ambientes |
Terraza y Parilla" (Saavedra, CABA, USD 132.000) —
`https://propiedades.redsuma.com.ar/ph-dos-ambientes-con-terraza-y-parilla`.
Mismo procedimiento que las primeras 4, sin tocar nada del motor del
carrusel (`CLONES = Math.min(4, items.length)` ya se ajusta solo al
nuevo total).

**Bug real, encontrado y arreglado con esta propiedad**: la limpieza de
`addressLocality` en `obtenerPropiedad()` sólo sabía sacar el sufijo
"Capital Federal" (`preg_replace('/,?\s*Capital Federal$/i', ...)`) — las
primeras 4 propiedades traían la ubicación así de origen, así que nunca se
notó. `PR-019885` viene con `"Saavedra, Buenos Aires"` en vez de
`"Saavedra, Capital Federal"` — la fuente no es consistente con qué
palabra usa para CABA — así que el resultado quedaba
**"Saavedra, Buenos Aires, CABA"** (redundante, `addressRegion` ya aporta
"CABA"). Cristian pidió que esto se ajuste solo, no sólo para esta
propiedad. **Arreglado de forma general**: ahora se recorta cualquiera de
`Capital Federal`, `Buenos Aires` o el propio valor de `$region` (por si
viniera repetido tal cual) del final de `addressLocality`, antes de
agregar la región real — así una futura propiedad con otra variante de
"CABA" al final (o incluso una de Zona Norte/GBA cuya región real
apareciera repetida en la localidad) se ajusta sola, sin necesitar otro
parche puntual. Probado: las 4 propiedades viejas siguen dando
"Villa Devoto, CABA" igual que antes (el recorte de "Capital Federal" no
cambió de comportamiento), y la nueva da "Saavedra, CABA".

### Sexta "propiedad": un ALQUILER cargado a mano, sin sourceUrl (2026-09-28)

> **ACTUALIZACIÓN 2026-10-08 — esta propiedad YA NO es manual.** Cristian
> publicó el aviso y pasó el link
> (`.../local-comercial-en-esquina-2-plantas-rs025813`, `PR-025813`): se
> sumó a `$FUENTES` + `$TITULOS_Y_DESCRIPCIONES` (va última, misma posición
> que tenía) y se borró el bloque manual de `propiedades.php`. Como no se
> pidió botón "ver publicación", el link se usa **sólo para sincronizar**,
> igual que las demás (no se muestra). Qué quedó de lo que dice más abajo:
> - `expensas`: sigue vigente, pero ahora sale **del portal** (y lo usan
>   también `PR-020944`/`PR-020934`, que tienen "$ 140.000 expensas").
> - `especificaciones`: **se eliminó** (campo y código en `index.html`) — los
>   datos del local ahora salen de la grilla del portal, y el "2 plantas ·
>   1 depósito subsuelo chico" viaja en la descripción (que es de Cristian).
> - `local-pueyrredon.jpg`: **quedó sin uso** (la foto ahora sale del CDN del
>   portal) y ya no entra en el zip. No se borró el archivo (no hay git).
> - "No se agregó etiqueta Venta/Alquiler": **superado**, ahora hay cartelito.
>
> El resto es historia de cómo se llegó hasta acá.

Cristian pasó por chat los datos de un local comercial en alquiler (foto
`.heic` del celular + título/ubicación/precio/specs/descripción escritos
en el mensaje) para sumarlo a este slider, aclarando "después lo
vinculás a una web/publicación externa como las demás tarjetas" — pero
sin pasar ese link todavía. Sin un `sourceUrl` no hay de dónde
sincronizar, así que se agregó **a mano, fuera del loop de `$FUENTES`**,
directo en `propiedades.php` (bloque `$resultado[] = [...]` con
`id: 'MANUAL-local-pueyrredon'`, comentado en el propio archivo con
"CUANDO CRISTIAN PASE EL LINK REAL... sacar este bloque"). **Pendiente
real**: el día que Cristian mande el link de la publicación real, migrar
esta entrada al mecanismo normal (sumarla a `$FUENTES` +
`$TITULOS_Y_DESCRIPCIONES`) y borrar el bloque manual.

Tres cosas nuevas que no existían hasta esta propiedad:

- **Es la primera propiedad en ALQUILER** de un slider que hasta ahora
  sólo tenía ventas en USD. Cristian confirmó que el precio es un
  alquiler MENSUAL en pesos, con expensas aparte. No se agregó ningún
  campo de "tipo de operación" ni una etiqueta Venta/Alquiler en la
  tarjeta (no pedido) — la única señal de que es un alquiler es el propio
  texto del precio (`'$ 2.630.000/mes'`).
- **Campo nuevo, opcional: `expensas`** (string, ya formateado — ej.
  `'$ 180.000 expensas'`). Cristian pidió que se vea **debajo del
  precio, en gris, más chica y sin negrita** — no alcanzaba con pegarlo
  al mismo texto del precio (primer intento, revertido: un solo string
  `'$ 2.630.000/mes + $ 180.000 expensas'`, todo en el mismo estilo
  bronce/negrita del precio). Ahora `crearTarjeta()`/`abrirDetalle()` en
  `index.html`, cuando `p.expensas` viene con algo, le agregan a
  `.propiedad__precio` (o `.propiedad-detalle__precio` en el detalle) un
  `<br>` + un `<span class="propiedad__expensas">` (o
  `propiedad-detalle__expensas`) — nuevas reglas CSS, sin negrita, gris
  (`var(--texto-suave)`), 11px en la tarjeta / 13px en el detalle. El
  `<span>` queda DENTRO del mismo contenedor del precio a propósito: en
  la tarjeta chica, `.propiedad__precio` ya reservaba alto fijo para 2
  líneas desde el fix de "Tarjetas de alto irregular" (ver "Motor
  genérico de carrusel" más arriba) — así que una propiedad sin
  `expensas` no cambia de alto ni desalinea el resto del carrusel, sin
  necesitar ningún elemento ni reserva de alto nuevos. Confirmado
  midiendo `offsetHeight` de varias tarjetas juntas (todas iguales) y el
  color/tamaño/peso reales del `<span>` con `getComputedStyle`. En el
  detalle no hace falta esa reserva de alto (el modal no comparte fila
  con otras tarjetas), así que ahí simplemente crece si hace falta.
- **Campo nuevo, opcional: `especificaciones`** (string ya armado). Un
  local comercial no tiene "ambientes" ni "dormitorios" en el sentido
  residencial de esos campos (tiene "2 plantas" y "1 depósito subsuelo
  chico", que no son ninguna de las dos cosas) — forzarlo en el molde de
  `ambientes`/`dormitorios`/`banos`/`superficieM2` de `abrirDetalle()` en
  `index.html` hubiera etiquetado mal el dato (ej. "2 amb." cuando en
  realidad son 2 plantas). Cuando `p.especificaciones` viene con algo, se
  usa tal cual y se salta el cálculo de siempre; si no viene (todas las
  propiedades sincronizadas, que nunca mandan este campo), el
  comportamiento es idéntico al de antes. `banos`/`superficieM2` sí se
  completaron de forma normal (1 baño, 135 m²) porque esos dos conceptos
  sí aplican tal cual a un local.
- **Foto guardada en el proyecto, no en el CDN de Red Suma.** Las 5
  propiedades sincronizadas nunca guardan una foto local — sus URLs
  vienen directo del CDN de la fuente externa. Acá no hay fuente externa
  todavía, así que la foto SÍ es un archivo del proyecto:
  `local-pueyrredon.jpg`, convertida a mano desde el `.heic` original que
  mandó Cristian (formato que ningún navegador soporta bien, no se puede
  usar directo) — redimensionada a 1600px de ancho (el original era
  8064×4536, un peso innecesario para una tarjeta de carrusel) vía la API
  `Windows.Graphics.Imaging` de WinRT desde PowerShell (no había
  ImageMagick/ffmpeg instalados; `System.Drawing` de .NET tampoco decodifica
  HEIC). Como es un archivo del proyecto (no una URL absoluta), **hay que
  acordarse de sumarla a la lista de archivos que entran en
  `cristian-stedtfeld-web.zip`** al armar el deploy — no está en `fonts/`
  ni en `form/`, que se copian enteras, así que si se reconstruye el zip
  copiando esas carpetas más una lista fija de archivos sueltos (como se
  viene haciendo), `local-pueyrredon.jpg` tiene que estar en esa lista.

Replicado también en `$propiedadesDePrueba` de `serve.ps1` (mismos datos,
misma foto local) para poder probarlo en este preview sin depender de
Hostinger — recordar reiniciar el servidor después de tocar ese array
(arma el JSON una sola vez al arrancar).

**Probado**: la tarjeta aparece en el carrusel con la altura idéntica a
las demás, el precio se lee completo (entra en una sola línea con el
ancho actual de tarjeta, no llegó a necesitar la segunda línea
reservada), y el detalle muestra specs/precio/descripción/foto en el
orden de siempre, con el texto de specs correcto (no una etiqueta
inventada de ambientes/dormitorios). Sin errores de consola.

### Datos de portal en tarjeta y detalle (2026-10-08)

Cristian pidió dos cosas en el mismo mensaje: (1) que una propiedad
**reservada** lo diga en la tarjeta, visible antes de abrir el detalle, y
(2) que la tarjeta y el detalle muestren "la mayor cantidad de info posible,
como un portal", siempre sincronizada (nunca cargada a mano).

**RESERVADO.** La fuente marca "Reservada" con
`offers.availability = LimitedAvailability` en el JSON-LD (verificado: la
misma publicación muestra el cartel "Reservada" en su página). `propiedades.php`
manda `reservado: true` si eso se cumple **o** si el HTML trae el cartel
`>Reservada<` (dos señales, por si una cambia). La tarjeta lo muestra como un
cartelito de relleno **bronce con texto casi negro** arriba a la izquierda de
la foto (`.propiedad__chip--reservado`), y el detalle lo repite arriba del
título. La tarjeta sigue siendo clickeable (no se oculta). `disponible`
(`=== InStock`) se sigue mandando pero index.html no lo usa. **Otros estados**
(ej. vendida/alquilada) no se contemplan: no se sabe qué valor manda la
fuente — si Cristian quiere que se oculten solas, hay que ver primero qué
trae el JSON-LD de una propiedad vendida. En **Desarrollos** el mismo
cartel funciona con `reservado: true` en el objeto del array (a mano; no
se sincroniza), hoy apagado en los tres.

**Qué se ve en la tarjeta** (sólo si el campo viene; "Desarrollos" no cambia
en nada): cartelito de operación (`VENTA`/`ALQUILER`, de las migas del
JSON-LD) y, si corresponde, `RESERVADO`; una línea de resumen
`3 amb · 3 dorm · 2 baños · 150 m²` entre ubicación y precio; el precio
ahora con el formato del portal (`$ 2.630.000` para pesos — antes salía
"ARS 2.630.000" —, `USD 132.000` para dólares, y `/mes` sólo si la
operación es exactamente "Alquiler"); y las expensas en gris debajo (para
todas las propiedades que las tengan). **Alto parejo**: si algún ítem del
slider tiene resumen, TODAS las tarjetas reservan su línea (2 líneas bajo
520px de ancho, 1 desde ahí) — verificado `offsetHeight` idéntico en las
14 tarjetas (6 + clones). Entre número y unidad va un espacio sin corte
(` `) para que un "m²" no quede huérfano en la segunda línea. Los
cartelitos no llevan `backdrop-filter` (la tarjeta ya tiene uno; apilar
otro por chip en ~13 tarjetas es costo de GPU sin ganancia — mismo cuidado
que ya se tomó con el blur, ver "FPS al arrastrar").

**Qué se ve en el detalle**, en este orden: Fotos → cartelitos
(`Alquiler · Local comercial`, `Reservado`) → Título → Ubicación → Precio
(+ expensas) → **Características** (grilla etiqueta/valor: Ambientes,
Dormitorios, Baños, Cocheras, Estado, Orientación, Disposición,
Luminosidad, Antigüedad…) → **Superficies** (Cubierta, Semicubierta,
Descubierta, Terreno) → etiquetas ("Apto crédito", "Apto comercial") →
Descripción (ahora con `white-space:pre-line`, para respetar los saltos de
línea de lo que escribe Cristian) → **Comodidades** (chips) → botón de
WhatsApp. Las grillas son genéricas (muestran el par que mande el portal,
sin lista fija de etiquetas), así que una etiqueta nueva del portal aparece
sola. El resumen de una línea del detalle queda sólo de respaldo (si no
hay grilla, ej. caché viejo). Todo se inserta con `textContent`, nunca como
HTML. `abrirDetalle()` conserva intacto el `dataLayer.push` de
`click_boton`/`ver-propiedades` y el botón de WhatsApp conserva
`data-evento="consulta-propiedad"` (verificado en el navegador después del
cambio).

**De dónde sale cada dato** (importante para el día que el portal cambie):
- Del **JSON-LD** (estructurado, lo más estable): precio/moneda, ubicación,
  fotos (siguen siendo máx. 5), ambientes/dormitorios/baños/m² totales,
  disponibilidad/reservada, **comodidades** (`amenityFeature`), y
  **operación y tipo** (de la lista de migas `BreadcrumbList`: posición 2 =
  Venta/Alquiler; posición 3 = slug del tipo, ej. `local-comercial`).
- Del **HTML renderizado** (`propiedades-extra.php`): expensas, la grilla
  Características, la grilla Superficies y las etiquetas. Esto va **contra
  la decisión original de "datos estructurados, no HTML"** — se hizo porque
  Cristian pidió esa info y el JSON-LD simplemente no la trae. Por eso está
  armado para romperse en silencio: archivo aparte cargado en try/catch
  (en PHP 7+ hasta un error de sintaxis en un archivo incluido es atrapable),
  `csre_extraer_del_html()` atrapa todo y devuelve vacío si no encuentra
  nada, y lee por **estructura** (los `<h2>` "Características"/
  "Superficies" y pares `<p>etiqueta</p><p>valor</p>`), no por clases de CSS
  (son utilidades de Tailwind y cambian). Si el portal rediseña su HTML, la
  consecuencia es que la tarjeta/detalle muestran menos datos, no que se
  caiga nada. **Cómo se validó**: primero las expresiones regulares se
  probaron en PowerShell/.NET contra las 6 publicaciones reales guardadas
  (todas dieron lo esperado, incluida la reservada y los dos casos con
  expensas), y después, ya con PHP real instalado (ver "PHP local para
  probar"), `propiedades.php` se corrió de verdad contra el portal y devolvió
  los mismos datos, y se probó que falle en silencio (archivo auxiliar
  ausente / con error de sintaxis / que tira excepción / que devuelve un tipo
  incorrecto). Lo único que sigue sin probarse es cómo se comporta en el
  PHP/servidor de Hostinger en sí (otra versión, otros módulos).
- **A propósito NO se extrae ni se muestra**: dirección exacta (calle y
  número — el portal la muestra, acá sólo barrio), nombre/contacto del
  agente, ni ningún link a la publicación. Mismo criterio de siempre.

**Al subir esto a Hostinger**: subir el zip (ahora incluye
`propiedades-extra.php`; `local-pueyrredon.jpg` ya no entra) **y borrar
`cache/propiedades.json` desde hPanel** — si no, hasta 8 horas se sigue
viendo el formato viejo (sin cartelitos ni datos de portal). Verificar
después: la PH de Saavedra muestra RESERVADO, las dos de Villa Devoto
muestran "$ 140.000 expensas", el local aparece como "ALQUILER" con
"$ 2.630.000/mes" y 5 fotos.

**Pruebas en localhost con GTM real (lección, 2026-10-08).** `index.html` y
los formularios cargan el GTM de producción también en localhost: cualquier
`dataLayer.push` de una prueba (`generate_lead`, `click_boton`) dispara los
tags reales — en una prueba se vio al Pixel de Meta intentando mandar un
`Lead` (esa llamada quedó interceptada por el stub de `fetch`, no salió;
pero GA4 usa otros canales y puede haber registrado el evento con
hostname `localhost`). Para probar formularios sin ensuciar la medición:
reemplazar `window.dataLayer.push` por una función que sólo registre (no
reenvíe) y stubear `fetch` para que **sólo** `enviar-lead.php` se simule y
cualquier otra llamada no salga a la red. Conviene revisar en GA4 si hay
eventos con hostname `localhost` y filtrarlos como tráfico interno.

## Slider de 7 propiedades + página "Ver todas" (2026-10-08)

Pedido de Cristian: el slider "Propiedades disponibles" muestra **siete en total**:
primero **las que él carga** (las de su perfil en el portal) y el resto las que él
va agregando diciendo "sincronizá este link" (con 1 propia: 1 + 6 agregadas; con 3
propias: 3 + 4); abajo, un botón que lleva a otra página de su web con todas.
**Implementado y probado en local; NO subido a Hostinger todavía** (hay que subir el
zip y verificar en vivo).

**`propiedades.php` (reescrito):**
- **Propias, automáticas**: lee `URL_PERFIL` (`https://propiedades.redsuma.com.ar/a/cristian-stedtfeld`)
  y toma las URLs del `ItemList` del JSON-LD (máx. `TOPE_PROPIAS` = 30). Si publica
  una nueva, aparece sola (con el vencimiento de 8 h). **Límite conocido**: ese
  `ItemList` trae como mucho 20 por página y no se pagina; hoy tiene 1.
- **Promovidas, a pedido**: array `$PROMOVIDAS` (`id` = sku de la publicación,
  `sourceUrl`), en el orden en que salen después de las propias — **para destacar una,
  se sube de lugar en esa lista**. Para agregar una por pedido de Cristian ("sincronizá
  este link"): sumar `['id' => <sku>, 'sourceUrl' => <url>]` (el sku está en el JSON-LD
  de la publicación, campo `sku`; sale en `propiedades.php` aunque `id` se pase vacío)
  y, sólo si él quiere texto propio, su entrada en `$TITULOS_Y_DESCRIPCIONES`.
  Reemplaza al viejo `$FUENTES`. El local de Villa Pueyrredón (PR-025813) ya no está en
  la lista: es propia y se detecta sola (conserva su texto manual).
- **Texto de las nuevas**: si no hay entrada manual, se usa el **nombre y la descripción
  de la propia publicación del portal** (decisión de Cristian: "traés el texto de la
  propiedad; si la descripción es pobre, vemos de cambiarla"). `limpiarDescripcion()`
  saca las líneas con teléfonos argentinos, mails y links (para no mostrar el contacto
  del otro agente, mismo criterio de siempre), junta saltos de línea de más y corta en
  ~2200 caracteres. Probado: deja precios/expensas/matrículas, saca "Consultas al 11 6759
  1512", "+54 9 11 5385-6697", mails, `www.`/`https://`. **Ojo**: es una heurística, no
  una garantía — si en alguna publicación se cuela un contacto, ampliar ese filtro o
  poner el texto a mano.
- **Orden y campo `propia`**: la respuesta trae todas, propias primero, cada una con
  `propia: true|false`. Sin repetidos (si una promovida es también propia, cuenta como propia).
- **Funciona solo**: copia de 8 h en `cache/propiedades-v2.json` (nombre nuevo a propósito:
  una copia vieja de un deploy anterior se ignora sola, **ya no hace falta borrar el cache a
  mano**). Al vencer, responde YA con la copia y refresca por detrás
  (`fastcgi_finish_request`/`litespeed_finish_request`; si el servidor no las tiene, el
  visitante espera ese refresco) con un lock (`cache/propiedades.lock`) para que sea un solo
  proceso. **Una publicación que el portal da por inexistente (404/410) se saca; cualquier
  otra falla (timeout, 5xx, página rara, perfil caído) NO borra nada**: conserva la última
  versión buena (las propias de la copia anterior si el perfil no responde) y reintenta a los
  15 min (`touch` de la copia). Si el resultado queda vacío pero hay copia, se conserva. El mapa
  `cache/propiedades-urls.json` (url → sku) permite conservar una propia aunque falle su fetch.
- **Probado con PHP real** (copia aislada, `scratchpad/probar_propiedades.py`, 7 escenarios):
  orden propias-primero con las 6 de hoy; copia vigente instantánea (0,09 s); copia vencida →
  responde con la vieja y refresca; perfil caído → conserva las propias y reintenta pronto;
  404 de una promovida → se saca y las demás siguen; host caído → no se borra; un link nuevo
  sin texto manual (una oficina de otro agente) entra con el nombre y la descripción del
  portal (limpia, sin contactos). También `probar_limpieza.py` para el filtro de contactos.

**Home (`index.html`)**: `var TOPE_PROPIEDADES = 7` — el slider recibe `datos.slice(0, 7)`
(el loop infinito y los clones se ajustan solos). Debajo, `<p id="propiedades-mas" hidden>`
con `<a href="propiedades/" data-evento="ver-propiedades" data-titulo="Ver todas las propiedades">`:
pastilla de vidrio chica con flecha (la maqueta aprobada). **Sólo se muestra si hay más de 7**
(`datos.length > TOPE_PROPIEDADES`); con las 6 de hoy NO se ve, porque llevaría a un listado
con las mismas tarjetas — decisión mía, se invierte cambiando esa condición. **Tracking**: usa
los `boton_id` de siempre (`ver-propiedades`, sin ningún ID nuevo, nada que tocar en GTM): el
evento sale `{event:'click_boton', boton_id:'ver-propiedades', boton_texto:'Ver todas las
propiedades', destino: .../propiedades/}` (verificado en el navegador, con `dataLayer.push`
aislado). Ojo: en GA4 `click_ver_propiedades` ahora cuenta también este clic; se distingue por
la dimensión "Button Text".

**`propiedades/index.html`**: feed con todas (propias primero), tarjeta con foto 3:2, cartelitos
VENTA/ALQUILER/RESERVADO, ubicación, título, resumen, precio + expensas y botón "Ver detalle →"
(toda la tarjeta abre el detalle). Una columna hasta 759 px, dos desde 760 (contenedor de hasta
1040). Filtro por operación (Todas/Alquiler/Venta) sólo si hay más de una operación. Detalle:
mismo contenido y orden que el de la home (cartelitos, título, ubicación, precio, Características,
Superficies, etiquetas, descripción con `white-space:pre-line`, Comodidades, WhatsApp), con una
**galería propia de scroll nativo con snap** (flechas, contador, `destinoFoto` para que dos toques
seguidos avancen dos fotos) en vez del motor de arrastre de la home — a propósito, para no
duplicar esa complejidad. Si el fetch falla o viene vacío: aviso "No pudimos cargar las
propiedades" + "Consultame por WhatsApp". `noindex,follow` por ahora. GTM-5JDWTPXN incluido.
Tracking (todos IDs existentes): abrir una propiedad → `ver-propiedades` (texto = título);
WhatsApp del detalle → `consulta-propiedad` (texto "Consultar por WhatsApp", igual que la home);
ícono del pie → `whatsapp-icono`.

**Probar en local**: `serve.ps1` ahora marca `propia` (sólo el local) y ordena propias primero;
con un archivo vacío `propiedades-muchas.flag` en la raíz suma 3 tarjetas "Próximamente" vacías (9 en
total; antes eran copias "(prueba)" de propiedades reales, cambiado el 2026-10-09 a pedido de
Cristian) para ver el botón "Ver todas" — **borrar la bandera al terminar** (a esta altura sigue
puesta, mientras Cristian revisa la vista previa). Probado: 6 → sin botón y
local primero; 9 → 7 tarjetas + botón; la página muestra las 9, filtra (1 Alquiler / 8 Venta),
abre el detalle (cartelitos, grillas, 5 fotos, comodidades), eventos correctos, sin desborde en
375 px y sin errores de consola. **Aviso de método**: durante parte de la prueba el panel del
navegador quedó "oculto" (`visibilityState: hidden`): ahí `requestAnimationFrame` y los scrolls
suaves no avanzan y las capturas salen en blanco; la lógica de la galería se verificó con
`requestAnimationFrame`/`scrollTo` simulados y con clics reales cuando el panel estaba visible.

**Al subirlo**: zip nuevo (incluye `propiedades.php`, `propiedades/index.html`, `index.html` y, desde el
2026-10-09, también las páginas de Desarrollos —`desarrollos.php`, `desarrollos-lib.php`,
`desarrollo-extra.php`, `desarrollos/` y `desarrollos/ficha/`—, que quedan **sin enlazar desde la home**).
Verificar en vivo: la home sigue mostrando las propiedades con el local primero, `propiedades/` carga
las 6, `propiedades.php` responde con `propia` en cada ítem, y `/desarrollos/` y
`/desarrollos/ficha/?o=olazabal` cargan (primer acceso: 8–13 s mientras se arma la copia). Este cambio agrega una ruta nueva y un botón con
tracking: *recordarle a Cristian exportar GTM y actualizar el Master*.

## Carpeta suelta vieja: `cristian-stedtfeld-web/` (aviso, 2026-10-08)

En la raíz del proyecto hay una carpeta `cristian-stedtfeld-web/` **de una descompresión vieja
(28/09/2026)** con versiones anteriores de `index.html`, `estilo.css`, `enviar-lead.php` y los
formularios. **No es el sitio actual.** Si alguna vez se sube contenido de esa carpeta en vez del
zip, se pisa el sitio con versiones viejas (es una causa plausible del deploy fallido de los
formularios del 2026-10-08, no confirmada). Pendiente de que Cristian dé el OK para borrarla (o
mandarla a la Papelera).

## Ideas pendientes, no implementadas

- Variantes por campaña (`/pilar`, `/zona-norte`) con botones distintos, para medir
  cada zona por separado.
- ~~Formularios propios (los 5)~~ — **hecho**, ver sección "Formularios
  propios" más arriba. Pendiente real: probar `enviar-lead.php` contra un
  PHP de verdad una vez subido a Hostinger (ver esa sección para la lista
  completa de qué confirmar).
- ~~Sincronizar "Propiedades en venta"~~ — **hecho** para las 4 propiedades
  que pasó Cristian, ver sección "Sincronización de Propiedades en venta"
  más arriba. Pendiente real: probar `propiedades.php` contra un PHP de
  verdad una vez subido a Hostinger.
- ~~Galería de fotos en el detalle de una propiedad~~ — **hecho** (hasta
  5 fotos, con flechas y contador — ver sección "Sincronización de
  Propiedades en venta").
- ~~Auto-hospedar las fuentes~~ — **hecho** (ver sección de Decisiones de diseño).
- Definir si el disclaimer de matrícula, hoy dentro de un modal, debe además
  aparecer fijo en el pie por una cuestión de cumplimiento.
- Las 5 propiedades **de ejemplo** que había en el slider (`propiedad-1.webp`
  a `propiedad-5.webp`, con título/ubicación/precio inventados) quedaron sin
  usar — ya no las llama nada desde que "Propiedades en venta" sale de
  `propiedades.php`. No se borraron los archivos (no hay git en este
  proyecto para poder deshacer un error), pero se pueden limpiar a mano si
  Cristian quiere.
- Los datos de "Desarrollos destacados" (Midoki, AC, OZB) los sacó Claude de
  las páginas de sumadesarrollos.com.ar — conviene que Cristian los revise,
  sobre todo precios/financiación (ver esa sección). Podría migrarse al
  mismo mecanismo de `propiedades.php` que ahora usa "Propiedades en venta",
  si esos desarrollos también tienen datos estructurados en su página de
  origen — no evaluado todavía.
- ~~Migrar el local de Villa Pueyrredón (alquiler) a `$FUENTES`~~ — **hecho
  el 2026-10-08** (ver la actualización al inicio de "Sexta 'propiedad'").
  `local-pueyrredon.jpg` quedó sin uso, igual que `propiedad-1..5.webp` — se
  puede borrar a mano cuando Cristian quiera.
- ~~Verificar `propiedades.php` + `propiedades-extra.php` contra un PHP real~~ —
  **hecho en local el 2026-10-08** (ver "PHP local para probar"). Falta sólo
  confirmarlo en Hostinger tras el deploy (borrando `cache/propiedades.json`).

## Preparación para Google Ads

Cristian pidió una auditoría técnica read-only (`GOOGLE_ADS_SITE_AUDIT.md`,
en la raíz del proyecto — **excluido del zip**, es un informe interno para
el especialista que arme las campañas, no algo que vaya al sitio público)
y, en un pedido aparte, un conjunto acotado de implementaciones basadas en
esa auditoría. Alcance explícito: sin rediseño, sin tocar los formularios
en sí (sus preguntas/campos), sin tocar IDs de tracking existentes, sin
`gtag.js` suelto ni un segundo GTM.

### 1. Seguridad crítica: los leads ya no viven dentro de `public_html`

`GOOGLE_ADS_SITE_AUDIT.md` encontró que `leads/leads.jsonl` (nombre,
teléfono, email de cada consulta) se podía leer directo por HTTP en
producción — el `leads/.htaccess` protegía el listado del directorio pero
no ese archivo puntual (causa exacta no confirmada; ver el informe).

**Solución implementada**: `enviar-lead.php` ahora guarda en
`LEADS_DIR = dirname(__DIR__) . '/leads_privados'` — un nivel arriba de
`public_html`, fuera de cualquier URL posible, sin depender de que
Hostinger respete ningún `.htaccess`. La carpeta `leads/` (con su
`.htaccess`) se deja donde estaba, vacía/en desuso, como red de más por si
algo vuelve a escribir ahí sin querer — no se borra nada.

**Depende de un supuesto sobre la estructura de Hostinger** (que
`public_html` cuelga directo de la carpeta de la cuenta, como es estándar
en cPanel/Hostinger) — si la cuenta de Cristian tuviera otra estructura
(por ejemplo un dominio addon), `dirname(__DIR__)` podría no caer afuera
de lo público. **Pendiente de confirmar en Hostinger** (ver Pendientes
más abajo): que la carpeta `leads_privados` se haya creado realmente
fuera de `public_html`, y que el `.jsonl` viejo (con los 2 leads de
prueba que ya existían) se haya migrado a mano a la ubicación nueva —
Claude no tiene acceso al servidor para moverlo.

### 2. Atribución de Google Ads/UTMs

Nuevo mecanismo, pensado para que un lead guarde de qué campaña vino:

- **Qué se captura**: `gclid`, `gbraid`, `wbraid`, `utm_source`,
  `utm_medium`, `utm_campaign`, `utm_term`, `utm_content` — cualquiera de
  estos presente en la URL al entrar a **cualquiera** de las 6 páginas
  (home + 5 formularios, porque un anuncio puede apuntar directo a
  cualquiera de las 6, no sólo a la home).
- **Dónde se guarda y por cuánto tiempo**: `localStorage`, clave
  `csre_atribucion`, **90 días** — se eligió `localStorage` (no
  `sessionStorage`) a propósito porque una decisión inmobiliaria puede
  tardar días/semanas; 90 días es una ventana generosa (coincide con el
  techo típico de ventana de conversión de Google Ads) sin ser
  indefinida. Es el primer uso de almacenamiento del navegador en todo el
  sitio (antes no había ni `localStorage` ni `sessionStorage` ni cookies
  propias en ningún lado).
- **Criterio de reemplazo**: "último click gana" — si la visita actual no
  trae ninguno de estos parámetros, se conserva lo que ya hubiera
  guardado (por si la persona entró por un anuncio y volvió por su cuenta
  días después); si trae alguno nuevo, reemplaza TODO lo guardado antes
  (mismo criterio que usa el propio `gclid` de Google Ads).
- **Function `leerAtribucion()`**: declarada como `var` suelta (no dentro
  de la IIFE del motor del formulario) en cada `form/<nombre>/index.html`
  — mismo patrón/nombre duplicado en los 5, mismo criterio que el resto
  del motor de formularios (sin JS compartido entre páginas). En la home
  sólo hace falta la mitad de "capturar" (no arma ningún payload), así
  que ahí es una IIFE más simple sin exponer ninguna función.
- **Nunca va al `dataLayer`/GTM** — sólo viaja en el `POST` a
  `enviar-lead.php`, mezclado en `construirPayload()` con
  `for (var campo in atribucion) payload[campo] = atribucion[campo];`,
  y de ahí a `enviar-lead.php`, que los agrega a `$lead` (sección nueva,
  "atribución de Google Ads / UTMs", antes de guardar) **sólo si vienen
  no vacíos** — nunca son obligatorios, un lead sin campaña de origen se
  guarda exactamente igual que antes.
- **No toca la URL visible** en ningún momento (no hay `replaceState` ni
  limpieza de query string).
- **Campos nuevos en `leads.jsonl`** (sólo presentes cuando corresponde):
  `gclid`, `gbraid`, `wbraid`, `utm_source`, `utm_medium`, `utm_campaign`,
  `utm_term`, `utm_content` — aparecen también en el email de aviso
  (recorre `$lead` genérico, no hizo falta tocar esa parte).
- **Todavía no implementado a propósito** (pedido explícito de Cristian,
  etapa futura): subir esto a Google Ads como Enhanced Conversions o
  conversión offline — hoy sólo queda guardado junto al lead.

### 3. Ícono de WhatsApp del pie, en los 5 formularios: ahora trackeado

`GOOGLE_ADS_SITE_AUDIT.md` encontró que este ícono (a diferencia del
mismo ícono en la home) no tenía `data-evento` ni ningún listener — los 5
`form/*/index.html` no cargan el delegado genérico de clicks de
`index.html` (nunca lo necesitaron hasta ahora). Se le agregó
`data-evento="whatsapp-icono"` al `<a>` y un IIFE chico al final del
`<script>` de cada formulario que engancha sólo ese ícono puntual y
empuja exactamente el mismo evento que la home
(`{event:'click_boton', boton_id:'whatsapp-icono', boton_texto:'', destino:href}`)
— sin traer el resto del delegado genérico (abrir `<dialog>`, etc.), que
no aplica acá. El ícono de **Email** del pie de los 5 formularios sigue
sin trackear — quedó afuera a propósito, no fue parte de este pedido.

### 4. `<h1>` + meta description en los 5 formularios

Cada `form/<nombre>/index.html` tenía su título visible en un
`<p class="form-header__marca">` (sin `<h1>` en toda la página) y sin
`<meta name="description">`. Cambio puramente semántico: el `<p>` pasó a
`<h1>` **sin tocar la clase** (`form-header__marca` sigue peinando el
mismo `estilo.css`, que no tiene ninguna regla `h1` que pudiera
pisarlo — ese selector sólo existe embebido en `index.html`, que estas
páginas no cargan) — cero cambio visual, confirmado por screenshot. Se
sumó una meta description propia y distinta por formulario (mismo tono
que la de la home). El `noindex` de las 5 páginas no se tocó.

### Bug de `valorDe()` en radios — encontrado y **arreglado** (tarea aparte)

Mientras se probaba el envío completo de "vender" para confirmar que la
atribución viaja bien en el payload, se encontró que **`valorDe(name)`
(el helper que arma casi todos los campos de `construirPayload()` en los
5 formularios) usaba `form.querySelector('[name="' + name + '"]')` — que
para un GRUPO DE RADIOS devuelve siempre el PRIMER radio del grupo en el
HTML, no el que está marcado**, porque `.value` de un `<input>` radio
devuelve su atributo `value` sin importar si está `checked`. Confirmado
en el navegador: tildar "Buen estado" en `estado_general` y leer
`valorDe('estado_general')` devolvía igual `"Excelente"` (la primera
opción del grupo).

Afectaba a **todos los campos tipo radio** de `vender`, `tasacion`,
`alquilar_propiedad` y `comprar` (`tipo_propiedad`, `estado_general`,
`situacion_actual`, `plazo`, `valor_en_mente`, `como_llego_valor`,
`publicada_actualmente`, `como_continuar`, `ya_tasada`,
`disponibilidad`, `forma_compra`, `plazo_compra`). **`buscar_alquiler`
nunca estuvo afectado** — todos sus campos de opción son checkboxes
(usan `valoresDe()`, que sí filtra por `:checked`). Era anterior a la
tarea de Google Ads (no se tocó `valorDe()` en esos edits) y venía desde
que se armaron los formularios — cualquier lead real que hubiera elegido
algo distinto de la primera opción de un radio quedó guardado con la
primera opción igual, tanto en `leads.jsonl` como en el email de aviso.
Reportado primero sin arreglar (la tarea de Google Ads decía
explícitamente "no cambies formularios"), y arreglado después en una
tarea aparte, explícita para esto.

**Arreglo**: `valorDe()` ahora cuenta cuántos elementos hay con ese
`name` — si hay uno solo (texto/textarea/email/tel), se comporta exactamente
igual que antes; si hay más de uno (grupo de radios), busca el que tiene
`:checked` (mismo criterio que ya usaba `valoresDe()` para checkboxes) y
devuelve `''` si ninguno está marcado, en vez de inventar una respuesta
con la primera opción del grupo. Mismo cambio, aplicado idéntico, en los
4 archivos afectados (`vender`, `tasacion`, `alquilar-mi-propiedad`,
`comprar`) — `buscar-alquiler` no se tocó, no lo necesitaba.

**Probado en el navegador, con envío completo simulado (`fetch`
interceptado) en los 4 formularios**, eligiendo a propósito la ÚLTIMA
opción de cada grupo de radios (nunca la primera): el payload capturado
coincidió exactamente con lo elegido en los 4 casos. También se probó
dejar sin marcar los 3 radios opcionales de "vender" (`plazo`,
`valor_en_mente`, `como_llego_valor`) — ahora viajan como `''`, no como
la primera opción de cada uno (antes del arreglo, hubieran viajado con
un valor inventado). Se confirmó de paso que esto no afecta en nada a
`generate_lead` (se sigue disparando una sola vez, con el mismo
`lead_type`/`form_name` de siempre) ni al camino de éxito ("¡Gracias!").

### Pendientes reales de esta tarea

1. Confirmar en Hostinger que `leads_privados/` se creó fuera de
   `public_html` (no como subcarpeta de `public_html`) — si la estructura
   de la cuenta no es la estándar, ajustar la constante `LEADS_DIR` en
   `enviar-lead.php`.
2. Migrar a mano los 2 leads de prueba que ya estaban en
   `leads/leads.jsonl` (dentro de `public_html`) a la ubicación nueva —
   Claude no tiene acceso al servidor para moverlos.
3. Confirmar que `GET` a `csrealestate.com.ar/leads/leads.jsonl` (la ruta
   vieja) ya no expone nada — lo ideal es que dé 404 una vez movido el
   archivo (con o sin el `.htaccess` funcionando, ya no hay nada que leer
   ahí).
4. Mandar una consulta de prueba real por cada uno de los 5 formularios
   ya en producción y confirmar que `leads_privados/leads.jsonl` recibe
   la línea nueva con los campos de atribución cuando corresponda.
5. ~~Decidir si vale la pena arreglar el bug de `valorDe()` de radios~~ —
   **hecho**, ver esa misma sección más arriba.
