# Manual de diseño — csrealestate.com.ar

Reglas que se pidieron y se aplican en toda la web. Si algo nuevo no entra en una regla de acá, se
propone una regla nueva (no un tamaño suelto) y se anota en este manual. Las medidas viven en
`estilo.css`, en `:root`: **se cambian ahí y cambian en todas las páginas a la vez**.

Última actualización: 9-oct-2026.

---

## 1. Escala de títulos

**Regla madre: mismo nivel = mismo tamaño, en todas las páginas.** Ningún título lleva un tamaño
propio escrito a mano: usa uno de estos niveles.

Los tres niveles salen de **una sola medida** (`--titulo-pagina`) y guardan siempre la misma
proporción **30 : 22 : 20** (sección = 11/15 × página; tarjeta = 2/3 × página). En el celular los tres
se achican juntos, "a escala". Para cambiar toda la escala se toca sólo `--titulo-pagina`.

| Nivel | Qué es | Compu | Celular (390 px) | Letra | Dónde se usa |
|---|---|---|---|---|---|
| **1 · Página** | El nombre de la página (h1) | 30 px | ~25 px | Chillax | "Propiedades", "Desarrollos", nombre de la obra (ej. "Monroe 1678") |
| **2 · Sección** | Cada bloque dentro de una página (h2) | 22 px | ~19 px | Chillax | "El edificio", "Elegí tu unidad", "Unidades y valores", "Planos", "Así va la obra", "Pliego de terminaciones", "¿Hablamos?" |
| **3 · Tarjeta / detalle** | Título de una tarjeta de obra, de un detalle, de una unidad o de un aviso | 20 px | 17 px (piso: nunca menos) | Chillax | Tarjetas de `/desarrollos/`, ventana de detalle de una propiedad (home y `/propiedades/`), "Piso 10 · Unidad B", carteles de aviso |

Tamaños en `estilo.css`: `--titulo-pagina`, `--titulo-seccion`, `--titulo-tarjeta`. Clases listas para
usar: `.titulo-pagina`, `.titulo-seccion`, `.titulo-tarjeta`.

**Textos que no son títulos (no se tocan al cambiar la escala):**

- *Sobretítulo / etiqueta* (el barrio arriba del nombre, "AMBIENTES", "AL FIRMAR"): 11–15 px, en mayúsculas y gris.
- *Ítem desplegable* (Estructura, Carpinterías…): 14 px en negrita.

**Para agregar un título nuevo:** elegir el nivel por lo que es (¿página, sección o tarjeta?) y usar su
clase. Nunca un `font-size` suelto.

## 2. Aire alrededor de "← Volver"

- Debajo del "← Volver" de arriba: **32 px** hasta lo que sigue (título, barrio…). Vale en TODAS las
  páginas que lo tienen, formularios incluidos (`--aire-volver`).
- El "← Volver" de abajo (en las páginas largas): **36 px** de separación de lo anterior y **48 px**
  hasta el pie (`--aire-volver-abajo`).
- Siempre pegado a la **izquierda**, en la misma altura de siempre. Sólo el texto es clickeable.

## 3. Tarjetas y listados

- `/propiedades/` y `/desarrollos/`: **3 por hilera** desde 1000 px de ancho, 2 desde 760 px y 1 en celular.
- Detalle de una tarjeta (foto + datos): **grande**, ventana de 620 px, foto del tamaño de una tarjeta del listado.
- **Tarjeta de prueba / "Próximamente"**: vacía, con el cartel "Próximamente" donde va la foto y **sin click**.
  Nunca copias de propiedades reales.
- Un botón "Ver todos/as…" y lo que viene después llevan el mismo aire (~36 px) que hay entre
  "Ver todas las propiedades" y "Desarrollos destacados".

## 4. Barra de scroll

- **Una sola barra en toda la web**: fina, en el bronce de la marca a media opacidad, con el carril
  transparente. Se define una vez, en `estilo.css`, y cubre la página entera, las ventanas de detalle
  (matrícula, privacidad, propiedades), los campos de texto de los formularios y las tiras de fotos.
- **La home también la lleva** (Cristian pidió dejarla, 9-oct-2026). **Siempre el mismo color y estilo, en
  todo lugar donde haya barra**: se define una sola vez y no se repite en ningún otro archivo.
- Los sliders (propiedades y desarrollos de la home) y la galería de fotos de `/propiedades/` no muestran
  barra, a propósito.
- En el celular la barra es flotante y la dibuja el sistema: el código es el mismo que en la compu, pero
  el color final lo decide el navegador del teléfono.

## 5. Sliders de fotos (ficha de una obra: "El edificio" y "Así va la obra")

- **Bordes difuminados**: la foto se funde con el fondo en los dos bordes, para que no se vea el corte.
  El difuminado de un lado sólo aparece si hay más fotos de ese lado (al principio, sólo a la derecha;
  al final, sólo a la izquierda; en el medio, a los dos).
- **Flechas ‹ ›** (46 px) a la altura de la foto, también en celular. Cada una aparece sólo si hay más
  fotos de ese lado; mueven una foto por vez.
- **Arrastre con el mouse** (como el slider de la home); con el dedo o el trackpad se desliza solo. Un
  arrastre no abre la foto; un clic sí (se amplía).
- **La rueda del mouse NO mueve el slider**: sigue scrolleando la página (si no, el slider "se come" el
  scroll). Shift + rueda y los gestos horizontales del trackpad sí lo mueven.
- Sin barra de scroll propia (la reemplazan las flechas). Si todas las fotos entran en pantalla, no hay
  flechas ni difuminado.
- Carga: las 4 primeras fotos ya; el resto apenas se toca, desliza o se usa una flecha.
- **Sliders de la home (Propiedades disponibles y Desarrollos destacados)**: el mismo criterio de bordes
  difuminados — que nunca se vea el corte: las tarjetas de los costados se funden con el fondo (64 px en
  el celular, 104 px en la compu; `--difuminado` en `index.html`). Como el slider da la vuelta, el
  difuminado está siempre en los dos lados.

## 6. Rendimiento (reglas para que la web siga fluida)

Medido en un celular lento simulado (CPU 4 veces más lenta, conexión "Slow 4G"). Meta: **60 cuadros por segundo** al
scrollear y al deslizar, y imagen principal en menos de 2 segundos.

- **El desenfoque de vidrio (`backdrop-filter`) es lo más caro que tiene la web.** No se pone en nada que se mueva
  (tarjetas de un slider) ni en ventanas grandes con fotos (el detalle de una propiedad). Sólo en elementos chicos
  y quietos (botones, íconos del pie) y en las ventanas chicas de texto (matrícula, privacidad) y las tarjetas de
  formulario. Medido: quitarlo de las tarjetas del slider llevó el deslizado de 53 a 60 cuadros por segundo; quitarlo
  de la ventana de detalle, de 24-29 a 60 (con el fondo del panel al 94 % de opacidad para que no se transparente
  la página de atrás: `.aviso--detalle` en `estilo.css`).
- Las fotos del portal se piden en el tamaño que hace falta (`/w=640`, `/w=720`, `/w=1280`), nunca el original.
- Lo que está debajo de la pantalla inicial (sliders, fotos) se pide con prioridad baja para no frenar la portada.
- Todo contenido que llega después (tarjetas, filtros, frase de la obra) reserva su lugar desde el principio:
  nada tiene que "saltar" cuando aparece.
- Antes de agregar un efecto nuevo: probarlo con los scripts de medición (cuadros por segundo al scrollear y al
  deslizar). Si baja de 55, no entra.

## 7. Excepciones decididas por Cristian (no se tocan)

Estas piezas quedan **como están, a propósito**. La home y los formularios son **landings de Google Ads**
(lo primero que ve quien llega desde un anuncio): decisión del 9-oct-2026, "los de la Home están bien, los
del Form también".

- **Home**: títulos de sección ("¿Cómo puedo ayudarte?", "Propiedades disponibles", "Desarrollos destacados"):
  18 px en negrita (Inter), igual que el diseño original. Títulos del slider: 14 px.
- **Los 5 formularios**: su título ("Quiero saber cuánto vale mi propiedad"…) mide 19 px (Chillax).
- **Tarjetas de propiedades en el listado `/propiedades/`**: título de **15 px** en negrita (Inter), como
  estaban (Cristian: "20 se ven muy grandes"). Son textos largos que vienen del portal. Es la misma idea que
  las tarjetas chicas del slider de la home (14 px). El título del *detalle* de la propiedad sí usa el nivel 3.

La escala de la sección 1 vale para las páginas de Propiedades, Desarrollos y la ficha de una obra.
