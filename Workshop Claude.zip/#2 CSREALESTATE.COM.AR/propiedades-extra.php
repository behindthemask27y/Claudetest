<?php
/**
 * propiedades-extra.php — datos "de portal" que el JSON-LD de
 * propiedades.redsuma.com.ar NO trae: expensas, estado, orientación,
 * disposición, luminosidad, antigüedad, cocheras, superficies detalladas
 * (cubierta/semicubierta/descubierta/terreno) y etiquetas tipo "Apto
 * crédito". Esos datos sólo están en el HTML ya renderizado de cada
 * publicación (el JSON-LD sólo trae ambientes/dormitorios/baños/m²
 * totales, precio, fotos y comodidades).
 *
 * Lo pidió Cristian ("que la tarjeta muestre la mayor cantidad de info
 * posible, como un portal"), aunque antes se había decidido priorizar los
 * datos estructurados por sobre el HTML. Por eso esto está hecho para
 * ROMPERSE EN SILENCIO sin llevarse nada por delante:
 *
 *  - Vive en su propio archivo, cargado desde propiedades.php dentro de
 *    un try/catch: en PHP 7+ un error de sintaxis en un archivo incluido
 *    se puede atrapar, así que si este archivo tuviera un problema (o no
 *    existiera), propiedades.php sigue andando con los datos de siempre
 *    y el slider no se cae. (Se escribió sin poder ejecutar PHP en la
 *    PC de desarrollo — ver CLAUDE.md —, de ahí la precaución.)
 *  - csre_extraer_del_html() atrapa cualquier error y, si el portal
 *    cambia su estructura y no encuentra nada, devuelve listas vacías:
 *    la tarjeta simplemente muestra menos datos, no se rompe.
 *  - Los datos se leen por ESTRUCTURA (títulos <h2> "Características" y
 *    "Superficies", pares <p>etiqueta</p><p>valor</p>), no por clases de
 *    CSS (que en ese sitio son utilidades de Tailwind y cambian seguido).
 *
 * A propósito NO se extrae: dirección exacta (calle y número), nombre o
 * contacto del agente, ni ningún link a la publicación original — mismo
 * criterio de siempre (ver propiedades.php).
 */

/** Saca etiquetas HTML, decodifica entidades, colapsa espacios y recorta. */
function csre_limpiar_texto(string $s, int $max = 80): string {
  $s = strip_tags($s);
  $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $s = trim((string)preg_replace('/\s+/u', ' ', $s));
  return function_exists('mb_substr') ? mb_substr($s, 0, $max, 'UTF-8') : substr($s, 0, $max);
}

/** Pares <p>etiqueta</p><p>valor</p> consecutivos (la grilla de datos del portal). */
function csre_pares_etiqueta_valor(string $cuerpo, int $maximo = 16): array {
  $pares = [];
  if (preg_match_all('#<p\b[^>]*>([^<]{1,60})</p>\s*<p\b[^>]*>([^<]{1,80})</p>#u', $cuerpo, $m, PREG_SET_ORDER)) {
    foreach ($m as $par) {
      $etiqueta = csre_limpiar_texto($par[1], 40);
      $valor = csre_limpiar_texto($par[2], 60);
      if ($etiqueta === '' || $valor === '') continue;
      $pares[] = ['etiqueta' => $etiqueta, 'valor' => $valor];
      if (count($pares) >= $maximo) break;
    }
  }
  return $pares;
}

/**
 * Devuelve:
 *   reservada       bool    el portal muestra el cartel "Reservada"
 *   expensas        string  ej. "$ 140.000 expensas" ('' si no hay)
 *   caracteristicas lista de {etiqueta, valor}  (Ambientes, Estado, ...)
 *   superficies     lista de {etiqueta, valor}  (Cubierta, Terreno, ...)
 *   etiquetas       lista de strings            (Apto crédito, ...)
 */
function csre_extraer_del_html(string $html): array {
  $salida = [
    'reservada' => false,
    'expensas' => '',
    'caracteristicas' => [],
    'superficies' => [],
    'etiquetas' => [],
  ];

  try {
    // fuera scripts, SVG y los comentarios <!-- --> que React deja entre texto y texto
    $limpio = preg_replace('#<script\b.*?</script>|<svg\b.*?</svg>|<!--.*?-->#is', '', $html);
    if (!is_string($limpio)) return $salida;
    $posBody = stripos($limpio, '<body');
    if ($posBody !== false) $limpio = substr($limpio, $posBody);

    // todo lo que está antes del primer <h2> es la cabecera (título, precio, cartelitos)
    $posH2 = stripos($limpio, '<h2');
    $cabecera = $posH2 !== false ? substr($limpio, 0, $posH2) : $limpio;

    if (preg_match('#<p\b[^>]*>\s*((?:\$|USD|U\$S)\s*[\d.,]+)\s*expensas\s*</p>#iu', $cabecera, $m)) {
      $salida['expensas'] = trim($m[1]) . ' expensas';
    }
    if (preg_match('#>\s*Reservad[ao]\s*<#iu', $cabecera)) {
      $salida['reservada'] = true;
    }

    // secciones: cada <h2>Título</h2> + todo lo que le sigue hasta el próximo <h2>
    if (preg_match_all('#<h2\b[^>]*>(.*?)</h2>(.*?)(?=<h2\b|$)#isu', $limpio, $secciones, PREG_SET_ORDER)) {
      foreach ($secciones as $seccion) {
        $titulo = strtolower(csre_limpiar_texto($seccion[1], 40));
        if (strpos($titulo, 'caracter') === 0) {
          $salida['caracteristicas'] = csre_pares_etiqueta_valor($seccion[2]);
          // debajo de la grilla, los "flags" (Apto crédito, Apto comercial...) son <span> sueltos
          if (preg_match_all('#<span\b[^>]*>([^<]{2,40})</span>#u', $seccion[2], $chips)) {
            foreach ($chips[1] as $chip) {
              $etiqueta = csre_limpiar_texto($chip, 40);
              if ($etiqueta !== '') $salida['etiquetas'][] = $etiqueta;
              if (count($salida['etiquetas']) >= 10) break;
            }
          }
        } elseif (strpos($titulo, 'superficie') === 0) {
          $salida['superficies'] = csre_pares_etiqueta_valor($seccion[2]);
        }
      }
    }
  } catch (\Throwable $e) {
    // el portal cambió de estructura o algo falló: se devuelve lo que se
    // haya alcanzado a leer (probablemente nada) y la tarjeta se arma
    // igual con los datos del JSON-LD.
  }

  return $salida;
}
