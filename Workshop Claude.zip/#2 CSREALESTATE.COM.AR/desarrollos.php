<?php
/**
 * Sincroniza "Desarrollos" con sumadesarrollos.com.ar (la vidriera de Red Suma).
 *
 * Esa web no tiene API: arma su vidriera en el navegador con (1) una lista de
 * obras escrita en el JS de su home (`const PROJECTS = [...]`: dirección, barrio,
 * entrega, plan de pago, descripción, foto, un respaldo `fb`) y (2) la
 * disponibilidad real de cada obra, que lee de 8 Google Sheets publicadas como
 * CSV. Este archivo hace lo mismo desde el servidor — con la MISMA lógica que su
 * home (bloques(), resumen(), clasificar(), plan(), anticipoDe(), cuotaDe()) —
 * y publica el resultado como JSON para que nuestra web lo dibuje con su diseño.
 * Ver CLAUDE.md, "Fuente de los desarrollos: sumadesarrollos.com.ar".
 *
 * Diferencia a propósito con su home: cada obra se lee de SU planilla. Su home
 * busca el bloque por una regex contra la dirección y a Isolina ("belgrano") le
 * toca a veces el bloque de Monroe ("Belgrano, CABA"), según qué planilla termine
 * de cargar primero. Acá, si hay más de un candidato, gana el que tiene el
 * número de la calle y/o el que viene de la planilla declarada en `fuente`.
 *
 * Reglas de funcionamiento (pedidas por Cristian: "que funcione solito"):
 *  - Se vuelve a leer todo cada TTL (8 h). Entre medio se sirve la copia guardada.
 *  - NO se muestra información vieja si la fuente se cae: vencido el TTL, si el
 *    refresco falla se sigue mostrando la copia sólo durante GRACIA (1 h, para que
 *    un tropiezo de minutos no apague todo); pasada esa hora la respuesta es
 *    {"ok":false,"estado":"caida"} y la web muestra "Web de desarrollos no disponible".
 *  - Si el refresco falla se reintenta como mucho cada ESPERA_REINTENTO (15 min).
 *  - Si lo leído parece roto (cae a menos de la mitad la cantidad de obras) se
 *    trata como falla: no se pisa la copia buena.
 *  - Se avisa por mail a Cristian (con tope de 1 por día) cuando la fuente cae
 *    más de un intento seguido, cuando se recupera, y cuando algo no se pudo leer
 *    (obras ambiguas, sin planilla...).
 *  - Cada obra falla sola: una obra rara no tumba a las demás.
 *
 * Los datos que consume nuestra web (sin tocar HTML ajeno) salen de acá: la lista
 * de obras (desarrollos/) y, de cada obra, las unidades con su precio, anticipo y
 * cuota para el simulador de la ficha (desarrollos/ficha/). Lo que sólo trae la
 * página de cada obra (fotos, planos, textos, avance) lo lee desarrollo-extra.php.
 * Las utilidades compartidas (lectura de páginas, JSON, mails) están en
 * desarrollos-lib.php.
 */

declare(strict_types=1);

require_once __DIR__ . '/desarrollos-lib.php'; // SUMA_BASE, AVISO_A, $ES_PRUEBA, http_get, leer_json, escribir_json, avisar

const TTL = 8 * 3600;
const GRACIA = 3600;
const ESPERA_REINTENTO = 900;
const TOPE_AVISO = 86400;

/* ==================== lógica de su home, portada ==================== */

/** Número tolerante a formatos ("1.234,50", "1,234", "$ 80.250"). */
function num($s): ?float {
  $s = preg_replace('/[^\d.,-]/', '', (string)($s ?? '')) ?? '';
  if ($s === '') return null;
  $c = strrpos($s, ',');
  $d = strrpos($s, '.');
  $c = $c === false ? -1 : $c;
  $d = $d === false ? -1 : $d;
  if ($c > $d) {
    if ((strlen($s) - $c - 1) === 3 && $d === -1) $s = str_replace(',', '', $s);
    else $s = str_replace(',', '.', str_replace('.', '', $s));
  } else {
    $s = str_replace(',', '', $s);
  }
  return is_numeric($s) ? (float)$s : null;
}

/** CSV completo (con campos entre comillas que pueden traer saltos de línea). */
function parse_csv(string $texto): array {
  $h = fopen('php://memory', 'r+');
  fwrite($h, $texto);
  rewind($h);
  $filas = [];
  while (($f = fgetcsv($h, 0, ',', '"', '')) !== false) $filas[] = $f;
  fclose($h);
  return $filas;
}

function celda(array $fila, int $i): string {
  return ($i >= 0 && $i < count($fila)) ? (string)($fila[$i] ?? '') : '';
}

/** El precio de referencia: contado, salvo que la fuente publique el financiado. */
function precio_de(array $r, int $iC, int $iF, ?string $cual): ?float {
  $c = $iC > -1 ? num(celda($r, $iC)) : null;
  $f = $iF > -1 ? num(celda($r, $iF)) : null;
  $bien = static fn($v) => $v !== null && $v > 0;
  if ($cual === 'financiado') return $bien($f) ? $f : ($bien($c) ? $c : null);
  return $bien($c) ? $c : ($bien($f) ? $f : null);
}

/**
 * Cada obra es un bloque de la planilla: una fila con la dirección en la
 * columna A, la fila de encabezados (Piso / UF / ...) y las unidades.
 */
function bloques(array $filas, ?string $cual, string $origen): array {
  $out = [];
  $n = count($filas);
  for ($i = 0; $i < $n - 1; $i++) {
    $dir = trim(celda($filas[$i], 0));
    if ($dir === '') continue;
    $head = array_map(static fn($h) => mb_strtolower((string)($h ?? '')), $filas[$i + 1]);
    $tienePiso = false;
    $iU = -1;
    foreach ($head as $k => $h) {
      if (str_contains($h, 'piso')) $tienePiso = true;
      if ($iU === -1 && trim($h) === 'uf') $iU = $k;
    }
    if (!$tienePiso || $iU === -1) continue;
    $col = static function (string $frag) use ($head): int {
      foreach ($head as $k => $h) if (str_contains($h, $frag)) return $k;
      return -1;
    };
    $igual = static function (string $txt) use ($head): int {
      foreach ($head as $k => $h) if (trim($h) === $txt) return $k;
      return -1;
    };
    $iP = $col('piso'); $iT = $col('total'); $iE = $col('estado'); $iA = $col('ambientes');
    $iC = $col('contado'); $iF = $col('financiado'); $iAnt = $igual('anticipo'); $iCuo = $igual('cuota');
    // para la ficha: superficie cubierta, "expansión" (balcón/terraza) y la columna "Cochera"/"Baulera"
    // (qué incluye cada unidad); el nombre de esa columna cambia de una obra a otra
    $iCub = $col('cubierta'); $iExp = $col('expansi');
    $iExtra = $col('cochera') > -1 ? $col('cochera') : $col('baulera');
    $extraNombre = $iExtra > -1 ? (str_contains($head[$iExtra], 'cochera') ? 'Cochera' : 'Baulera') : null;
    $entrega = '';
    if (preg_match('/entrega aproximada:?\s*([^,|]+)/iu', implode(' ', $filas[$i]), $m)) $entrega = trim($m[1]);
    $uds = [];
    for ($j = $i + 2; $j < $n; $j++) {
      $r = $filas[$j];
      if (!$r || trim(celda($r, 0)) !== '') break;
      if (trim(celda($r, $iU)) === '') continue;
      $uds[] = [
        'piso' => celda($r, $iP),
        'uf' => trim(celda($r, $iU)),
        'tot' => num(celda($r, $iT)),
        'cub' => $iCub > -1 ? num(celda($r, $iCub)) : null,
        'exp' => $iExp > -1 ? num(celda($r, $iExp)) : null,
        'extra' => $iExtra > -1 ? trim(celda($r, $iExtra)) : '',
        'estado' => trim(celda($r, $iE)),
        'amb' => $iA > -1 ? trim(celda($r, $iA)) : '',
        'precio' => precio_de($r, $iC, $iF, $cual),
        'ant' => $iAnt > -1 ? num(celda($r, $iAnt)) : null,
        'cuo' => $iCuo > -1 ? num(celda($r, $iCuo)) : null,
      ];
    }
    if ($uds) $out[] = ['dir' => $dir, 'entrega' => $entrega, 'uds' => $uds, 'origen' => $origen, 'extra_nombre' => $extraNombre];
  }
  return $out;
}

/** Cocheras y bauleras que se venden aparte: no son vivienda. */
function es_cochera(array $u): bool {
  $t = mb_strtolower(implode(' ', [(string)$u['piso'], (string)$u['uf'], (string)$u['amb']]));
  return (bool)preg_match('/coch|garage|garaje|guarda|baulera/u', $t);
}

function piso_key($p): string {
  return trim(str_replace('°', '', mb_strtoupper((string)$p)));
}

function clasificar(array $u, array $p): string {
  $fix = ($p['corr'] ?? [])[piso_key($u['piso']) . '|' . mb_strtoupper((string)$u['uf'])] ?? null;
  $a = mb_strtolower((string)($fix ?: $u['amb'] ?: ''));
  if (str_contains(mb_strtolower((string)$u['uf']), 'local')) return 'local';
  if ($a === '' && !empty($p['tipoMap'])) {
    $clave = (piso_key($u['piso']) === 'PB' ? 'PB-' : 'T-') . mb_strtoupper((string)$u['uf']);
    $a = mb_strtolower((string)($p['tipoMap'][$clave] ?? ''));
  }
  if (str_contains($a, 'local')) return 'local';
  if (str_contains($a, 'mono') || preg_match('/^1\b/u', $a)) return 'mono';
  if (str_starts_with($a, '2')) return 'd2';
  if (str_starts_with($a, '3')) return 'd3';
  if (str_starts_with($a, '4')) return 'd4';
  return 'otro';
}

function estado_norm(string $e): string {
  $t = mb_strtolower(trim($e));
  if (str_starts_with($t, 'dispon')) return 'disponible';
  if (str_starts_with($t, 'reserv')) return 'reservada';
  if (str_starts_with($t, 'vend')) return 'vendida';
  if (str_starts_with($t, 'no dispon')) return 'no_disponible';
  return 'otro';
}

const NOMBRES_TIPO = [
  'mono' => ['monoambiente', 'monoambientes'], 'd2' => ['de 2 amb.', 'de 2 amb.'], 'd3' => ['de 3 amb.', 'de 3 amb.'],
  'd4' => ['de 4 amb.', 'de 4 amb.'], 'local' => ['local', 'locales'], 'otro' => ['unidad', 'unidades'],
];

/** "16 unidades: local, monoambientes y 2 amb." → ['local'=>1,'mono'=>1,'d2'=>1] (respaldo sin planilla). */
function amb_de_texto(string $t): array {
  $x = mb_strtolower($t);
  $c = [];
  if (str_contains($x, 'local')) $c['local'] = 1;
  if (str_contains($x, 'mono')) $c['mono'] = 1;
  if (preg_match('/\b2\s*amb|\bdos amb/u', $x)) $c['d2'] = 1;
  if (preg_match('/\b3\s*amb|\btres amb/u', $x)) $c['d3'] = 1;
  if (preg_match('/\b4\s*amb|\bcuatro amb/u', $x)) $c['d4'] = 1;
  return $c;
}

/** Resumen de lo que queda libre: texto de tipologías, cantidad, "desde", cocheras. */
function resumen(array $uds, array $p): array {
  $todas = array_values(array_filter($uds, static fn($u) => str_starts_with(mb_strtolower((string)$u['estado']), 'dispon')));
  $cocheras = array_values(array_filter($todas, 'es_cochera'));
  $libres = array_values(array_filter($todas, static fn($u) => !es_cochera($u)));
  $prC = array_values(array_filter(array_map(static fn($u) => $u['precio'], $cocheras)));
  $coch = $cocheras ? ['n' => count($cocheras), 'desde' => $prC ? min($prC) : null] : null;
  if (!$libres) return ['texto' => 'Consultar', 'n' => 0, 'desde' => null, 'amb' => [], 'coch' => $coch];
  $c = [];
  foreach ($libres as $u) { $k = clasificar($u, $p); $c[$k] = ($c[$k] ?? 0) + 1; }
  $partes = [];
  foreach (['mono', 'd2', 'd3', 'd4', 'local', 'otro'] as $k) {
    if (isset($c[$k])) $partes[] = $c[$k] . ' ' . NOMBRES_TIPO[$k][$c[$k] > 1 ? 1 : 0];
  }
  $pr = array_values(array_filter(array_map(static fn($u) => $u['precio'], $libres)));
  return ['texto' => implode(' · ', $partes), 'n' => count($libres), 'desde' => $pr ? min($pr) : null, 'amb' => $c, 'coch' => $coch];
}

/** Del texto del plan ("30% + 36 cuotas fijas en USD") saca el % de anticipo y las cuotas. */
function plan_de(array $p): ?array {
  $t = (string)($p['fin'] ?? '');
  if (preg_match('/contado/iu', $t)) return ['ant' => 1.0, 'cuotas' => 0];
  if (!preg_match('/(\d+)\s*%/u', $t, $a)) return null;
  $cuotas = preg_match('/(\d+)\s*cuotas/u', $t, $c) ? (int)$c[1] : 0;
  return ['ant' => ((float)$a[1]) / 100, 'cuotas' => $cuotas];
}

/** Anticipo de UNA unidad: primero lo que publica la planilla, si no se deduce del plan. */
function ant_ud(array $u, ?array $pl): ?float {
  if (($u['ant'] ?? 0) > 0) return (float)$u['ant'];
  return ($pl && ($u['precio'] ?? null)) ? $u['precio'] * $pl['ant'] : null;
}

/** Cuota de UNA unidad. */
function cuo_ud(array $u, ?array $pl, array $p): ?float {
  if (($u['cuo'] ?? 0) > 0) return (float)$u['cuo'];
  if (!empty($p['cuotaFija'])) return (float)$p['cuotaFija'];
  if (!$pl || !$pl['cuotas'] || !($u['precio'] ?? null)) return null;
  return $u['precio'] * (1 - $pl['ant']) / $pl['cuotas'];
}

function anticipo_de(array $p, array $d, array $libres): ?float {
  $pl = plan_de($p);
  $v = array_values(array_filter(array_map(static fn($u) => ant_ud($u, $pl), $libres), static fn($n) => $n > 0));
  if ($v) return min($v);
  if (($d['ant'] ?? 0) > 0) return (float)$d['ant'];
  return ($pl && !empty($d['desde'])) ? $d['desde'] * $pl['ant'] : null;
}

function cuota_de(array $p, array $d, array $libres): ?float {
  $pl = plan_de($p);
  $v = array_values(array_filter(array_map(static fn($u) => cuo_ud($u, $pl, $p), $libres), static fn($n) => $n > 0));
  if ($v) return min($v);
  if (!empty($p['cuotaFija'])) return (float)$p['cuotaFija'];
  if (($d['cuota'] ?? 0) > 0) return (float)$d['cuota'];
  if (!$pl || empty($d['desde']) || !$pl['cuotas']) return null;
  return $d['desde'] * (1 - $pl['ant']) / $pl['cuotas'];
}

/* ==================== lectura de la home de ellos ==================== */

/** Valor de un campo `clave:"texto"` dentro de una línea de PROJECTS. */
function campo_texto(string $linea, string $clave): ?string {
  if (!preg_match('/\b' . preg_quote($clave, '/') . ':"((?:[^"\\\\]|\\\\.)*)"/u', $linea, $m)) return null;
  return stripcslashes($m[1]);
}

function mapa_de(string $linea, string $clave): array {
  if (!preg_match('/\b' . preg_quote($clave, '/') . ':\{([^}]*)\}/u', $linea, $m)) return [];
  preg_match_all('/"([^"]+)"\s*:\s*"([^"]+)"/u', $m[1], $pares, PREG_SET_ORDER);
  $out = [];
  foreach ($pares as $par) $out[$par[1]] = $par[2];
  return $out;
}

/** La lista de obras: una por línea dentro de `const PROJECTS = [ ... ];`. */
function leer_proyectos(string $home): array {
  if (!preg_match('/const PROJECTS = \[(.*?)\n\];/su', $home, $m)) return [];
  $out = [];
  foreach (preg_split('/\R/u', $m[1]) as $linea) {
    if (!preg_match('/\bnum:"/u', $linea)) continue;
    $p = [
      'num' => campo_texto($linea, 'num'),
      'calle' => campo_texto($linea, 'calle'),
      'barrio' => campo_texto($linea, 'barrio'),
      'url' => campo_texto($linea, 'url'),
      'desc' => campo_texto($linea, 'desc'),
      'entrega' => campo_texto($linea, 'entrega'),
      'fin' => campo_texto($linea, 'fin'),
      'fuente' => campo_texto($linea, 'fuente'),
      'proxima' => (bool)preg_match('/\bproxima:true\b/u', $linea),
      'match' => null,
    ];
    if (preg_match('/\bmatch:\/((?:[^\/\\\\]|\\\\.)+)\//u', $linea, $mm)) $p['match'] = $mm[1];
    if (preg_match('/\bcuotaFija:(\d+)/u', $linea, $cf)) $p['cuotaFija'] = (int)$cf[1];
    if (preg_match('/\bfb:\{([^}]*)\}/u', $linea, $fb)) {
      $f = $fb[1];
      $p['fb'] = [
        'texto' => campo_texto($f, 'texto') ?? '',
        'n' => preg_match('/\bn:(\d+)/u', $f, $x) ? (int)$x[1] : 0,
        'desde' => preg_match('/\bdesde:(\d+)/u', $f, $x) ? (float)$x[1] : 0.0,
        'ant' => preg_match('/\bant:(\d+)/u', $f, $x) ? (float)$x[1] : null,
        'cuota' => preg_match('/\bcuota:(\d+)/u', $f, $x) ? (float)$x[1] : null,
      ];
    }
    $p['corr'] = mapa_de($linea, 'corr');
    $p['tipoMap'] = mapa_de($linea, 'tipoMap');
    // foto: puede ser un texto o una lista; la primera
    if (preg_match('/\bimg:\s*\[\s*"([^"]+)"/u', $linea, $im) || preg_match('/\bimg:\s*"([^"]+)"/u', $linea, $im)) $p['img'] = $im[1];
    if (($p['num'] ?? '') === '' || ($p['calle'] ?? '') === '' || ($p['url'] ?? '') === '') continue;
    $out[] = $p;
  }
  return $out;
}

/**
 * Qué planillas lee su home y qué precio publica cada una: se saca de su propio
 * código (const CSV y FUENTES), así una planilla nueva que ellos sumen se lee
 * sola. Si cambian el formato y no se puede leer, se usa este respaldo.
 */
function leer_fuentes(string $home): array {
  $urls = [];
  if (preg_match('/const CSV = \{(.*?)\};/su', $home, $m)) {
    preg_match_all('/(\w+):\s*"(https:\/\/docs\.google\.com[^"]+)"/u', $m[1], $pares, PREG_SET_ORDER);
    foreach ($pares as $par) $urls[$par[1]] = $par[2];
  }
  $fuentes = [];
  if (preg_match_all('/\{clave:"(\w+)",\s*url:\s*CSV\.(\w+),\s*nombre:\s*"([^"]*)",\s*precio:\s*(null|"[^"]*")\}/u', $home, $filas, PREG_SET_ORDER)) {
    foreach ($filas as $f) {
      if (!isset($urls[$f[2]])) continue;
      $fuentes[] = ['clave' => $f[2], 'nombre' => $f[3], 'url' => $urls[$f[2]], 'precio' => $f[4] === 'null' ? null : trim($f[4], '"')];
    }
  }
  if (!$fuentes) {
    $respaldo = ['h1' => null, 'h2' => null, 'cg' => null, 'cuore' => 'financiado', 'boh' => 'financiado', 'iso' => 'financiado', 'mon' => 'financiado', 'jbj' => 'financiado'];
    foreach ($respaldo as $k => $precio) if (isset($urls[$k])) $fuentes[] = ['clave' => $k, 'nombre' => $k, 'url' => $urls[$k], 'precio' => $precio];
  }
  return $fuentes;
}

/* ==================== armado de cada obra ==================== */

function url_absoluta(?string $ruta): ?string {
  if ($ruta === null || $ruta === '') return null;
  if (preg_match('#^https?://#', $ruta)) return $ruta;
  return SUMA_BASE . ltrim($ruta, '/');
}

/**
 * Qué incluye una unidad además de la vivienda (la columna "Cochera"/"Baulera" de la
 * planilla): "Cochera", "Baulera", "Cochera a definir"... o null si no incluye nada.
 */
function incluye_de(array $u, ?string $nombre): ?string {
  $v = mb_strtolower(trim((string)($u['extra'] ?? '')));
  if ($nombre === null || $v === '' || preg_match('/^(no|0)$/u', $v)) return null;
  if (preg_match('/^(sin def\.?|s\/d|a definir|indef\.?)$/u', $v)) return $nombre . ' a definir';
  return $nombre;
}

/** Qué bloque de planilla le corresponde a esta obra (y avisos si hay dudas). */
function elegir_bloque(array $p, array $bloques, array &$avisos): ?array {
  if ($p['match'] === null) return null;
  $cands = [];
  foreach ($bloques as $b) {
    if (@preg_match('/' . $p['match'] . '/u', mb_strtolower($b['dir']))) $cands[] = $b;
  }
  if (!$cands) return null;
  if (!empty($p['fuente'])) {
    $propios = array_values(array_filter($cands, static fn($b) => $b['origen'] === $p['fuente']));
    if ($propios) $cands = $propios;
  }
  if (count($cands) === 1) return $cands[0];
  $conNumero = array_values(array_filter($cands, static fn($b) =>
    (bool)preg_match('/(?<!\d)' . preg_quote((string)$p['num'], '/') . '(?!\d)/u', str_replace('.', '', $b['dir']))));
  if (count($conNumero) === 1) return $conNumero[0];
  $avisos[] = 'Obra ambigua: ' . $p['calle'] . ' ' . $p['num'] . ' calza con ' . count($cands) . ' bloques de planilla (' . implode(' | ', array_map(static fn($b) => $b['dir'], $cands)) . '); se usó el primero.';
  return ($conNumero ?: $cands)[0];
}

function armar_obra(array $p, array $bloques, array &$avisos): array {
  $bl = elegir_bloque($p, $bloques, $avisos);
  $fb = $p['fb'] ?? ['texto' => '', 'n' => 0, 'desde' => 0.0, 'ant' => null, 'cuota' => null];
  $entrega = (string)($p['entrega'] ?? '');
  $libresCalc = [];
  $unidades = [];
  $contEstados = ['disponible' => 0, 'vendida' => 0, 'reservada' => 0, 'no_disponible' => 0, 'otro' => 0];

  if ($bl) {
    $r = resumen($bl['uds'], $p);
    $d = ['texto' => $r['texto'], 'n' => $r['n'], 'desde' => $r['desde'] ?: $fb['desde'], 'amb' => $r['amb'], 'coch' => $r['coch']];
    if ($bl['entrega'] !== '' && empty($p['proxima'])) $entrega = $bl['entrega'];
    foreach ($bl['uds'] as $u) {
      $est = estado_norm((string)$u['estado']);
      $coch = es_cochera($u);
      if (!$coch) $contEstados[$est]++;
      if ($est === 'disponible' && !$coch && !empty($u['precio'])) {
        $libresCalc[] = ['tipo' => clasificar($u, $p), 'precio' => $u['precio'], 'ant' => $u['ant'], 'cuo' => $u['cuo']];
      }
    }
    $pl = plan_de($p);
    foreach ($bl['uds'] as $u) {
      $coch = es_cochera($u);
      $est = estado_norm((string)$u['estado']);
      $unidades[] = [
        'piso' => trim((string)$u['piso']),
        'uf' => $u['uf'],
        'tipo' => $coch ? 'cochera' : clasificar($u, $p),
        'ambientes' => $u['amb'],
        'm2' => $u['tot'],
        'cub' => $u['cub'],
        'exp' => $u['exp'],
        'incluye' => $coch ? null : incluye_de($u, $bl['extra_nombre'] ?? null),
        'estado' => $est,
        'precio' => $est === 'disponible' ? $u['precio'] : null,
        'anticipo' => ($est === 'disponible' && !empty($u['precio'])) ? ant_ud($u, $pl) : null,
        'cuota' => ($est === 'disponible' && !empty($u['precio'])) ? cuo_ud($u, $pl, $p) : null,
        'cochera' => $coch,
      ];
    }
    $origen = 'planilla';
  } else {
    $d = $fb;
    $d['amb'] = amb_de_texto((string)$fb['texto']);
    $d['coch'] = null;
    $origen = 'respaldo';
  }

  $n = (int)($d['n'] ?? 0);
  $coch = $d['coch'] ?? null;
  $obra = [
    'id' => trim((string)$p['url'], '/'),
    'numero' => $p['num'],
    'calle' => $p['calle'],
    'barrio' => $p['barrio'],
    'titulo' => trim($p['calle'] . ' ' . $p['num']),
    'descripcion' => $p['desc'],
    'entrega' => $entrega,
    'proxima_entrega' => !empty($p['proxima']),
    'plan' => $p['fin'],
    // % de anticipo y cantidad de cuotas sacados del texto del plan, y la comisión del 4 % que
    // cobra Red Suma al comprador (la misma que usa el simulador de su ficha); la ficha la usa
    // para armar el simulador. La comisión real de una obra se corrige con desarrollo-extra.php.
    'plan_detalle' => ($pd = plan_de($p)) ? ['anticipo_pct' => $pd['ant'], 'cuotas' => $pd['cuotas'], 'comision_pct' => 0.04] : null,
    'imagen' => url_absoluta($p['img'] ?? null),
    'ficha_origen' => SUMA_BASE . $p['url'],
    'origen' => $origen,
    'agotada' => $n === 0,
    'unidades_libres' => $n,
    'desde' => $d['desde'] ?? null,
    'tipologias' => $n === 0 ? 'Todas las unidades vendidas' : (string)$d['texto'],
    'tipos' => $d['amb'] ?? [],
    'anticipo_desde' => $n > 0 ? anticipo_de($p, $d, $libresCalc) : null,
    'cuota_desde' => $n > 0 ? cuota_de($p, $d, $libresCalc) : null,
    'cocheras' => $coch,
    'conteo' => $bl ? $contEstados : null,
    'unidades' => $unidades,
  ];
  return $obra;
}

/* ==================== sincronización completa ==================== */

/**
 * Lee todo. Devuelve ['obras'=>..., 'resumen'=>..., 'avisos'=>[...]] o, si la
 * fuente no está disponible, null y el motivo en $motivo.
 */
function sincronizar(?string &$motivo, array &$avisos): ?array {
  global $ES_PRUEBA;
  $avisos = [];
  $archivoPrueba = $ES_PRUEBA ? getenv('CSRE_PRUEBA_HOME') : false;
  $urlHome = $ES_PRUEBA && getenv('CSRE_PRUEBA_URL') ? (string)getenv('CSRE_PRUEBA_URL') : SUMA_BASE;
  $home = $archivoPrueba ? (@file_get_contents((string)$archivoPrueba) ?: null) : http_get($urlHome);
  if ($home === null) { $motivo = 'No respondió la página principal de sumadesarrollos.com.ar'; return null; }

  $proyectos = leer_proyectos($home);
  if (count($proyectos) < 3) { $motivo = 'No se pudo leer la lista de obras de su página (¿cambió el formato?). Obras leídas: ' . count($proyectos); return null; }

  $fuentes = leer_fuentes($home);
  if (!$fuentes) { $motivo = 'No se pudo leer la lista de planillas de su página (¿cambió el formato?)'; return null; }

  $bloques = [];
  $caidas = [];
  foreach ($fuentes as $f) {
    $texto = http_get($f['url'], 15, 3);
    if ($texto === null) { $caidas[] = $f['nombre']; continue; }
    $b = bloques(parse_csv($texto), $f['precio'], $f['clave']);
    if (!$b) { $avisos[] = 'La planilla "' . $f['nombre'] . '" respondió pero no tiene el formato esperado.'; $caidas[] = $f['nombre']; continue; }
    $bloques = array_merge($bloques, $b);
  }
  // si la mitad o más de las planillas no responde, la fuente está caída: no se publica a medias
  if (count($caidas) * 2 >= count($fuentes)) {
    $motivo = 'No respondieron ' . count($caidas) . ' de ' . count($fuentes) . ' planillas (' . implode(', ', $caidas) . ')';
    return null;
  }
  if ($caidas) $avisos[] = 'No respondieron estas planillas (esas obras usan el respaldo de su página): ' . implode(', ', $caidas);

  $obras = [];
  foreach ($proyectos as $p) {
    try {
      $obras[] = armar_obra($p, $bloques, $avisos);
    } catch (\Throwable $e) {
      $avisos[] = 'No se pudo armar la obra ' . ($p['calle'] ?? '?') . ' ' . ($p['num'] ?? '') . ': ' . $e->getMessage();
    }
  }
  if (count($obras) < 3) { $motivo = 'Se pudieron armar menos de 3 obras'; return null; }

  $barrios = [];
  $unidades = 0;
  $desde = null;
  foreach ($obras as $o) {
    $barrios[$o['barrio']] = true;
    $unidades += $o['unidades_libres'];
    if ($o['desde'] && !$o['agotada'] && ($desde === null || $o['desde'] < $desde)) $desde = $o['desde'];
  }
  return [
    'obras' => $obras,
    'resumen' => ['obras' => count($obras), 'barrios' => count($barrios), 'unidades_libres' => $unidades, 'desde' => $desde],
    'avisos' => $avisos,
  ];
}

/* ==================== respuesta ==================== */

function responder(array $cuerpo): void {
  header('Content-Type: application/json; charset=utf-8');
  // Una respuesta buena se puede reusar 2 minutos en el navegador: la home, la lista y la ficha
  // piden este mismo JSON, y al pasar de una a otra no hace falta volver a bajarlo (los datos se
  // renuevan cada 8 h, 2 minutos no se notan). Un error ("caída") NUNCA se guarda: en cuanto la
  // fuente se recupera, la web lo tiene que ver ya.
  header('Cache-Control: ' . (!empty($cuerpo['ok']) ? 'public, max-age=120, stale-while-revalidate=600' : 'no-cache, must-revalidate'));
  header('X-Content-Type-Options: nosniff');
  echo json_encode($cuerpo, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function responder_ok(array $datos, int $generado): void {
  responder(['ok' => true, 'estado' => 'ok', 'actualizado' => date('c', $generado)] + $datos);
}

function responder_caida(string $mensaje): void {
  responder(['ok' => false, 'estado' => 'caida', 'mensaje' => $mensaje]);
}

/* ==================== flujo principal ==================== */

$dirCache = __DIR__ . '/cache';
$archivoCache = $dirCache . '/desarrollos.json';
$archivoEstado = $dirCache . '/desarrollos-estado.json';
$ahora = time();

$cache = leer_json($archivoCache);
$edad = ($cache && isset($cache['generado'])) ? $ahora - (int)$cache['generado'] : PHP_INT_MAX;

// 1) copia fresca: se sirve directo
if ($cache && $edad < TTL) {
  responder_ok($cache['datos'], (int)$cache['generado']);
  exit;
}

$estado = leer_json($archivoEstado) ?? ['ultimo_intento' => 0, 'fallos' => 0, 'ultimo_aviso' => 0, 'aviso_enviado' => false];
$toca = !$cache || ($ahora - (int)$estado['ultimo_intento']) >= ESPERA_REINTENTO;
$dentroDeGracia = $cache && $edad < TTL + GRACIA;

// 2) hace poco que se intentó y falló: no se vuelve a pegar a la fuente todavía
if (!$toca) {
  if ($dentroDeGracia) responder_ok($cache['datos'], (int)$cache['generado']);
  else responder_caida('No se pudo actualizar la información de los desarrollos.');
  exit;
}

// 3) hay que refrescar. Un solo proceso a la vez.
@mkdir($dirCache, 0755, true);
$lock = @fopen($dirCache . '/desarrollos.lock', 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
  if ($dentroDeGracia) responder_ok($cache['datos'], (int)$cache['generado']);
  else responder_caida('Actualizando la información de los desarrollos. Probá de nuevo en unos minutos.');
  exit;
}

ignore_user_abort(true);
@set_time_limit(120);

// Con copia vigente dentro de la gracia se responde YA y se refresca después de contestar
// (así ningún visitante espera lo que tarda leer 9 fuentes). Sin esa posibilidad, se espera.
$respondido = false;
if ($dentroDeGracia) {
  responder_ok($cache['datos'], (int)$cache['generado']);
  if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); $respondido = true; }
  elseif (function_exists('litespeed_finish_request')) { @litespeed_finish_request(); $respondido = true; }
  elseif (PHP_SAPI === 'cli') { $respondido = true; }
}

$motivo = null;
$avisos = [];
$res = sincronizar($motivo, $avisos);

// una lectura que de golpe trae menos de la mitad de las obras se considera rota
if ($res && $cache && !empty($cache['datos']['obras'])) {
  $antes = count($cache['datos']['obras']);
  if ($antes >= 6 && count($res['obras']) * 2 < $antes) {
    $motivo = 'La lectura trajo ' . count($res['obras']) . ' obras contra ' . $antes . ' de la anterior; se descarta por parecer un error de lectura.';
    $res = null;
  }
}

if ($res) {
  $datos = ['obras' => $res['obras'], 'resumen' => $res['resumen']];
  escribir_json($archivoCache, ['generado' => $ahora, 'datos' => $datos]);
  $recuperada = !empty($estado['aviso_enviado']);
  escribir_json($archivoEstado, ['ultimo_intento' => $ahora, 'fallos' => 0, 'ultimo_aviso' => $estado['ultimo_aviso'] ?? 0, 'aviso_enviado' => false]);
  if ($recuperada) {
    avisar('Desarrollos: la sincronización se recuperó', "La información de los desarrollos volvió a sincronizarse bien (" . count($res['obras']) . " obras).");
  }
  if ($res['avisos'] && ($ahora - (int)($estado['ultimo_aviso'] ?? 0)) >= TOPE_AVISO) {
    avisar('Desarrollos: algo no se pudo leer del todo', "La sincronización funcionó, pero hay cosas para revisar:\n\n- " . implode("\n- ", $res['avisos']));
    $est = leer_json($archivoEstado) ?? [];
    $est['ultimo_aviso'] = $ahora;
    escribir_json($archivoEstado, $est);
  }
  if (!$respondido) responder_ok($datos, $ahora);
} else {
  $fallos = (int)$estado['fallos'] + 1;
  $enviar = $fallos >= 2 && ($ahora - (int)($estado['ultimo_aviso'] ?? 0)) >= TOPE_AVISO;
  escribir_json($archivoEstado, [
    'ultimo_intento' => $ahora, 'fallos' => $fallos,
    'ultimo_aviso' => $enviar ? $ahora : ($estado['ultimo_aviso'] ?? 0),
    'aviso_enviado' => $enviar ? true : !empty($estado['aviso_enviado']),
    'motivo' => $motivo,
  ]);
  if ($enviar) {
    avisar('Desarrollos: no se pudo sincronizar con sumadesarrollos.com.ar',
      "Hace $fallos intentos seguidos que no se puede leer la información de los desarrollos.\n\nMotivo: $motivo\n\n"
      . "Mientras tanto la web muestra \"Web de desarrollos no disponible\" (una vez pasada 1 hora desde el último dato bueno). "
      . "Se vuelve a intentar sola cada 15 minutos. Si dura, puede que ellos hayan cambiado el formato de su página.");
  }
  if (!$respondido) {
    if ($dentroDeGracia) responder_ok($cache['datos'], (int)$cache['generado']);
    else responder_caida('No se pudo actualizar la información de los desarrollos.');
  }
}
flock($lock, LOCK_UN);
fclose($lock);
