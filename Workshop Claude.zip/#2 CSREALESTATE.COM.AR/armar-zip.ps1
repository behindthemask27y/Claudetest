# armar-zip.ps1 — arma cristian-stedtfeld-web.zip (lo que se sube a Hostinger) y lo verifica.
# NO va en el zip. Se corre desde esta carpeta:
#   powershell -NoProfile -ExecutionPolicy Bypass -File armar-zip.ps1
#
# Hace 3 cosas, en este orden:
#  1) SELLA LA VERSIÓN DEL CSS: cada página pide los estilos como estilo.css?v=<huella>. La huella cambia sola
#     cada vez que estilo.css cambia, así que cualquier navegador/celular/CDN que tenga guardada una copia vieja
#     baja la nueva (pasó el 2026-10-09: un iPhone mostraba la ficha con estilos viejos y el "← Volver" en azul,
#     porque tenía guardado un estilo.css anterior). El resto de los archivos ya se revalidan solos (no-cache).
#  2) Arma el zip con barras "/" y carpetas explícitas (como pide el extractor de Hostinger).
#  3) Compara cada archivo del zip contra el de esta carpeta (huella SHA256) y cuenta carpetas/archivos.
#
# Lo que NO entra al zip: CLAUDE.md, MANUAL/MAPA/PLAN, serve.ps1, este script, .claude/, archivos de prueba
# (desarrollos-prueba.json, desarrollos-extra-prueba/, *.flag), htaccess-*.txt, OLD*, y los originales sin uso.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$raiz = Split-Path -Parent $MyInvocation.MyCommand.Path
$sha = [System.Security.Cryptography.SHA256]::Create()

# ---------- 1) sellar la versión del CSS ----------
$huellaCss = ([BitConverter]::ToString($sha.ComputeHash([System.IO.File]::ReadAllBytes("$raiz\estilo.css"))) -replace '-', '').Substring(0, 8).ToLower()
$paginas = @('index.html', 'propiedades/index.html', 'desarrollos/index.html', 'desarrollos/ficha/index.html',
  'form/vender/index.html', 'form/tasacion/index.html', 'form/alquilar-mi-propiedad/index.html', 'form/comprar/index.html', 'form/buscar-alquiler/index.html')
$cambiadas = 0
foreach ($p in $paginas) {
  $ruta = Join-Path $raiz ($p -replace '/', '\')
  $bytes = [System.IO.File]::ReadAllBytes($ruta)
  $conBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
  $texto = [System.IO.File]::ReadAllText($ruta, [System.Text.Encoding]::UTF8)
  $nuevo = [regex]::Replace($texto, '(href="(?:\.\./)*estilo\.css)(\?v=[0-9a-f]+)?"', ('$1?v=' + $huellaCss + '"'))
  if ($nuevo -ne $texto) {
    [System.IO.File]::WriteAllText($ruta, $nuevo, (New-Object System.Text.UTF8Encoding($conBom)))
    $cambiadas++
  }
}
"CSS sellado: estilo.css?v=$huellaCss  ($cambiadas pagina(s) actualizada(s) de $($paginas.Count))"

# ---------- 2) armar el zip ----------
$carpetas = @('cache', 'desarrollos', 'desarrollos/ficha', 'fonts', 'form', 'form/alquilar-mi-propiedad', 'form/buscar-alquiler', 'form/comprar', 'form/tasacion', 'form/vender', 'leads', 'propiedades')
$archivos = @(
  'desarrollos.php', 'desarrollos-lib.php', 'desarrollo-extra.php', 'desarrollos/index.html', 'desarrollos/ficha/index.html',
  'index.html', 'estilo.css', 'enviar-lead.php', 'propiedades.php', 'propiedades-extra.php',
  'foto.webp', 'og.jpg',
  'icono-legal.png', 'logo-redsuma.png',
  'fonts/chillax-500.woff2', 'fonts/inter-latin.woff2',
  'form/alquilar-mi-propiedad/index.html', 'form/buscar-alquiler/index.html', 'form/comprar/index.html',
  'form/tasacion/index.html', 'form/vender/index.html',
  'leads/.htaccess', 'cache/.htaccess', 'propiedades/index.html'
)
$tmp = Join-Path $raiz 'cristian-stedtfeld-web.nuevo.zip'
if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Confirm:$false }
$fs = [System.IO.File]::Open($tmp, [System.IO.FileMode]::Create)
$zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Create)
foreach ($c in $carpetas) { [void]$zip.CreateEntry($c + '/') }
foreach ($a in $archivos) {
  $ruta = Join-Path $raiz ($a -replace '/', [string][System.IO.Path]::DirectorySeparatorChar)
  [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $ruta, $a, [System.IO.Compression.CompressionLevel]::Optimal)
}
$zip.Dispose(); $fs.Dispose()
[System.IO.File]::Copy($tmp, "$raiz\cristian-stedtfeld-web.zip", $true)
Remove-Item -LiteralPath $tmp -Confirm:$false

# ---------- 3) verificar ----------
$z = [System.IO.Compression.ZipFile]::OpenRead("$raiz\cristian-stedtfeld-web.zip")
$nArch = 0; $nDir = 0; $distintos = 0; $barras = 0
foreach ($e in $z.Entries) {
  if ($e.FullName.Contains('\')) { $barras++ }
  if ($e.FullName.EndsWith('/')) { $nDir++; continue }
  $nArch++
  $s = $e.Open(); $ms = New-Object System.IO.MemoryStream; $s.CopyTo($ms); $s.Dispose()
  $h1 = [BitConverter]::ToString($sha.ComputeHash($ms.ToArray()))
  $h2 = [BitConverter]::ToString($sha.ComputeHash([System.IO.File]::ReadAllBytes((Join-Path $raiz ($e.FullName -replace '/', '\')))))
  if ($h1 -ne $h2) { $distintos++; "DISTINTO: $($e.FullName)" }
}
$z.Dispose()
"ZIP LISTO: {0} archivos, {1} carpetas, distintos de la carpeta: {2}, barras invertidas: {3}, {4:N0} KB" -f $nArch, $nDir, $distintos, $barras, ((Get-Item -LiteralPath "$raiz\cristian-stedtfeld-web.zip").Length / 1KB)
