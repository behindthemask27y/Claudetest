# Contexto: mensajes de WhatsApp (consultas, prospección y seguimiento)

Se lee cuando Cris pide un mensaje de WhatsApp: responder una consulta, retomar un chat, prospectar a un propietario, acompañar un PDF o hacer un seguimiento. Sale de las notas que Cris pasó el 6 de octubre de 2026 (Ninja Selling de Larry Kendall y Cómo ganar amigos e influir sobre las personas de Dale Carnegie). Las reglas generales del proyecto (no inventar, español rioplatense, USD) no se repiten acá.

---

## 1. Qué leer

- `Comunication-Strategy WPP/Prompt_Maestro_Leads_CS_Real_Estate.md` → **la base, entera**: rol, diagnóstico antes de redactar, cómo construir la respuesta, preguntas según el caso, situaciones que traban, seguimiento, voz, límites y formato.
- `Comunication-Strategy WPP/Estrategia_WhatsApp_Leads_CS_Real_Estate.docx` → las notas con páginas de cada libro, ejemplos A a K, tabla para ordenar la conversación y cómo medir la conversión. Se consulta solo si hace falta un ejemplo o medir.
- Este archivo → las reglas de Cris que mandan sobre el prompt y cómo convive con los otros contextos.

## 2. Reglas de Cris que mandan sobre el prompt

El prompt pone primero "las condiciones actuales que yo confirme". Estas ya están confirmadas:

- **Saludo:** nunca "¿cómo estás?". Usar "espero que andes bien", "¡éxito en tu día!" o "bendiciones", variando (regla del 2-oct-2026). "Bendiciones" es un saludo: no se usa para empujar una decisión, así que no choca con el límite de "religión" del prompt.
- **Sin firma** (Cris, 6-oct-2026: "La firma de WhatsApp sacala"). Ni nombre al pie ni matrícula: la presentación va en la primera línea ("Soy Cristian Stedtfeld, agente inmobiliario de Red Suma") cuando es un primer contacto.
- **Honorarios de venta confirmados** (carpeta para propietarios de Canva): 3% + IVA para el vendedor sobre el precio de venta, pactados por escrito antes de empezar; la producción de marketing está incluida. Para alquileres y búsquedas de compradores: "Dato a confirmar".
- **Primer mensaje a un dueño directo:** sin honorarios, sin exclusividad y sin "sin cargo" (decisión del 4-oct-2026). Se ofrece ayuda o compartir un análisis que ya esté hecho, caso por caso. Sin "lo charlamos 15 minutos" (Cris, 8-oct-2026): el cierre es una pregunta fácil sobre su venta, para que responda.
- **Datos:** solo verificados (avisos con link, CRM, números del script). Antes de citar un aviso de otro en un mensaje, comprobar que siga publicado.
- **Honorarios:** si preguntan y no está confirmado → "Dato a confirmar: honorarios" (igual que el prompt).
- Nada de jerga técnica ni palabras internas (MAN, FORD, etapa, lead) en los mensajes.

## 3. Formato de entrega

El del prompt: **Lectura del caso** (hasta 3 líneas) · **Mensaje sugerido** (una sola versión, lista para copiar) · **Próximo paso** (una línea). Si Cris dice "solo el mensaje", va solo el texto.

Largo: 30 a 90 palabras. Un primer mensaje de prospección con datos puede llegar a ~110 si los datos lo justifican. Una sola pregunta por mensaje.

## 4. Seguimiento

- Consulta entrante sin respuesta: la pauta del prompt (48–72 h, después ~1 semana, después pausa con un cierre sin reproche, como el ejemplo K).
- Prospección a dueños directos: un seguimiento a los 5–7 días con un aporte real (lo que ya pedía Dueño vende) y, si no responde, un cierre a la semana. Después, pausa. Si responde "no me interesa", no se lo vuelve a contactar.

## 5. Cómo convive con los otros contextos

- **Dueño vende:** los mensajes de primer contacto siguen ese contexto y además este (una pregunta, datos verificables, un solo objetivo).
- **ACM y pre-ACM:** el mensaje que acompaña el PDF y las respuestas a objeciones siguen este formato.
- **Búsqueda de compradores:** sin presuponer exclusividad (igual que el prompt).
