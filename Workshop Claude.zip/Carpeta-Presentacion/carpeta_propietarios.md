# Carpeta de presentación para propietarios (texto de Canva)

Copia del texto del diseño de Canva **"Carpeta presentación propietarios - AGENTE INMOBILIARIO"** (12 páginas), leída el 6-oct-2026. El diseño manda: si se edita en Canva, actualizar esta copia.
Editar: https://www.canva.com/d/V8C6PzrArJ30zsb · Ver: https://www.canva.com/d/NuX_oDcYWUBN05s

Encabezado de cada página: "CS." · AGENTE INMOBILIARIO. Pie (corregido el 6-oct-2026): "Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609" + "Los corredores públicos intermedian y concluyen todas las operaciones. Los agentes operan bajo el control y supervisión de un corredor público."

## Portada
CRISTIAN STEDTFELD · REAL ESTATE · CARPETA DE PRESENTACIÓN PARA PROPIETARIOS · +54 9 11 6695-1945 · cstedtfeld@redsuma.com.ar

## 01 · Trabajo solo con exclusividad.
Parece lógico pensar: "Si se la doy a cinco inmobiliarias, tengo cinco veces más chances". Pero suele pasar lo contrario...
- **Sin exclusividad:** múltiples publicaciones mediocres en portales · distintos precios y datos · por ende, llegan ofertas más bajas · nadie invierte realmente en tu propiedad. ¿Quién va a producir un buen video, fotos profesionales, pauta publicitaria y hacer un seguimiento serio si mañana la vende el otro?
- **Con exclusividad:** una publicación en cada portal por mí · estrategia previa para salir al mercado · plan de marketing a medida · mejor defensa del valor mediante negociaciones · un responsable comprometido.
- **Exclusividad no significa menos alcance.** Comparto tu propiedad en red con otros colegas profesionales, pero manteniendo: un solo precio, una sola estrategia, una sola cara visible, un único responsable.

## 02 · Mi propuesta
- **Análisis y planificación:** relevamiento completo de la propiedad · revisión inicial de la documentación disponible · análisis de sus pros y contras · definir el perfil del comprador · organización de cada etapa antes de lanzar · consejos para mejorar.
- **Plan de marketing a medida:** producción audiovisual profesional (fotos, videos, tours y planos con layout hechos por mi equipo) · pautas publicitarias con campañas segmentadas por Meta Ads, Google Ads y TikTok Ads.
- **Definir el precio:** según el interés en vender, entrego un informe con análisis completo de la zona, comparables en venta, comparables ya vendidos y sus tiempos de venta, y un valor sugerido por 20 días para salir con el precio correcto.
- **Publicación llamativa en portales:** la primera impresión hoy es digital: ahí se gana o se pierde la visita. Título atractivo y descripción pensada para el comprador ideal. Difusión en mi red de colegas profesionales. No espero a que nos encuentren, salgo a buscar un comprador.
- **Reportes con métricas reales:** vistas de la publicación, consultas, visitas y qué dice el mercado. Siempre sabés qué está pasando con tu operación. Si algo hay que ajustar, lo decidimos juntos y con datos.
- **Filtro de interesados:** pre-califico cada consulta. A tu propiedad entran visitas con intención de compra, no curiosos.
- **Documentación y autorización:** ordenamos toda la documentación necesaria para trabajar profesionalmente.
- **Asesoramiento en todo el proceso:** te asesoro y te acompaño en cada decisión, de la primera charla hasta el cierre de la operación.
- **Respaldo legal completo:** cada operación se instrumenta a través de corredor matriculado (Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609), cumpliendo la normativa vigente en CABA y Provincia de Buenos Aires.
- **No hago promesas mágicas:** no inflo tasaciones para trabajar con tu propiedad, ni prometo plazos que nadie puede garantizar. Prefiero la verdad incómoda hoy antes que hacerte perder meses y yo quedar como un mal profesional. Vos decidís siempre con información.
- Cierre: "Mi propuesta es tratar tu propiedad como un negocio a lanzar: con planificación previa, un marketing bien hecho, seguimiento y comunicación clara en equipo durante todo el proceso."

## 03 · Presencia en portales. / Ventajas de trabajar con nosotros.
(Presencia en portales: solo imágenes.)
- **Mayor alcance:** una inmobiliaria tradicional suele trabajar principalmente con su propio equipo y su cartera de compradores. Dentro de una red, la propiedad también puede compartirse con otros profesionales que ya acompañan búsquedas activas o que se especializan en distintas zonas. La colaboración amplía las posibilidades de encontrar comprador, manteniendo una misma estrategia de precio, presentación y negociación.
- **Consultas legales:** ante una situación jurídica o documental particular, contamos con un departamento legal para realizar consultas, anticipar posibles dificultades y orientar los próximos pasos.
- **Único contacto para vos:** vos seguís hablando conmigo durante todo el proceso. Yo te coordino las consultas y el trabajo con la red.
- Cierre: "Atención personal para vos, con una red de profesionales trabajando detrás."

## 04 · Preguntas frecuentes.
- **¿Por qué otra inmobiliaria me tasó un valor más alto?** Hay inmobiliarias que tasan alto a propósito, porque saben que el dueño firma exclusividad con el que le dice el número más lindo. Después la propiedad se clava seis meses, no la visita nadie, y ahí te empiezan a pedir que bajes el precio. Al final vendés más bajo que si hubieras salido bien de entrada y encima perdiste tiempo. Yo no te digo el número que querés escuchar, sino que te muestro de dónde sale el mío, dato por dato, y la decisión final es tuya. Pero si el precio que querés publicar queda muy lejos de lo que muestran los datos, necesitamos definir tu urgencia y acordar una estrategia concreta. Si querés vender dentro de un plazo determinado, no voy a recomendarte un valor que probablemente nos haga perder meses. Si no tenés apuro, podemos probar una salida más alta, pero con fechas de revisión definidas desde el principio. Sin ese límite, suelen llegar el desgaste, las sucesivas bajas de precio y una negociación peor.
- **¿Una reforma puede aumentar el valor de venta?** Depende. Algunas reformas responden más al gusto personal que al valor de mercado. Antes de gastar, vemos qué conviene mejorar y qué no. En general, conviene reparar desperfectos evidentes, solucionar filtraciones o humedad, reemplazar elementos rotos, mejorar la iluminación, ordenar, limpiar profundamente y reducir muebles u objetos personales. La propiedad debe verse cuidada, luminosa y fácil de recorrer.
- **¿Cuánto cuesta mi servicio?** Los honorarios son lo usual del mercado (3% + IVA para el vendedor sobre el precio de venta), pactados por escrito antes de empezar. La producción de marketing está incluida en mi trabajo.
- **¿Cuánto vale mi propiedad?** Cualquier número que te tire ahora, sin haberla visto y sin sentarme con los datos de la zona, sería chamuyo. Y justamente porque no quiero chamuyarte, lo hago así: la visito, relevo todo, te preparo un informe y con eso definimos juntos el valor. No te cobro nada y te llevás el informe aunque no trabajes conmigo.
- **¿Puedo vender y comprar a la vez?** Podemos planificar ambos procesos. Primero vemos si necesitás el dinero de la venta para comprar, cuándo tendrías que mudarte y qué alternativas tendrías si las fechas no coinciden. Todo se coordina con el corredor y los profesionales que intervengan.
- **¿Qué factores pueden retrasar la operación?** Falta de documentación, deudas, diferencias entre planos y estado actual, sucesiones pendientes, embargos, hipotecas o inhibiciones. También dificultades para coordinar a las partes, observaciones del escribano, tiempos del Registro de la Propiedad, una venta encadenada o cambios en las condiciones acordadas. Por eso conviene revisar la documentación antes de publicar.
- **¿Publicar más caro para "probar" puede perjudicar la venta?** Sí. Esa prueba no es gratis. Si el precio queda fuera de mercado, muchos compradores la descartan antes de visitarla. Cuando finalmente se corrige, la publicación ya perdió novedad y puede generar la sensación de que hay algún problema. Podemos contemplar un margen razonable de negociación, pero el precio inicial tiene que poder defenderse.

## 05 a 08 · ACM de muestra ("EJEMPLO · DATOS ILUSTRATIVOS")
Páginas del ACM (portada, reporte, comparables, más comparables y valor sugerido con los valores en "USD ––") con el aviso "DOCUMENTO DE MUESTRA. Las direcciones, precios y fotos son ilustrativos". Zona Martínez, radio 2 km, 7 comparables, rango USD 235.000–360.000. ID de ejemplo A-00000; la venta cerrada de muestra figura como "Mariano Moreno 3100 (Vicente López)".

## Contratapa
Logo Red Suma · General Justo José de Urquiza 405, Vicente López, Buenos Aires, Argentina (oficina) · leyenda legal y línea del corredor responsable.
