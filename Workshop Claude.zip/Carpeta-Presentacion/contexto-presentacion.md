# Contexto: presentación de servicios (carpeta y hoja)

Se lee cuando Cris pide algo de su presentación: la carpeta para propietarios, la hoja "Cómo trabajo.", cuándo mandar cada una o cambiar sus textos. Armado el 6-oct-2026 juntando la carpeta de Canva, la hoja nueva y lo que se habló en el chat "Respuesta cliente Claudia Torres" (5-oct-2026).

---

## 1. Piezas

| Pieza | Dónde está | Qué es |
|---|---|---|
| **Carpeta para propietarios** | Canva: "Carpeta presentación propietarios - AGENTE INMOBILIARIO", 12 págs. ([editar](https://www.canva.com/d/V8C6PzrArJ30zsb)). Texto copiado en `Carpeta-Presentacion/carpeta_propietarios.md` | La versión completa: exclusividad (01), propuesta en 10 puntos (02), portales y ventajas de la red (03), preguntas frecuentes con honorarios (04) y un ACM de muestra (05 a 08) |
| **Hoja "Cómo trabajo."** | `Carpeta-Presentacion/CS_Como_trabajo.pdf` · generador `Carpeta-Presentacion/generar_onepager.py` (textos en `TEXTOS`, usa `Diseno/plantilla_base.py`) | La versión corta, una A4 aprobada el 6-oct-2026: "Publicar no es vender.", método en 4 pasos, VOS / YO y botón "Escribime" |

## 2. Cuándo se usa cada una

- **Primer mensaje:** ninguna. Lo único que se busca es que conteste (chat de Claudia Torres).
- **Si no contesta en 48–72 h:** la hoja, en lugar de un recordatorio vacío. En el chat de Claudia se había propuesto la carpeta; la hoja es más liviana para ese momento.
- **Antes de la reunión:** la hoja por WhatsApp. La carpeta, si el propietario ya decidió vender y quiere el detalle.
- **En la reunión de captación:** la carpeta, impresa o en pantalla, junto con el ACM.
- **Propiedad publicada por varias inmobiliarias o por el dueño y otras:** la pág. 01 de la carpeta (exclusividad) explica justo ese problema. Va cuando el propietario ya respondió, nunca en el primer mensaje.
- **Referidos:** la hoja.
- **Con un pre-ACM:** no la hoja, porque la hoja 02 del pre-ACM ya trae VOS / YO.
- Si la carpeta está pensada para un tipo de propiedad o zona que no coincide con el cliente, revisarla antes de mandar.

## 3. Datos confirmados que salen de la carpeta

Sirven para WhatsApp, ACM y objeciones (ver también `Comunication-Strategy WPP/contexto-whatsapp.md`):
- **Trabaja solo con exclusividad.** Comparte en red con un solo precio, una sola estrategia, una sola cara visible y un único responsable.
- **Honorarios de venta:** 3% + IVA para el vendedor sobre el precio de venta, pactados por escrito antes de empezar. La producción de marketing está incluida.
- **Qué incluye:** relevamiento y revisión de documentación, perfil del comprador, fotos, video, tours y planos con layout (su equipo), pauta en Meta, Google y TikTok Ads, publicación en portales, difusión en la red, reportes con métricas, filtro de interesados, autorización y documentación, acompañamiento hasta el cierre, corredor responsable y consultas al departamento legal de la red.
- **Informe de valor:** análisis de la zona, comparables en venta y vendidos con tiempos, y "un valor sugerido por 20 días". La carpeta dice que no se cobra y que se lo lleva aunque no trabaje con Cris. En el primer mensaje igual no se ofrece "sin cargo" (decisión del 4-oct-2026).
- **Preguntas frecuentes** (pág. 04): tasación más alta de otro, reformas, cuánto cuesta, cuánto vale, vender y comprar a la vez, qué retrasa una operación y publicar caro para probar. Son la base para responder objeciones.

## 4. Correcciones hechas en la carpeta (6-oct-2026, guardadas en Canva con OK de Cris)

- **Teléfono** de la tapa: +54 9 11 6695-1945 (antes decía 6759-1512).
- **Pie legal** de las 9 páginas con pie, de la contratapa y de la línea "Respaldo legal" de "Mi propuesta": texto aprobado ("Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609"). Antes decía "CSI 6609".
- **ACM de muestra:** el ID real A-59439 pasó a A-00000, y "Doctor Mariano Moreno 3169" a "Mariano Moreno 3100".
- La dirección de la contratapa (General Justo José de Urquiza 405, Vicente López) es la de la oficina: queda como está.

## 5. Cambios

- **Hoja:** se cambian los textos en `TEXTOS` y se regenera (`python generar_onepager.py --pdf`). Si cambia el diseño, se muestra la vista previa antes de generar.
- **Carpeta:** se edita en Canva. Si Cris lo pide, se puede hacer desde acá con el conector de Canva, mostrando cada cambio antes.
