#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HOJA "CÓMO TRABAJO." (una A4) — Cristian Stedtfeld · Red Suma  (v1.0, aprobada por Cris el 6-oct-2026)
Cuándo se usa: Carpeta-Presentacion/contexto-presentacion.md
Usa Diseno/plantilla_base.py (header, pie, contacto con botón). Los bloques "método" y
"equipo" repiten las medidas de las tarjetas y del bloque VOS/YO del pre-ACM, con la escala del ACM.

USO  python generar_onepager.py            -> CS_Como_trabajo.html y vista previa (+ .pdf con --pdf)
"""
import os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, "..", "Diseno"))
import plantilla_base as B  # noqa: E402

TEXTOS = {
    "titulo": "Publicar no es vender.",
    "sub": "Vender es un trabajo. Así lo hago yo.",
    "pill": "Cómo trabajo",
    "frase": "No tomo todas las propiedades. Por eso vendo las que tomo.",
    "speech": ("Antes de ponerle precio, miro lo que <b>de verdad se vendió</b> en tu zona. Después la muestro como "
               "se merece y la pongo frente al comprador correcto. <b>No te voy a dar un número lindo para quedarme "
               "con tu propiedad. Te voy a dar uno que la venda.</b>"),
    "metodo_titulo": "Mi método",
    "pasos": [
        ("Precio con datos.", "Ventas reales cerradas de tu zona, no solo avisos publicados."),
        ("Presentación.", "Fotos, video y recorrido pensados para el comprador de tu propiedad."),
        ("Difusión.", "Portales, campañas en redes y la red de colegas de Red Suma."),
        ("Negociación.", "Filtro curiosos, coordino visitas y te acompaño hasta la escritura."),
    ],
    "rotulo": "Conmigo se trabaja en equipo",
    "vos": "Me dejás ver la propiedad y me das toda la información que necesite.",
    "yo": "Analizo y te digo la verdad, y si la tomo, invierto y trabajo hasta venderla.",
    "cierre_equipo": "Si no me dejás asesorarte, no puedo hacer mi trabajo. Y prefiero decírtelo antes que hacerte perder tiempo.",
    "remate": "¿Cuánto vale tu propiedad? Eso no sale de un formulario. Sale de verla.",
    "boton": "Escribime",  # corto, para que los datos de contacto entren en una línea
    "whatsapp_msg": "Hola Cristian, quiero vender mi propiedad. ¿Coordinamos una reunión?",
}

CSS_EXTRA = r"""
.hero1{margin-top:24px;background:#fff;border-radius:8px;border:1px solid #E4E4E4;padding:20px 24px 18px}
.hero1 .fr{font-family:'Goodtime',sans-serif;font-size:20px;line-height:24px;color:var(--ink);word-spacing:-.12em}
.hero1 .fr em{font-style:normal;color:var(--gold)}
.hero1 .par{margin-top:12px}
.pasos{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:14px}
.paso{background:var(--card);border-radius:5px;padding:13px 16px 14px}
.paso .nn{font-weight:700;font-size:10px;letter-spacing:.2em;color:var(--gold)}
.paso .hd{font-weight:700;font-size:16px;line-height:19px;color:var(--navy);margin-top:6px}
.paso .tx{font-size:11.3px;line-height:17px;color:var(--txt);margin-top:4px}
.team{margin-top:24px;background:#fff;border-radius:8px;border:1px solid #E4E4E4;padding:15px 20px 14px}
.team .vy{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:9px}
.team .vy>div{border-radius:5px;padding:10px 14px 11px}
.team .v{background:var(--card)}
.team .y{background:var(--navy)}
.team .vy span{display:block;font-weight:700;font-size:13px;letter-spacing:.16em;text-transform:uppercase;color:var(--gold)}
.team .y span{color:#FBF0D9}
.team .vy p{font-size:11.3px;line-height:16px;color:var(--txt);margin-top:3px}
.team .y p{color:#fff}
.team .ci{margin-top:10px;font-size:11.3px;line-height:16px;color:var(--ink);font-weight:700}
.remate{margin-top:22px;padding-left:12px;border-left:3.4px solid var(--gold2);font-weight:700;font-size:15px;line-height:20px;color:var(--ink)}
.cta{margin-top:22px}
"""

def construir(T=TEXTOS):
    a1, a2 = T["frase"].split(". ", 1)
    hero = (f'<div class="hero1"><div class="fr">{B.esc(a1)}.<br><em>{B.esc(a2)}</em></div>'
            f'<p class="par">{T["speech"]}</p></div>')
    pasos = "".join(f'<div class="paso"><div class="nn">{i:02d}</div><div class="hd">{B.esc(h)}</div>'
                    f'<div class="tx">{B.esc(t)}</div></div>' for i, (h, t) in enumerate(T["pasos"], 1))
    team = (f'<div class="team"><div class="lbl k">{B.esc(T["rotulo"])}</div>'
            f'<div class="vy"><div class="v"><span>Vos</span><p>{B.esc(T["vos"])}</p></div>'
            f'<div class="y"><span>Yo</span><p>{B.esc(T["yo"])}</p></div></div>'
            f'<div class="ci">{B.esc(T["cierre_equipo"])}</div></div>')
    cuerpo = (B.titulo(T["titulo"], T["sub"], pill=T["pill"]) + hero
              + B.seccion(T["metodo_titulo"], 28) + f'<div class="pasos">{pasos}</div>'
              + team + f'<div class="remate">{B.esc(T["remate"])}</div>'
              + B.contacto_boton(T["boton"], T["whatsapp_msg"]))
    return B.documento("Cristian Stedtfeld · Cómo trabajo", [cuerpo], css_extra=CSS_EXTRA)

def a_pdf_y_png(html_txt, base, pdf=False):
    html_path = os.path.join(AQUI, base + ".html")
    open(html_path, "w", encoding="utf-8").write(html_txt)
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 794, "height": 1123})
        pg.goto("file:///" + html_path.replace("\\", "/"))
        pg.wait_for_timeout(500)
        alto = pg.evaluate("Math.max(...[...document.querySelectorAll('.content')].map(e=>e.getBoundingClientRect().bottom))")
        pg.screenshot(path=os.path.join(AQUI, base + "_vista_previa.png"), full_page=True)
        if pdf:
            pg.pdf(path=os.path.join(AQUI, base + ".pdf"), format="A4", print_background=True,
                   prefer_css_page_size=True, margin={"top": "0", "right": "0", "bottom": "0", "left": "0"})
        b.close()
    return alto

if __name__ == "__main__":
    alto = a_pdf_y_png(construir(), "CS_Como_trabajo", pdf="--pdf" in sys.argv)
    print(f"contenido termina en y = {alto:.0f} px (el pie empieza en 1056 px)")
