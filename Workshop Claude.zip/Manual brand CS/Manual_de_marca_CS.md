# Manual de marca — Cristian Stedtfeld · Red Suma

Manual para cualquier pieza de Cris: reportes, presentaciones, carruseles de Instagram, flyers, fichas de propiedades, documentos y páginas web. Sale del diseño de sus reportes de ACM. **Regla de oro: si algo no está en este manual, no se usa.** Si una pieza necesita algo nuevo, se arma combinando lo que ya está acá, y se avisa qué se agregó.

---

## 0. Prompt corto (para pegar en las instrucciones de otro proyecto)

```
MARCA (obligatorio en toda pieza visual o documento para clientes):
- Colores: solo esta paleta. Negro #171717, texto #2B2B34, gris #6A6A6A,
  gris tarjeta #DBDBDB, fondo #ECECEC→#FFFFFF, blanco #FFFFFF,
  azul marino #253C64 (y #1F2A5C), dorado #988355 (acentos),
  dorado cálido #AD8A48 (separadores), dorado texto #8A6A2F sobre crema #FBF0D9,
  rojo #FF5F5F solo para variaciones negativas. Nada de verde ni otros colores.
- Tipografías: títulos Goodtime Grotesk (terminan en punto: "Comparables.");
  nombre "Cristian Stedtfeld" en Chillax Semibold; bajadas en mayúsculas
  espaciadas en Montserrat SemiBold; cuerpo y números en Arial/Helvetica;
  textos legales en Inter. Ninguna otra.
- Logos: "CS." (letras negras + punto dorado) arriba a la izquierda;
  "AGENTE INMOBILIARIO · RED SUMA" arriba a la derecha. No deformar ni recolorear.
- Estilo: fondos claros, mucho aire, tarjetas gris claro con esquinas redondeadas,
  dorado solo como acento (líneas, subtítulos, detalles), sin sombras fuertes ni
  degradés de color, íconos lineales finos.
- Voz: rioplatense, cercana y profesional, frases cortas, sin tecnicismos.
- Piezas para clientes: pie legal y matrícula (ver manual, sección 9).
Seguí el documento "Manual_de_marca_CS.md" para todo lo demás.
```

---

## 1. Identidad

| Elemento | Uso |
|---|---|
| **Logo personal "CS."** | "CS" en negro `#171717` (Goodtime Grotesk con trazo reforzado) + punto circular dorado `#988355`. Es la firma principal de Cris. |
| **Logo Red Suma** | "RED" en dorado `#988355`, "SUMA" y "CONEXIÓN INMOBILIARIA" en negro. Es el logo oficial: se usa tal cual, nunca se redibuja. |
| **Bajada** | `AGENTE INMOBILIARIO` en Montserrat SemiBold, mayúsculas, tracking 0,34 em, seguida de "·" y el logo Red Suma. |
| **Header estándar** | "CS." a la izquierda; bajada + logo Red Suma a la derecha, alineados arriba. |
| **Firma / nombre** | "Cristian Stedtfeld" en Chillax Semibold. Debajo, "Agente inmobiliario · Red Suma" en gris. |
| **Contacto** | WhatsApp +54 9 11 6695-1945 · cstedtfeld@redsuma.com.ar · csrealestate.com.ar |

**Reglas de logo**
- Margen libre alrededor del "CS." igual a la altura del punto dorado, como mínimo.
- Tamaño mínimo: "CS." de 24 px de alto en pantalla o 8 mm impreso. Logo Red Suma de 90 px o 25 mm de ancho.
- Sobre fondos oscuros o fotos: poné el logo sobre una franja o tarjeta clara. *Versión negativa pendiente de definir:* una propuesta es letras blancas con el punto dorado, a confirmar con Cris antes de usarla.
- Nunca: estirar, rotar, cambiar colores, agregar sombras o contornos, ni poner el logo sobre zonas de la foto con mucho detalle.
- "CS." aparece **una sola vez por página o pieza**. No se repite en bloques de contacto.

## 2. Paleta

| Rol | Color | HEX | Para qué |
|---|---|---|---|
| Base | Negro | `#171717` | Títulos, logo, encabezados |
| Base | Texto | `#2B2B34` | Cuerpo, direcciones, datos |
| Base | Gris | `#6A6A6A` | Etiquetas, notas, texto secundario |
| Base | Gris tarjeta | `#DBDBDB` | Fondos de tarjetas y cajas |
| Base | Fondo | degradé radial `#FFFFFF` al centro → `#ECECEC` en los bordes | Fondo de páginas y slides |
| Base | Blanco | `#FFFFFF` | Tarjetas destacadas, respiro |
| Principal | Azul marino | `#253C64` | Cifras clave, precios, botones, pills, barras |
| Principal | Azul profundo | `#1F2A5C` | Cifra protagonista (1 por pieza) |
| Acento | Dorado | `#988355` | Subtítulos, líneas finas, punto del logo, íconos, bordes |
| Acento | Dorado cálido | `#AD8A48` | Separadores verticales y marcadores |
| Acento | Dorado texto | `#8A6A2F` | Texto sobre crema |
| Acento | Crema | `#FBF0D9` | Fondo de badges o etiquetas ("Vendida", "Tu propiedad") |
| Acento | Dorado oscuro | `#7D6531` | Marcador destacado (por ejemplo, un pin de mapa) |
| Alerta | Rojo | `#FF5F5F` | **Solo** para variaciones negativas ("-4,1%") |

**Proporción aproximada por pieza:** 60% neutros claros, 25% negro y texto, 10% azul marino, 5% dorado.

**Prohibido:** verde, violeta, naranja, celeste y cualquier color fuera de la tabla. Tampoco van degradés de color (solo el gris radial del fondo), neón, colores saturados de stock o dorado en bloques grandes: el dorado es siempre un acento.

**Variaciones positivas:** van en azul marino con signo ("+3,2%"), nunca en verde.

## 3. Tipografía

| Rol | Fuente | Estilo | Notas |
|---|---|---|---|
| Títulos | **Goodtime Grotesk** | Regular (ya es gruesa) | Frase corta **terminada en punto**: "Valor sugerido.", "Tu próxima casa." Tracking normal y espacio entre palabras levemente reducido. |
| Nombre propio | **Chillax** | Semibold | Solo para "Cristian Stedtfeld" y firmas. |
| Bajadas y rótulos de marca | **Montserrat** | SemiBold, MAYÚSCULAS | Tracking amplio (0,3 em). Ej.: AGENTE INMOBILIARIO. |
| Cuerpo, datos, números | **Arial / Helvetica** | Regular y Bold | Bold para cifras, direcciones y valores. |
| Etiquetas | Arial Bold | MAYÚSCULAS, tracking 0,2 em, gris | "PRECIO DE PUBLICACIÓN", "COMPARABLES". |
| Encabezados de sección | Arial Bold | MAYÚSCULAS, tracking 0,12 em, negro | "POSICIONAMIENTO VS MERCADO". |
| Legales y pie | **Inter** | Regular, chica | Textos legales, créditos y fuentes. |

**Reemplazos** (solo si la fuente no está disponible): Goodtime → Montserrat ExtraBold · Chillax → Montserrat SemiBold · Arial → Liberation Sans o Helvetica · Inter → Arial.

**Licencias:**
- **Goodtime Grotesk** es "Personal Use". Para piezas comerciales hay que comprar la licencia (MadeType).
- **Chillax** (Fontshare), **Montserrat** e **Inter** (Google Fonts) son de uso libre.

**Máximo 3 fuentes visibles por pieza** (título + cuerpo + una de apoyo).

### Escalas por formato (guía)

| Formato | Título | Subtítulo | Cuerpo | Etiqueta | Cifra destacada | Márgenes |
|---|---|---|---|---|---|---|
| A4 vertical (794 px) | 31 px | 15 px bold dorado | 11–12 px | 9,4 px | 20–42 px | 65 px |
| Instagram post / carrusel 1080×1350 | 80–96 px | 36–40 px | 30–34 px | 22 px | 90–120 px | 90 px |
| Story / Reel 1080×1920 | 90–110 px | 40 px | 34 px | 24 px | 120–150 px | 90 px lateral · 250 px arriba y abajo (zonas seguras) |
| Presentación 16:9 (1920×1080) | 64–72 px | 32 px | 26–28 px | 18 px | 80–100 px | 110 px |
| Web | 40–56 px | 20 px | 16–18 px | 12 px | 36–48 px | contenido máx. 1200 px |

Interlineado: 1,5 en el cuerpo y 1,0–1,1 en los títulos.

## 4. Composición

- **Aire:** mucho espacio en blanco. Si dudás, sacá un elemento.
- **Jerarquía por pieza:** 1 título → 1 subtítulo dorado → contenido → cierre o llamado a la acción. Una sola cifra protagonista.
- **Alineación:** a la izquierda. Solo se centran piezas muy cortas, como una cita o una story de una línea.
- **Grilla:** 2 o 3 columnas con separación chica (6–16 px en A4, 24 px en redes).
- **Esquinas:** tarjetas con radio de 5–8 px; fotos con radio de 15 px (fotos de tarjeta) o 9–18 px (fotos grandes).
- **Sombras:** ninguna o casi imperceptible. **Bordes:** 1 px claro o 2 px dorado solo para destacar un aviso.

## 5. Componentes reutilizables

| Componente | Cómo es |
|---|---|
| **Título + subtítulo** | Título en Goodtime con punto. Debajo, una línea en dorado bold que explica la pieza. |
| **Caja KPI** | Fondo `#DBDBDB`, radio de 5 px, etiqueta gris en mayúsculas, valor en azul marino bold y nota gris chica opcional. |
| **Tarjeta de propiedad** | Foto a la izquierda con radio de 15 px. Luego: precio en azul marino, dirección en bold, meta en gris ("Venta · Casa"), datos ("3 amb · 2 dorm · 1 baño · 65 m²") y USD/m² en dorado. |
| **Badge** | Rectángulo crema `#FBF0D9` con texto `#8A6A2F` bold, radio de 6 px. Ej.: "Vendida jul-2026", "Nuevo ingreso", "Tu propiedad". |
| **Pill** | Cápsula azul marino con texto blanco en mayúsculas espaciadas. Máximo una por pieza. |
| **Regla dorada** | Línea de 2–3 px en `#988355`, corta (80 px) bajo títulos, o completa en el pie. |
| **Separador vertical** | 3–4 px en `#AD8A48`, entre columnas de cifras. |
| **Barra de rango** | Pista gris redondeada, relleno azul marino, marcador dorado cálido y etiquetas MÍNIMO / PROMEDIO / MÁXIMO. |
| **Botón o llamado a la acción** | Fondo azul marino, texto blanco bold, radio completo. Alternativa: borde dorado de 2 px con texto dorado. |
| **Íconos** | Lineales, trazo de 1,5–2 px, en gris `#6A6A6A` o dorado. Nunca a color ni rellenos. |
| **Fotos** | Reales, luminosas, bien encuadradas. Sin filtros de color ni stickers. Se permite un velo negro al 40–60% para poner texto encima. |
| **Gráficos** | Serie principal en azul marino, referencia en dorado, grilla gris clara, sin 3D ni colores extra. |

## 6. Aplicaciones

- **Reportes y documentos (A4):** header estándar, títulos con punto, pie legal con línea dorada y número de página en Goodtime a la derecha.
- **Instagram (carrusel):**
  - Portada: fondo claro o foto con velo, título Goodtime grande, subtítulo dorado y "CS." chico en una esquina.
  - Interiores: una idea por slide.
  - Último slide: firma en Chillax, datos de contacto y llamado a la acción en azul.
- **Stories y reels:** textos dentro de las zonas seguras, máximo 2 líneas de título, logo "CS." chico.
- **Presentaciones:** fondo claro con degradé radial, header estándar en cada slide y una cifra o idea por slide.
- **Fichas de propiedad y flyers:** foto protagonista, precio en azul marino, 3 a 5 datos clave, badge crema si corresponde, contacto al pie.
- **Web:** fondo blanco o gris muy claro, botones azul marino y enlaces en azul marino con subrayado dorado al pasar el mouse. En lo demás, seguí el estilo de csrealestate.com.ar.

## 7. Voz y textos

- Español rioplatense, con voseo: "tenés", "tu propiedad".
- Profesional, cercana y directa. Frases cortas, sin tecnicismos ni frases hechas de inmobiliaria.
- Títulos cortos que afirman y terminan en punto: "Tu propiedad vale más de lo que pensás."
- Cerrá siempre con un próximo paso claro: "Escribime y lo vemos juntos."
- Sin emojis en piezas formales (reportes, fichas, presentaciones). En redes, como máximo 1 o 2 y solo si suman.

## 8. Formatos de datos

- Dinero: **USD 262.429** (punto de miles, sin decimales). Pesos: **$ 1.250.000**.
- Porcentajes: coma decimal y signo, **+1,0% / -4,1%**.
- Superficie: **65 m²** (con superíndice).
- Fechas: **27 de septiembre de 2026**, o abreviadas **sep-2026**.
- Datos de propiedad: **3 amb · 2 dorm · 1 baño · 1 coch**, con singular y plural correctos.

## 9. Pie legal (obligatorio en piezas para clientes)

> Los corredores públicos intermedian y concluyen todas las operaciones. Los agentes operan bajo el control y supervisión de un corredor público.
> Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609

En redes, donde el espacio es chico, va al menos "Corredor resp.: VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609" en la descripción o en el último slide.

**Matrícula (Cris, 4-oct-2026).** Dato legal completo: VL REALTOR S.R.L. · Corredor responsable: Diego Enrique Mastrangelo — CUCICBA 7615 · CMCPSI 6609. Nunca va pegada al nombre de Cris como si fuera suya: siempre dice "Corredor responsable". Se usa así, según la pieza:
- **PDF y documentos A4** (pie legal, línea 2): "Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609".
- **Fotos, redes y piezas chicas**, donde no entra la línea entera: "Corredor resp.: VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609". En la web, el nombre del corredor puede ir dentro de un botón o desplegable, como ya lo tiene Cris.
- **Mensajes de WhatsApp:** sin firma y sin matrícula (Cris, 6-oct-2026).

## 10. Tokens para HTML / CSS

```css
:root{
  --negro:#171717; --texto:#2B2B34; --gris:#6A6A6A; --gris-tarjeta:#DBDBDB;
  --fondo:#ECECEC; --blanco:#FFFFFF;
  --azul:#253C64; --azul-profundo:#1F2A5C;
  --dorado:#988355; --dorado-calido:#AD8A48; --dorado-texto:#8A6A2F;
  --crema:#FBF0D9; --dorado-oscuro:#7D6531; --rojo:#FF5F5F;
  --f-titulo:'Goodtime Grotesk','Montserrat',sans-serif;
  --f-nombre:'Chillax','Montserrat',sans-serif;
  --f-rotulo:'Montserrat',sans-serif;
  --f-cuerpo:Arial,'Liberation Sans',Helvetica,sans-serif;
  --f-legal:'Inter',Arial,sans-serif;
}
body{background:radial-gradient(ellipse at 50% 50%,#FFFFFF 0%,#F7F7F7 45%,#ECECEC 100%);
     color:var(--texto);font-family:var(--f-cuerpo)}
```

## 11. Checklist antes de entregar

- [ ] Solo colores de la paleta. Nada de verde y rojo solo en negativos.
- [ ] Solo las tipografías del manual, con un máximo de 3 visibles.
- [ ] Títulos cortos terminados en punto.
- [ ] "CS." una sola vez y logo Red Suma sin alterar.
- [ ] Dorado solo como acento.
- [ ] Números con formato argentino (USD 262.429 · -4,1% · 65 m²).
- [ ] Datos de contacto correctos y pie legal si es para clientes.
- [ ] Nada cortado ni desbordado. Buen aire. Una sola cifra protagonista.
