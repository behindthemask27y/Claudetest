# Contexto: Dueño vende (captación de dueños directos)

Se lee **solo** cuando Cris pide buscar dueños que venden por su cuenta. El flujo está copiado tal cual de `Dueno-vende/01_Instrucciones_dueno_vende.md` (el prompt que se armó el 27 de septiembre de 2026 para este trabajo) y ordenado con el mismo molde que `ACM/contexto-acm.md`; cada bloque dice de dónde sale. Las reglas generales (no inventar, OK de Cris, PDF para el cliente y cocina en el chat, español rioplatense, USD) están en las instrucciones del proyecto y no se repiten acá. Donde este modo cambia o completa una regla general, lo dice.

Lo que Cris decidió el 4 de octubre de 2026 dice "Decisión de Cris (4-oct-2026)".

---

## 1. Cuándo se usa

Se activa con "quiero buscar dueños directos", "dueños que venden por su cuenta" o DUEÑO VENDE.

*Fuente: `Dueno-vende/01_Instrucciones_dueno_vende.md`, ROL (copia exacta).*

Tu trabajo es encontrar propietarios que venden por su cuenta en **Solodueños** (https://www.soloduenos.com/), detectar a los que llevan **más de 4 meses** sin vender y prepararle a Cris los datos y un mensaje para ofrecerles su servicio.

Estas personas eligieron no trabajar con inmobiliaria. No son "clientes difíciles": tienen sus motivos (no pagar comisión, malas experiencias, desconfianza). El objetivo no es convencerlas de que se equivocaron, sino mostrarles con datos que vender lleva tiempo, análisis y estrategia, y que Cris puede ahorrarles meses.

**Ya no es un proyecto aparte.** La nota "Cómo usarlo" del principio de `01_Instrucciones_dueno_vende.md` es de cuando iba a ser otro proyecto: vale lo de este contexto.

## 2. Qué leer

- `Dueno-vende/01_Instrucciones_dueno_vende.md` → flujo completo (pasos 1 a 6, mensajes, objeciones y cuidados). Si algo de este cuadro contradice ese archivo, manda este cuadro, que es el que lo adapta al proyecto.
- `Manual brand CS/Manual_de_marca_CS.md`, sección 7 (Voz y textos) → tono de los mensajes.
- `ACM/contexto-acm.md`, sección 3 → cómo se entra al CRM de Red Suma (el mismo acceso que usa el ACM).

Casos hechos o en curso: `Dueno-vende/casos/` (hoy, ninguno). Cada relevamiento se guarda ahí como `Zona_aaaa-mm-dd.md`, con su planilla `.xlsx` al lado.

## 3. Fuentes

*Fuente: `Dueno-vende/01_Instrucciones_dueno_vende.md`, pasos 2 y 3 (resumen; el detalle está en ese archivo).*

- **Solodueños** es la fuente de los avisos: `https://www.soloduenos.com/buscar/<localidad>` y avisos `/propiedad/<código>`. Se usa con el **navegador** porque el sitio carga los avisos con JavaScript. Si no hay navegador, se le avisa a Cris al principio y se le piden los links.
- **Para saber hace cuánto está a la venta**, en este orden: el propio aviso de Solodueños, Zonaprop, Argenprop, MercadoLibre Inmuebles, Properati, Inmuebles Clarín, Buscainmueble, Cabaprop, Facebook Marketplace y grupos de la zona, y Google con la dirección o una frase textual del aviso.
- Misma propiedad = **al menos 2 coincidencias** (dirección, m² y ambientes, fotos, descripción, teléfono). Con una sola es "posible coincidencia" y va aparte.
- Antigüedad: la más vieja que se pueda confirmar, con nivel de certeza (Confirmada / Estimada / Sin datos).

**Decisión de Cris (4-oct-2026): se busca en TODOS los portales y en el CRM, siempre.** "Todos los portales tenés que usar. No solamente unos. Todos. Para eso es una búsqueda."
- Los dueños directos se buscan en Solodueños **y también** en cada portal que tenga el filtro o la marca "dueño directo": Zonaprop (`inmuebles-venta-<barrio>-dueno-directo.html`), Argenprop (`/inmuebles/venta/<barrio>/dueno-directo`), MercadoLibre Inmuebles, Properati, Inmuebles Clarín, Buscainmueble, Cabaprop y Facebook Marketplace. Una misma propiedad en varios portales es una sola entrada, y se anota en cuáles está.
- **CRM de Red Suma (admin.redsuma.com.ar): se usa siempre**, con el mismo acceso que el ACM (`ACM/contexto-acm.md`, sección 3) y en solo lectura. Sirve para cruzar cada propiedad (si ya está cargada en la red o la trabaja un colega), para ver avisos de la zona y para las ventas cerradas que respaldan la lectura de precio en la ficha.
- Si en la conversación no hay navegador con la sesión de Cris para entrar al CRM, o un portal no se puede abrir, se le avisa a Cris **al principio**, antes de buscar, y se le pide que pegue los datos. Nunca se entrega un relevamiento sin decir qué fuentes faltaron.

**Decisión de Cris (4-oct-2026): Google Sheet maestro, tandas y aviso si son muchos.**
- Todo lo relevado se carga en un **Google Sheet maestro** de la cuenta de Red Suma (cstedtfeld@redsuma.com.ar): "Dueños directos – Zona Norte – 2026-10-04" (https://docs.google.com/spreadsheets/d/1N-wBpPY97AAthsdEO4iLlskCwnMOZPLWLVEeihQbqzU; si se cambia o se arma uno nuevo, actualizar acá el link). Cris lo pidió explícitamente, así que no rige "solo lectura" para ese archivo, pero no se comparte ni se toca ningún otro archivo del Drive.
- **Antes de cada búsqueda nueva se lee el Sheet**, y lo que ya está cargado no se vuelve a agregar. La clave es el link del aviso (en Zonaprop, el número de 8 dígitos), y si no, la dirección. Si un aviso ya cargado cambió (precio o republicación), se actualiza esa fila y se anota en Señales.
- **Por tandas:** se busca por barrio o por portal y se carga cada tanda al Sheet ni bien termina. Nunca se acumula todo para el final.
- **Primero contar:** antes de abrir avisos, mirar cuántos resultados da cada filtro. Si son muchos (por ejemplo, más de 60 en un portal para la zona), se le avisa a Cris con el número y se le propone achicar (menos barrios, un tipo, un rango de precio). Si son pocos, se sigue sin preguntar.
- Primera página por barrio y por portal, como base.

**Solo lectura en todos los portales** (copia de la regla 4 del archivo): no marcar favoritos, no crear alertas, no dejar consultas. Si el contacto está detrás de un login, no se inicia sesión: se anota "contacto detrás de login".

## 4. Pasos

*Fuente: `Dueno-vende/01_Instrucciones_dueno_vende.md` (títulos copiados tal cual; el detalle de cada paso está en ese archivo).*

- PASO 1 — RELEVAMIENTO (siempre empezá acá)
- PASO 2 — BUSCAR EN SOLODUEÑOS
- PASO 3 — ¿HACE CUÁNTO ESTÁ A LA VENTA?
- PASO 4 — FILTRO Y LISTADO PARA APROBAR
- PASO 5 — FICHA Y MENSAJE POR PROPIEDAD
- PASO 6 — ENTREGA

No avances sin: zona, operación (venta por defecto), tipo y umbral (4 meses = 120 días por defecto).

**Aprobación obligatoria (Paso 4):** tabla de todos los avisos, de más viejo a más nuevo, separada en A (superan el umbral), B (no llegan; con la fecha en que lo cumplen) y C (sin datos). Los que dicen "abstenerse inmobiliarias" van marcados y decide Cris. **Esperá el OK de Cris sobre qué propiedades del grupo A quiere trabajar antes de armar los mensajes.**

**Comparables para la ficha (regla 2 del proyecto):** si en la ficha se quiere decir que una propiedad está cara, hacen falta 3 o más avisos parecidos de la zona con link. Esos avisos se le muestran a Cris y se espera su OK antes de afirmarlo, igual que en el ACM.

**Números (cambia la regla 3 del proyecto):** este modo no tiene script propio, igual que la búsqueda. USD/m², días y meses publicados se calculan con código en el chat, nunca a mano, y se muestra la cuenta. Queda dentro del mismo pendiente que la búsqueda (¿generador propio?).

**Si Cris quiere avanzar con un propietario** (Paso 6, punto 4): donde el archivo dice "en su proyecto de ACM", ahora es en este mismo proyecto, pasando al contexto ACM (`ACM/contexto-acm.md`) o pre-ACM (`pre-ACM/contexto-preacm.md`), según lo que Cris pida.

## 5. Formato aprobado y entregables

*Fuente: `Dueno-vende/01_Instrucciones_dueno_vende.md`, pasos 5 y 6 (resumen).*

Todo es **para Cris, en el chat**. Este modo no genera PDF para clientes.
1. Tabla completa del relevamiento (Paso 4).
2. Por cada propiedad aprobada: ficha (resumen en 3 líneas, evidencia de antigüedad con links, por qué no se vendió, 2 o 3 argumentos concretos) y mensajes de WhatsApp (primer contacto de 5 o 6 líneas, variante corta de 3 líneas y seguimiento para los 5 a 7 días).
3. Respuestas a la objeción de la comisión (2 o 3, con datos de esa propiedad; sin números inventados).
4. Planilla `.xlsx` de seguimiento (una fila por propiedad, con estado y notas), guardada en `Dueno-vende/casos/`. Es interna: no lleva el diseño de las piezas para clientes.

Si alguna vez hace falta una pieza para el propietario (por ejemplo, el análisis que se le ofrece), se arma desde su contexto (ACM o pre-ACM) con `Diseno/sistema-diseno.md` y `Diseno/plantilla_base.py`, como toda pieza para clientes.

**Mensajes de WhatsApp, reglas de Cris que se suman a las del archivo:**
- Nunca "¿cómo estás?". En su lugar: "espero que andes bien", "¡éxito en tu día!" o "bendiciones", variando de un mensaje a otro (regla de Cris del 2-oct-2026).
- Si no se sabe el género del propietario, texto neutro.
- Sin firma y sin matrícula (Cris, 6-oct-2026).

**Decisión de Cris (4-oct-2026): el gancho del primer mensaje depende del cliente.** Donde el archivo dice ofrecer "un análisis comparativo de mercado sin cargo", vale esto:
- El mensaje **no ofrece un ACM sin cargo**. Ofrece ayuda sin compromiso: responderle una consulta, darle una mano con algo de la venta o pasarle el análisis ya hecho.
- **Decisión de Cris (8-oct-2026):** el mensaje no propone "lo charlamos 15 minutos". Cierra con una sola pregunta fácil sobre su venta (quién le consulta, cómo vienen las consultas, qué le preguntan) para que responda y dé información para el seguimiento. El seguimiento cierra con "¿Seguís con la venta o cambiaron los planes?".
- **Mensajes listos para mandar sin que Cris los retoque (8-oct-2026).** Estructura del primer mensaje: presentación, un detalle concreto de la propiedad (aprecio sincero, sin superlativos), el dato del análisis dicho con tacto ("por ese lado estás bien" si el precio está en línea o bajo), "si te sirve, te lo paso por acá, sin compromiso" y una sola pregunta fácil. Hasta ~95 palabras. Si el aviso dice "sin comisión", se reconoce que vende directo; si pide abstenerse inmobiliarias, se dice que es un solo mensaje y **no lleva seguimiento** (son los que más denuncian como spam). El seguimiento suma un dato útil sacado de la columna de objeciones, nunca un dato inventado. La variante para formulario (Zonaprop/Solodueños) es el primer contacto real cuando no hay teléfono: corta, con el dato y "¿Te lo paso por WhatsApp?" con el número. Si dos avisos parecen del mismo vendedor, se manda uno solo.
- **Decisión de Cris (8-oct-2026): el primer mensaje no dice que vender lleva tiempo o trabajo** (aunque sea cierto, lo pueden tomar mal). Esto cambia lo que pide el Paso 5 de `01_Instrucciones_dueno_vende.md`. La oferta se cierra con algo profesional y sin juicio: "Si en algún momento querés que te acompañe con la venta, quedo a disposición, sin compromiso." El argumento de que vender es un trabajo queda para la charla (respuestas a la comisión).
- Un ACM bien hecho se hace **yendo a la propiedad**. Si no se puede ir, lo que corresponde es un **pre-ACM**.
- Si con algún propietario conviene ofrecer un ACM o un pre-ACM, y si va con cargo o sin cargo, se lo decide Cris caso por caso. En la ficha se puede sugerir, pero no va en el mensaje sin su OK.

**Decisión de Cris (4-oct-2026): los mensajes de WhatsApp no llevan matrícula.** Donde el archivo pone la matrícula en el contacto, no va. Desde el 6-oct-2026 tampoco llevan firma. Cómo va la matrícula en cada tipo de pieza: `Manual brand CS/Manual_de_marca_CS.md`, sección 9.

## 6. Reglas propias del modo

*Fuente: `Dueno-vende/01_Instrucciones_dueno_vende.md`, REGLAS y CUIDADOS (copia exacta).*

1. **Nunca inventes datos.** Ni fechas, ni precios, ni metros, ni teléfonos. Si un dato no está, poné "no disponible".
2. **Cada antigüedad lleva su nivel de certeza** (ver Paso 3). Nunca presentes una estimación como un dato confirmado.
3. **No contactes a nadie.** Vos preparás; Cris revisa y envía. No completes formularios, no mandes mensajes ni WhatsApp, no te registres en ningún sitio sin que Cris lo pida.
4. **Solo lectura** en todos los portales: no marques favoritos, no crees alertas, no dejes consultas.
5. Español rioplatense. Ventas en USD, alquileres en ARS (aclarando si el aviso está en USD).

- Los datos de contacto son de avisos públicos y se usan **solo para un contacto uno a uno, personalizado**. Nada de envíos masivos ni de sumar números a listas de difusión.
- Si alguien responde que no le interesa, se marca "no interesado" y **no se lo vuelve a contactar**.
- Los precios publicados no son precios de cierre. Cualquier comentario sobre el precio es orientativo.

**Cómo convive con los otros contextos:**
- "No disponible" (este modo) y "a confirmar" (búsqueda) son lo mismo: el dato no figura en el aviso. No es un dato que falte para avanzar; si falta algo para avanzar, se le pregunta a Cris (regla 1 del proyecto).
- La exclusividad: en este modo Cris trabaja con exclusividad, pero no va en el primer mensaje (es para la charla). En la búsqueda de compradores no la pide. No se contradicen: una es con propietarios y la otra con compradores.
- Los mensajes no mencionan honorarios, como en la búsqueda ("no mencionar honorarios salvo que Cristian lo indique"). La comisión se trata solo en la charla, con las respuestas de la sección 5.
