# ID 60 · Depto 3 amb PB, Emilio Lamarca (sin altura), Villa del Parque — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, departamentos de 3 ambientes en Villa del Parque). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Duplicados entre portales sacados; también el propio aviso. Aviso: https://www.zonaprop.com.ar/propiedades/clasificado/veclappa-venta-3-amb-pb-villa-del-parque-a-nuevo!-59131495.html

**Sujeto:** USD 105.000 · 52 m² (52 cubiertos) · USD 2.019/m² · 2 dorm, 1 baño · 35 años, totalmente reciclado · planta baja, dormitorios a la calle · expensas $110.000 · apto crédito, “facilidad de pago” · 142 días publicado.

**Ojo:** no encontré el mismo depto publicado por una inmobiliaria ni en Argenprop (primera página).

## Números (calculados con código)
- 22 avisos: precio USD 81.500 a 229.000, mediana USD 143.950 (P25–P75: 119.750–168.750).
- USD/m² total (22 avisos con m² totales): mediana 1.953 (P25–P75: 1.726–2.154). El sujeto está a 2.019/m² (+3% contra la mediana).
- Parecidos en tamaño (39–65 m², 9 avisos): mediana USD 129.000 y **USD 2.048/m²**. El sujeto: 2.019/m², −1%.
- Los 3 más parecidos en tamaño: Helguera 2800 (52 m², USD 108.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-helguera-al-2000-3-amb.-al-fte-56766114.html); Av. Nazca 3100, piso 1 (47 m², USD 81.500, AP 18337208); Tinogasta 3000 (60 m², USD 145.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-en-villa-del-parque-60066940.html).
- 10 m² a la mediana de la zona ≈ USD 19.500.
- Dato de precio en el mensaje: No dice que está caro: 9 deptos de 39–65 m², mediana USD 129.000 y USD 2.048/m²; el sujeto está a USD 2.019/m² (−1%), en línea. El mensaje usa “tu precio está en línea…”.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Condarco 3102 | 125.000 | 94 | 59 | 1.330 | 1 | terraza, balcón | ZP 59703330 |
| Tinogasta 3200 | 100.000 | 70 | 59 | 1.429 | 1 | 2 patios, apto crédito | ZP 60245067 |
| Enrique de Vedia 2100, piso 3 | 189.000 | 124,41 | 75 | 1.519 | 1 | terraza propia 40 m², 7 años | AP 20458594 |
| Helguera 2775 | 105.000 | 62 | 59 | 1.694 | 1 | 2do piso, balcón | ZP 59984853 |
| Álvarez Jonte 2883 | 119.000 | 70 |  | 1.700 | 2 | 5to, semipiso | ZP 58838128 |
| Av. Nazca 3100, piso 1 | 81.500 | 47 | 47 | 1.734 | 1 | 60 años | AP 18337208 |
| Helguera 2700 (b) | 140.000 | 79 | 69 | 1.772 | 1 | dependencia, cochera | ZP 60210425 |
| Av. Nazca 2600, piso 1 | 120.000 | 65 | 65 | 1.846 | 1 | 45 años | AP 18339809 |
| Terrada 3036 | 210.000 | 113 | 68 | 1.858 | 2 | dúplex, terraza, cochera | ZP 58198889 |
| Tinogasta 3600 | 145.000 | 75 | 75 | 1.933 | 2 | cochera, 40 años | AP 19732469 |
| José Pedro Varela 3400 | 152.000 | 78 | 44 | 1.949 | 1 | 5to, terraza propia | ZP 59961042 |
| Helguera 2700 | 144.900 | 74 | 67 | 1.958 | 1 | piso alto, cochera, baulera | ZP 59479242 |
| Nogoyá 2700 | 130.000 | 65 | 65 | 2.000 | 1 | 2 cocheras, 35 años | AP 19648642 |
| Pedro Lozano 3200 | 155.000 | 76 | 60 | 2.039 | 1 | 4to piso, cochera | ZP 59043048 |
| Nogoyá 3100, piso 4 | 129.000 | 63 | 63 | 2.048 | 1 | baulera, toilette | AP 19942862 |
| Tinogasta 2800 | 229.000 | 111 | 77 | 2.063 | 2 | cochera, 10 años | AP 20525357 |
| Helguera 2800 | 108.000 | 52 | 47 | 2.077 | 1 | 2do piso, con renta | ZP 56766114 |
| San Blas 3000, piso 8 | 143.000 | 60 | 60 | 2.383 | 1 | 14 años | AP 20443333 |
| Tinogasta 3000 | 145.000 | 60 | 55 | 2.417 | 1 | cochera, contrafrente | ZP 60066940 |
| Nogoyá 3300 | 162.000 | 60 | 60 | 2.700 | 2 | 11 años | AP 19801907 |
| Nogoyá 2400 | 189.000 | 68 | 62 | 2.779 | 1 | cochera, baulera (también AP 20210119) | ZP 59854018 |
| Simbrón 3500 | 198.000 | 67 |  | 2.955 | 1 | al frente, 3 cocheras | ZP 59299198 |

**Excluidos:**
- Terrada 3100 · USD 158.000 · 89 m²: es un PH, no depto (ZP 60263084)
- Ricardo Gutiérrez 2927 · USD 171.500 · 113 m²: preventa (ZP 58398242)
- Pedro Lozano 3000 · USD 125.000 · 65 m²: a estrenar (entrega dic-2026) (ZP 59213789)
- Helguera 2700 / Nazarre 3000 / Nogoyá 3800 / Argerich 2300 / Campana 2900 / Melincué 3256: a estrenar
- Santo Tomé 3000 / Simbrón 3200 / Melincué 3200 / Arregui 2900 / Nogoyá 4000 (x3): a estrenar o edificio a estrenar (AP)
- Av. Estado de Israel 3000 · USD 225.000: fuera del barrio (Villa Crespo) (AP 18595060)
- Emprendimientos (Campana 3333, Campana 2929, Nogoyá 2590, Baigorria 3515, Arregui 2920): en pozo / precio 'desde'

## Pre-ACM
`ID60/PreACM_Emilio_Lamarca_PB.pdf` (2 hojas). Rango USD 81.500–229.000, mediana USD 143.950, 10 m² ≈ USD 20.000. Tarjeta 3: la de deptos (“En un mismo complejo existen precios distintos. El estado, el piso, la orientación y la cochera suman o restan.”).
Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu depto de Emilio Lamarca: 3 ambientes en planta baja, totalmente reciclado y apto crédito. Me tomé el trabajo de mirar los departamentos parecidos de Villa del Parque y armé un pequeño análisis: tu precio está en línea con los de tamaño similar, así que lo que puede estar frenando la venta es otra cosa, como la presentación o a quién le llega.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario):** Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los deptos parecidos a tu depto de Emilio Lamarca. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

Hola, ¡éxito en tu día! Te escribí hace unos días por el depto de Emilio Lamarca. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: con un precio en línea con los parecidos, el depto ya lleva casi 5 meses publicado. Cada mes que pasa es un mes más esperando, y pagando expensas. Mi trabajo es acortar ese tiempo con una presentación que le hable al comprador correcto."
- "Un 3 ambientes reciclado y apto crédito lo busca sobre todo quien compra su primera vivienda con crédito hipotecario. Esa operación tiene sus tiempos y sus papeles (tasación del banco, aprobación, escritura con el banco), y acompañarla bien evita que se caiga a mitad de camino."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
