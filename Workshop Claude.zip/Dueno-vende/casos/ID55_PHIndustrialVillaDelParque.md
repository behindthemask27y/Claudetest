# ID 55 · PH estilo industrial (dirección no publicada), Villa del Parque — comparables para pre-ACM

**6-oct-2026:** CRM consultado (ACM A-30087, PH cerrados en Villa del Parque). PDF nuevo con ventas cerradas, estrategia y mensaje en `pre-ACM/casos/Duenos_2026-10-06.md`.

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, PH de 4 ambientes en Villa del Parque). MercadoLibre bloqueado. **CRM sin consultar.** Duplicados entre portales sacados.

**Sujeto:** precio publicado "$ 320.000" (ver abajo) · 236 m² totales, 119 cubiertos · 4 amb, 3 dorm en suite · 3 baños + toilette · 2 cocheras · 50 años, totalmente remodelado (instalaciones nuevas, preinstalación de aire) · estilo industrial, planta baja sin escaleras, techos altos, cocina abierta con isla, patio de invierno y jardín · dueño directo, sin teléfono visible · más de un año publicado. Dirección no publicada ("Comuna 11").

**Ojo:**
- **Precio:** el aviso del dueño dice "$ 320.000" (pesos), que no tiene sentido para esta propiedad. El mismo PH figura como aviso de **inmobiliaria Yacoub** en Zonaprop (aviso 59843553) con los mismos 236/119 m², 4 amb, 3 baños, 2 cocheras, 50 años, patio y jardín, a **USD 320.000**. Casi seguro es un error de moneda en el aviso del dueño. Los números de abajo usan USD 320.000 como hipótesis.
- El aviso de Yacoub ubica el PH en **Álvarez Jonte, entre Pasaje Pernambuco y Bolivia**. En el mensaje no lo uso (el dueño no publicó la dirección). **Confirmar si ya lo trabaja Yacoub.**
- Con USD 320.000 queda en USD 1.356/m², en línea con los PH de 177 a 295 m² (mediana 1.382). No está caro por m²; el mensaje no habla de precio y usa el dato de la moneda.

## Números (calculados con código)
- 34 avisos usados: precio USD 89.000 a 420.000, mediana USD 197.500 (P25–P75: 161.000–219.750).
- USD/m² total (34 avisos con m²): mediana 1.544 (P25–P75: 1.295–1.713). Sujeto 1.356/m²: −12% contra la mediana.
- Parecidos, PH de 177 a 295 m² (±25%): 9 avisos, mediana USD 265.000 y **USD 1.382/m²**. El sujeto está a 1.356/m², 2% abajo. 4 de 9 piden menos por m² y 8 de 9 piden menos en total.
- Los 3 más parecidos: [Nazarre 3700](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-del-parque-59557396.html) (201 m², USD 279.900, 1.393/m², terraza, quincho); [Emilio Lamarca 3200](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-jardin-y-piscina-en-villa-del-60178454.html) (228 m², USD 315.000, 1.382/m², piscina, jardín); [Av. Nazca 2500](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-de-227-m-sup2--totales-3-dorm-pileta-56623318.html) (227 m², USD 315.000, 1.388/m², pileta, quincho).
- 10 m² a la mediana de la zona ≈ USD 15.400.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Elpidio González 3300 | 215.000 | 268 | 127 | 802 | 1 | patio, cochera | [AP 19828275](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19828275) |
| Ricardo Gutiérrez 2300 | 129.000 | 159 | 88 | 811 | 2 | estado regular | [AP 19714699](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19714699) |
| Llavallol 3369 | 220.000 | 240 | 210 | 917 | 2 | cochera, terraza | [ZP 60034540](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-villa-del-parque-llavallol-3369-y-j.-p.-varela-4-amb-60034540.html) |
| Terrero 3100 | 160.000 | 156 |  | 1.026 | 1 | entrada independiente, terraza | [ZP 59289163](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-entrada-independiente-terraza-59289163.html) |
| Cuenca 2500 | 198.000 | 176 | 77 | 1.125 | 2 | terraza, patio | [ZP 58419924](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-apto-credito!-4-ambientes-primer-piso.-c-banos-58419924.html) |
| Bolivia 2500 | 240.000 | 210 | 180 | 1.143 | 2 | dos plantas, cochera | [AP 18036245](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--18036245) |
| San Nicolás 1900 | 210.000 | 177 | 96 | 1.186 | 1 | terraza (Villa Santa Rita) | [ZP 60239571](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-terraza-en-villa-santa-rita-60239571.html) |
| Teodoro Vilardebó 2400 | 208.000 | 170 | 120 | 1.224 | 2 | patio, terraza (también ZP 60264076, 59446705 y AP 19017551) | [ZP 59042239](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-departamento-ph-en-venta-en-villa-del-parque-capital-59042239.html) |
| Teodoro Vilardebó 2900 | 175.000 | 136 | 76 | 1.287 | 1 | doble altura, sin expensas | [AP 19815501](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19815501) |
| Terrada 2800 PB | 185.000 | 140 | 80 | 1.321 | 2 | independiente, sin expensas | [AP 20192620](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--20192620) |
| Arregui 2800 | 180.000 | 132 | 132 | 1.364 | 2 | 1er piso, terraza | [AP 17343523](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--17343523) |
| Emilio Lamarca 3200 | 315.000 | 228 | 111 | 1.382 | 3 | piscina, jardín | [ZP 60178454](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-jardin-y-piscina-en-villa-del-60178454.html) |
| Av. Nazca 2500 | 315.000 | 227 |  | 1.388 | 2 | pileta, quincho | [ZP 56623318](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-de-227-m-sup2--totales-3-dorm-pileta-56623318.html) |
| Nazarre 3700 | 279.900 | 201 | 120 | 1.393 | 2 | terraza, quincho | [ZP 59557396](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-del-parque-59557396.html) |
| Pedro Lozano 3400 | 265.000 | 180 | 140 | 1.472 | 2 | cochera, terraza | [ZP 59190776](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-4-amb-con-cochera-patio-y-terraza-en-villa-del-59190776.html) |
| Alfredo Bufano 2760 | 219.000 | 148 | 91 | 1.480 | 2 | reciclado a nuevo, terraza | [ZP 59448525](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-en-villa-del-parque-en-planta-59448525.html) |
| Arregui 2800 1° | 130.000 | 85 | 85 | 1.529 | 2 | terraza | [AP 19546377](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19546377) |
| Argerich 2344 | 268.000 | 172 |  | 1.558 | 2 | reciclado, terraza | [ZP 59327646](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-villa-del-parque-venta-ph-4-ambientes-reciclado-2-59327646.html) |
| Emilio Lamarca 3300 | 89.000 | 55,71 | 55,71 | 1.598 | 1 |  | [AP 20420932](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--20420932) |
| Condarco 4500 | 420.000 | 261 | 210 | 1.609 | 2 | terraza propia | [ZP 60044436](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-en-villa-del-parque-con-terraza-propia-60044436.html) |
| Terrada 2800 | 115.000 | 69 | 69 | 1.667 | 1 | a refaccionar | [AP 19941133](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19941133) |
| Concordia 2400 | 197.000 | 117 |  | 1.684 | 2 | dúplex, cochera, patio | [ZP 60047740](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-de-casa-4-ambientes-en-villa-del-parque-60047740.html) |
| Beiro 3100 | 164.000 | 97 | 97 | 1.691 | 1 | terraza | [ZP 60092533](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-4-ambientes-venta-villa-del-parque-terraza-lumi-60092533.html) |
| Baigorria 3500 | 215.000 | 126 |  | 1.706 | 2 | patio, jardín, suite | [ZP 59397152](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-interesante-ph-de-4-ambientes-al-contrafrente-con-59397152.html) |
| Marcos Sastre 2700 | 123.000 | 72 | 63 | 1.708 | 1 | reciclado (también AP 19551896) | [ZP 59521469](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-del-parque-de-3-ambientes-y-playroom-59521469.html) |
| Bahía Blanca 2900 | 180.000 | 105 | 65 | 1.714 | 2 | terraza, patio | [ZP 59845759](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-luminoso-ph-de-4-ambientes-terraza-patio-59845759.html) |
| Nazarre 3722 | 220.000 | 127 | 127 | 1.732 | 2 | dúplex, cochera, patio | [ZP 59787898](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-villa-del-parque-ph-tipo-duplex-nazarre-3722-y-emilio-59787898.html) |
| Nazarre 2800 | 179.000 | 99 | 63 | 1.808 | 1 | terraza | [ZP 59536198](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-terraza-villa-del-parque-59536198.html) |
| Av. Nazca 3100 | 135.000 | 72 | 72 | 1.875 | 1 | terraza propia | [AP 16592228](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--16592228) |
| Teodoro Vilardebó 2651 | 142.000 | 75 |  | 1.893 | 1 | patio (también AP 19748532) | [ZP 59212268](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-villa-del-parque-ph-4-amb-2-dorm-escrit-patio-59212268.html) |
| Lascano 2300 | 210.000 | 110 |  | 1.909 | 2 | cochera (también AP 20076413) | [ZP 52276527](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-hermoso-ph-de-4-ambientes-escritorio-cochera!-52276527.html) |
| Laplace 3300 | 139.000 | 72 | 72 | 1.931 | 1 | al frente, terraza | [AP 19686256](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19686256) |
| Argerich 2700 | 179.000 | 90 | 90 | 1.989 | 2 | refaccionado | [AP 19262718](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-4-ambientes--19262718) |
| Bolivia 2300 | 210.000 | 90 |  | 2.333 | 1 | patio, balcón | [ZP 48907053](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-bolivia-2300-ph-de-4-ambientes-al-frente-en-dos-48907053.html) |

**Excluidos:** Álvarez Jonte e/ Pje. Pernambuco y Bolivia (ZP 59843553, Yacoub) (es la propiedad: mismos 236/119 m², 3 baños, 2 cocheras, 50 años, USD 320.000); Arregui 2300 (ZP 60061131 / AP 20445799) (a estrenar); Baigorria 3400 (ZP 58054464) (en construcción); Tinogasta 3600 (ZP 60244006) (a estrenar); Marcos Sastre 4000 (ZP 60271727 / AP 20468460) (figura a estrenar en AP); Alfredo R. Bufano 2600 (AP 17304196) (a estrenar); Baigorria 3000 piso 8 (AP 11956571) (dúplex en piso 8, no es PH); Teodoro Vilardebó (ZP 60264076, 59446705; AP 19017551) (duplicados de ZP 59042239); Lascano 2300 (AP 18946126) (duplicado).

## Pre-ACM
`ID55/PreACM_PH_Industrial_Villa_del_Parque.pdf` (2 hojas). Rango USD 89.000–420.000, mediana USD 197.500, 10 m² ≈ USD 15.000. Tarjeta 3: la alternativa para PH o casa ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción", porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
> Vi tu PH estilo industrial de Villa del Parque: 236 m², remodelado a nuevo, con jardín, patio de invierno y dos cocheras. Me tomé el trabajo de mirar los PH parecidos de la zona y armé un pequeño análisis para que veas en qué rango se están publicando los de tamaño similar. Un detalle que vi: en el aviso el precio figura en pesos ($ 320.000), y eso puede confundir a quien lo ve o dejarlo afuera de algunas búsquedas en dólares.
> Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
> ¿Te lo paso?
> 
> Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal):**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los PH parecidos a tu PH estilo industrial de Villa del Parque. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

> Hola, ¡éxito en tu día! Te escribí hace unos días por tu PH estilo industrial de Villa del Parque. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.
> 
> Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: el PH lleva más de un año publicado, y con el precio en pesos en el aviso, muchos compradores ni siquiera entienden cuánto pedís. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Un PH remodelado a nuevo, de 236 m² y con dos cocheras, lo busca alguien que quiere mudarse sin hacer obra y que valora el diseño. A ese comprador hay que mostrarle lo que se invirtió, y una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
