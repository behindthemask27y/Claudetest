# ID 37 · Casa Gramajo Gutiérrez 352, Villa Martelli (Vicente López) — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, casas 3 ambientes en Villa Martelli). MercadoLibre bloqueado. **CRM sin consultar.** Duplicados entre portales sacados. **Para casas se compara por m² cubiertos** (los totales mezclan lotes muy distintos). Excluidos: casas con galpón o local (Talcahuano 700, Florencio Varela 100, Bolivia 206, Agustín Álvarez 3900, Laprida 3600), Venezuela 4000 y Franklin 900 (sin m² cubiertos), Bolivia 200 (sin m²), EEUU 100 (multifamiliar a demoler), Las Heras 4500 (a terminar), J. S. Agüero 192 (es de Florida) y el propio aviso.

**Sujeto (Solodueños código 177493):** USD 305.000 · 3 amb · Barrio Parque Villa Martelli · 212 días publicado (estimado: el alta del 06/03/2026 es por migración del portal) · **pide abstenerse inmobiliarias**. El aviso de Solodueños no se pudo leer (carga por JavaScript).

**Ojo: la misma casa está publicada por una inmobiliaria**, Cristian Castiglia Propiedades: Zonaprop 57651802 y Argenprop 16078371 ("Gramajo Gutiérrez al 300", USD 305.000, 3 amb). De ese aviso: 240 m² totales, 110 cubiertos en tres plantas, 2 dorm (ampliable a 3), 2 baños, 2 cocheras, 30 años, tipo cabaña, patio de 200 m², parrilla, alarma y portón eléctrico. Confirmar si ya la trabaja una inmobiliaria antes de escribir. USD 2.773/m² cubierto (USD 1.271/m² total).

## Números (calculados con código)
- 22 avisos: precio USD 109.000 a 244.000, mediana USD 171.500 (P25–P75: 138.625–191.750). Ninguno llega a USD 305.000.
- USD/m² cubierto: mediana 1.674 (P25–P75: 1.433–1.945). Sujeto: 2.773, un 65,7% arriba.
- Parecidos por tamaño (83–138 m² cub, 13 avisos): mediana USD 179.000 y **USD 1.492/m² cub**. El sujeto está un 85,9% arriba. Por m² total (los 17 que lo traen): mediana USD 969/m², parecidos 180–300 m² (8): USD 902/m² contra 1.271 del sujeto.
- Los 3 más parecidos (108–119 m² cub, jardín o cochera): [Blanco Encalada 200](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-de-3-ambientes-con-jardin-y-quincho-en-villa-59856231.html) (108 m² cub / 245 tot, jardín y quincho, 16 años, USD 230.000), [Chile 500](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-de-3-ambientes-con-amplio-jardin-apto-credito!-60148582.html) (114 cub / 227 tot, 2 cocheras, jardín, USD 220.000), [Estanislao del Campo 100](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-3-ambientes-villa-martelli-cochera-60263901.html) (119 cub / 159 tot, cochera, terraza, USD 200.000).
- 10 m² cubiertos a la mediana de la zona ≈ USD 16.738.
- El mensaje **sí** dice "por debajo de tu precio" (sin "un poco", porque la diferencia es grande): los 3 parecidos con link y la mediana del subgrupo están por debajo, en precio y en USD/m². El barrio parque y los 2 baños explican parte de la diferencia, no toda.

## Tabla (m² cubiertos)

| Dirección | USD | m² cub | m² tot | USD/m² cub | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Cochabamba 300 | 109.000 | 110 |  | 991 | 2 | 2 cocheras, 40 años | [AP 12871390](https://www.argenprop.com/casa-en-venta-en-villa-martelli-3-ambientes--12871390) |
| Bolivia al 1000 | 169.000 | 165 | 250 | 1.024 | 1 | refaccionada, cochera | [ZP 59459483](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-3-ambientes-garage-patio-refaccionada-59459483.html) |
| Av. D. French 200 | 115.000 | 95 |  | 1.211 | 1 | con renta, a refaccionar, 50 años | [AP 5914013](https://www.argenprop.com/casa-en-venta-en-villa-martelli-3-ambientes--5914013) |
| Gral. Lavalle 4300 | 140.000 | 100 | 185 | 1.400 | 1 | cochera, terraza | [ZP 60154790](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-venta-v.-martelli-3-ambientes-cochera-terraza-60154790.html) |
| Adolfo Alsina 3200 | 180.000 | 128 | 182 | 1.406 | 1 | lote propio, 2 cocheras | [ZP 60154758](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-venta-lote-propio!-60154758.html) |
| Méjico 3200 | 173.000 | 120 | 200 | 1.442 | 1 | jardín, cochera, 50 años (también AP 15836048) | [ZP 51206538](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-4-ambientes-3-dorm.-jardin-cochera-vicente-51206538.html) |
| G. de Posadas al 600 | 130.000 | 90 | 102 | 1.444 | 1 | terraza 80 m², 25 años (también AP 8918060) | [ZP 57932045](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-3-amb-c-patio-galeria-y-terraza-villa-57932045.html) |
| Güemes al 3900 | 179.000 | 120 | 168 | 1.492 | 1 | refaccionada a nuevo (también AP 17638802) | [ZP 56513166](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-refaccionada-a-nuevo-3-ambientes-56513166.html) |
| Brasil al 400 | 225.000 | 150 | 225 | 1.500 | 1 | cochera, jardín, 60 años (también AP 20310528) | [ZP 59964095](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-3-ambientes-garage-y-jardin-59964095.html) |
| Estanislao del Campo al 100 (b) | 180.000 | 110 | 110 | 1.636 | 1 | cochera, terraza | [ZP 60230850](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-2-dorm.-venta-villa-martelli-60230850.html) |
| B. Franklin al 700 | 244.000 | 146 | 366 | 1.671 | 2 | pileta, jardín, 30 años (también AP 19714320) | [ZP 59210516](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-con-jardin-y-pileta-en-villa-martelli-59210516.html) |
| Estanislao del Campo 100 | 200.000 | 119.3 | 159 | 1.676 | 1 | cochera, terraza, patio | [ZP 60263901](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-3-ambientes-villa-martelli-cochera-60263901.html) |
| C. F. Melo 4372 | 170.000 | 100 | 250 | 1.700 | 1 | lote propio, galpón, jardín (también AP 20387818) | [ZP 59983909](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-lote-propio-3-ambientes-con-galpon-y-jardin-59983909.html) |
| Gral. Lavalle al 3700 | 132.000 | 75 | 160 | 1.760 | 1 | patio, terraza, parrilla | [ZP 58297513](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-en-venta-casa-3-amb.-patio-y-terraza.-v.-martelli-58297513.html) |
| Martín J. Haedo 3500 | 149.000 | 82 |  | 1.817 | 1 | 2 cocheras, 45 años | [AP 17671300](https://www.argenprop.com/casa-en-venta-en-villa-martelli-3-ambientes--17671300) |
| Alsina al 3900 | 134.500 | 72 | 160 | 1.868 | 1 | patio, terraza | [ZP 59843185](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-3-amb-c-patio-y-terraza-villa-martelli-59843185.html) |
| Chile al 500 | 220.000 | 114 | 227 | 1.930 | 1 | 2 cocheras, jardín, 30 años (también AP 20455063) | [ZP 60148582](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-de-3-ambientes-con-amplio-jardin-apto-credito!-60148582.html) |
| Lavalle al 3200 | 189.000 | 95 | 172 | 1.989 | 1 | 2 cocheras, terraza (también AP 18891031) | [ZP 58155873](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-de-4-ambientes-en-villa-martelli-58155873.html) |
| Blanco Encalada al 200 | 230.000 | 108 | 245 | 2.130 | 1 | quincho, jardín, 16 años (también AP 20215967) | [ZP 59856231](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-de-3-ambientes-con-jardin-y-quincho-en-villa-59856231.html) |
| T. M. Saubidet al 3900 | 165.000 | 69 | 117 | 2.391 | 1 | dúplex, patio, terraza (también AP 17075498) | [ZP 55708143](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-3-amb-tipo-duplex-en-venta-c-patio-y-terraza.-55708143.html) |
| Agustín Álvarez 3200 | 180.000 | 65 |  | 2.769 | 1 | 1 dorm, 5 cocheras, 40 años | [AP 15829924](https://www.argenprop.com/casa-en-venta-en-villa-martelli-3-ambientes--15829924) |
| Cipriano Lima 4100 | 160.000 | 50 |  | 3.200 | 1 | dúplex | [AP 20477634](https://www.argenprop.com/casa-en-venta-en-villa-martelli-3-ambientes--20477634) |

## Pre-ACM
`ID37/PreACM_Gramajo_Gutierrez_352.pdf` (2 hojas). Rango USD 109.000–244.000, mediana USD 171.500, 10 m² ≈ USD 17.000 (m² cubiertos). Lead "Las casas de 3 ambientes usadas se publican entre". Tarjeta 2 con "creo que son 110" (cubiertos). Tarjeta 3: la de casa ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción".

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo, y sé que preferís vender sin inmobiliaria. Pensalo así: la casa lleva más de seis meses publicada. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que muestre lo que la hace distinta: el barrio parque, el patio y la casa tipo cabaña."
- "El comprador de esta casa no compara solo precio por m²: busca tranquilidad, verde y barrio parque, y paga por eso si se lo muestran bien. Encontrar a ese comprador y negociar con él es un trabajo en sí. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
