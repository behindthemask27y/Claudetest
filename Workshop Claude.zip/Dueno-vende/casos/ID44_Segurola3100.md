# ID 44 · Casa Segurola 3100, Villa Devoto — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, casas de 4 ambientes en Villa Devoto). MercadoLibre bloqueado. **CRM sin consultar.** Duplicados entre portales sacados.

**Sujeto:** USD 450.000 · 154 m² · USD 2.922/m² · casa 4 amb · 212 días publicada (estimado: alta 06/03/2026 por migración del portal) · Solodueños código 181300 · la hoja dice que no pide abstenerse inmobiliarias.

**Ojo:**
- **Aviso no leído:** probé una vez en soloduenos.com y la página no devuelve los avisos (solo la portada). Todo lo del sujeto sale de la hoja: no sé si los 154 m² son cubiertos o totales, ni baños, cochera, lote o estado. **Antes de mandar el mensaje conviene abrir el aviso**: si la casa tiene lote grande, pileta o está a nuevo, la comparación cambia.
- Con los datos de la hoja, el precio queda muy arriba: 12 de las 13 casas de 116 a 192 m² piden menos (la única por encima es Habana 4800, tríplex con piscina y 3 cocheras, USD 515.000).
- No encontré Segurola 3100 en las primeras páginas de Zonaprop ni de Argenprop.
- La muestra general tiene casas muy grandes (hasta USD 1.400.000, 420 m² con piscina): por eso el rango del pre-ACM es tan amplio. La mediana y el subgrupo parecido son los números útiles.

## Números (calculados con código)
- 35 avisos usados: precio USD 205.000 a 1.400.000, mediana USD 315.000 (P25–P75: 254.500–485.000).
- USD/m² total (35 avisos con m²): mediana 1.588 (P25–P75: 1.133–2.290). Sujeto 2.922/m²: +84% contra la mediana.
- Parecidos, casas de 116 a 192 m² (±25%): 13 avisos, mediana USD 248.000 y **USD 1.588/m²**. El sujeto está a 2.922/m², 84% arriba. 12 de 13 piden menos por m² y 12 de 13 piden menos en total.
- Los 3 más parecidos: [Navarro 5200](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-4-ambientes-con-patio-y-terraza-villa-58858754.html) (162 m², USD 290.000, 1.790/m², reciclada, patio y terraza); [Emilio Lamarca 3500](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-lamarca-al-3500-garage-2-terrazas-2-bauleras-58340037.html) (150 m², USD 248.000, 1.653/m², garage, 2 terrazas (también AP 19017890)); [Av. General Paz 6800](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-4-ambientes-en-2-plantas-59150754.html) (170 m², USD 270.000, 1.588/m², 2 plantas, garage).
- 10 m² a la mediana de la zona ≈ USD 15.900.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Melincué 4600 | 260.000 | 339 |  | 767 | 3 | local al frente (también AP 20242689) | [ZP 59885795](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-cada-4-ambientes-venta-villa-devoto-59885795.html) |
| Nazarre 4300 | 340.000 | 387 |  | 879 | 1 | lote 10,46 x 25,72 | [ZP 59995354](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-de-4-ambientes-sobre-lote-de-10.46-x-25.72-con-59995354.html) |
| Av. Mosconi 4177 | 440.000 | 499 | 184 | 882 | 3 | a refaccionar, lote 50 m | [ZP 59929146](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa.-4-amb.-lote-50-m.-jardin.-a-refaccionar.-villa-59929146.html) |
| Bazurco 3500 | 249.000 | 279 | 149 | 892 | 2 | ampliable, cochera | [ZP 58679046](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-villa-devoto-58679046.html) |
| Navarro 4600 | 500.000 | 495 | 270 | 1.010 | 3 | dependencia, lote propio (también AP 20166577) | [ZP 59786752](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-4-ambientes-dependencia-lote-propio-en-59786752.html) |
| José León Cabezón 3900 | 260.000 | 249 |  | 1.044 | 2 | jardín (también AP 18417201) | [ZP 57526213](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-4-ambienets-con-jardin-en-venta-villa-devoto-57526213.html) |
| Bermúdez 3500 | 280.000 | 260 | 180 | 1.077 | 2 |  | [ZP 60203102](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-villa-devoto-60203102.html) |
| Pasaje Mónaco 4500 | 210.000 | 190 |  | 1.105 | 1 | reciclada, quincho, terraza | [ZP 59989210](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-cuatro-ambientes-villa-devoto-59989210.html) |
| Mercedes 4800 | 598.000 | 530 | 330 | 1.128 | 3 | piscina, 30 años | [AP 19911689](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--19911689) |
| Navarro 3200 | 215.000 | 189 | 113 | 1.138 | 2 | lote propio, terraza, cochera | [ZP 60303170](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-lote-propio-terraza-cochera-vlla-60303170.html) |
| Campana 5660 | 235.000 | 189 |  | 1.243 | 1 | 2 cocheras, patio, terraza | [ZP 53206549](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-4-amb-2-cocheras-patio-y-terraza-lote-8-66-x-53206549.html) |
| Simbrón 3800 | 205.000 | 160 |  | 1.281 | 1 |  | [ZP 55422526](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-venta-55422526.html) |
| Nogoyá 5200 | 295.000 | 225 | 140 | 1.311 | 4 | pileta, quincho | [ZP 60255856](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-4-ambientes-devoto-pileta-quincho-60255856.html) |
| Larsen 3300 | 267.000 | 192 |  | 1.391 | 2 | lote propio, cochera | [ZP 59533193](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-4-ambientes-villa-devoto-59533193.html) |
| Bahía Blanca 2800 | 219.900 | 150 |  | 1.466 | 1 | terraza, apto crédito | [ZP 60266613](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-villa-devoto-casa-4-amb-con-terraza-apto-credito-60266613.html) |
| Navarro 3200 (b) | 315.000 | 210 | 175 | 1.500 |  | inglesa, de época | [ZP 59159511](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-inglesa-con-detalles-de-epoca-y-espacios-59159511.html) |
| Simbrón 5000 | 305.000 | 198 | 150 | 1.540 | 3 | pileta, jardín, cochera | [ZP 59467403](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-4-ambientes-con-pileta-jardin-y-cochera-en-59467403.html) |
| Av. General Paz 6800 | 270.000 | 170 | 163 | 1.588 | 3 | 2 plantas, garage | [ZP 59150754](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-4-ambientes-en-2-plantas-59150754.html) |
| José Cubas 4200 | 498.000 | 313 | 100 | 1.591 | 2 | lote propio, a reformar | [AP 20253060](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--20253060) |
| Emilio Lamarca 3500 | 248.000 | 150 |  | 1.653 | 2 | garage, 2 terrazas (también AP 19017890) | [ZP 58340037](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-lamarca-al-3500-garage-2-terrazas-2-bauleras-58340037.html) |
| Emilio Lamarca 4300 | 330.000 | 190 | 190 | 1.737 | 2 | tríplex, 2 cocheras | [AP 19104773](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--19104773) |
| Navarro 5200 | 290.000 | 162 | 94 | 1.790 | 2 | reciclada, patio y terraza | [ZP 58858754](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-4-ambientes-con-patio-y-terraza-villa-58858754.html) |
| Emilio Lamarca 4900 | 218.000 | 119 | 119 | 1.832 | 2 | terraza, 30 años | [AP 20337954](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--20337954) |
| Calderón de la Barca 3700 | 430.000 | 200 | 150 | 2.150 | 2 | remodelada, cochera | [ZP 58056529](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-de-diseno-completamente-remodelada-con-cochera-58056529.html) |
| Bahía Blanca 3900 | 490.000 | 224 | 224 | 2.188 | 2 | patio, terraza, cochera | [AP 17560755](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--17560755) |
| Navarro 4400 | 450.000 | 200 | 200 | 2.250 | 2 | estilo español | [AP 16480549](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--16480549) |
| Simbrón 4400 | 480.000 | 206 | 150 | 2.330 | 1 | pileta climatizada, cochera | [ZP 57994820](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-de-4-ambientes-con-pileta-climatizada-y-cochera-57994820.html) |
| Av. S. M. del Carril 5100 | 470.000 | 200 | 200 | 2.350 | 4 | piscina, gran fondo | [AP 18893481](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--18893481) |
| Bahía Blanca 4900 | 390.000 | 160 |  | 2.438 | 3 | a nuevo, mini piscina (también AP 20167496) | [ZP 59790050](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-bahia-blanca-y-av-san-martin-t-a-nuevo-gran-59790050.html) |
| Tinogasta 4500 | 550.000 | 222 | 222 | 2.477 | 3 | 3 terrazas, jardín | [AP 20478210](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--20478210) |
| Asunción 3400 | 1.200.000 | 465 | 298 | 2.581 | 2 | pileta climatizada, 3 cocheras | [ZP 59735061](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-venta-casa-en-villa-devoto-59735061.html) |
| Bahía Blanca 2700 | 245.000 | 88 |  | 2.784 | 1 | dúplex, patio | [ZP 57057840](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-hermoso-duplex-de-4-ambientes-con-espacio-guardacoche-57057840.html) |
| Pareja 4600 | 840.000 | 290 | 290 | 2.897 | 4 | reciclada, piscina | [AP 19970332](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--19970332) |
| Habana 4800 | 515.000 | 170 | 170 | 3.029 | 4 | tríplex, piscina, 3 cocheras | [AP 19369884](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--19369884) |
| Pareja 4400 | 1.400.000 | 420 | 420 | 3.333 | 4 | piscina climatizada, 5 cocheras | [AP 19092728](https://www.argenprop.com/casa-en-venta-en-villa-devoto-4-ambientes--19092728) |

**Excluidos:** José Cubas 4100 (ZP 60073122) (a estrenar); José Cubas 4100 (ZP 57693623) (probable mismo inmueble a estrenar); Asunción 4900 (ZP 57590614 / AP 18464675) (dúplex a estrenar); Pedro Morán 3400 (AP 17928230) (a estrenar); Allende 3300 (ZP 59796014) (es PH tipo casa); Simbrón 5000 (ZP 59845386 / AP 20214773) (duplicado probable de ZP 59467403 (mismo precio y cuadra)); Mónaco 4500 (AP 17498810) (duplicado probable de Pasaje Mónaco 4500); Emilio Lamarca 3500 (AP 19017890) (duplicado de ZP 58340037).

## Pre-ACM
`ID44/PreACM_Segurola_3100.pdf` (2 hojas). Rango USD 205.000–1.400.000, mediana USD 315.000, 10 m² ≈ USD 16.000. Tarjeta 3: la alternativa para PH o casa ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción", porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
> Vi tu casa de Segurola al 3100, de 4 ambientes y 154 m². Me tomé el trabajo de mirar las casas parecidas de Villa Devoto y armé un pequeño análisis: las de tamaño similar se están publicando por debajo de tu precio.
> Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
> ¿Te lo paso?
> 
> Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal):**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de las casas parecidas a tu casa de Segurola al 3100. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

> Hola, ¡éxito en tu día! Te escribí hace unos días por la casa de Segurola. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.
> 
> Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: con lo que pedís hoy, la casa lleva unos siete meses publicada. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Una casa de 4 ambientes en Devoto la busca sobre todo una familia que viene de un depto o de un PH, y muchas veces depende de vender lo suyo o de un crédito. Saber filtrar eso y negociar bien suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
