# ID 30 · PH Argerich 5300, Villa Pueyrredón — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, PH 4 ambientes en Villa Pueyrredón). MercadoLibre bloqueado por robots desde acá. **CRM sin consultar.** Duplicados entre portales sacados; excluidos: a estrenar (Escobar 2900, Griveo 2600, Pareja 2157, Asunción 2277, Franco 2900) y el propio aviso.

**Sujeto:** USD 239.000 · 176 m² · USD 1.358/m² · 3 dorm, 1 baño · 50 años · sin expensas · apto 2 pisos más.

**Ojo:** el mismo PH figura también como aviso de **inmobiliaria** en Zonaprop (aviso 59263627) y en Argenprop (19768604, con 140 m² cubiertos). Confirmar si ya lo trabaja una inmobiliaria.

## Números (calculados con código)
- 33 avisos usados: precio USD 137.000 a 359.000, mediana USD 220.000 (P25–P75: 186.000–260.000).
- USD/m² total: mediana 1.479 (P25–P75: 1.198–1.754).
- PH grandes (160 m² o más, 15 avisos): mediana USD 250.000 y **USD 1.179/m²**. El sujeto está a 1.358/m², un 15% arriba.
- Los más parecidos (≈180 m², 1 baño, terraza): Artigas 4200 (180 m², USD 219.000), Av. Mosconi 2800 (185 m², sin expensas, USD 189.000), Griveo 2476 (210 m², terraza 140 m², USD 215.000).
- 10 m² a la mediana de la zona ≈ USD 14.800.

## Tabla

| Dirección | USD | m² tot | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|
| Campana 5200 | 230.000 | 260 | 885 | 2 | cochera | AP 19771005 |
| Av. Albarellos 2600 | 193.000 | 213 | 906 | 2 | a reciclar | ZP 59986716 |
| Caracas 5000 | 250.000 | 245 | 1.020 | 3 | reciclado | ZP 58912278 |
| Av. Mosconi 2800 | 189.000 | 185 | 1.022 | 1 | terraza 80 | ZP 57750578 |
| Griveo 2476 | 215.000 | 210 | 1.024 | 2 | terraza 140 | ZP 59346078 |
| Nueva York 2700 | 310.000 | 286 | 1.084 | 3 | cochera | ZP 59670340 |
| Condarco 4219 | 280.000 | 243 | 1.152 | 1 | 2 cocheras | ZP 59108277 |
| Ladines 2500 | 250.000 | 212 | 1.179 | 3 | dependencia | ZP 60108141 |
| Artigas 4200 | 219.000 | 180 | 1.217 | 1 | terraza | ZP 60143773 |
| Nueva York 2400 | 270.000 | 214 | 1.262 | 3 | quincho | ZP 60203192 |
| Bazurco 3000 | 188.000 | 148 | 1.270 | 2 | quincho | ZP 58460633 |
| Carlos A. López 2300 | 174.900 | 135 | 1.296 | 2 | terraza | ZP 60255244 |
| Ladines 3500 | 260.000 | 195 | 1.333 | 3 | garage | AP 5147557 |
| Av. Nazca 4400 | 260.000 | 188 | 1.383 | 2 | patio. terraza. s/exp | ZP 59569996 |
| Campana 5600 | 250.000 | 180 | 1.389 | 2 | cochera | ZP 59426245 |
| Terrada 4300 | 150.000 | 107 | 1.402 | 2 | a refaccionar | ZP 60025095 |
| Cuenca 5000 | 179.000 | 121 | 1.479 | 2 | terraza | ZP 60153598 |
| Gabriela Mistral 2100 | 184.900 | 123 | 1.503 | 2 |  | AP 18381065 |
| Basilio Hall 4100 | 187.000 | 119 | 1.571 | 2 | quincho | ZP 57130232 |
| Av. Gral. Paz 5600 | 220.000 | 139 | 1.583 | 3 | reservado | ZP 59512441 |
| Artigas 4600 | 230.000 | 144 | 1.597 | 2 | terraza | ZP 58553028 |
| Nueva York 2300 | 359.000 | 218 | 1.647 | 3 | 2 cocheras | ZP 59744712 |
| Obispo San Alberto 2900 | 137.000 | 81 | 1.691 | 2 |  | ZP 59690443 |
| Av. Nazca 4100 | 179.000 | 105 | 1.705 | 2 |  | AP 19957749 |
| Ladines 2700 | 240.000 | 139 | 1.727 | 2 |  | AP 20353761 |
| Franco 3100 | 228.000 | 128 | 1.781 | 1 | 7 años | AP 4329839 |
| Asunción 2300 | 185.000 | 101 | 1.832 | 2 | garage | AP 20439702 |
| Nueva York 2700 (b) | 357.000 | 186 | 1.919 | 2 | 2 cocheras | ZP 60233661 |
| Bolivia 4600 | 295.000 | 149 | 1.980 | 1 |  | ZP 60169717 |
| Pedro Morán 2300 | 220.000 | 110 | 2.000 | 2 | cochera (Agronomía) | ZP 59933632 |
| Basilio Hall 4120 | 259.990 | 122 | 2.131 | 1 | cochera | ZP 60012125 |
| Av. Nazca 4000 | 179.000 | 79 | 2.266 | 2 |  | AP 20005902 |
| Del Carril 2300 | 198.000 | 73 | 2.712 | 1 |  | AP 17777826 |

## Pre-ACM
`ID30/PreACM_Argerich_5300.pdf` (2 hojas). Rango USD 137.000–359.000, mediana USD 220.000, 10 m² ≈ USD 15.000. Tarjeta 3: la alternativa para PH ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción", porque los datos salen del aviso y no del dueño.

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: con lo que pedís hoy, el PH lleva más de un año publicado. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Este PH tiene dos compradores posibles, una familia o alguien que quiere construir, y la negociación con cada uno es distinta. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
