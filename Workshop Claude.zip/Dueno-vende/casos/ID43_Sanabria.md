# ID 43 · Piso Sanabria (sin altura), Villa Devoto — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, departamentos **usados** de 4 o más ambientes y 180 m² o más, Villa Devoto). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Excluidos: a estrenar / en construcción (Allende 4400, Solano López 3400, J. P. Varela 3800 —posible a estrenar—, Griveo 4100 PB, Navarro 3800), duplicados (Pedro Morán 3900 ZP 59972764, Segurola 3800 ZP 60255901, Sanabria 4390 de 330 m² ZP 49037749), Sanabria 4300 (USD 111), emprendimientos con precio “desde”, una casa y los de menos de 180 m².

**Sujeto:** **Sin precio** (“consultar precio”). 270 m² (270 cub.) · 3 dorm (suite con vestidor e hidromasaje) + “gran ambiente versátil”, 2 baños + toilette · 2 cocheras · 10 años · al frente · expensas $220.000 · palier propio, doble entrada, altillo con lavadero, calefacción y aire central. El aviso no da la altura ni la cantidad de ambientes.

**Ojo:** Revisé los pisos de Sanabria de la primera página: Sanabria 4390 (270 m², ZP 55171560) tiene 25 años, 4 dorm y 3 baños, y Sanabria 4300 (270 m², ZP 53289048, figura USD 111) tiene 4 dorm y 5 baños: no parecen el mismo. No lo encontré publicado por inmobiliaria.

## Números (calculados con código)
- 20 avisos: precio USD 345.000 a 1.200.000, mediana USD 627.500 (P25–P75: 474.750–752.500).
- USD/m² total: mediana 2.483 (P25–P75: 2.112–3.435).
- Parecidos en tamaño (±25%, 16 avisos): mediana USD 635.000 y **USD 2.430/m²**.
- Los más parecidos: Sanabria 4390 (270 m², misma calle, 2 cocheras, USD 750.000, [ZP 55171560](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-piso-5-ambientes-en-villa-devoto-residencial-55171560.html)), Pareja 4283 (284 m², 2 cocheras, USD 690.000, [ZP 59439020](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-v.-devoto-residencial-piso-6-ambientes-de-categoria-59439020.html)) y San Nicolás 4007 (284 m², 3 cocheras, USD 690.000, [ZP 57133942](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-villa-devoto-6-ambientes-con-57133942.html)).
- 10 m² a la mediana de la zona ≈ USD 24.830.
- Lectura para el mensaje: **Sin precio para comparar.** El mensaje ofrece el análisis para ver en qué rango se mueven los parecidos.

## Tabla

| Dirección | USD | m² tot | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|
| Segurola 3800 | 380.000 | 240 | 1.583 | 3 | dúplex, terraza, 3 cocheras (otro aviso igual: ZP 60255901) | [ZP 60153336](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-depto.-5-amb.-a-200-m-sup2--de-plaza-arenales-60153336.html) |
| Sanabria 2400 | 345.000 | 205 | 1.683 | 2 | 4 amb, dúplex, terraza | [ZP 60119191](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-duplex-villa-devoto-apto-credito-60119191.html) |
| San Nicolás 4700 | 390.000 | 224 | 1.741 | 2 | 4 amb, terraza propia, quincho, cochera | [ZP 58582770](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-4-ambientes-cochera-y-terraza-58582770.html) |
| Pedro Morán 3900 | 550.000 | 306 | 1.797 | 3 | 6 amb, dependencia, 2 cocheras (otro aviso igual: ZP 59972764) | [ZP 60100017](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-depto-6-ambientes-con-cochera-doble-mas-dependencia-60100017.html) |
| Segurola 4300 | 550.000 | 300 | 1.833 | 4 | 6 amb, esquina, 2 cocheras | [ZP 56345073](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-6-ambientes-2-cocheras-baulera-56345073.html) |
| Asunción 4500 | 580.000 | 263 | 2.205 | 4 | tríplex, terraza, 4 cocheras | [ZP 60264894](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-depto-5-amb-en-triplex-terraza-en-v-devoto-60264894.html) |
| Av. S. M. del Carril 4100 | 450.000 | 200 | 2.250 | 2 | 5 amb, dependencia, cochera | [ZP 59341884](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-dorm-dep-y-cochera-v.-devoto-cap-fed-59341884.html) |
| Mercedes 3993 | 480.000 | 211 | 2.275 | 3 | 5 amb, dependencia, cochera | [ZP 59130391](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-nuevo-valor!-venta-depto-5-amb-en-devoto-59130391.html) |
| Pareja 4283 | 690.000 | 284 | 2.430 | 4 | 6 amb, terraza, 2 cocheras | [ZP 59439020](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-v.-devoto-residencial-piso-6-ambientes-de-categoria-59439020.html) |
| San Nicolás 4007 | 690.000 | 284 | 2.430 | 4 | 6 amb, terraza, 3 cocheras | [ZP 57133942](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-villa-devoto-6-ambientes-con-57133942.html) |
| San Nicolás 3500 | 459.000 | 181 | 2.536 | 3 | 4 amb, terraza, parrilla, cochera | [ZP 60296500](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-4-amb-devoto-cochera-terraza-60296500.html) |
| Sanabria 4390 | 750.000 | 270 | 2.778 | 3 | 5 amb, 25 años, dependencia, 2 cocheras | [ZP 55171560](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-piso-5-ambientes-en-villa-devoto-residencial-55171560.html) |
| San Nicolás 3600 | 640.000 | 224 | 2.857 | 2 | 5 amb, suite, terraza, 2 cocheras | [ZP 58951429](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-5-ambientes-villa-devoto-58951429.html) |
| Pedro Morán 3550 | 630.000 | 208 | 3.029 | 4 | 5 amb, 4 cocheras, pileta | [ZP 55992233](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-de-5-ambientes-4-dorm.-4-cocheras-55992233.html) |
| José Luis Cantilo 4191 | 625.000 | 182 | 3.434 | 3 | 5 amb, impecable, 2 cocheras | [ZP 58587089](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-increible-piso-en-venta-en-impecable-estado.-58587089.html) |
| Pedro Morán 4500 | 980.000 | 285 | 3.439 | 4 | 4 amb, 1 año, 2 cocheras, jacuzzi | [AP 16905812](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-4-ambientes--16905812) |
| Mcal. F. Solano López 3800 (otro) | 760.000 | 196 | 3.878 | 4 | 5 amb, dependencia, 5 cocheras, pileta | [ZP 59720944](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-exclusivo-5-amb.-c-dependencia-5-cocheras-y-piscina-59720944.html) |
| Pareja 3981 | 990.000 | 235 | 4.213 | 4 | 6 amb, semipiso frente a plaza, pileta | [ZP 59600125](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-exclusivo-semipiso-6-ambientes-frente-a-plaza-arenales-59600125.html) |
| Joaquín V. González 3600 | 1.200.000 | 270 | 4.444 | 2 | 6 amb, dúplex, terraza, 2 cocheras | [ZP 58765303](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-villa-devoto-58765303.html) |
| Mcal. F. Solano López 3800 | 1.000.000 | 212 | 4.717 | 3 | 5 amb, 3 suites, 2 cocheras | [ZP 59158400](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-piso-completo-en-venta-3-dorm.-en-suite-212-59158400.html) |

## Pre-ACM
`ID43/PreACM_Sanabria.pdf` (2 hojas). Rango USD 345.000–1.200.000, mediana USD 627.500, 10 m² ≈ USD 25.000. Tarjeta 3 para deptos: “En un mismo edificio puede haber precios distintos. / El estado, el piso, la orientación y la cochera suman o restan.” Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes
**1er contacto**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu piso de Sanabria: 270 m² con palier propio, doble entrada y 2 cocheras. Como no tiene precio publicado, quien busca filtrando por precio puede no encontrarlo. Me tomé el trabajo de mirar los departamentos grandes usados de Villa Devoto y armé un pequeño análisis para que veas en qué rango se mueven los parecidos.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal)**

Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los pisos parecidos a tu piso de Sanabria. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento**

Hola, ¡éxito en tu día! Te escribí hace unos días por el piso de Sanabria. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- “Te entiendo. Pensalo así: el piso lleva más de un año publicado sin precio, y muchos compradores ni consultan cuando no ven un número. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto.”
- “Un piso de 270 m² con palier propio y dos cocheras lo busca una familia grande o alguien que deja una casa y no quiere resignar metros. Son pocos compradores y negocian fuerte. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla.”
- “No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo.”
