# ID 31 · PH Pasaje El Fogón 4389, Villa Pueyrredón — comparables para pre-ACM

**6-oct-2026:** CRM consultado (ACM A-24743, PH cerrados en Villa Pueyrredón). PDF nuevo con ventas cerradas, estrategia y mensaje en `pre-ACM/casos/Duenos_2026-10-06.md`.

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, PH 5 ambientes en Villa Pueyrredón). MercadoLibre bloqueado. **CRM sin consultar.** Excluidos: blocks y unidades múltiples (Vallejos 2200, Gabriela Mistral 2800, Caracas 4400, Terrada 5500, Cuenca 2 deptos, Larsen 2974), Vallejos 2900 (depto con ascensor), Condarco 5800 (duplicado de Condarco 5865 por otra inmobiliaria) y el propio aviso.

**Sujeto (aviso Zonaprop 56724625, dueño directo):** precio publicado **$ 250.000 (en pesos)** · 158 m² totales (92 cubiertos + 66 descubiertos) · 5 amb, 2 dorm, 1 baño · reciclado a nuevo (el aviso dice "a estrenar") · terraza con parrilla y solarium · plaza a una cuadra · sin teléfono visible · publicado hace más de un año. Si el precio fuera USD 250.000: USD 1.582/m² total.

**Precio:** el aviso muestra "$ 250.000". Para un PH de 158 m² solo tiene sentido en dólares: casi seguro es un error de moneda al cargarlo. No se corrige en la hoja (`precio_corregido` null) y se usa como dato para el contacto.

**¿Otro portal?** No aparece en los listados de PH 5 amb de Zonaprop ni de Argenprop. En Argenprop hay un "El Fogón 4300, piso 1" (AP 20472761, USD 100.000, 61 m², 3 amb), que es otra unidad.

## Números (calculados con código)
- 22 avisos: precio USD 129.000 a 348.000, mediana USD 239.500 (P25–P75: 202.500–277.500).
- USD/m² total: mediana 1.186 (P25–P75: 997–1.473). Sujeto (si fuera USD): 1.582, un 33,4% arriba.
- Parecidos por tamaño (119–198 m², 12 avisos): mediana USD 207.500 y **USD 1.300/m²**. El sujeto queda un 21,8% arriba, pero es reciclado a nuevo y varios parecidos no.
- Los 3 más parecidos (reciclados o con terraza y parrilla, 140–165 m²): [Condarco 5865](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-5-ambientes-reciclado-a-nuevo-con-patio-y-terraza-60207130.html) (153 m², reciclado, USD 210.000), [Bolivia 4300](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-en-villa-pueyrredon-60156158.html) (140 m², reciclado, terraza y parrilla, USD 249.000), [Vallejos 2800](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-de-departamento-ph-6-ambientes-en-villa-58929873.html) (165 m², quincho y parrilla, USD 240.000).
- 10 m² a la mediana de la zona ≈ USD 11.865.
- El mensaje **no** dice "por debajo de tu precio": el precio está publicado en pesos (no confirmado en USD) y el sujeto es reciclado. El gancho es el error de moneda y el año publicado.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Vallejos al 2100 | 239.000 | 347 |  | 689 | 1 | quincho, patio 144 m², sin expensas | [ZP 59835992](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-tipo-casa-5-amb-con-entrada-independient-patio-59835992.html) |
| Larsen 2700 | 290.000 | 330 |  | 879 | 2 | cochera, jardín, quincho (reservado) | [ZP 57881845](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-reservado-ph-5-ambientes-venta-villa-pueyrredon-57881845.html) |
| Av. Nazca al 5800 | 248.000 | 272 |  | 912 | 3 | 3 plantas, terrazas, parrilla | [ZP 60088915](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-amplio-ph-con-terrazas-y-parrilla-en-villa-pueyrredon-60088915.html) |
| Av. Mosconi 2600 | 285.000 | 308 |  | 925 | 1 | terraza 131 m², apto crédito | [ZP 59830297](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-apto-credito-ph-5-amb.-terraza-villa-59830297.html) |
| Terrada 5480 | 159.000 | 171 |  | 930 | 1 | azotea, patio, sin expensas | [ZP 60030100](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-en-villa-pueyrredon-60030100.html) |
| Gral. Artigas al 5400 | 262.000 | 257 |  | 1.019 | 2 | 6 amb, dos patios, jardín | [ZP 57284159](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-6-ambientes-2-patios-y-jardin-en-villa-pueyrredon-57284159.html) |
| F. Solano López al 2500 | 129.000 | 125 |  | 1.032 | 2 | a reciclar (Agronomía) | [ZP 58747967](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-pueyrredon-58747967.html) |
| Escobar al 2400 | 348.000 | 334 |  | 1.042 | 2 | reciclado, jardín, quincho | [ZP 57697673](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-5-ambientes-venta-villa-pueyrredon-57697673.html) |
| Argerich 5647 | 129.000 | 120 | 96 | 1.075 | 2 | a refaccionar | [ZP 58674443](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-frente-3-habitaciones-independiente-terraza-58674443.html) |
| Gabriela Mistral 2888 | 205.000 | 186 |  | 1.102 | 3 | terraza, parrilla, sin expensas | [ZP 57082424](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-casa-ph.-venta-5-amb.-v.-pueyrredon-terraza.-57082424.html) |
| Av. Mosconi 2200 | 210.000 | 187 | 110 | 1.123 | 2 | 3 plantas, apto crédito | [ZP 60124740](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-con-terraza-villa-pueyrredon-60124740.html) |
| Ladines al 3200 | 215.000 | 172 |  | 1.250 | 2 | 6 amb, pileta, parrilla | [ZP 59759905](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-pueyrredon-6-ambientes-con-patio-pileta-y-59759905.html) |
| Obispo San Alberto al 2700 | 305.000 | 230 | 163 | 1.326 | 3 | cochera, reciclado (también AP 12683105) | [ZP 51463454](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-casa-en-villa-pueyrredon-51463454.html) |
| Pareja 2300 | 255.000 | 189 |  | 1.349 | 3 | parrilla, patio (reservado) | [ZP 58260603](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-reservado-ph-5-ambientes-venta-villa-pueyrredon-58260603.html) |
| Condarco 5865 | 210.000 | 153 |  | 1.373 | 2 | reciclado, sin expensas (también ZP 56966604) | [ZP 60207130](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-5-ambientes-reciclado-a-nuevo-con-patio-y-terraza-60207130.html) |
| Bazurco 2300 | 325.000 | 231 |  | 1.407 | 4 | 7 amb, 3 plantas | [ZP 60194976](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-amplia-casa-en-altos-ph-entrada-indep.-muy-buena-60194976.html) |
| Vallejos al 2800 | 240.000 | 165 |  | 1.455 | 2 | quincho, parrilla, sin expensas | [ZP 58929873](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-de-departamento-ph-6-ambientes-en-villa-58929873.html) |
| Gral. Artigas 4818 | 185.000 | 121 |  | 1.529 | 1 | patio, terraza, apto crédito | [ZP 58796963](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-excelente-ubicacion-villa-pueyrredon-apto-58796963.html) |
| Vallejos 2400 | 195.000 | 120 |  | 1.625 | 2 | terraza, sin expensas | [ZP 60196903](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-s-expensas-villa-pueyrredon-60196903.html) |
| Bolivia al 4300 | 249.000 | 140 |  | 1.779 | 2 | reciclado, patio, terraza, parrilla | [ZP 60156158](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-en-villa-pueyrredon-60156158.html) |
| Obispo San Alberto 2300 | 218.000 | 92 | 92 | 2.370 | 1 | un piso, sin expensas, 70 años (solo m² cub) | [AP 13339810](https://www.argenprop.com/ph-en-venta-en-villa-pueyrredon-5-ambientes--13339810) |
| Escobar al 2837 | 275.000 | 112 |  | 2.455 | 2 | cochera, patio, reciclado | [ZP 59216745](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-5-ambientes-al-frente-con-cochera-2-banos-y-59216745.html) |

## Pre-ACM
`ID31/PreACM_Pasaje_El_Fogon_4389.pdf` (2 hojas). Rango USD 129.000–348.000, mediana USD 239.500, 10 m² ≈ USD 12.000. Tipología "PH de 5 ambientes" (sin "usados", porque el sujeto está reciclado a nuevo). Tarjeta 3: la de PH ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción".

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: el PH lleva más de un año publicado. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Este PH, reciclado y con terraza, le habla sobre todo a una pareja o a una familia chica que quiere algo listo para entrar. Ese comprador compara mucho y negocia cada detalle. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
