# ID 35 · Depto Terrada 4600, Villa Pueyrredón — comparables para pre-ACM

**6-oct-2026:** es el aviso de Solodueños 400d17fc (ahora carga: 25 años, baño + toilette, 1er piso frente, este, expensas $120.000, cochera, baulera, apto crédito). CRM consultado (ACM A-77850, deptos 3 amb cerrados en Villa Pueyrredón). PDF nuevo, estrategia y mensaje en `pre-ACM/casos/Duenos_2026-10-06.md`.

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, departamentos 3 ambientes en Villa Pueyrredón). MercadoLibre bloqueado. **CRM sin consultar.** Duplicados entre portales sacados. Excluidos: a estrenar y en pozo (Griveo 2900, Llavallol 4528, Condarco 4500, Av. Mosconi 2100 x3, José Cubas 2600, Terrada 4600, emprendimientos Mosconi 2151/2885/2500 y José Cubas 2100) y Av. Mosconi 2100 de Bonillo sin m².

**Sujeto (Solodueños código 187199):** USD 199.000 · 85 m² · 3 amb · dúplex con cochera · 214 días publicado · USD 2.341/m². **El aviso no se pudo leer** (la página de Solodueños carga por JavaScript): baños, expensas, antigüedad y teléfono sin confirmar; los datos salen de la hoja.

**Ojo:** en Argenprop hay un aviso de Bonillo en **Terrada 4600, a estrenar** (AP 17783351: semipiso 3 amb, 65 m² cub, 2 baños, cochera, terraza 70 m², USD 273.000). No es el mismo depto, pero puede ser el mismo edificio. Si el dúplex es a estrenar, los parecidos son los a estrenar (8 avisos, mediana USD 2.621/m²) y el sujeto quedaría por debajo.

## Números (calculados con código)
- 24 avisos usados: precio USD 89.000 a 259.000, mediana USD 148.950 (P25–P75: 138.375–193.500).
- USD/m² (total, o cubierto si el aviso no trae total): mediana 2.281 (P25–P75: 1.766–2.519). Sujeto: 2.341, un 2,6% arriba.
- Parecidos por tamaño (64–106 m², 13 avisos): mediana USD 170.000 y **USD 2.286/m²**. El sujeto está un 2,4% arriba: **en línea**.
- Los 3 más parecidos (dúplex o con cochera, 80–123 m²): [Helguera 4700](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-3-amb-en-duplex-c-terraza-quincho-v.-60136052.html) (dúplex, 105 m², terraza y quincho, USD 240.000), [Duarte 5000](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-duplex-3-ambientes-venta-villa-pueyrredon-59501363.html) (dúplex con cochera, 123 m² tot / 90 cub, USD 225.000), [Av. Mosconi 3100](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-venta-villa-pueyrredon-60068224.html) (80 m², cochera, USD 195.000).
- 10 m² a la mediana de la zona ≈ USD 22.813.
- El mensaje **no** dice "por debajo de tu precio": está en línea con los parecidos. El gancho es la presentación y a quién le llega.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Vallejos 2800 | 187.000 | 178 |  | 1.051 | 1 | PB, patio y terraza propia | [ZP 60185839](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-venta-villa-pueyrredon-60185839.html) |
| Av. Constituyentes 4300 | 89.900 | 56 | 56 | 1.605 | 1 | 50 años (solo m² cub) | [AP 20522567](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--20522567) |
| Cuenca 4495 | 144.900 | 90 | 70 | 1.610 | 1 | cochera, apto crédito | [ZP 59754170](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-con-cochera-apto-credito-59754170.html) |
| Llavallol 4400 | 102.000 | 60 | 60 | 1.700 | 1 | PB, patio, 50 años (solo m² cub) | [AP 19612970](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--19612970) |
| Cochrane 2600 | 98.900 | 58 | 58 | 1.705 | 1 | reciclado (solo m² cub) | [AP 19474791](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--19474791) |
| Gral. Artigas 4600 | 89.000 | 51 |  | 1.745 | 1 | contrafrente | [ZP 60074556](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-oportunidad!-luminoso-departamento-de-3-ambientes-con-60074556.html) |
| Duarte 5000 | 225.000 | 123 | 90 | 1.829 | 2 | dúplex, patio, cochera (también AP 19943398) | [ZP 59501363](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-duplex-3-ambientes-venta-villa-pueyrredon-59501363.html) |
| Gral. Artigas 4800 | 139.500 | 71 | 63 | 1.965 | 1 | reciclado, patio, 50 años | [AP 19210790](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--19210790) |
| Carlos A. López 2800 | 138.000 | 65 | 65 | 2.123 | 1 | piso 9, 20 años (solo m² cub) | [AP 8279544](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--8279544) |
| J. L. Cabezón 2600 | 170.000 | 79 | 79 | 2.152 | 2 | cochera, 45 años (solo m² cub) | [AP 16995657](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--16995657) |
| Gabriela Mistral 2200 | 160.000 | 74 | 56.09 | 2.162 | 2 | balcón aterrazado, 16 años | [AP 20427251](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--20427251) |
| Pje. J. Castellanos 4800 | 148.000 | 65 |  | 2.277 | 2 | cochera, al frente | [ZP 59457159](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-venta-en-villa-pueyrredon-59457159.html) |
| Helguera 4700 | 240.000 | 105 | 90 | 2.286 | 1 | dúplex, terraza, quincho | [ZP 60136052](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-3-amb-en-duplex-c-terraza-quincho-v.-60136052.html) |
| Terrada al 5200 | 148.000 | 64 |  | 2.312 | 1 | al frente, 3er piso | [ZP 60161714](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-terrada-al-5200-60161714.html) |
| Av. Mosconi 3100 | 195.000 | 80 | 70 | 2.438 | 2 | cochera, 20 años (también AP 20397151) | [ZP 60068224](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-venta-villa-pueyrredon-60068224.html) |
| Pareja 3200 | 148.000 | 60 | 57 | 2.467 | 1 | remodelado (también ZP 59972916) | [ZP 59923699](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-3-ambientes-con-balcon-en-villa-59923699.html) |
| Av. Del Carril 2500 (b) | 119.000 | 48 | 48 | 2.479 | 1 | 15 años (solo m² cub) | [AP 19478687](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--19478687) |
| Gabriela Mistral 2700 | 149.900 | 60 |  | 2.498 | 1 | balcón al frente | [ZP 57830731](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-3-ambientes-2-banos-balcon-al-frente-villa-57830731.html) |
| Carlos A. López 2400 | 148.000 | 58.6 | 52 | 2.526 | 1 | contrafrente (también AP 20456880) | [ZP 60150612](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-venta-villa-pueyrredon-60150612.html) |
| Av. Del Carril 2500 | 160.000 | 62 | 58 | 2.581 | 1 | piscina (también AP 19989428) | [ZP 59569788](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-venta-villa-pueyrredon-59569788.html) |
| Bazurco 2900 | 189.000 | 73 | 66 | 2.589 | 2 | cochera, piscina | [ZP 58680986](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-3-ambientes-venta-villa-urquiza-cochera-baulera-58680986.html) |
| Vallejos 2600 | 228.000 | 79 | 72 | 2.886 | 1 | piso 7 al frente | [ZP 59454165](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-vta-departamento-3-ambientes-al-frente-villa-59454165.html) |
| Vallejos 3100 | 259.000 | 80 | 80 | 3.238 | 1 | 2 cocheras, 3 años (solo m² cub) | [AP 19235349](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--19235349) |
| Av. Mosconi 3100 p.11 | 230.000 | 70 | 70 | 3.286 | 2 | semipiso, cochera, 15 años (solo m² cub) | [AP 19092725](https://www.argenprop.com/departamento-en-venta-en-villa-pueyrredon-3-ambientes--19092725) |

## Pre-ACM
`ID35/PreACM_Terrada_4600.pdf` (2 hojas). Rango USD 89.000–259.000, mediana USD 148.950, 10 m² ≈ USD 23.000. Tarjeta 3: la de deptos del generador ("En un mismo complejo existen precios distintos. El estado, el piso, la orientación y la cochera suman o restan."). Sin "Según tu descripción".

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: el depto lleva unos siete meses publicado y el precio está en línea con los parecidos, así que lo que falta no es bajarlo: es que le llegue a la gente correcta y se muestre bien. Ese es mi trabajo."
- "Un dúplex de 3 ambientes con cochera le interesa sobre todo a una pareja o familia que quiere más espacio sin irse a una casa. Muchas veces ese comprador depende de un crédito o de vender lo suyo, y coordinar esos tiempos es parte de la negociación. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
