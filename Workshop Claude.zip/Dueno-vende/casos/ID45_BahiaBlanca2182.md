# ID 45 · Monoambiente Bahía Blanca 2182, Villa Devoto — comparables para pre-ACM

**6-oct-2026:** CRM consultado (ACM A-54862, monoambientes cerrados en Villa Devoto). PDF nuevo con ventas cerradas, estrategia y mensaje en `pre-ACM/casos/Duenos_2026-10-06.md`.

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, monoambientes **usados**, Villa Devoto). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Excluidos: a estrenar / pozo / en construcción (Mosconi 3300, Bermúdez 3100, G. Mistral 3300 y 3400, Beiró 3402/3657, J. Cubas 3362, Lastra 4200 Milaires, San Nicolás 5200, Varela 3800, JV González 4800, Sanabria 2745, Griveo 4100, Pedro Morán 3300, Calderón de la Barca 3035, Chivilcoy 3300, Vallejos 3300, Marcos Sastre 4200, San Martín 7200 piso 9), un 4 ambientes mal clasificado (Allende 3800) y el propio depto en Argenprop.

**Sujeto:** USD 83.900 · 35 m² totales (33 cub.) · USD 2.397/m² · 1 baño · 8 años · 3er piso al frente, este · expensas $160.000 · balcón con deck, edificio con SUM y parrilla.

**Ojo:** **El mismo depto está publicado por una inmobiliaria**: Argenprop [19772671](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--19772671), Estilo Inmobiliario, “Bahía Blanca 2200 piso 3”, mismo precio (USD 83.900), semipiso al frente, este, 10 años, 37 m². Confirmar antes de contactar si ya lo trabaja esa inmobiliaria.

## Números (calculados con código)
- 16 avisos: precio USD 68.000 a 125.000, mediana USD 80.500 (P25–P75: 75.000–96.125).
- USD/m² total: mediana 2.317 (P25–P75: 2.028–2.508).
- Parecidos en tamaño (±25%, 14 avisos): mediana USD 78.000 y **USD 2.317/m²**. El sujeto está a 2.397/m², un 3,5% arriba.
- Los de edad parecida (7 a 11 años, 7 avisos): mediana USD 75.000 y USD 2.265/m² (el sujeto está 6% arriba por m² y 12% arriba en precio). Los más parecidos: Santo Tomé 4000 (35 m², 8 años, USD 68.000, [AP 19578675](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--19578675)), Av. San Martín 7200 (31 m², 7 años, USD 75.000, [AP 20505615](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20505615)) y Sanabria 2600 (34 m², 10 años, al frente con balcón, USD 75.000, [AP 20473666](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20473666)).
- 10 m² a la mediana de la zona ≈ USD 23.170.
- Lectura para el mensaje: **Un poco arriba**: los parecidos en tamaño (14) tienen mediana USD 78.000 y USD 2.317/m² (sujeto +3,5% por m², +8% en precio); los de edad parecida, USD 75.000 (+12%). Con 7+ comparables con link que lo sostienen, el mensaje dice “un poco por debajo de tu precio”.

## Tabla

| Dirección | USD | m² tot | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|
| Simbrón 3900 | 72.000 | 42 | 1.714 | 1 | 48 años, PB, patio | [AP 20159948](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20159948) |
| Sanabria 2700 | 79.000 | 42 | 1.881 | 1 | espacioso, apto crédito | [ZP 60145745](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-monoambiente-en-villa-devoto-muy-espacioso-60145745.html) |
| Santo Tomé 4000 | 68.000 | 35 | 1.943 | 1 | 8 años, SUM, terraza con parrilla | [AP 19578675](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--19578675) |
| Av. San Martín 7100 | 70.000 | 35 | 2.000 | 1 | 10 años, contrafrente, patio | [AP 20584008](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20584008) |
| Av. San Martín 6300 | 110.000 | 54 | 2.037 | 1 | balcón aterrazado, amenities | [ZP 60118738](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-monoambiente-con-balcon-aterrazado-en-60118738.html) |
| Sanabria 2600 | 75.000 | 34 | 2.206 | 1 | 10 años, frente, balcón, divisible | [AP 20473666](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20473666) |
| Av. Gral. Mosconi 3400 | 77.000 | 34 | 2.265 | 1 | 11 años, divisible, balcón | [AP 20489426](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20489426) |
| Lavallol 4500 | 75.000 | 33 | 2.273 | 1 | 10 años, contrafrente, balcón | [AP 20472669](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20472669) |
| Av. Francisco Beiró 5023 | 85.000 | 36 | 2.361 | 1 | divisible, balcón, con renta | [ZP 59360472](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-dpto-1-amb-divisible-con-balcon-zona-shopping-59360472.html) |
| Av. San Martín 7200 | 75.000 | 31 | 2.419 | 1 | 7 años, balcón, piso 7 | [AP 20505615](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20505615) |
| Pareja 3398 | 95.000 | 39 | 2.436 | 1 | balcón aterrazado, cochera, amenities | [ZP 58798841](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-monoambiente-en-villa-devoto-con-cochera-58798841.html) |
| Bermúdez 3000 | 82.000 | 33 | 2.485 | 1 | 20 años, frente, 3er piso | [AP 18959150](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--18959150) |
| Av. Gral. Mosconi 4300 | 85.000 | 33 | 2.576 | 1 | balcón, cochera, bajas expensas | [ZP 60143783](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-vta-depto-mono-plaza-arenales-balcon-coch-baja-exp-60143783.html) |
| Simbrón 4200 | 125.000 | 48 | 2.604 | 1 | al frente, balcón | [ZP 58075661](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-de-monoambiente-en-villa-devoto-58075661.html) |
| Carlos A. López 3600 | 99.500 | 34 | 2.926 | 1 | 11 años, cochera, frente, balcón | [AP 20250596](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-1-ambiente--20250596) |
| Av. Francisco Beiró 4600 | 100.000 | 32 | 3.125 | 1 | balcón, piso alto, amenities | [ZP 60112900](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-monoambiente-en-villa-devoto-60112900.html) |

## Pre-ACM
`ID45/PreACM_Bahia_Blanca_2182.pdf` (2 hojas). Rango USD 68.000–125.000, mediana USD 80.500, 10 m² ≈ USD 23.000. Tarjeta 3 para deptos: “En un mismo edificio puede haber precios distintos. / El estado, el piso, la orientación y la cochera suman o restan.” Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes
**1er contacto**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu monoambiente de Bahía Blanca al 2100: 35 m² en un 3er piso al frente, con balcón con deck, en un edificio de 8 años con SUM. Me tomé el trabajo de mirar los monoambientes usados de Villa Devoto y armé un pequeño análisis: los de tamaño y antigüedad parecidos se están publicando un poco por debajo de tu precio.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal)**

Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los monoambientes parecidos a tu monoambiente de Bahía Blanca al 2100. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento**

Hola, ¡éxito en tu día! Te escribí hace unos días por el monoambiente de Bahía Blanca. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- “Te entiendo. Pensalo así: lleva más de cuatro meses publicado, y hoy hay monoambientes parecidos más baratos compitiendo con el tuyo. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto.”
- “Un monoambiente así lo compra sobre todo un inversor que mira la renta o alguien que busca su primera vivienda, muchas veces con crédito. Cada uno negocia distinto, y una buena negociación suele cubrir de sobra lo que cuesta acompañarla.”
- “No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo.”
