# ID 57 · PH Marcos Sastre 3600, Villa del Parque — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, PH de 3 ambientes en Villa del Parque). MercadoLibre bloqueado. **CRM sin consultar.** Duplicados entre portales sacados. En Argenprop varios avisos no traen m² totales: entran en el rango de precios pero no en el USD/m².

**Sujeto:** USD 135.000 · 115 m² totales, 67 cubiertos · USD 1.174/m² · 3 amb, 2 dorm · 1 baño (el de arriba sin terminar) · 50 años, buen estado · a la calle, entrada independiente · PB: living-comedor, dormitorio, baño, cocina y patio cerrado; PA: dormitorio con placard, hall y terraza en ele · cerca de Plaza Aristóbulo del Valle · dueño directo, contacto solo por WhatsApp · **el aviso dice "INMOBILIARIAS ABSTENERSE DE LLAMAR"** · más de un año publicado.

**Ojo:**
- El precio **no está caro**: está por debajo de los parecidos por m² total. Tiene sentido, porque son solo 67 m² cubiertos (el resto es patio y terraza) y un baño sin terminar. El mensaje no habla de precio caro: apunta a la presentación y a quién le llega.
- No encontré Marcos Sastre 3600 publicado por inmobiliaria en Zonaprop ni en Argenprop (primeras páginas).

## Números (calculados con código)
- 41 avisos usados: precio USD 85.000 a 344.000, mediana USD 145.000 (P25–P75: 124.000–170.000).
- USD/m² total (31 avisos con m²): mediana 1.544 (P25–P75: 1.366–1.825). Sujeto 1.174/m²: −24% contra la mediana.
- Parecidos, PH de 86 a 144 m² (±25%): 16 avisos, mediana USD 156.950 y **USD 1.524/m²**. El sujeto está a 1.174/m², 23% abajo. 1 de 16 piden menos por m² y 4 de 16 piden menos en total.
- Los 3 más parecidos: [Av. Álvarez Jonte 2300](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-ambientes-con-patio-quincho-y-terraza-60180585.html) (113 m², USD 169.900, 1.504/m², patio, terraza, quincho); [Nogoyá 2454](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-casa-ph-venta-3-amb.-patio-sotano.-58633129.html) (103 m², USD 160.000, 1.553/m², patio, sótano); [Concordia 3000](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-amb-villa-del-parque-a-nuevo-terraza-60028198.html) (130 m², USD 219.000, 1.685/m², a nuevo, terraza (también AP 20371854)).
- 10 m² a la mediana de la zona ≈ USD 15.400.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Llavallol 5400 | 140.000 | 158 |  | 886 | 1 | tipo casa, azotea, jardín | [ZP 59415652](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-tipo-casa-3-ambientes-108-m-sup2--50-m-sup2-59415652.html) |
| Camarones 2700 | 149.000 | 168 | 83 | 887 |  | terraza 70 m², sin expensas | [ZP 60084619](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-3-ambientes-con-terraza-unica-sin-expensas!-60084619.html) |
| Arregui 3124 | 185.000 | 178 |  | 1.039 | 1 | patio, terraza, cochera | [ZP 59856499](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-ambientes-con-patio-terraza-y-cochera-en-59856499.html) |
| Lascano 3200 | 145.000 | 134 | 59 | 1.082 | 2 | terraza, local comercial | [ZP 60170102](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-en-villa-del-parque-60170102.html) |
| Joaquín V. González 2800 | 179.000 | 158 | 70 | 1.133 | 1 | gran terraza, quincho | [AP 20056706](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--20056706) |
| San Nicolás (e/ Arregui y Santo Tomé) | 105.000 | 85 | 62 | 1.235 | 1 | parrilla, terraza | [ZP 60204577](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-2-dorm.-1-bano-85-m-villa-del-parque-60204577.html) |
| Pasaje Amsterdam 3700 | 128.000 | 95 | 57 | 1.347 | 1 | terraza 37 m² | [ZP 59902675](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-ambientes-con-terraza-en-villa-del-parque-59902675.html) |
| Emilio Lamarca 2331 | 184.900 | 137 |  | 1.350 | 1 | garage, quincho, terraza (también AP 19957743) | [ZP 59522492](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-3-ambientes-con-garage-quincho-y-terraza-59522492.html) |
| Emilio Lamarca 3000 | 130.000 | 94 | 70 | 1.383 | 1 | terraza, balcón | [ZP 59882181](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-3-amb-en-villa-del-parque-59882181.html) |
| José Pedro Varela 3400 | 125.000 | 90 | 70 | 1.389 | 1 | sin expensas (también AP 19488501) | [AP 20387108](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--20387108) |
| General Rivas 2300 | 124.000 | 89 | 62 | 1.393 | 1 | patio | [ZP 60228843](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-3-ambientes-en-villa-del-parque-apto-60228843.html) |
| José Ingenieros 2700 | 145.000 | 97,56 | 67,92 | 1.486 | 1 | de época, a refaccionar | [AP 19516214](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--19516214) |
| Av. Álvarez Jonte 2300 | 169.900 | 113 | 70 | 1.504 | 1 | patio, terraza, quincho | [ZP 60180585](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-ambientes-con-patio-quincho-y-terraza-60180585.html) |
| Llavallol 2200 | 119.000 | 79 | 43 | 1.506 | 1 | PB, terraza, reciclado | [ZP 59455050](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-3-amb-en-planta-baja-con-terraza-propia-reciclado.-59455050.html) |
| Emilio Lamarca 2400 | 110.000 | 73 |  | 1.507 | 1 | dos patios | [ZP 58734419](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-excelente-ph-de-3-ambientes-en-planta-baja-lateral-con-58734419.html) |
| José Pedro Varela 3500 | 139.000 | 90 |  | 1.544 | 1 | dúplex, terraza, quincho | [ZP 59906781](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-3-ambientes-tipo-duplex-con-terraza-y-quincho-59906781.html) |
| Nogoyá 2454 | 160.000 | 103 |  | 1.553 | 1 | patio, sótano | [ZP 58633129](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-casa-ph-venta-3-amb.-patio-sotano.-58633129.html) |
| Baigorria 3855 | 125.000 | 75 |  | 1.667 | 1 | patio (también AP 18908875) | [ZP 58189099](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-departamento-3-ambientes-villa-del-parque-58189099.html) |
| Arregui 3968 | 165.000 | 98 | 70 | 1.684 | 2 | balcón, patio | [ZP 57347343](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-3-ambientes-venta-villa-del-parque-apto-credito-57347343.html) |
| Concordia 3000 | 219.000 | 130 | 93 | 1.685 | 1 | a nuevo, terraza (también AP 20371854) | [ZP 60028198](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-amb-villa-del-parque-a-nuevo-terraza-60028198.html) |
| Nazarre 3900 | 154.900 | 90 |  | 1.721 | 1 | terraza, refaccionado | [ZP 60097462](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-villa-del-parque-3-ambientes-totalmente-60097462.html) |
| Helguera 2300 | 276.000 | 154 | 97 | 1.792 | 1 | remodelado, patio, terraza | [ZP 60164328](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-remodelado-en-villa-del-parque-60164328.html) |
| Santo Tomé 3100 | 159.000 | 88 | 82 | 1.807 | 1 | patio, 2 plantas | [ZP 59902905](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-3-ambientes-con-patio-en-villa-del-parque-59902905.html) |
| Adolfo P. Carranza 2700 | 129.000 | 70 |  | 1.843 | 1 | dúplex, balcón | [ZP 57354758](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-3-ambientes-al-frente-tipo-duplex-con-balcon-57354758.html) |
| Arregui 2900 | 184.000 | 96 | 78 | 1.917 | 2 | dúplex, 7 años | [AP 11187615](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--11187615) |
| Julio Dantas 3264 | 169.900 | 88 |  | 1.931 | 2 | dúplex, balcón, terraza | [ZP 58900571](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-departamento-3-ambientes.-julio-dantas-al-3200-58900571.html) |
| Condarco 2600 | 145.000 | 75 | 65 | 1.933 | 1 | terraza, parrilla | [ZP 60091484](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-del-parque-60091484.html) |
| Nazarre 3400 | 120.000 | 56 | 50 | 2.143 | 1 | sin expensas, balcón | [ZP 60027915](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-3-ambientes-sin-expensas-excelente-ubicacion-60027915.html) |
| Tinogasta 2900 | 344.000 | 155 |  | 2.219 | 1 | patio, deck, parrilla | [ZP 60056440](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-3-ambientes-con-amplio-patio-en-el-corazon-60056440.html) |
| Baigorria 3500 | 174.000 | 78 |  | 2.231 | 1 | dúplex, patio, sin expensas | [ZP 59191197](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-tipo-duplex-con-patio-3-ambientes-59191197.html) |
| Pedro Lozano 2900 | 190.000 | 78 |  | 2.436 | 1 | sin expensas, refaccionado (también AP 19840120) | [ZP 60026959](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-3-amb-sin-expensas-refaccionado-v.-del-parque-60026959.html) |
| Av. Álvarez Jonte 3400 | 85.000 |  | 59 |  | 1 | PB, terraza compartida | [AP 19993158](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--19993158) |
| Terrada 3100 PB | 187.000 |  |  |  | 1 | al frente, jardín (dueño) | [AP 17601563](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--17601563) |
| Terrada 3100 1° | 170.000 |  |  |  | 1 | entrada independiente (dueño) | [AP 18931509](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--18931509) |
| Melincué 3700 | 149.000 |  | 63 |  | 1 | patio y terraza | [AP 19923559](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--19923559) |
| Navarro 3200 | 119.900 |  | 54 |  | 1 | refaccionado, sin expensas | [AP 20379090](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--20379090) |
| José Pedro Varela 3100 | 108.000 |  | 57 |  | 1 | tipo chorizo, 1er piso | [AP 17966595](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--17966595) |
| San Nicolás 2300 | 115.000 |  | 53 |  | 1 | 2 balcones | [AP 17635322](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--17635322) |
| Baigorria 2800 | 105.000 |  | 58 |  | 1 | a refaccionar | [AP 20172571](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--20172571) |
| General César Díaz 2700 | 85.000 |  | 49 |  | 1 | al frente | [AP 20455396](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--20455396) |
| Llavallol 2100 | 159.900 |  |  |  | 3 | dúplex al frente | [AP 19216850](https://www.argenprop.com/ph-en-venta-en-villa-del-parque-3-ambientes--19216850) |

**Excluidos:** Cuenca 2500 (ZP 59634700) (a estrenar); Génova 3330 (ZP 55508811) (a estrenar); Av. Álvarez Jonte 5400 (AP 19704260) (en obra, entrega 2028); Pedro Lozano 2900 (AP 19840120), Emilio Lamarca 2300 (AP 19957743), Baigorria 3800 (AP 18908875), Concordia 3000 (AP 20371854), José P. Varela 3400 (AP 19488501) (duplicados).

## Pre-ACM
`ID57/PreACM_Marcos_Sastre_3600.pdf` (2 hojas). Rango USD 85.000–344.000, mediana USD 145.000, 10 m² ≈ USD 15.000. Tarjeta 3: la alternativa para PH o casa ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción", porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
> Vi tu PH de Marcos Sastre al 3600: a la calle, con entrada independiente y terraza en ele. Me tomé el trabajo de mirar los PH parecidos de Villa del Parque y armé un pequeño análisis: tu precio está en línea con los de tamaño similar, así que lo que puede estar frenando es otra cosa: la presentación o a quién le llega.
> Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
> ¿Te lo paso?
> 
> Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal):**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los PH parecidos a tu PH de Marcos Sastre al 3600. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

> Hola, ¡éxito en tu día! Te escribí hace unos días por el PH de Marcos Sastre. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.
> 
> Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Tu precio está bien ubicado y aun así el PH lleva más de un año publicado: eso dice que lo que falla no es el número sino cómo se muestra y a quién le llega. Mi trabajo es justamente eso, y acortar el tiempo de espera."
- "Un PH de 3 ambientes a la calle, con entrada independiente y terraza, lo busca alguien que sale de un depto y quiere su espacio, muchas veces con crédito. Hay que saber mostrarle el potencial (como el baño de arriba para terminar) y negociar sin regalar. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
