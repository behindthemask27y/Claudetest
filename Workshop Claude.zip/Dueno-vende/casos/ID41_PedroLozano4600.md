# ID 41 · PH en block (3 unidades) Pedro Lozano 4600, Villa Devoto — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop (primera página, PH de 5 ambientes o más en Villa Devoto; 48 resultados en total). La primera página de Argenprop no filtró por ambientes (devolvió PH de 2 a 4 amb): solo aportó el duplicado de Baigorria 4000. MercadoLibre bloqueado. **CRM sin consultar.**

**Sujeto:** USD 263.000 · 204 m² totales (170–174 cubiertos) · USD 1.289/m² · 8 amb en 3 unidades con acceso independiente: PB reciclada de 109 m² (living, cocina-comedor, parrilla, baulera) y dos unidades en planta alta a estrenar (una con balcón corrido, otra con patio techado) · 3 baños + toilette · sin expensas · jardín, patio y balcón · sin cochera mencionada · dueño directo, sin teléfono visible · más de un año publicado.

**Ojo:**
- **Venta en block:** no hay una tipología igual en los portales. Se compara contra los PH grandes de Devoto (5 amb o más, que incluyen casas-PH multifamiliares) y, aparte, contra los 4 avisos de PH en block (2 o 3 unidades) de la misma página: Vallejos 3800, José L. Cantilo 4800 (dos avisos) y Tinogasta 5200. Un comprador inversor mira el precio por unidad; una familia grande, el total. La comparación por m² es orientativa.
- El aviso marca "a estrenar" porque las dos unidades de arriba son nuevas; la de PB es reciclada. Eso justifica algo de sobreprecio contra PH usados, así que la diferencia de +6% es chica.
- No encontré el mismo inmueble publicado por inmobiliaria en Zonaprop ni en Argenprop (primeras páginas).

## Números (calculados con código)
- 24 avisos usados: precio USD 130.000 a 650.000, mediana USD 277.000 (P25–P75: 216.844–302.250).
- USD/m² total (24 avisos con m²): mediana 1.227 (P25–P75: 1.053–1.386). Sujeto 1.289/m²: +5% contra la mediana.
- Parecidos, PH de 153 a 255 m² (±25%): 14 avisos, mediana USD 272.500 y **USD 1.217/m²**. El sujeto está a 1.289/m², 6% arriba. 11 de 14 piden menos por m² y 6 de 14 piden menos en total.
- PH en block (4 avisos): mediana **USD 1.132/m²** (Tinogasta 5200 657, Vallejos 3800 1.010, Cantilo 4800 de 2 PH 1.253, Cantilo 4800 de 3 PH 1.321). El sujeto está un 14% arriba.
- Los 3 más parecidos: [Vallejos 3800](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-2-ph-en-block-lote-propio-terraza-cochera-devoto-60208846.html) (296 m², USD 299.000, 1.010/m², 2 PH en block, lote propio); [José L. Cantilo 4800 (b)](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-devoto-59420281.html) (249 m², USD 312.000, 1.253/m², 2 PH en block (6 amb)); [Baigorria 5000](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-en-villa-devoto-con-terraza-sin-58990321.html) (203 m², USD 250.000, 1.232/m², sin expensas, terraza).
- 10 m² a la mediana de la zona ≈ USD 12.300.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Tinogasta 5200 | 130.000 | 198 |  | 657 | 2 | 2 PH en block, terraza | [ZP 59959886](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-devoto-2-ph-en-block-59959886.html) |
| Baigorria 4000 | 220.000 | 333 | 204 | 661 | 2 | 9 amb, cochera, 60 años (también AP 20023029) | [ZP 60229507](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-de-9-amb.-cochera-ptios-y-tza-propia.-333-m-sup2-60229507.html) |
| Av. Mosconi 4100 | 240.000 | 329 |  | 729 | 2 | 8 amb, de 1930, a reciclar | [ZP 60315382](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-a-reciclar-devoto-60315382.html) |
| Bermúdez 2700 | 160.000 | 168 |  | 952 | 2 | 6 amb, 3 plantas | [ZP 60108521](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-6-ambientes-en-villa-devoto-60108521.html) |
| Vallejos 3800 | 299.000 | 296 |  | 1.010 | 3 | 2 PH en block, lote propio | [ZP 60208846](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-2-ph-en-block-lote-propio-terraza-cochera-devoto-60208846.html) |
| Joaquín V. González 2600 | 289.900 | 286 |  | 1.014 | 2 | cochera, patio, terraza | [ZP 59868756](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-tipo-casa-en-venta-5-ambientes-cochera-patio-y-59868756.html) |
| Cervantes 2434 | 240.000 | 225 |  | 1.067 | 2 | 2 cocheras, terraza | [ZP 58991829](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-casa-tipo-ph-de-5-ambientes-en-planta-baja-2-plantas-58991829.html) |
| Nogoyá 4515 | 270.000 | 253 |  | 1.067 | 2 | terraza, quincho, sin expensas | [ZP 57219218](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-amplio-y-luminoso-en-devoto-5-amb-terraza-57219218.html) |
| Av. Mosconi 4200 | 179.000 | 156 |  | 1.147 | 1 | PB, terraza | [ZP 59869516](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-villa-devoto-planta-baja-con-59869516.html) |
| Simbrón 3500 | 280.000 | 240 |  | 1.167 | 1 | dúplex, 2 cocheras | [ZP 60284913](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-tipo-casa-devoto-vdp-60284913.html) |
| Pareja 4700 | 299.000 | 247 |  | 1.211 | 2 | 2 cocheras, terraza | [ZP 59404331](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta.-villa-devoto.-ph-independiente.-5-ambientes.-59404331.html) |
| Nazarre 5200 | 192.000 | 157 |  | 1.223 | 2 | cochera, uso dual | [ZP 59971982](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-casa-tipo-ph-5-ambientes-con-cochera-en-villa-59971982.html) |
| Baigorria 5000 | 250.000 | 203 |  | 1.232 | 3 | sin expensas, terraza | [ZP 58990321](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-ambientes-en-villa-devoto-con-terraza-sin-58990321.html) |
| José L. Cantilo 4800 (b) | 312.000 | 249 |  | 1.253 | 3 | 2 PH en block (6 amb) | [ZP 59420281](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-devoto-59420281.html) |
| José Pedro Varela 4400 | 315.000 | 250 |  | 1.260 | 3 | jardín, cochera | [ZP 60250412](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-5-amb-con-jardin-y-parrilla-v.-devoto-60250412.html) |
| Bahía Blanca 4690 | 460.000 | 360 |  | 1.278 | 3 | tipo casa, reciclado, garage | [ZP 59027408](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-tipo-casa-con-garage-y-patio!-totalmente-reciclado.-59027408.html) |
| José L. Cantilo 4800 | 490.000 | 371 |  | 1.321 | 4 | 3 PH independientes (10 amb) | [ZP 59419782](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-devoto-59419782.html) |
| Marcos Paz 3906 | 340.000 | 248 |  | 1.371 | 4 | 3 plantas, cochera | [ZP 51524855](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-excelente-casa-ph-en-3-plantas-en-villa-devoto-51524855.html) |
| Vallejos 3700 | 275.000 | 192 |  | 1.432 | 3 | garage, terraza | [ZP 60208943](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-al-frente-de-5-ambientes-3-banos-con-garage-60208943.html) |
| San Nicolás 2800 | 194.900 | 128 |  | 1.523 | 1 | cochera, patio | [ZP 59481820](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-villa-devoto-venta-59481820.html) |
| Tinogasta 5000 | 207.375 | 136 |  | 1.525 | 2 | refaccionado, patio | [ZP 59674945](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-de-5-amb-en-villa-devoto-59674945.html) |
| San Nicolás 3940 | 650.000 | 422 |  | 1.540 | 3 | cochera, sótano | [ZP 59129189](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-casa-ph-de-5-ambientes-con-terraza-en-villa-devoto-59129189.html) |
| Av. Lastra 3600 | 279.000 | 165 |  | 1.691 | 3 | terraza, quincho | [ZP 60136562](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-dependencia-en-devoto-60136562.html) |
| Simbrón 4000 | 279.000 | 124 |  | 2.250 | 3 | dúplex, sin expensas | [ZP 57900919](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-villa-devoto-venta-ph-en-duplex-sin-expensas-57900919.html) |

**Excluidos:** Nueva York 4274 (lote de 679 m² con piscina y parque: otra categoría); Bahía Blanca 4600 (duplicado probable de Bahía Blanca 4690 (mismo precio, otra inmobiliaria)); Asunción 3400 (AP 20227870) (a estrenar).

## Pre-ACM
`ID41/PreACM_Pedro_Lozano_4600.pdf` (2 hojas). Rango USD 130.000–650.000, mediana USD 277.000, 10 m² ≈ USD 12.000. Tarjeta 3: la alternativa para PH o casa ("Lo construido y lo que dice el plano pueden no coincidir"). Sin "Según tu descripción", porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
> Vi tu PH de Pedro Lozano al 4600: tres unidades con entrada independiente, sin expensas, con la de planta baja reciclada y las dos de arriba a estrenar. Me tomé el trabajo de mirar los PH grandes y las ventas en block de Villa Devoto y armé un pequeño análisis: los de tamaño parecido se están publicando un poco por debajo de tu precio por m².
> Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
> ¿Te lo paso?
> 
> Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal):**

> Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los PH parecidos a tu PH de Pedro Lozano al 4600. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

> Hola, ¡éxito en tu día! Te escribí hace unos días por el PH de Pedro Lozano. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.
> 
> Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: con lo que pedís hoy, el PH lleva más de un año publicado. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Tres unidades en block tienen dos compradores posibles: un inversor que piensa en alquilarlas o una familia grande que quiere vivir junta pero cada uno en lo suyo, y a cada uno se le muestra y se le negocia distinto. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura, que en una venta en block incluye revisar la documentación de las tres unidades. Es tu tiempo."
