# ID 59 · PH de 4 ambientes con patio y terraza (dirección no publicada, Comuna 11), Villa del Parque — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, PH de 4 ambientes en Villa del Parque). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Duplicados entre portales sacados; también el propio aviso. Aviso: https://www.zonaprop.com.ar/propiedades/clasificado/veclphpa-ph-4-ambientes-con-patio-y-terraza-en-villa-del-parque-58324632.html

**Sujeto:** USD 208.000 · 170 m² totales (120 cubiertos) · USD 1.224/m² · 3 dorm, 2 baños + toilette · 14 años (refaccionado), cocina refaccionada hace un año · planta baja, entrada independiente · patio con parrilla y lavadero, terraza, baulera · sin expensas · a 2 cuadras de plaza Aristóbulo del Valle · 236 días publicado.

**Ojo:** el mismo PH figura como aviso de **inmobiliaria** en Zonaprop (59446705 “Teodoro Vilardebó 2483”, 59042239 “Teodoro Vilardebo 2400” y 60264076 “Teodoro Vilardebó e/ Marcos Sastre y Tobas”) y en Argenprop (19017551, 170/120 m², 14 años), todos a USD 208.000. Dirección probable: Teodoro Vilardebó 2483. Confirmar si ya lo trabajan inmobiliarias (si es así, la objeción de la comisión puede no aplicar).

## Números (calculados con código)
- 35 avisos: precio USD 89.000 a 420.000, mediana USD 198.000 (P25–P75: 160.000–220.000).
- USD/m² total (28 avisos con m² totales): mediana 1.476 (P25–P75: 1.212–1.713). El sujeto está a 1.224/m² (−17% contra la mediana).
- Parecidos en tamaño (128–212 m², 11 avisos): mediana USD 210.000 y **USD 1.287/m²**. El sujeto: 1.224/m², −5%.
- Los 3 más parecidos en tamaño: Argerich 2344 (172 m², USD 268.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-villa-del-parque-venta-ph-4-ambientes-reciclado-2-59327646.html); Cuenca 2500 (176 m², USD 198.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-apto-credito!-4-ambientes-primer-piso.-c-banos-58419924.html); San Nicolás 1900 (177 m², USD 210.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-venta-ph-4-ambientes-con-terraza-en-villa-santa-rita-60239571.html).
- 10 m² a la mediana de la zona ≈ USD 14.800.
- Dato de precio en el mensaje: No dice que está caro: 11 PH de 128–212 m², mediana USD 210.000 y USD 1.287/m²; el sujeto está a USD 1.224/m² (−5%), en línea. El mensaje usa “tu precio está en línea… lo que puede estar frenando es la presentación o a quién le llega”.

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Elpidio González 3300 | 215.000 | 268 | 127 | 802 | 1 | patio, terraza, cochera, 60 años | AP 19828275 |
| Ricardo Gutiérrez 2300 | 129.000 | 159 | 88 | 811 | 2 | patio, terraza (estado regular) | AP 19714699 |
| Llavallol 3369 | 220.000 | 240 |  | 917 | 2 | cochera, terraza, s/exp | ZP 60034540 |
| Terrero 3100 | 160.000 | 156 |  | 1.026 | 1 | terraza, quincho, s/exp | ZP 59289163 |
| Cuenca 2500 | 198.000 | 176 |  | 1.125 | 2 | patio, terraza, 1er piso | ZP 58419924 |
| Bolivia 2500 | 240.000 | 210 | 180 | 1.143 | 2 | cochera, patio con parrilla | AP 18036245 |
| San Nicolás 1900 | 210.000 | 177 |  | 1.186 | 1 | terraza, s/exp (título: Villa Santa Rita) | ZP 60239571 |
| Teodoro Vilardebó 2900, PB | 175.000 | 136 | 76 | 1.287 | 1 | doble altura, patio, s/exp | AP 19815501 |
| Terrada 2800, PB | 185.000 | 140 | 80 | 1.321 | 2 | terraza, patio, s/exp | AP 20192620 |
| Álvarez Jonte (e/ Pernambuco y Bolivia) | 320.000 | 236 |  | 1.356 | 3 | jardín, cochera 2 autos | ZP 59843553 |
| Emilio Lamarca 3200 | 315.000 | 228 |  | 1.382 | 3 | piscina, jardín | ZP 60178454 |
| Av. Nazca 2500 | 315.000 | 227 |  | 1.388 | 2 | pileta, quincho | ZP 56623318 |
| Nazarre 3700 | 279.900 | 201 |  | 1.393 | 2 | quincho, terraza | ZP 59557396 |
| Pedro Lozano 3400 | 265.000 | 180 |  | 1.472 | 2 | cochera, patio, terraza | ZP 59190776 |
| Alfredo Bufano 2760 | 219.000 | 148 |  | 1.480 | 2 | reciclado, patio, terraza | ZP 59448525 |
| Argerich 2344 | 268.000 | 172 |  | 1.558 | 2 | terraza con parrilla, s/exp, reciclado | ZP 59327646 |
| Condarco 4500 | 420.000 | 261 |  | 1.609 | 2 | terraza | ZP 60044436 |
| Concordia 2400 | 197.000 | 117 |  | 1.684 | 2 | cochera, balcón, patio | ZP 60047740 |
| Av. Francisco Beiró 3100 | 164.000 | 97 |  | 1.691 | 1 | terraza | ZP 60092533 |
| Baigorria 3500 | 215.000 | 126 |  | 1.706 | 2 | patio, jardín, s/exp | ZP 59397152 |
| Marcos Sastre 2700 | 123.000 | 72 |  | 1.708 | 1 | 3 amb + playroom (también AP 19551896) | ZP 59521469 |
| Bahía Blanca 2900 | 180.000 | 105 |  | 1.714 | 2 | patio, terraza | ZP 59845759 |
| Nazarre 3722 | 220.000 | 127 |  | 1.732 | 2 | dúplex, cochera, patio | ZP 59787898 |
| Marcos Sastre 4000 | 220.000 | 127 |  | 1.732 | 2 | quincho, terraza, reciclado | ZP 60271727 |
| Nazarre 2800 | 179.000 | 99 |  | 1.808 | 1 | terraza grande, s/exp | ZP 59536198 |
| Teodoro Vilardebó 2651 | 142.000 | 75 |  | 1.893 | 1 | patio, s/exp (también AP 19748532) | ZP 59212268 |
| Lascano 2300 | 210.000 | 110 |  | 1.909 | 2 | cochera, patio (también AP 18946126 y 20076413) | ZP 52276527 |
| Bolivia 2300 | 210.000 | 90 |  | 2.333 | 1 | balcón, patio | ZP 48907053 |
| Laplace 3300 | 139.000 |  | 72 |  | 1 | terraza, quincho, 35 años | AP 19686256 |
| Argerich 2700 | 179.000 |  | 90 |  | 2 | refaccionado, patio, 20 años | AP 19262718 |
| Terrada 2800 | 115.000 |  | 69 |  | 1 | a reciclar, s/exp | AP 19941133 |
| Emilio Lamarca 3300 | 89.000 |  | 55,71 |  | 1 | 2do piso, con expensas | AP 20420932 |
| Arregui 2800 | 180.000 |  | 132 |  | 2 | terraza, 40 años | AP 17343523 |
| Arregui 2800, 1° | 130.000 |  | 85 |  | 2 | terraza propia, s/exp | AP 19546377 |
| Av. Nazca 3100, 1° | 135.000 |  | 72 |  | 1 | terraza, con expensas | AP 16592228 |

**Excluidos:**
- Teodoro Vilardebó 2483 · USD 208.000 · 170 m²: ES LA PROPIEDAD (inmobiliaria) (ZP 59446705)
- Teodoro Vilardebó 2400 · USD 208.000 · 170 m²: es la propiedad (inmobiliaria) (ZP 59042239)
- Teodoro Vilardebó e/ Marcos Sastre y Tobas · USD 208.000 · 170 m²: es la propiedad (inmobiliaria; AP con 120 cub y 14 años) (ZP 60264076 · AP 19017551)
- Baigorria 3400 · USD 299.900 · 150 m²: en construcción (ZP 58054464)
- Tinogasta 3600 · USD 292.000 · 158 m²: a estrenar (ZP 60244006)
- Arregui 2300 · USD 240.000 · 162 m²: a estrenar según Argenprop (AP 20445799) (ZP 60061131)
- Alfredo R. Bufano 2600 · USD 119.000: a estrenar (AP 17304196)
- Baigorria 3000, piso 8 · USD 349.000: piso 8 con expensas: depto, no PH (AP 11956571)

## Pre-ACM
`ID59/PreACM_PH_4_ambientes_Villa_del_Parque.pdf` (2 hojas). Rango USD 89.000–420.000, mediana USD 198.000, 10 m² ≈ USD 15.000. Tarjeta 3: la alternativa para PH (“Lo construido y lo que dice el plano pueden no coincidir”).
Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu PH de 4 ambientes con patio y terraza en Villa del Parque: 170 m², 3 dormitorios, 2 baños y sin expensas. Me tomé el trabajo de mirar los PH parecidos de la zona y armé un pequeño análisis: tu precio está en línea con los de tamaño similar, así que lo que puede estar frenando la venta es otra cosa, como la presentación o a quién le llega.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario):** Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los PH parecidos a tu PH de 4 ambientes con patio y terraza en Villa del Parque. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

Hola, ¡éxito en tu día! Te escribí hace unos días por tu PH de 4 ambientes en Villa del Parque. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: tu precio está en línea con los parecidos y aun así el PH lleva casi 8 meses publicado. Eso dice que lo que falta no es bajar el número, sino cómo se muestra y a quién le llega. Ese es justamente mi trabajo."
- "Un PH de 3 dormitorios con patio y terraza lo busca una familia, que muchas veces tiene que vender otra propiedad para comprar. Coordinar las dos operaciones y negociar los plazos es lo que más se complica, y una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
