# ID 42 · Depto 3 amb Ricardo Gutiérrez 3785, Villa Devoto — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, 3 ambientes **usados**, Villa Devoto). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Excluidos: a estrenar / pozo / en construcción (Bahía Blanca 3400, José Cubas 4814, Calderón de la Barca 3035, Griveo 4100, Navarro 4200, Pareja 3600 y 3670 —El Convento—, Chivilcoy 3300, Navarro 3500, Sanabria 4200, Llavallol 4600, Cnel. Ramón Lista 5100 a estrenar), Pedro Morán 3300 (mismo edificio que un aviso en construcción) y emprendimientos con precio “desde”. Emilio Lamarca 3600 aparece en ZP (USD 185.000, 73 m²) y en AP (USD 212.000, 64 m²) con datos distintos: quedan los dos.

**Sujeto:** USD 105.000 · 64 m² totales (62 cub.) · USD 1.641/m² · 3 amb, 2 dorm, 1 baño · 45 años · al frente, SE, luminoso · expensas $210.000 · apto profesional · cocina y baño reciclados a nuevo.

**Ojo:** No lo encontré publicado por inmobiliaria ni en Argenprop. Anunciante no identificado en el aviso (la hoja lo tiene como dueño).

## Números (calculados con código)
- 25 avisos: precio USD 89.999 a 435.000, mediana USD 175.000 (P25–P75: 124.900–228.000).
- USD/m² total: mediana 2.467 (P25–P75: 2.067–2.805).
- Parecidos en tamaño (±25%, 18 avisos): mediana USD 159.000 y **USD 2.386/m²**. El sujeto está a 1.641/m², un 31,2% abajo.
- Los más parecidos por tamaño y antigüedad: José Cubas 3600 (68 m², 50 años, USD 145.000, [AP 20552019](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20552019)), José Pedro Varela 5000 (58 m², 54 años, USD 93.000, [AP 20554090](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20554090)) y José Cubas 3300 (69 m² cub., 45 años, USD 159.000, [AP 20073236](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20073236)).
- 10 m² a la mediana de la zona ≈ USD 24.670.
- Lectura para el mensaje: **Precio bajo**: USD 1.641/m² contra USD 2.386/m² de los parecidos (−31%); es el 3er precio más bajo de 26. El mensaje NO dice que está caro: dice que está entre los más bajos y que lo que frena es otra cosa.

## Tabla

| Dirección | USD | m² tot | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|
| Av. San Martín 7400 | 89.999 | 74 | 1.216 | 1 | patio, sin expensas | [ZP 60102092](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes.-av-san-martin-al-7400-60102092.html) |
| Lavallol 3500 | 112.000 | 83 | 1.349 | 1 | 45 años, 1er piso (m² cubiertos) | [AP 20034043](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20034043) |
| Asunción 3100 | 109.000 | 72 | 1.514 | 1 | apto profesional | [ZP 60259119](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-3-ambientes-villa-devoto-a-prof-60259119.html) |
| José Pedro Varela 5000 | 93.000 | 57,82 | 1.608 | 1 | 54 años, semipiso | [AP 20554090](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20554090) |
| Gutenberg 3600 | 114.900 | 70 | 1.641 | 1 |  | [ZP 58639857](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-de-3-ambientes-en-villa-devoto-58639857.html) |
| Molière 2800 | 124.900 | 73,57 | 1.698 | 1 | 51 años, balcón (m² cubiertos) | [AP 20444636](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20444636) |
| José Luis Cantilo 4800 | 248.000 | 120 | 2.067 | 2 | 50 años, quincho, terraza | [AP 18900209](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--18900209) |
| José Cubas 3600 | 145.000 | 67,86 | 2.137 | 1 | 50 años, balcón | [AP 20552019](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20552019) |
| Griveo 3700 | 177.000 | 77 | 2.299 | 1 | balcón aterrazado | [ZP 60316780](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-de-3-ambientes-con-balcon-terraza-en-60316780.html) |
| Av. Francisco Beiró 3900 | 175.000 | 76 | 2.303 | 1 | 45 años, balcón, cochera | [AP 19813087](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--19813087) |
| José Cubas 3300 | 159.000 | 69 | 2.304 | 2 | 45 años, jardín, pileta (m² cubiertos) | [AP 20073236](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20073236) |
| Av. San Martín 6300 | 109.000 | 47 | 2.319 | 1 | reciclado | [ZP 60307992](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-dpto-3-amb-devoto-refaccionado-oportunidad-60307992.html) |
| Mcal. F. Solano López 3100 | 148.000 | 60 | 2.467 | 1 | 20 años, semipiso, cochera | [AP 20333683](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20333683) |
| Emilio Lamarca 3600 | 185.000 | 73 | 2.534 | 2 | luminoso, vista a pulmón verde | [ZP 60239849](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-3-ambientes-venta-v-devoto-vista-a-pulmon-verde-60239849.html) |
| Cnel. Ramón Lista 5100 | 205.000 | 77,64 | 2.640 | 2 | 5 años, semipiso, balcón | [AP 19117239](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--19117239) |
| Av. Francisco Beiró 4800 | 435.000 | 163 | 2.669 | 2 | cochera, balcón terraza, jacuzzi | [ZP 59815725](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-3-ambientes-en-devoto-con-cochera-y-59815725.html) |
| Calderón de la Barca 3050 | 214.900 | 79 | 2.720 | 2 | cochera, laundry (antigüedad sin dato) | [ZP 59925206](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-de-tres-ambientes-devoto-59925206.html) |
| Av. San Martín 6300 (otro) | 148.000 | 54 | 2.741 | 1 | balcón, SUM | [ZP 60282923](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-3-ambientes-con-balcon-apto-a-credito-60282923.html) |
| Av. Francisco Beiró 3400 | 230.000 | 82 | 2.805 | 2 | semipiso, terraza | [ZP 59558979](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-villa-devoto-59558979.html) |
| Navarro 3000 | 228.000 | 80 | 2.850 | 2 | semipiso al frente, balcón | [ZP 59748501](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-semipiso-de-3-ambientes-al-frente-con-balcon-59748501.html) |
| Gualeguaychú 3800 | 159.000 | 55 | 2.891 | 1 | 50 años, 6to piso (m² cubiertos) | [AP 17578194](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--17578194) |
| Emilio Lamarca 3600 (otro) | 212.000 | 64 | 3.312 |  | 40 años, balcón (m² cubiertos) | [AP 19836413](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--19836413) |
| Gualeguaychú 3300 | 400.000 | 105 | 3.810 | 2 | full amenities (antigüedad sin dato) | [ZP 59439346](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-villa-devoto-59439346.html) |
| Concordia 4100 | 282.700 | 74 | 3.820 | 2 | terraza, parrilla, pileta; antigüedad sin dato (m² cub.) | [AP 17288000](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--17288000) |
| Gabriela Mistral 4300 | 329.000 | 85 | 3.871 | 2 | 6 años, semipiso, cochera (m² cubiertos) | [AP 20160413](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-3-ambientes--20160413) |

## Pre-ACM
`ID42/PreACM_Ricardo_Gutierrez_3785.pdf` (2 hojas). Rango USD 89.999–435.000, mediana USD 175.000, 10 m² ≈ USD 25.000. Tarjeta 3 para deptos: “En un mismo edificio puede haber precios distintos. / El estado, el piso, la orientación y la cochera suman o restan.” Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes
**1er contacto**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu departamento de Ricardo Gutiérrez al 3700: 3 ambientes de 64 m², apto profesional, con la cocina y el baño reciclados a nuevo. Me tomé el trabajo de mirar los 3 ambientes usados de Villa Devoto y armé un pequeño análisis: tu precio está entre los más bajos de los parecidos, así que lo que puede estar frenando la venta es otra cosa, como la presentación o a quién le llega el aviso.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal)**

Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los departamentos parecidos a tu departamento de Ricardo Gutiérrez al 3700. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento**

Hola, ¡éxito en tu día! Te escribí hace unos días por el departamento de Ricardo Gutiérrez. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- “Te entiendo. Pensalo así: tu precio ya está entre los más bajos de los 3 ambientes parecidos y aun así lleva más de un año publicado. El problema no parece ser el precio, sino cómo se muestra y a quién le llega. Ahí está mi trabajo.”
- “Un 3 ambientes apto profesional tiene dos compradores posibles: una familia que lo quiere para vivir o un profesional que busca consultorio u oficina. A cada uno hay que hablarle distinto, y una buena negociación suele cubrir de sobra lo que cuesta acompañarla.”
- “No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo.”
