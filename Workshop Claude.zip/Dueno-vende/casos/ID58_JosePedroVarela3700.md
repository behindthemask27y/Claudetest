# ID 58 · PH José Pedro Varela 3700, Villa del Parque — comparables para pre-ACM

**6-oct-2026:** CRM consultado (ACM A-30087, PH cerrados en Villa del Parque). PDF nuevo con ventas cerradas, estrategia y mensaje en `pre-ACM/casos/Duenos_2026-10-06.md`.

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, PH de 2 ambientes en Villa del Parque). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Duplicados entre portales sacados; también el propio aviso. Aviso: https://www.zonaprop.com.ar/propiedades/clasificado/veclphpa-sin-expensas-ph-2-ambientes-con-patio-villa-del-57397718.html

**Sujeto:** USD 126.000 · 67 m² totales (49 cubiertos) · USD 1.881/m² · 1 dorm, 1 baño · 25 años, renovado · planta baja al fondo, entrada independiente · patio y jardín de invierno/lavadero vidriado · sin expensas (único gasto común: agua) · lote de 4 unidades · 356 días publicado.

**Ojo:** el mismo PH figura también como aviso de **inmobiliaria** en Zonaprop (59169400, “José Pedro Varela 3681”, USD 126.000, 67/49 m²; 60237414, USD 125.900; 60260287, USD 125.900, 61/49 m², mismo texto) y en Argenprop (19312316, 19685125 y 20522812: 49 m² cub, 25 años). Confirmar si ya lo trabajan inmobiliarias. Aparte, ZP 60296996 (JPV 3600, 68/46 m², 30 años, USD 125.000, “solo 4 unidades en el lote”) podría ser la otra unidad de PB del mismo lote: lo dejé afuera por las dudas.

## Números (calculados con código)
- 23 avisos: precio USD 70.000 a 165.000, mediana USD 109.000 (P25–P75: 98.000–135.000).
- USD/m² total (17 avisos con m² totales): mediana 1.650 (P25–P75: 1.404–1.942). El sujeto está a 1.881/m² (+14% contra la mediana).
- Parecidos en tamaño (50–84 m², 11 avisos): mediana USD 105.000 y **USD 1.650/m²**. El sujeto: 1.881/m², +14%.
- Los 3 más parecidos en tamaño: Emilio Lamarca 2200 (69 m², USD 105.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-2-amb-c-terraza-propia-en-villa-del-parque-60149007.html); Álvarez Jonte 2600 (71 m², USD 98.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-en-venta-2-ambientes-dos-patios-villa-del-parque-60240904.html); San Blas 2600 (71 m², USD 110.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-ph-2-ambientes-planta-baja-c-patio-59655764.html).
- 10 m² a la mediana de la zona ≈ USD 16.500.
- Dato de precio en el mensaje: Sí dice “un poco por debajo de tu precio”: 11 PH de 50–84 m² con link, mediana USD 105.000 y USD 1.650/m²; el sujeto está a USD 1.881/m² (+14%).

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Nogoyá 4300 | 115.000 | 104 | 60 | 1.106 | 1 | 2 patios, terraza, s/exp, reciclado (también AP 20381204) | ZP 60048724 |
| Terrada 2100 | 134.000 | 109 | 61 | 1.229 | 1 | terraza propia, parrilla, s/exp (también AP 18617801) | ZP 57799366 |
| Terrada 2000 | 105.000 | 80 |  | 1.312 | 1 | PB, terraza propia, con renta, s/exp | ZP 54030488 |
| Álvarez Jonte 2600 | 98.000 | 71 | 49 | 1.380 | 1 | dúplex, 2 patios (también AP 20524863) | ZP 60240904 |
| Alfredo R. Bufano 2300 | 149.900 | 105 | 49 | 1.428 | 1 | terraza propia | ZP 60217373 |
| Emilio Lamarca 2950 | 89.900 | 61 | 51 | 1.474 | 1 | s/exp, patio techado (también ZP 58696060) | ZP 55525499 |
| Emilio Lamarca 2200 | 105.000 | 69 | 54 | 1.522 | 1 | terraza, parrilla, s/exp | ZP 60149007 |
| San Blas 2600 | 110.000 | 71 | 60 | 1.549 | 1 | PB, patio (también AP 20051050) | ZP 59655764 |
| Álvarez Jonte 3400 | 99.000 | 60 | 40 | 1.650 | 1 | 2do piso, doble terraza, s/exp (también AP 20306921) | ZP 59957959 |
| Mercedes 2700 | 99.900 | 60 | 60 | 1.665 | 1 | balcón, patio, parrilla (también AP 20485092) | ZP 60185681 |
| Bolivia 2300 | 140.000 | 82 | 65 | 1.707 | 2 | dúplex, doble terraza | ZP 60265331 |
| Marcos Sastre 2700 | 165.000 | 90 | 70 | 1.833 | 1 | 2 y medio amb, entrada indep. (también AP 19714615) | ZP 58338266 |
| José Pedro Varela 3085 | 73.000 | 38 |  | 1.921 | 1 | reciclado | ZP 46496677 |
| Baigorria 3600 | 157.000 | 80 | 65 | 1.962 | 1 | tríplex, patio, cochera | ZP 59337226 |
| Lascano 2770 | 83.000 | 42 |  | 1.976 | 1 | tipo casa, patio, PB | ZP 58928945 |
| Teodoro Vilardebó 2400 | 120.000 | 57 | 52 | 2.105 | 1 | primer piso, s/exp, doble altura | ZP 59689660 |
| Teodoro Vilardebó 2400 (b) | 138.000 | 57 | 41 | 2.421 | 1 | patio con parrilla | ZP 60258669 |
| Av. Nazca 2400, piso 1 | 70.000 |  |  |  | 1 | sin m² publicados | AP 20465025 |
| Bahía Blanca 2700, PB | 135.000 |  | 45 |  | 1 | dúplex, cochera, 10 años | AP 19947276 |
| José Pedro Varela 3100 | 108.000 |  | 57 |  | 1 | tipo chorizo, patio, 65 años | AP 18966401 |
| Av. Francisco Beiró 3200, piso 1 | 125.000 |  | 45 |  | 1 | con expensas, 40 años | AP 6153975 |
| Andalucía 2400 | 98.000 |  |  |  | 1 | balcón, s/exp, sin m² | AP 8000092 |
| Los Territorios 2700 | 109.000 |  | 51 |  | 1 | PB, patio, tipo loft | AP 17404582 |

**Excluidos:**
- José Pedro Varela 3681 · USD 126.000 · 67 m²: ES LA PROPIEDAD (inmobiliaria) (ZP 59169400)
- José Pedro Varela 3600 · USD 125.900 · 67 m²: es la propiedad (inmobiliaria) (ZP 60237414)
- José Pedro Varela · USD 125.900 · 61 m²: es la propiedad (mismo texto: jardín de invierno, único gasto agua; 49 cub) (ZP 60260287)
- José Pedro Varela 3700 / 3600 PB / 3600 · USD 126.000: es la propiedad en Argenprop (49 cub, 25 años) (AP 19312316 · AP 19685125 · AP 20522812)
- José Pedro Varela 3600 · USD 125.000 · 68 m²: posible otra unidad del mismo lote de 4 (46 cub, 30 años); fuera por las dudas (ZP 60296996)
- Av. Álvarez Jonte 3474 · USD 105.000 · 60 m²: probable duplicado de Álvarez Jonte 3400 (60 m², 2 terrazas) (ZP 57709676)
- Campana 3200 · USD 89.000 · 51 m²: a estrenar (ZP 60322817)
- Simbrón 3039 · USD 74.900 · 40 m²: a estrenar (también AP 20011800) (ZP 59588931)
- Marcos Sastre 2600 (x2) / Comuna 11 · USD 115.000 · 51 m²: a estrenar (ZP 57748380, 59883768, 60174859; AP 20427784) (ZP 57748380)
- Emilio Lamarca 1400 (x2) · USD 125.000 · 44 m²: a estrenar (AP 18039002, 18102782) (AP 18039002)

## Pre-ACM
`ID58/PreACM_Jose_Pedro_Varela_3700.pdf` (2 hojas). Rango USD 70.000–165.000, mediana USD 109.000, 10 m² ≈ USD 16.000. Tarjeta 3: la alternativa para PH (“Lo construido y lo que dice el plano pueden no coincidir”).
Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu PH de José Pedro Varela al 3700: 2 ambientes renovados, con patio y sin expensas. Me tomé el trabajo de mirar los PH parecidos de Villa del Parque y armé un pequeño análisis: los de tamaño similar, de 2 ambientes con patio o terraza, se están publicando un poco por debajo de tu precio.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario):** Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los PH parecidos a tu PH de José Pedro Varela al 3700. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

Hola, ¡éxito en tu día! Te escribí hace unos días por el PH de José Pedro Varela. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo. Pensalo así: con lo que pedís hoy, el PH lleva casi un año publicado. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Un PH de 2 ambientes sin expensas lo busca mucho quien compra su primera vivienda, muchas veces con crédito hipotecario. Esa operación tiene sus tiempos y sus papeles (tasación del banco, aprobación del crédito), y acompañarla bien evita que se caiga a mitad de camino."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo."
