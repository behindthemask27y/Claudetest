# ID 56 · Monoambiente a estrenar con baulera (dirección no publicada, Comuna 11), Villa del Parque — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, monoambientes en Villa del Parque (Zonaprop 1 ambiente; en Argenprop el filtro de 1 ambiente trajo sobre todo 2 y 3 amb, sirvieron 2 avisos). Solo se usaron unidades **a estrenar o de pozo con precio y m² propios**). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Duplicados entre portales sacados; también el propio aviso. Aviso: https://www.zonaprop.com.ar/propiedades/clasificado/veclappa-dueno-vende-sin-comision-monoambiente-con-baulera-en-55574908.html

**Sujeto:** USD 105.000 · 41 m² totales (37 cubiertos) · USD 2.561/m² · 1 baño · baulera · contrafrente SE · en construcción, entrega prevista noviembre 2026 · porcelanato, cocina equipada · lo publica el dueño “sin comisión” · más de 365 días publicado (según la hoja). Expensas no informadas.

**Ojo:** No encontré el mismo monoambiente publicado por una inmobiliaria ni en Argenprop (primera página). El título dice “Dueño vende sin comisión”: el argumento de venta del dueño es justamente que el comprador no paga comisión.

## Números (calculados con código)
- 11 avisos: precio USD 65.000 a 103.900, mediana USD 86.000 (P25–P75: 78.444–94.500).
- USD/m² total (11 avisos con m² totales): mediana 2.256 (P25–P75: 2.121–2.324). El sujeto está a 2.561/m² (+14% contra la mediana).
- Parecidos en tamaño (31–51 m², 10 avisos): mediana USD 87.000 y **USD 2.282/m²**. El sujeto: 2.561/m², +12%.
- Los 3 más parecidos en tamaño: Av. San Martín 5200 (41 m², USD 89.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-monoambiente-villa-del-parque-a-60118293.html); Nazarre 2600 (40 m², USD 83.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-oportunidad-impecable-monoambiente-con-gran-balcon-59914279.html); Nazarre 2900 (42 m², USD 103.000, https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-monoambiente-categoria-en-villa-del-60045986.html).
- 10 m² a la mediana de la zona ≈ USD 22.600.
- Dato de precio en el mensaje: Sí dice “un poco por debajo de tu precio”: 10 monoambientes a estrenar/pozo de 31–51 m² con link, mediana USD 87.000 y USD 2.282/m²; el sujeto está a USD 2.561/m² (+12%).

## Tabla

| Dirección | USD | m² tot | m² cub | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|---|
| Av. Nazca 2500 | 94.500 | 47 |  | 2.011 | 1 | a estrenar, amenities, cochera opcional | ZP 57738049 |
| Nazarre 2600 | 83.000 | 40 |  | 2.075 | 1 | a estrenar, balcón aterrazado | ZP 59914279 |
| Av. Nazca 2600 | 70.000 | 33 |  | 2.121 | 1 | a estrenar, amenities | ZP 58446557 |
| Av. San Martín 5200 | 89.000 | 41 |  | 2.171 | 1 | a estrenar, balcón, pileta | ZP 60118293 |
| Argerich 1700 (b) | 65.000 | 29 |  | 2.241 | 1 | a estrenar | ZP 59159735 |
| Argerich 1700 | 88.000 | 39 |  | 2.256 | 1 | a estrenar, SUM, terraza | ZP 59159784 |
| Av. San Martín 4820 | 78.444 | 34 |  | 2.307 | 1 | en pozo, entrega sep-2027 | ZP 59226233 |
| Cuenca 2500, piso 1 | 103.900 | 45 | 36 | 2.309 | 1 | en construcción, entrega ene-2028 (también ZP 59971434) | AP 20322422 |
| Pedro Lozano 3100 | 86.000 | 37 |  | 2.324 | 1 | a estrenar, balcón | ZP 60262771 |
| Nazarre 2900 | 103.000 | 42 |  | 2.452 | 1 | en pozo, balcón aterrazado | ZP 60045986 |
| Av. San Martín 4600 | 83.000 | 32 |  | 2.594 | 1 | a estrenar, balcón, pileta | ZP 59115017 |

**Excluidos:**
- Llavallol 2500 · USD 91.000 · 36 m²: usado (1 año) (ZP 60246735)
- Melincué 3256 / Melincué 3200 p2 · USD 96.300 · 40 m²: estado no indicado (el edificio tiene 3 amb a estrenar); ZP 58454254 = AP 17536949 (ZP 58454254)
- Emilio Lamarca 2100, R. Gutiérrez 3300 y 3000, Av. Nazca 3100, Nogoyá 3200, Bolivia, San Nicolás 2000: estado no indicado (probablemente usados)
- Condarco 3129, Av. San Martín 4820 (ficha general), Nazca 3093, Cittadini 2390 (emprendimientos): precio 'desde', sin unidad concreta

## Pre-ACM
`ID56/PreACM_Monoambiente_Villa_del_Parque.pdf` (2 hojas). Rango USD 65.000–103.900, mediana USD 86.000, 10 m² ≈ USD 23.000. Tarjeta 3: la de deptos (“En un mismo complejo existen precios distintos. El estado, el piso, la orientación y la cochera suman o restan.”).
Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes

**1er contacto:**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu monoambiente a estrenar en Villa del Parque: 41 m², con baulera y entrega prevista para noviembre. Me tomé el trabajo de mirar los monoambientes a estrenar y de pozo de la zona y armé un pequeño análisis: los de tamaño similar se están publicando un poco por debajo de tu precio.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario):** Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los monoambientes a estrenar parecidos a tu monoambiente con baulera de Villa del Parque. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento:**

Hola, ¡éxito en tu día! Te escribí hace unos días por tu monoambiente a estrenar de Villa del Parque. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- "Te entiendo, y veo que lo publicaste “sin comisión” justamente para que le cierre al comprador. Pensalo así: así planteado ya lleva más de un año publicado, y en noviembre se entrega. Ahí pasa a competir con los monoambientes terminados de la zona. Mi trabajo es que llegues a ese momento con un precio bien fundado y con una presentación que le hable al comprador correcto."
- "Un monoambiente lo compra sobre todo un inversor que busca renta o alguien que va por su primera vivienda. Los dos comparan mucho y negocian con números en la mano. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla."
- "No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura, que en una unidad de pozo también implica coordinar con la desarrolladora. Es tu tiempo."
