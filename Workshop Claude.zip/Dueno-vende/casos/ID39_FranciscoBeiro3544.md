# ID 39 · Depto 2 amb a estrenar Francisco Beiró 3544, Villa Devoto — comparables para pre-ACM

Relevado el 4-oct-2026 en Zonaprop y Argenprop (primera página, 2 ambientes **a estrenar o en construcción** (el sujeto es a estrenar, así que se comparan nuevos con nuevos), Villa Devoto). MercadoLibre bloqueado desde acá. **CRM sin consultar.** Excluidos: los usados del listado, emprendimientos con precio “desde” (Beiró 3402 en rango, Chivilcoy 3395, Sanabria 2745, Av. San Martín 7433, Vallejos 3311), avisos de Zonaprop sin link legible (Pareja 3489, Sanabria al 3000, Gral. Paz al 6700, Pareja 3600 USD 382.000, C. A. López 3395) y duplicados entre portales.

**Sujeto:** USD 162.000 · 62 m² totales (54 cub.) · USD 2.613/m² · 2 amb, 1 dorm, baulera · a estrenar, entrega estimada nov-2026 · contrafrente SE · expensas sin dato. El aviso carga “2 baños + 1 toilette”, raro para 1 dormitorio: confirmar.

**Ojo:** El título dice “Dueño vende – sin comisión inmobiliaria” (no dice “abstenerse”). No lo encontré publicado por inmobiliaria ni en Argenprop en la primera página. Más de 365 días publicado con entrega en noviembre: el pozo se está terminando sin vender.

## Números (calculados con código)
- 16 avisos: precio USD 85.600 a 457.600, mediana USD 151.100 (P25–P75: 129.425–168.625).
- USD/m² total: mediana 2.946 (P25–P75: 2.579–3.332).
- Parecidos en tamaño (±25%, 11 avisos): mediana USD 155.000 y **USD 2.710/m²**. El sujeto está a 2.613/m², un 3,6% abajo.
- Los más parecidos: José Cubas 3362 (62 m², a estrenar, USD 168.000, [ZP 51700801](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-de-dos-ambientes-a-estrenar-en-villa-51700801.html)), Pareja 3400 (58 m², a estrenar, USD 155.000, [AP 19078130](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--19078130)) y Av. Francisco Beiró 3400 (52 m², en obra, misma avenida, USD 153.200, [AP 19586935](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--19586935)).
- 10 m² a la mediana de la zona ≈ USD 29.460.
- Lectura para el mensaje: **Precio en línea** con los parecidos por USD/m² (−3,6%), y por debajo de la mediana general de nuevos (−11%). El mensaje NO dice “por debajo de tu precio”.

## Tabla

| Dirección | USD | m² tot | USD/m² | Baños | Nota | Fuente |
|---|---|---|---|---|---|---|
| Av. Lope de Vega 2900 | 134.900 |  |  | 1 | a estrenar, terraza, patio (sin m² en el aviso) | [AP 17996524](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--17996524) |
| Navarro 4500 | 160.000 | 71 | 2.254 | 1 | pozo, balcón terraza, amenities | [ZP 60014759](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-2-ambientes-pozo-villa-devoto-60014759.html) |
| Carlos A. López 3400 | 121.000 | 52 | 2.327 | 1 | a estrenar, al frente, balcón | [ZP 59783146](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-frente-a-estrenar-2-ambientes-59783146.html) |
| Baigorria 4100 | 85.600 | 36 | 2.378 | 1 | pozo, monoambiente dividido, cochera | [ZP 59569373](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-monoambiente-dividido-villa-devoto-59569373.html) |
| Griveo 4100 | 128.000 | 50 | 2.560 | 1 | en construcción, terraza | [ZP 57375634](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-de-dos-ambientes-en-venta-devoto-57375634.html) |
| Gualeguaychú 4969 | 124.700 | 48 | 2.598 | 1 | nuevo, parrilla propia, pileta | [ZP 60252846](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin--venta-2-ambientes-devoto-parrilla-propia-60252846.html) |
| Pareja 3400 | 155.000 | 58 | 2.672 | 1 | a estrenar, piso radiante | [AP 19078130](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--19078130) |
| José Cubas 3362 | 168.000 | 62 | 2.710 | 1 | a estrenar, balcón aterrazado, parrilla, amenities | [ZP 51700801](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-de-dos-ambientes-a-estrenar-en-villa-51700801.html) |
| Av. Francisco Beiró 3400 | 153.200 | 52 | 2.946 | 1 | emprendimiento en obra (Beiró 3402), terraza, parrilla, piso 7 | [AP 19586935](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--19586935) |
| Carlos A. López 3500 | 129.900 | 43 | 3.021 | 1 | a estrenar, balcón | [ZP 60021986](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-depto-2-ambientes-lateral-con-balcon-villa-60021986.html) |
| Gabriela Mistral 3356 | 149.000 | 48 | 3.104 | 2 | a estrenar, cochera | [ZP 58930215](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-2-ambientes-con-cochera-a-estrenar-zona-devoto-58930215.html) |
| Chivilcoy 3300 | 170.500 | 52 | 3.279 | 1 | en construcción, balcón, piso 5 | [AP 18029383](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--18029383) |
| Bahía Blanca 2600 | 145.600 | 43 | 3.386 | 1 | a estrenar (1 año), balcón | [AP 17635351](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--17635351) |
| Pareja 3600 | 457.600 | 128 | 3.575 | 1 | a estrenar, jardín privado, complejo con amenities | [ZP 59723178](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-venta-departamento-en-villa-devoto-2-ambientes-a-59723178.html) |
| José Luis Cantilo 4600 | 215.000 | 58 | 3.707 | 1 | a estrenar, patio, amenities, pileta | [AP 14941359](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--14941359) |
| Av. S. M. del Carril 5000 | 223.000 | 53 | 4.208 | 1 | a estrenar, amenities, pileta | [AP 15800595](https://www.argenprop.com/departamento-en-venta-en-villa-devoto-2-ambientes--15800595) |

## Pre-ACM
`ID39/PreACM_Francisco_Beiro_3544.pdf` (2 hojas). Rango USD 85.600–457.600, mediana USD 151.100, 10 m² ≈ USD 29.000. Tarjeta 3 para deptos: “En un mismo edificio puede haber precios distintos. / El estado, el piso, la orientación y la cochera suman o restan.” Sin “Según tu descripción”, porque los datos salen del aviso y no del dueño.

## Mensajes
**1er contacto**

Hola, espero que andes bien. Soy Cristian Stedtfeld, agente inmobiliario de Red Suma.
Vi tu departamento de Francisco Beiró al 3500: 2 ambientes a estrenar de 62 m², con baulera y entrega en noviembre. Me tomé el trabajo de mirar los 2 ambientes a estrenar y en construcción de Villa Devoto y armé un pequeño análisis: tu precio está en línea con los parecidos, así que lo que puede estar frenando la venta es otra cosa, como la presentación o a quién le llega el aviso.
Si te sirve, te lo mando sin cargo y sin compromiso, y si querés lo charlamos 15 minutos.
¿Te lo paso?

Cristian Stedtfeld · Agente inmobiliario · Red Suma

**Corto (formulario del portal)**

Hola, espero que andes bien. Soy Cristian Stedtfeld, de Red Suma. Armé un análisis sin cargo de los departamentos parecidos a tu departamento de Francisco Beiró al 3500. ¿Te lo mando por WhatsApp? Mi número es +54 9 11 6695-1945.

**Seguimiento**

Hola, ¡éxito en tu día! Te escribí hace unos días por el departamento de Francisco Beiró. El análisis de la zona sigue a tu disposición, sin compromiso. Si te interesa, avisame y te lo paso.

Cristian · Red Suma

## Si dice "no quiero pagar comisión" (para Cris)
- “Te entiendo, y sé que lo publicaste justamente sin comisión. Pensalo así: con lo que pedís hoy, lleva más de un año publicado y la entrega ya es en noviembre. Cada mes que pasa es un mes más esperando. Mi trabajo es acortar ese tiempo con un precio bien fundado y con una presentación que le hable al comprador correcto.”
- “Un 2 ambientes a estrenar lo busca sobre todo un inversor que mira la renta o alguien que compra su primera vivienda, y cada uno negocia distinto: plazos, forma de pago, fecha de entrega. Una buena negociación suele cubrir de sobra lo que cuesta acompañarla.”
- “No es solo publicar: es filtrar curiosos, coordinar visitas, negociar y acompañarte con los papeles hasta la escritura. Es tu tiempo.”
