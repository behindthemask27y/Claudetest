# Meta Ads – contexto para seguir trabajando

Manual para retomar las campañas de Meta (Facebook/Instagram) de Cris sin volver a preguntar lo ya definido. Última actualización: 9-oct-2026.

## Objetivo de Cris
- Leads de **alta calidad**. Los que tenía eran malísimos.
- Canales: WhatsApp, formularios instantáneos y web.
- Campañas separadas por público: propietarios (captación), compradores y remarketing. Nada de una campaña general.
- Presupuesto **total de $10.000 ARS por día** para probar, con presupuesto por campaña (Meta lo reparte entre los conjuntos).
- Zona: CABA cerca de Villa del Parque (incluye Belgrano, Núñez y Colegiales) + Zona Norte (Vicente López, Olivos, Martínez, San Isidro, Tigre, Munro, San Martín y alrededores). **Radios chicos**: "no me mandes a 45 km".

## Cuenta (todo en el Chrome de Cris, con su sesión)
- Cuenta publicitaria **"IG Real Estate"**: act=2105334063528925, business_id=1439717201317750. Ads Manager abre por defecto otra cuenta vacía (1579334669347554): cambiar siempre a la de IG Real Estate.
- Página de Facebook "CS Real Estate", Instagram "cristian.sted". El WhatsApp de Cris ya está conectado a la página (9-oct-2026).
- Píxel "Datos web csrealestate.com.ar" (evento Cliente potencial), cargado por Google Tag Manager.
- Política de privacidad para formularios: https://csrealestate.com.ar/#privacy-policy
- **"Vivienda" (categoría especial): NO va.** Es obligatoria solo para EE. UU., Canadá y parte de Europa. La campaña vieja "META_1_Leads_Propietarios" estaba marcada como Vivienda, lo que fuerza un público amplio (radio de unos 25 km, todas las edades): probable causa de los leads malos.

## Reglas de trabajo
- Todo se arma en pausa o en borrador. **Pedir el OK de Cris antes de cada "Publicar"** y antes de activar o pausar campañas (gastan plata). Nunca poner contraseñas ni datos de tarjeta.
- Al entrar ya había **4 borradores de Cris sin publicar** ("Revisar y publicar (4)"). No tocarlos ni publicarlos. Al 9-oct-2026 quedan 3: un conjunto y los anuncios viejos "Ad_Alquilar_1" y "Ad_Tasacion_1", con errores. Se le sugirió a Cris descartarlos él mismo.
- Publicar desde el botón "Publicar" del editor de la campaña (publica solo esa), no desde "Revisar y publicar".
- La campaña vieja **META_1_Leads_Propietarios sigue ACTIVA** (con Vivienda). Cuando salga Propietarios, recomendar pausarla (con OK de Cris) para no pasarse de los $10.000 por día.

## Textos (ver también la memoria "copy-ads-no-generico")
- Decir **CABA**, nunca "Capital". **No nombrar barrios ni zonas** en los textos: eso lo define la ubicación.
- Nada genérico tipo "¿Pensás vender tu propiedad en…?". Cada texto sale de algo que Cris hace distinto. No inventar datos ni testimonios.
- Cris **no** hace video recorrido de todas las propiedades: no prometerlo.
- No usar "tasación" ni "gratis" (atrae curiosos). Decir "análisis de mercado".
- En alquileres, Cris prefiere **no poner el precio** en el texto, para que le pregunten.

## Estado al 9-oct-2026

### 1. Alquiler – Local Nazca 4501 · PUBLICADA (quedó en revisión)
- Clientes potenciales, $5.000 por día, sin fecha de fin (pausarla cuando se alquile).
- Conjunto "Local Nazca - WhatsApp": dirección 4501 Nazca + 4 km, edad mínima 25. Para encontrarla en Meta se busca "Nazca 4501, Villa Pueyrredón, CABA" y se elige la opción "Dirección" (coordenadas -34.5877, -58.5008).
- Anuncio "Video recorrido IG": reel de Instagram del 8-oct (Cris editó el pie). Plantilla de chat "Local Nazca 4501":
  - Bienvenida: "¡Hola! Gracias por tu consulta. Ya te paso la info del local."
  - Mensaje ya escrito: "Hola, vi el video del local de Nazca 4501. Quiero más información."

### 2. Propietarios - Captación · PUBLICADA 9-oct-2026 (solo el conjunto Formulario; el clic final de "Publicar" lo hizo Cris porque el sistema bloquea ese clic al asistente)
- Mejoras automáticas de Meta APAGADAS en los 5 anuncios (contenido 0/5, esenciales 0/3), por pedido de Cris. Para apagarlas: "Revisar opciones predeterminadas" → "Editar" → en el diálogo, destildar todos los `input[type=checkbox]` menos el primero ("Todas las optimizaciones") y tocar "Guardar".
- META_1_Leads_Propietarios: la pausó Cris.
- Clientes potenciales, $5.000 por día de campaña, sin categoría especial.
- Conjunto **"Propietarios - Formulario"**: formularios instantáneos, edad mínima 25 (Meta no deja poner más de 25), 21 códigos postales:
  - CABA: C1416, C1417, C1419, C1426, C1427, C1428, C1429, C1430, C1431
  - Zona Norte: B1602, B1603, B1605, B1607, B1636, B1638, B1640, B1642, B1643, B1648, B1650, B1653
  - B1604 (Florida Oeste) y B1641 (Acassuso) no existen en Meta.
- Formulario **"Propietarios - Mayor intención oct-2026"**: mayor intención + verificación del teléfono por SMS + entrega flexible desactivada.
  - Saludo: "Antes de vender, mirá los números de tu zona" / "Contame un poco de tu propiedad. Te escribo por WhatsApp y te muestro qué se vendió cerca y a cuánto, para que decidas con datos."
  - Preguntas: ¿Qué querés hacer? (Vender / Vender y comprar otra / Por ahora, conocer el valor) · ¿Qué tipo de propiedad es? (Depto / Casa / PH / Local u oficina / Terreno) · ¿Cuándo pensás vender? (En los próximos 3 meses / De 3 a 6 meses / Más adelante) · ¿En qué barrio o localidad está? (respuesta breve).
  - Final: "¡Gracias! Ya tengo tus datos." + botón a WhatsApp.
  - El formulario viejo "VENDER_Propiedad_Meta" queda sin usar.
- Anuncios. Todos con descripción "Red Suma · CABA y Zona Norte", botón "Más información" y el flyer en versión feed (1080x1350) de `Flyers ADS/`:

| Anuncio | Estado | Flyer | Título | Texto principal |
|---|---|---|---|---|
| Precio - flyer 04 | hecho | 04A | Preguntá de dónde sale el precio | Si tres inmobiliarias te dieron tres precios distintos, preguntales de dónde sale cada número. Yo te muestro lo que de verdad se vendió cerca de tu propiedad y lo que se pagó. Con eso decidís vos. |
| Meses publicada - flyer 01 | hecho | 01A | Meses publicada se paga al negociar | Cuando un aviso lleva meses en los portales, los compradores empiezan a preguntarse qué problema tiene. Y la negociación arranca con vos a la defensiva. Salir con el precio correcto desde el primer día te ahorra eso. |
| Herencia - flyer 06 | hecho | 06A | Herencia ordenada, venta tranquila | ¿Heredaste con tus hermanos y cada uno quiere una cosa distinta? Antes de publicar ordenamos papeles, tiempos y números, con el respaldo legal de Red Suma. |
| Mudanza - flyer 05 | hecho | 05A | Vendé y comprá con las fechas atadas | ¿Vendés para comprarte otra? El riesgo está en las fechas: firmar la venta sin tener a dónde ir, o reservar sin haber vendido. Eso se planifica antes de publicar. |
| Vos - flyer 10 | hecho | 10A | Un precio que venda, aunque no guste | Mi trabajo depende de que me recomiendes. Por eso prefiero decirte un precio que no te gusta antes que uno que no vende. Soy Cristian, de Red Suma. |

- **Pendiente:**
  1. El conjunto "Propietarios - WhatsApp": duplicar el conjunto, pasar la ubicación de la conversión a WhatsApp y armar la plantilla de chat con un mensaje ya escrito tipo "Hola, quiero vender mi propiedad. ¿Cómo trabajás?". Se suma más adelante, porque con $5.000 por día dos conjuntos aprenden peor.
  2. 9-oct-2026: se cambiaron los flyers donde aparecía Cris. 04 ahora va con la foto 107 y el título "Vender bien no es vender barato." (el anterior daba a entender que vende barato). 10 va con la foto 80 de fondo. En Meta se subieron como "04A v2 - Vender bien - feed.png" y "10A v2 - Recomiendes foto 80 - feed.png" (copias en `Flyers ADS/_subir`) y se cambiaron en los anuncios Precio y Vos; el "Publicar" lo hace Cris. Para flyers nuevos (Compradores, etc.) Cris quiere usar fondos de su lista. Para elegir hay una hoja numerada de las 139 fotos en `Flyers ADS/Hoja de fotos de fondo.jpg`, con el índice de archivos en el .txt del mismo nombre. Después hay que reemplazar las imágenes en los anuncios.
  3. Al publicar, el clic final de "Publicar" lo tiene que hacer Cris (el sistema se lo bloquea al asistente).

## Próximas etapas (acordadas)
- Cuando termine el alquiler del local, sus $5.000 pasan a **Compradores**: usados por WhatsApp y formulario "Qué buscás", y pozo por WhatsApp. Textos ya aprobados en estilo:
  - "Lo que el aviso no dice": "Luminoso" que da a un pozo de aire, "a metros del subte" que son ocho cuadras.
  - "Sábados perdidos".
  - "Antes de ofertar".
- **Pozo:** Cris tiene obras en la sección "desarrollos" de su web. Hacer un carrusel con las tarjetas de cada obra. Los textos de "quién construye" o "costo total" van solo si él tiene esos datos.
- **Web:** campaña de contactos con el píxel (página "vender" y página de propiedades).
- **Remarketing:** se arma, pero queda pausado.
- **Contenido:** Cris va a grabarse hablando a cámara. Escribirle guiones con los mismos ángulos y después cambiar los videos dentro de las campañas.
- **Pulido pendiente** (Cris quiere pulirlo): textos, versiones story 1080x1920 de los flyers y preguntas del formulario.
- A las 2 semanas: mirar costo por contacto y **cuántos sirven de verdad**, y redistribuir.
- **Google Ads:** Cris ya tiene cuenta y campañas armadas con ChatGPT que traen leads malos. Las va a pasar para pulirlas. Lo que se le explicó (9-oct-2026): Google y Meta no comparten datos entre sí, el puente es la web. Si la gente que llega desde Google entra a csrealestate.com.ar, el píxel de Meta la registra y se le puede volver a mostrar anuncios en Meta (Remarketing, "visitas web", que se puede filtrar por gclid o utm_source=google). También se pueden subir listas de contactos a las dos plataformas y devolverles qué leads fueron buenos (conversiones offline o del CRM), para que cada una aprenda a traer mejores. Para que funcione, Google tiene que llevar a la web y no a formularios de Google.

## Trucos técnicos del Administrador de anuncios (Claude in Chrome)
- **Coordenadas:** las capturas usan un cuadro de 1568 px y la página mide 1920 px CSS (factor 0,8167). Para ubicar un botón: buscarlo por texto con JS, hacer `scrollIntoView` y multiplicar por 0,8167.
- **Capturas que fallan:** a veces dan error de tiempo después de hacer scroll. Usar `find` o JS para leer; `read_page` y `get_page_text` sirven poco en esta página.
- **Subir imágenes sin la ventana de Windows:** antes de tocar "Subir", parchear `HTMLInputElement.prototype.click` para que el input de archivo se agregue al DOM con `aria-label="claude-file-input"` en vez de abrir la ventana. Después buscar ese input y usar `file_upload` (máximo 10 MB por llamada). Así se subieron los 5 flyers juntos a la biblioteca de la cuenta.
- **Videos de más de 10 MB:** no se pueden subir así. Usar la publicación de Instagram ya publicada ("Usar publicaciones ya existentes"); Meta la pasa sola a Facebook.
- **Zonas por código postal:** en Lugares → "Agregar lugares de forma masiva" → Códigos postales, país Argentina, con formato C#### para CABA y B#### para Provincia. Los códigos de 4 números solos no funcionan.
- **Edad mínima:** el control no deja pasar de 25.
- **Duplicar un anuncio:** "…" del anuncio en el árbol → "Duplicar rápidamente". Desmarcar la sugerencia de agregar música y tocar "Duplicar".
- **Al terminar un anuncio:** los pasos son Contenido multimedia → Texto → Generación de imágenes (no elegir imágenes de IA) → Mejoras → OK.
- **Ojo al publicar:** el "Publicar" del editor publica solo el anuncio que está abierto. Después de publicar, revisar en la pestaña Anuncios que ninguno haya quedado en "Borrador". Para publicar varios: tildarlos en la lista y que Cris toque "Publicar" en la barra. Así pasó el 9-oct-2026 con 4 de los 5 anuncios de Propietarios.
- **Ver resultados del día:** el rango de fechas por defecto ("Últimos 30 días") NO incluye hoy. Elegir "Hoy" en el selector de fechas o agregar `&date=AAAA-MM-DD_AAAA-MM-DD%2Ctoday` a la URL. 9-oct-2026: el local registró la primera conversación de WhatsApp a las pocas horas ($583 gastados, 91 impresiones).
- **Mensaje ya escrito de WhatsApp:** a veces no se guarda al primer intento. Volver a "Editar" la plantilla, borrar, escribir, salir del campo con Tab y guardar.
