# Google Ads – contexto para seguir trabajando

Cuenta "CS Real Estate" (921-755-2199). Cris la armó con ChatGPT (ver `Contexto ChatGPT 2026-10-09.txt`). Trae leads, pero malos: 15 formularios sin ninguna oportunidad real. Última revisión: 9-oct-2026, con el export de Google Ads Editor y el informe de términos de búsqueda del 11-sep al 8-oct.

## Cómo se trabaja
- Los cambios se hacen con archivos CSV para **Google Ads Editor**, que importa Cris. Gasta muchos menos créditos que operar desde el navegador.
- El navegador solo para lo que no se importa (conversiones, GTM o GA4, vinculaciones).
- No cambiar presupuestos, pujas, objetivos, zonas ni medición sin explicarlo y sin el OK de Cris (lo pidió explícitamente).
- Textos: misma regla que Meta. Decir "análisis de mercado", no "tasación"; decir CABA, no "Capital". "Tasar" sí puede usarse como palabra clave, porque es lo que busca la gente.

## Estado al 9-oct-2026
- **Activas:**
  - #Search_1_vendedores: $1.000 por día
  - #Search_2_valor_propiedad: $3.000
  - #Search_4_compradores: $1.000
  - #Search_11_whatsapp_general: $1.500, objetivo propio OBJ_WhatsApp_Click
  - #Search_12_portales: $500, Maximizar clics, unas 300 palabras de portales (zonaprop, argenprop…)
  - Una "Campaign #1" de Búsqueda figura activa con presupuesto 0, AI Max, red de Display y toda Argentina: revisar qué es.
- **Pausadas:** alquiler propietarios, inquilinos, marca, locales (2), desarrollos, inversión y una PMax "Campaign #1".
- **Zonas:** dos radios de 6 km, centrados en (-34.590, -58.484), Villa del Parque/Devoto, y en (-34.495, -58.483), Zona Norte.
- **Destino:** todos los anuncios van a la home https://csrealestate.com.ar/ porque Cris lo pidió así. Los formularios están en /form/vender/, /form/tasacion/, /form/comprar/, /form/alquilar-mi-propiedad/ y /form/buscar-alquiler/.
- **Conversiones:**
  - Principal: GA4 `generate_lead`, que es el envío exitoso de CUALQUIER formulario de la web. 17 en 30 días.
  - Secundarias: click_whatsapp y click_form.
  - El formulario de Google, en versión "Más volumen", está en Vendedores y Campaign #1.
- **Resultados (30 días):** $85.821 gastados, 86 clics y 9 conversiones. 5 de esas conversiones son de Valor propiedad.

## Diagnóstico (por qué los leads son malos)
1. **Medición:** `generate_lead` cuenta igual a quien quiere vender y a quien busca alquiler. Google aprende a traer cualquier formulario.
2. **Búsquedas de curiosos:** quienes buscan una "tasación online gratis" o "simulador", o "precio metro cuadrado por barrio", quieren un número gratis, no un agente. De ahí salen la mayoría de las conversiones de Valor propiedad, que además es la campaña con más presupuesto.
3. **Portales:** el término más caro fue "zonaprop" ($10.939, 14 clics). Esa gente va a buscar avisos. Ahora es negativa en Vendedores, pero la campaña Portales le apunta a propósito.
4. **Fuera de zona o de intención:** búsquedas de Mar del Plata, Moreno, Lugano, Avellaneda, alquileres, "casa en cuotas" y "compramos tu casa".
5. **Concordancia amplia** en Vendedores (16 palabras) con Maximizar conversiones, que abre a búsquedas parecidas.
6. **Todo va a la home:** el que busca "cuánto vale mi casa" cae en una página general y completa el formulario que encuentra.

## Plan propuesto (esperando OK de Cris)
Ver el mensaje del 9-oct-2026 en el chat: separar las conversiones por formulario, mandar cada campaña a su formulario, armar una lista de negativas compartida, sacar la concordancia amplia, pausar Portales y revisar Campaign #1, pasar el formulario de Google a "Mayor intención" y, más adelante, avisarle a Google qué leads fueron buenos (desde el CRM).
