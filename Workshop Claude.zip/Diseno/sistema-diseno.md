# Sistema de diseño — Cristian Stedtfeld · Red Suma

Sistema único para toda pieza para clientes en PDF A4 (ACM, pre-ACM, reporte de búsqueda y las que se sumen).
**Todo lo que figura acá está medido desde los archivos aprobados, no de memoria:**

- `ACM/generar_acm.py` (v2.0): CSS, `page()`, `tarjeta()`, `MARCA`, recursos embebidos.
- `pre-ACM/generar_preacm.py`: `CSS_PRE` y `construir_html()`. Las medidas se tomaron de la v1.1; la v1.2 pasa a 2 hojas con las medidas del ACM (ver sección 8).
- `Manual brand CS/Manual_de_marca_CS.md` y `ACM/02_Manual_de_marca_reportes.md`.
- Medición: los dos ejemplos de los generadores (`--ejemplo`) renderizados en Chromium a 794 × 1123 px. Las posiciones son las que da el navegador.

**Unidades.** Los generadores trabajan en px de CSS (96 por pulgada). Para pasar a pt: **pt = px × 0,75**. Para pasar a mm: **mm = px × 0,2646**.

La plantilla de código es `Diseno/plantilla_base.py`. Los generadores del ACM y del pre-ACM no se tocan.

---

## 1. Colores

Todos están en el CSS de `generar_acm.py` (`:root`) y coinciden con los dos manuales.

| Token CSS | HEX | Dónde va (según el código) |
|---|---|---|
| `--ink` | `#171717` | Títulos Goodtime, encabezados de sección (`.h2`), "AGENTE INMOBILIARIO", letras del logo "CS.", número de página, nombre en Chillax |
| `--txt` | `#2B2B34` | Color de cuerpo (`body`), direcciones, fila de datos, párrafos |
| `--gray` | `#6A6A6A` | Etiquetas en mayúsculas (`.lbl`), meta de tarjeta ("Venta · Casa · Zonaprop"), notas (`.small`), cargo |
| `--card` | `#DBDBDB` | Fondo de tarjetas, cajas KPI, caja de contacto, pista de la barra de rango |
| `--navy` | `#253C64` | Precios de tarjeta, valores KPI, pill, barra de rango, botón de WhatsApp, caja "YO", número de WhatsApp |
| `--navy2` | `#1F2A5C` | Cifra protagonista: los tres valores de "Valor sugerido" (ACM) y el rango (pre-ACM) |
| `--gold` | `#988355` | Subtítulo, USD/m², línea del pie, punto del logo, borde de "Para tener en cuenta", íconos, bordes de pines, regla corta |
| `--gold2` | `#AD8A48` | Separadores verticales (Valor sugerido), marcador de promedio o mediana en la barra, filete del remate (pre-ACM) |
| `--goldtxt` | `#8A6A2F` | Texto dentro del badge crema |
| `--cream` | `#FBF0D9` | Fondo del badge ("Tu propiedad", "Vendida mmm-aaaa"); rótulo "YO" del pre-ACM |
| `--red` | `#FF5F5F` | Solo variación negativa de precio ("-4,1% del valor publicado") |
| — | `#7D6531` | Pin "Tu propiedad" en el mapa (ACM) |
| — | `#FFFFFF` | Tarjeta de portada, hero del pre-ACM, "Para tener en cuenta", pines del mapa, texto de pill y botón |
| Fondo de página | degradé radial `#FFFFFF` 0% → `#F7F7F7` 45% → `#ECECEC` 100% (elipse 75% × 60%, centro 50% 52%) | Todas las páginas |

Grises de apoyo que usa el código (no figuran en los manuales): `#D2D2D2` (borde de cajas de portada), `#E4E4E4` (borde de tarjetas blancas del pre-ACM), `#F2F2F2` / `#E6E6E6` (borde de la tarjeta de propiedad), `#C9C9C9` (fondo de foto vacía), `#8A8A8A` (precio tachado, crédito de foto), `#222` (texto del pie legal).

**Reglas** (de los dos manuales): no hay verde ni otros colores. El rojo va solo en negativos. El dorado es siempre un acento, nunca un bloque grande.

## 2. Tipografías

Las cinco van embebidas en `generar_acm.py` (`__ASSETS__`, WOFF2 en base64), así que no se necesita internet.

| Fuente (nombre en el CSS) | Recurso | Peso | Uso |
|---|---|---|---|
| Goodtime Grotesk (`Goodtime`) | `goodtime` | 400 | Títulos con punto final, número de página, frase "No tomo todas…" del pre-ACM |
| Chillax (`ChillaxCS`) | `chillax-600` | 600 | Solo "Cristian Stedtfeld" |
| Montserrat (`MontserratCS`) | `montserrat-600` | 600 | Solo "AGENTE INMOBILIARIO" del header |
| Arial (`ArialCS`) | `arial-400`, `arial-700` | 400 / 700 | Todo lo demás: cuerpo, datos, cifras y etiquetas |
| Inter (`InterCS`) | `inter-400` | 400 | Pie legal y aclaración chica del pre-ACM |

Licencia: Goodtime Grotesk es "Personal Use". Los dos manuales piden comprar la licencia comercial para piezas que se entregan a clientes.

### Tamaños por nivel

| Nivel | ACM (`generar_acm.py`) | pre-ACM (`generar_preacm.py`) |
|---|---|---|
| Título de página (Goodtime) | 31 px = **23,25 pt**, interlineado 1,0 (31 px), tracking 0,005 em, espacio entre palabras -0,14 em | igual |
| Subtítulo dorado (Arial Bold) | 15,2 px = **11,4 pt**, interlineado normal, 22 px debajo del título | 15 px = **11,25 pt**, interlineado 19 px, 13 px debajo del título |
| Encabezado de sección (`.h2`, Arial Bold, mayúsculas) | 16,5 px = **12,4 pt**, tracking 0,12 em | 11 px = **8,25 pt**, tracking 0,2 em |
| Cuerpo (Arial) | 11,3 px = **8,5 pt**, interlineado 17 px (1,5) | 11 px = **8,25 pt**, interlineado 15,5 px (1,41) |
| Etiquetas (`.lbl`, Arial Bold, mayúsculas, gris) | 9,4 px = **7,05 pt**, tracking 0,2 em | igual |
| Notas (`.small`) | 9,6 px = **7,2 pt**, gris | 9,4 px en contacto y datos |
| Valor KPI (`.val`) | 20,5 px = 15,4 pt, interlineado 1,15, azul marino | 18 px (KPIs opcionales) |
| Cifra protagonista | 19 px (Valor sugerido, `#1F2A5C`) | 36 px = **27 pt**, interlineado 40 px (rango, `#1F2A5C`) |
| Nombre (Chillax) | 19 px = **14,25 pt** | 20 px = **15 pt** |
| Pie legal (Inter) | 7,7 px = **5,8 pt**, interlineado 18 px | igual |
| Número de página (Goodtime) | 27 px = **20,25 pt**, interlineado 1,0 | igual |

Tarjeta de propiedad (ACM): precio 19,6 px / 24 px · dirección 15 px Bold / 20 px · meta y datos 12,2 px / 19 px · USD/m² 12,2 px Bold dorado.

## 3. Hoja, márgenes y grilla

- **Hoja:** A4 vertical, `@page{size:A4;margin:0}`: 210 × 297 mm = 794 × 1123 px = 595,5 × 842,25 pt. Imprime los fondos (`print-color-adjust:exact`).
- **Márgenes laterales:** 65 px = 48,75 pt = 17,2 mm. **Ancho útil:** 664 px = 498 pt = 175,6 mm.
- **Arriba:** el header empieza a 72 px (19,05 mm). El contenido (`.content`) arranca a **183 px** (137,25 pt = 48,4 mm).
- **Abajo:** la línea del pie va a **1056 px** (792 pt = 279,4 mm). El contenido tiene que terminar antes.
- **Grillas que se usan** (separación entre columnas):
  - 3 columnas con 6 px: KPIs, contexto de mercado y tarjetas "dato grande".
  - 2 columnas con 6 px: VOS / YO.
  - 2 columnas con 16 px: posicionamiento y "Para tener en cuenta".
  - 2 columnas con 26 px: checklist.
  - Portada del ACM: 263 + 292 px con 43 px.
- **Espacios verticales (ACM):** 22 px entre título y subtítulo, 12,4 px entre tarjetas, 28 a 35 px antes de cada encabezado de sección.

## 4. Header (igual en ACM y pre-ACM, `page()` de `generar_acm.py`)

| Elemento | Posición (desde el borde de la hoja) | Medida |
|---|---|---|
| Logo "CS." (`logo_cs`, SVG) | izquierda 65 px · arriba 72 px | alto 38 px → 86,7 × 38 px = 65 × 28,5 pt = 22,9 × 10,1 mm |
| "AGENTE INMOBILIARIO" | alineado a la derecha (derecha 65 px), arriba 79 px | Montserrat SemiBold 10,3 px = 7,7 pt, tracking 0,34 em, `#171717` |
| "·" | entre el rótulo y el logo, separación de 13 px | Montserrat SemiBold 12 px |
| Logo Red Suma (`logo_redsuma`, SVG) | derecha 65 px · arriba **82 px** (79 px del bloque + **3 px más abajo**) | ancho 97 px → 97 × 18,9 px = 72,75 × 14,2 pt = 25,7 × 5,0 mm |

**Regla fija (Cris, 2-oct-2026): el logo de Red Suma va 3 px más abajo** que el centro del bloque, para que la base de "REDSUMA" quede alineada con la de "AGENTE INMOBILIARIO". Se aplica **siempre**, en todo documento nuevo. En el código: `.hdr-right img{…;position:relative;top:3px}`, que ya está en `generar_acm.py` (y por eso en el pre-ACM) y en `plantilla_base.py`.

## 5. Footer (igual en ACM y pre-ACM, `page()` de `generar_acm.py`)

| Elemento | Posición | Medida |
|---|---|---|
| Línea dorada | arriba 1056 px, de 65 px a 65 px de los bordes | 1,7 px (1,3 pt) `#988355` |
| Leyenda legal, línea 1 | 8 px debajo de la línea | Inter 7,7 px (5,8 pt), interlineado 18 px, `#222`: "Los corredores públicos intermedian y concluyen todas las operaciones. Los agentes operan bajo el control y supervisión de un corredor público." |
| Matrícula, línea 2 | debajo de la línea 1 | igual: "Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609" |
| Número de página | a la derecha, 9 px debajo de la línea | Goodtime 27 px (20,25 pt), `#171717`. Formato `01`, `02`; continuaciones `03.1`; anexo `00` |

**Matrícula (Cris, 4-oct-2026).** Dato legal completo: VL REALTOR S.R.L. · Corredor responsable: Diego Enrique Mastrangelo — CUCICBA 7615 · CMCPSI 6609. Nunca va pegada al nombre de Cris como si fuera suya: siempre dice "Corredor responsable". Se usa así, según la pieza:
- **PDF y documentos A4** (pie legal, línea 2): "Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609".
- **Fotos, redes y piezas chicas**, donde no entra la línea entera: "Corredor resp.: VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609". En la web, el nombre del corredor puede ir dentro de un botón o desplegable, como ya lo tiene Cris.
- **Mensajes de WhatsApp:** sin firma y sin matrícula (Cris, 6-oct-2026).

El **contacto no va en el footer**. Va en un bloque propio (sección 7): WhatsApp +54 9 11 6695-1945 · cstedtfeld@redsuma.com.ar · csrealestate.com.ar.

## 6. Logos

- Los dos están **embebidos como SVG** en `generar_acm.py` (`__ASSETS__['logo_cs']` y `['logo_redsuma']`). No hay archivos de imagen aparte en el proyecto.
- "CS.": viewBox 1811,5 × 793,9, colores `#171717` + `#988355`. Está recreado con tipografía; si Cris manda el original, se reemplaza.
- Red Suma: viewBox 3272 × 638, colores `#988355` + `#000`. Es el vector trazado del logo oficial.
- El "CS." va **una sola vez por página** (header). La tarjeta de contacto no lleva logo.

## 7. Componentes que se repiten

| Componente | Medidas (del código) | Dónde |
|---|---|---|
| **Título + subtítulo** | Goodtime 31 px con punto final + subtítulo dorado bold (ver tabla de tamaños) | ACM y pre-ACM |
| **Caja KPI** (`.box`) | fondo `#DBDBDB`, radio 5 px; etiqueta `.lbl` arriba, valor `.val` azul marino, nota `.small`. En el resumen: 214 × 90 px, padding 21/15 px | ACM (pre-ACM opcional, 71 px de alto) |
| **Tarjeta de propiedad** (`tarjeta()`) | 664 × 122,6 px, fondo `#DBDBDB`, borde 1,3 px `#F2F2F2`, radio 4 px. Foto 155 × 103 px a 10,2 / 9,2 px, radio 15 px, `object-fit:cover`. Texto desde x = 182 px. Hasta 5 por página, separadas 12,4 px | ACM |
| **Badge** | 153,5 × 31 px, a 16 px de arriba y de la derecha de la tarjeta, fondo `#FBF0D9`, texto `#8A6A2F` Bold 11,4 px, radio 6 px | ACM |
| **Variación de precio** | debajo del badge (arriba 57 px), 153,5 px de ancho, rojo Bold 11,2 / 13,5 px, dos líneas | ACM |
| **Botón "Ver aviso"** (`.lk`) | 153,5 × 26 px, a 16 px de la derecha y 13 px de abajo de la tarjeta; borde 1,2 px `#253C64`, radio 6 px, sin relleno; texto "Ver aviso" centrado, `#253C64` Bold 11,4 px, sin flecha. Es el único link clickeable de la tarjeta (la foto no). Solo en comparables publicados con `link`; nunca en vendidas ni en "Tu propiedad". Aprobado por Cris el 6-oct-2026 | ACM |
| **Pill** | cápsula `#253C64`, texto blanco Bold, mayúsculas, tracking 0,2 em, radio 20 px. Portada ACM: 27 px de alto, 8,3 px de letra. Checklist y pre-ACM: 24 px de alto, 8 px de letra, alineada a la derecha del título | ACM y pre-ACM |
| **Regla dorada corta** | 80 × 2,8 px `#988355` | Portada ACM |
| **"Para tener en cuenta"** (`aclaraciones_html()`) | fondo blanco, borde 1,5 px dorado, radio 6 px, padding 12/16 px; 2 columnas con 16 px; círculo "!" de 17 px con borde dorado; texto 11 / 15,5 px | ACM y pre-ACM |
| **Caja con borde dorado** (`.sample`) | borde 2,2 px dorado, radio 6 px, fondo blanco, texto dorado 11,2 / 14,5 px | ACM (muestras) |
| **Tarjeta de contacto, ACM** (`.contact`) | caja `#DBDBDB`, radio 5 px, padding 20/22 px; nombre Chillax 19 px; "Agente inmobiliario · Red Suma" gris 10,5 px; a la derecha, WhatsApp (azul) / mail / web en 11 / 18 px | ACM pág. 05 |
| **Contacto + botón de WhatsApp, pre-ACM** (`.cta` + `.btn`) | caja `#DBDBDB`, radio 5 px, padding 9/20 px; nombre Chillax 20 px; cargo y datos en 9,4 px debajo. Botón: 40 px de alto, radio 30 px, `#253C64`, texto blanco Bold 11 px, tracking 0,16 em, mayúsculas, flecha "→" de 14 px. Link `https://wa.me/5491166951945?text=…` con mensaje precargado. En `plantilla_base.py` y en `generar_preacm.py` (v1.4) la flecha es un SVG (`FLECHA`, 14 × 10 px, trazo 1,5 px) centrado con las mayúsculas del texto (Cris, 2-oct-2026) | pre-ACM |
| **Barra de rango** | ACM: pista 17 px, radio 9 px, relleno azul hasta el promedio, marcador 4,5 × 26 px `#AD8A48`, flecha "SUGERIDO". pre-ACM: pista 9 px, banda azul P25–P75, un punto blanco de 10 px con borde dorado por aviso, marcador 3,4 × 19 px en la mediana | Cada uno el suyo |
| **Bloque "Ventas cerradas"** (`.sold`, pre-ACM v1.3) | caja `#DBDBDB`, radio 5 px, padding 20/32/18 px, 20 px debajo del rango. Etiqueta `.lbl` + frase 15 / 19 px + rango en azul marino Bold 20,5 px (el "y" en 15 px regular) + diferencia promedio con lo publicado (cifra en rojo `#FF5F5F` Bold, cuerpo 11,3 / 17 px) + nota `.small`. Sale solo con 2 o más cierres | pre-ACM |
| **Tarjeta de búsqueda** (`tarjeta_busqueda()`, aprobada 2-oct-2026) | Arriba, igual que la tarjeta de propiedad: foto 155 × 103 px con radio 15 px, "OPCIÓN 0N" en dorado 9,4 px, precio, zona, datos y USD/m². Lectura de precio en el badge crema. Abajo, separadas por una línea de 1 px `#C9C9C9`, dos columnas (1,25 : 1, 20 px de separación): "Por qué encaja" (viñetas doradas) y "A tener en cuenta" (viñetas grises), cuerpo 11,3 / 17 px. Padding 14/18/20/14 px; 30 px entre tarjetas. Entran 2 por hoja | Búsqueda |
| **Hoja final** (`hoja_final()`) | Contenido arriba, frase de cierre (15 / 20 px Bold, filete `#AD8A48` de 3,4 px) y contacto con botón **apoyado abajo** de la hoja | Búsqueda |
| **Numeración** | automática en `construir_html()`: `00` anexo, `01`, `02`… y `NN.1` para continuaciones. Goodtime 27 px en el pie | ACM y pre-ACM |
| **Tablas** | **No hay** componente de tabla en los PDFs aprobados. Las tablas (ajustes, avisos, pool) son internas y van en el chat | — |

Componentes propios de un solo modo, que no pasan a la plantilla base: mapa, "Valor sugerido" en 3 columnas y checklist (ACM); hero del rango, tarjetas "dato grande + una línea" y bloque "Conmigo se trabaja en equipo" (pre-ACM).

## 8. Diferencias entre ACM y pre-ACM

**Decisión de Cris (2 de octubre de 2026): manda el ACM.** En los seis puntos, toda pieza nueva usa la columna ACM, y `plantilla_base.py` ya está armada así. Excepción aprobada: el pre-ACM mantiene su contacto con el botón de WhatsApp.

**Pre-ACM en 2 hojas (aprobado por Cris el 2 de octubre de 2026).** `generar_preacm.py` v1.2 ya usa las medidas del ACM (`CSS_DOS_HOJAS`) y deja más aire entre bloques.
- **Hoja 01:** título, datos, rango, ventas cerradas (v1.3, si hay 2 o más) y "Para tener en cuenta".
- **Hoja 02:** tarjetas, remate, equipo, contacto con botón y aclaración.
- Cada hoja lleva su header, su pie y su número. La v1.1 y la v1.2 quedaron guardadas en `Respaldo/`. Si hay ventas cerradas y KPIs a la vez, los KPIs pasan arriba de la hoja 02.
- `pre-ACM/02_Diseno_hoja.md` todavía dice "una sola hoja": vale lo de acá.

La tabla de abajo muestra cómo estaba antes de la v1.2.

| # | Qué | ACM (manda) | pre-ACM v1.1 (antes) |
|---|---|---|---|
| 1 | Subtítulo dorado | 15,2 px, 22 px debajo del título | 15 px / 19 px, 13 px debajo |
| 2 | Encabezado de sección | 16,5 px, tracking 0,12 em | 11 px, tracking 0,2 em |
| 3 | Cuerpo de texto | 11,3 px, interlineado 17 px | 11 px, interlineado 15,5 px |
| 4 | Nombre en Chillax | 19 px | 20 px |
| 5 | Bloque de contacto | Datos a la derecha, sin botón | Datos debajo del nombre + botón azul de WhatsApp |
| 6 | Pill | 27 px de alto, letra 8,3 px (portada) | 24 px de alto, letra 8 px (igual al checklist del ACM) |

## 9. Observaciones (no se cambió nada)

- `pre-ACM/02_Diseno_hoja.md` dice que el rango va en **38 px**. El código lo pisa al final del CSS y lo deja en **36 px / 40 px**, que es lo que sale impreso.
- (v1.1) Con el ejemplo del propio `generar_preacm.py`, la aclaración chica ("Referencia orientativa…", y = 1062 px) se encima con el pie legal (y = 1065 px). Puede no pasar con datos reales más cortos.
- Con la v1.2 en 2 hojas, el contenido del ejemplo termina en y = 800 px (hoja 01) y en y = 890 px (hoja 02), antes del pie (1056 px). Así deja de pisarse con el pie, como pasaba en la v1.1.
- En este entorno, `a_pdf()` no encuentra Chromium porque busca el navegador por defecto de Playwright. El HTML sale bien y el PDF se generó pasándole la ruta de Chromium a mano.
