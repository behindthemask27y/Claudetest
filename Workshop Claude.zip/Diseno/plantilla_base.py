#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PLANTILLA BASE — Cristian Stedtfeld · Red Suma
==============================================
Copia de ACM/generar_acm.py (v2.0) con SOLO lo común a toda pieza para clientes:
recursos de marca embebidos (tipografías y logos), datos de MARCA, formatos
(USD, m², %, fechas), estilos, header, footer, numeración y componentes.
No trae cálculos ni páginas propias del ACM o del pre-ACM.

Medidas y reglas: Diseno/sistema-diseno.md. Los generadores del ACM y del
pre-ACM NO importan este archivo y no se tocan.

USO (desde un generador nuevo, en la misma carpeta o en ../Diseno/)
    import plantilla_base as B
    cuerpo = B.titulo("Selección.", "Una línea que explica la página.") + ...
    html = B.documento("Título del PDF", [cuerpo_pag_1, cuerpo_pag_2])
    B.a_pdf(html, "salida.pdf")

    python3 plantilla_base.py --demo      -> escribe demo_plantilla.pdf (o .html)
"""
import argparse, base64, datetime as dt, html, io, json, math, os, re, statistics, sys, unicodedata, urllib.parse, urllib.request, zlib


__ASSETS__ = {  # recursos de marca embebidos (no editar a mano)
    'arial-400': ('d09GMgABAAAAAE4kABEAAAAAmGAAAE3EAAIZmQAAAAAAAAAAAAAAAAAAAAAAAAAAGiIbhGQcSAZgAHQIhQgJjzQREAqB/TCB5jkB'
        'NgIkA4ZsC4M4AAQgBYMeByAMhkMbDYoH2HTgX7PcNgDqdugz43JHInS3IuIW5BGODAQbBwxr28js//+EpDZGpuGWtAWRVwc5Zqkz'
        'etZMVLtColeW4EuJXPKErGt3w40ZcyrvjhVEt00lcgpmF8QuHJsIUhSujXIwXaK/Nts2XaIpXsdk31AQ0hbTsMg8xlMpfogaTZJW'
        'eJl4/ZkVO4q3rNE9oNgsx+pZL3ERPY5KFTL+JlZN7IODKkVDePlMcg99UXRD/B0Q1fBDMohvCXqw/4UqhUzkqXN/MxYSEycas/sL'
        'dQa2jfxJTt6/5zfzzzn3vvsuL7kNYV9J668JsGas+G3CUrZK07dZMUKZpHU2Q8VfM1Q8zVBxZoeKszvU/FU8k1L9xuzwzfmi3H9O'
        'c0YyxDP6chTtFvj1DERH/NY3dNd2AJfA1hQku2jHPSG/e/nGLAi0PMDP6x9TedN9Impnk5uo3dSGYTY2TJwYYzZRNZ13OIcrde27'
        '4ipc5P8fPPzv5y4ukj1Z8ryEJ5J55JBo3ljDVNKfPB767sW/MzuzLydi6RbQ0ghaIYpQ1AMS/Vr3/3+n/rf32QdFR2jJVlIpqZOW'
        '5fYSyI8wegPcaw9h/AjjIaxnrQccD2EyhPUQJkOYfPRvIBn4o6iZq49sB5Q0V1wgmv8ZtabZj2OdbECXJQAIE7RAtmXNp8ua4Eqg'
        'gVXnUrKArvx/qqV/MAMMIicAAwwCSSwJ3j4KvMMuRglKpBzp6nhOHQQ7lwq5cuhDKvV6h1TtubOrvDy5UmnnWv4/nXr/LsAX4u8g'
        'GQJkla5l24MK/PYAjQWe8p6SEm8BUuMSqJ2It4BKqBLLf1VN8tKanMkIU0j8UelVFgUbui4HIO0goNxOztT6WHnZhse7vmXNsvUt'
        'Z9TUvKpW3M6S7bfcyrz8ckpvOxqlFfgwgAfBAJwJIKENPQ0rnWlwbrfGaFSTkMQqI5QJEimNl0r1RCU12xyVSmxQoZduLxn0F/1U'
        'DJq0QB8NkGUx8f9MNds/ACSDF0FHypF0vst0UYWQWDlEvevczfwZYHZmF9AuIEq7gCUmSQ8gJR0AJYYLXOAC6JQjCIUHKry3yhR1'
        'MXSOofO7yjlV7ty5Kt21MZeV+8ZFa0tPbi4tlJYMaGaPZ9pd9T6+EQ6kgMPywLdXP+n9O+doUxr8MLUC5v0pHeFQeTTy6GnsWdlv'
        'W9GWipTWPc92zttS0Z4glLDalO5jlNJ4IzgIhIBwFN/fL///7JAAdlRSaqv2KGJ0rfv5ptGvvbZ5y5UuZ8NGGoewJhjJDVaifrZj'
        'bPbscVEpaVAHIm6HzOWnJeH4ZecAJUyxIInMYC5DexhAADoJeIQdDvsWFr6AW7Ff4A43BrW4ChRb9q27LyB1n0bEASrPxMg4tH2E'
        'J+EXYPvvQMCvE28mh6l/JOIBLq7NoYBl4pl5ntW+hvjDiFWu1ZLb8BS1MCwqYzcexRd4xhGVVBOQmXNGiTodBoyYMGPOkgsfAQIF'
        'uwabAOLsJcr2Up7RWBZmVghusOyFMEPBfEmWvQqoqUAiwWrzsxSEEk6CQGfFab95GQ5RG0hWATZ2oMCv/slMlScpNhtRoOLtmufM'
        'yKcEzMippBVkuK3S98pxVM6OXCi4LgkO5dMTX+KvAo+oYLeCHyWqGEgVkWGpHEEPEkFUWKAThqj4DhBBFBFEEUUkSG5NFFFELX5B'
        'sEeMoIr2DETUtrdDqkAyUohP4q386ypAs6zcHsUDQZUIJT6u7o6VX0OIOY+Fr2wmKL7a14E5kV43uMUFnMO07wgJBMD0PkMST7WQ'
        'KUXbS2QEkSfczZlKuXWm/X1Rjh0wRtsIAHRSjdmOqDwn2ZkrOUOOz6V5Knuv3Vp84eME2FPYt9Q5+O8JI9MWJ1J2q8ATDQoAHNoA'
        'INbKzibOr8JGxxMCGrf8gDPdlmhLiiXdkm0ZTNuRHhnampKjMsoSXxPq/ur6v//X7o7pw3q/3qNnTkoTvGMNFqRtrMsYmU0hKu1C'
        'kgjrWCCCDGg/+ehX5/8GHSh5JDXLRrXzbpSFic+Uh96yDoOz5/YBJT4XvWIAr11JA5rNOz9HnhLdprYqE3YnTb0hc/oA6IlGsA5x'
        'hpf8I9gG6eJNFAuVmOIymT23mgDUkF9Ib3rD5/1BkYuuXVvEKANgpe5ACikIcRx2i0Twzm5Wrke6HJzPRtv6ykTpJQ9dmVoxEvsm'
        'QWWq+BBdL/GrH7o85KHPiOnDu69FU5r5IzZnkvX/dgDAnaKb/1LD4yGAOoYDjBJthSVSN9Lno0/sqdfLcwgDFrTbDUeSCzI4KNDP'
        '18cbAffy9HB3c4VBXS5AnJ0cHeztbG2srSwtzM1MTQz09XR1tDXU1VRVlJUU5SVEhIUEBfh5ebjVBPmzEk2BGQ0WlbWsJE1l05qX'
        'ul6lz86aMgenlBjiMWo2izaVAk7FKFWecCuib9lIRF9Jl/FI3mQ3/RtUtD9PH4UN3D5nRrjNsNn8PcKnZHhsSpSjlJkHhIEaUoqT'
        'Lyu/0aW34Tx0WAPUGO5FHwtWx6D28VjMoscBZ93mk16apa8/PNitfiT2Mq/LAdKXIp0KpextqIVD+tLqDAz4uwHEAMy0HHd7u+EW'
        'J8z77jtfDrKei/cPaFA+MGDDx+p7ttHffEO1O8ZsStV9+3c079VDzJtkNeYyLszn26jJH+4K4TCiEUn/N8AMbf0vzRoGQSPejAIN'
        'AAeNksUio8z5m7MrMx/ywxttL+umjsjv7+y8Oa+dBKQNsLSNV285Eslv2xB0FV9tH3dxNp9jxly3apDzZFXOWLPuHVJXhaqZH6tZ'
        'rHdlDOYAhHHTSumgsPiyZtnJEninmxE4DcQS6DOxBWVezn77gEPvz/YkretINcPywvgqj7ZCYz2GXhyGl4VTPrKKTVFe39+FIh+q'
        'yWtnLFmrBDPG534jBsHgy50Fjw3Svlyxl+h7v/eL+dpheY2SPiNiqSbtUPHLqg4vK+c5pGIN2OB6R6evbl06q0+HRWfMTulOmXFq'
        'yZNhIT2GTYljsUwDelyY/HGaNWE3AJk+pmTqJpWV2nsZykcxBslmN2FpWw92KZaXsotg05xF4YYBi/n92zoY4VgnBnDcSBqhoC1w'
        '2JIZWsw2TnT2T1ya1k820jZ5Qflcx1wtBQ4Er2fHo5oHZUugYhhRyOjuYt/EkdvsJhV9c2T2cim5GWkZTKqsEBHsFy27U+PV+ZHM'
        'xeyfaanUw5QEb/0ctQGl7kZTEH7UTASd5YSyVccmribWklIqM+vdGk01nwOjns2vTNGGMKOuA36YNDQkS9WY1bNGLdQNN3BcE9zc'
        'cTdNbN9ITSHyAMetibHQpIdk7MYP4AQfJikfgk0ClUsv+/LCc05SVs5A0RYAvv36ak3cax7MMcpKFQWO+v1+fTeQ09V1Dm5fa6DU'
        'rG8SYlvifRBv/TCEWM5Paid8LgSCJPTxL6cHzW88o2M2g4w5N7pmiZAGXGJDpEwL4IR1iBDjVchBIWoepiR1xabeFvZMfsfxwJkb'
        'CIvZMooQISsoJRyjRUIRntKEhEdk2OPLdAB9be7uXkPv1nv0flJ0ZMB7tcR1X0VgAYTlTlS4BF54vvdl9PbbLPGRePO1rWzNZrnu'
        '5o7ZQ4DvjG1tKCk/dVLXK8pTSlbLAUjK3tvKZ2ygFSBcpWgaxoF9txkobCYgic6q1TdM0NGXvArdidwJCTApO2G+1/DYHpiN6PzG'
        'XaMognPkh/DBLSfZ2+LHbvngv8SEAACMKSw8LOLfSBwVAdCCc/C7qEqP2r9aWODQP2HTodmk/XG3KWKDtZYilmlbxjXpJlB1K/a3'
        'LgqTn0/i1Dg+JfEfBli81qqy39IKmEImVFWtuvHugnvLQFa/4XEbrrdkyFCqxqJ6PEVZoT3WDHtnBNt3DKhYVpj+no7Lc3TzgZzE'
        'OEpAgAG2xD/PZ+8mITAsiT/qNFeMNmb2D9f6CX1wcAbdpREnAxvr13kMIBGXaeQoDWyv3TR2HMIOuwFY+MOMA/BLQCmjXfBeS8ke'
        'JDE76LI0MdL7JYrkzM657D+nZDMCaJzrEgI5AgK1EG3Rbnn7ANUAjJT7JQq5hwxCTZ5vbkbqCpw6tVoJ+ZqqxXWPwe1H7v+vadK0'
        'ZmfUh7E0BtnHpqC9wEppFHiJBlqLJ/25PBbls/8JF9I0WgzjMe+RcPhMwb3R39ZLIwaelp9YhpeB/ogk7xcNB5/Rodh8WstN7cmq'
        'iyvwDSmd03ZRLwuYUIlLsT20hhNlDXSNMmMfHyhNubWHJuBUWzJX69R0Uwdm1nSbfNwi20Fls6Vg7gewbTN2CVuogJEBhHsyUDQy'
        '9tCqsa4PDY2ENuSxZVSVDs7xFDLzpYnVsXXAorJUWJpfhfoPBSZV4/c24VplsqAaUi4W2S4KlxjCJ9lJy/okdSxylvnL76S2B26d'
        'hq6IcpW9eNLVGeaCarUebdloTwbW8LTkomeHjEHXjZO6eHcMclu7KJ1xxQsG92I920pgGooJWjQVDxl+/YzXnCp+TNpGgV4fBD3o'
        'acGghHhGfWBmkq58I/I/h2EmUiV8lKGkpMpeh2E2XE/AeyOxbf6TovMGeJv/Sv5mask/t/Vdt3Bo/1fjy+YebvGS1TW533TrJNwP'
        'T/oarFebWWDKQVeqE8+XnHTxmnUspbAJDieX0d0aPHjS56lejPCmu7TKitTkUR8+N5KpMTmLD9PpbRwp9OsUiQdtcpMEYSmWo4NV'
        'i5/nF90tw7hQLXKfRdPd9YBiG6JYXlWVIuYf02+vfJyPbH6qClKOaaJ7FAZBrVZSpeRtfvIr8tRXtx8+uBmWH7yEsszLNvXwKV+/'
        'au06BQq0RHk0cApqEg7uHamZNkDzMWc03f5qH22bXglNRQorJTo7T1SZLtDWCtqD3E2Nh8I36GCmy0YyRRUHfdg7upbRLFmGH/Ps'
        'H4/Ca75mhAUU2STp3dJd2Xxb9u6ZeS6b91eX6fgqr6zx8lEpUDEcDfozKNPQmsRriALqM3R3jWwgC6Hqy3ZjjTdURx9kEbkBXdCn'
        'DNjsbcVpoFJYlboz0gG0cqgT6GTlIfCiccR20Btuha0IcQ78m6/rtR22R1bSOszjmlty7zwc5c+PA5unojQ9LfBQ1IRTS5SWg681'
        'CSAYo6VEZUIOtGwLPsADwHAwDKm8yMRHkvYFcSxP5FcdMRjGokmKqLKIU/EZ+tOAFbEdwWpU7njQ/dbAhXirtRQr7C1qqz5YWuP5'
        'FVAq75DAY8txgp8azzGLw73kyzESVc8ywFtOrgW/0dCwlIufcogkzmx+ljmHXjyzulSyfllJdkyobYtYweWYMKVV0tM8HmvjZtaB'
        'X4pYJ8eRT9V+UxO3SMiGgYEK0eayhEohottIkUtRnJ6eLEgk2pFilULe9RI2ps0+7Q5eZPfewXOGZMTb5y3O09oqLyzx8kpjBPH9'
        'yJieX+17asx32u1e0vYzigtZXbXmCLRjEWAu+37JDOUyqTUWfjmKoSHcb4w/iYidtFMH7+VqkJCymZbgRb8xsY72WzzvBYUf2Br3'
        'SYBwf7Zlx7arLr37I9j7+vrff9HixKaKwyRKi+ix2i3LCiRk21jhd/pJgRP+xWpM2zEN9mFMprldp+Dp9iChEXlmkxlw6+P5mYrO'
        'VRnw5ltol7nUgxbOviiBM77zOw4yxKbpOf34jweRW3Q6xJURrz+2/3NWoXNIb4fVEQEqIBDHj24tHqD/4ARWVynCF4wQI96ELOIS'
        'w/wCuMe3kdjT6BUKXr3TJIvKKs2mG7tdpy3wP8sM+t9Fvu7U9zuCHeerbwd5bn4smD/wHGWup2d6OaW4CFsM8w0sLERerXkdwwnu'
        'is+zpE9C3iqXZ2wVuhEYlfFLofVHMcM6TdvIRY3DMxUYSj5hEtSb2E+4tIi8AL2jbeKzY4x2czIURKLT1gKaac/uoAs+uFZVt+BB'
        'SBcsK+GimjyslJstkvRzloL/xnlradEsLNXmF/TivPbR84C03XVpXMlCPSa99NQfRlhSMP50pMmJbQZUn+iiUxiCtjv4FgmYdd/x'
        's/lWgqBKrOlNfALer+mVqUAaszPrPThVTClpnMfxZJhC+PeKtb9NT+79eirCWdBB8/jCOMVzWqebAIONVmRk5B1ATzMMbSevWTc+'
        'jEGT5ajcZ651M+MSU40VU31RVHOsf28BBaQJWww5QxawigPrsyj3G6wlWmykjT7YKCBn9mk6bjdv+M5bwHNffJ8PC1CE6TOBSFLj'
        'Eks0r8NWe7wKWN/k9MZ1SMplQOjgGshO1ny2Wb9mh9qfZEuaZDgwj9rteD5CK+0863inX7MplzYwSnkVyEiJxMgGzIHcadz/wDMl'
        'wPIyt9GDlo43NYtcA0HD0DESmHjrcoqMMo3F9ZE7/PtciPcfxPba9tkrta5rpeCFuYKFEpHcVNkclOyRwIaTDqjD+9XF+WQa3W3c'
        's+9t/+LOBUKADugVHeCueCXE3v+ynGYH9wtDfPtVJFJaySVcn8fOF0C8g1WiYU1PR25z5V3KW+C6UavZNqwARqVhk3iWJzRrIQEB'
        'OmREz+nmEU/npTZxByOfcNMSlTvFXLWkrq9WBogIM7x0D4j/XrzDxP2Ol63NrU+PTuof93bXnbh7lzdZ9FBaHIX42hqePH7Y+qa1'
        'tfXV4ZOGx34Hh5Pu7UgkvGVm0LMbGYjodWC9NubWERzi1To57NV9MQDeF+BazjeemuVqfxkSc//d7Tkx/1p+vf4LtTPdzLq5OmrK'
        'zOyzIPzN6dsJPRZfy7Vsf1UfhoYnuDyhJUtWp0HRwf5h6Cgk0Z6Sa5zuYRvE1hWy8Sb18Tv0dlpjcYFLiWmyUNc1050hySyw4tSN'
        'xesjCzsjB2KiQ3tL+yNLNyZvyitpCS42srg3vCsuPrK3sPvXXIYazBmlnScJnfud4lLD0nRWAbdTSz/Fodr5PLG8GoU+raFDVUPM'
        'SubFOemU84gZq1qibp+BomUFHioF77R/a5dfPFw/FBeRnH7aKpn8FOxouBr+i/S1/Q9dIjrufQzw+z1+JsqgWLizt5zfRLtStL2t'
        'SlqjuSHa2ub5gPtJ7+uAhvPR2YZJlRMd5a0Z2RmeNP8kWnYaqfoSX8KsEJj5Y3Pt7snWvLdrR1XHbj8RRauVhTxpsHWoyF//effl'
        'vf+viC/NCyn/FixszKeSxnL6opojqjtziInU3DxyZRovfoofPPRjde3O26tjtFpmmSxbi9DoONpM2M5uwK6+WMNnZnnqWqk4iCxq'
        'hFrDgk1gX7+YOuzdeMJ19ts4HZTvnBYx331f0TXSkN/dVQzL1Hk5pvtdsSFTaiUpaGT3x9cQh4pbT05Z7n78G+6NZ6d9sfOWG5Qz'
        'HpxsZMoJ6QePh5DWT77O3G2o6SnIaqykdLXvZOVWjcDtr366DxtPDoxbXxI48eWlfm/o0nLooK//fPj6+f93Nxgti+lgNqIUdTKt'
        '4/Pmjd3P631p+ZMkMbYC0Zq5I75PHNlUMjmtMCszm5qkBMpropbQG0ozlTWryor9HJSO4rjyv/dcY2g1DkqZjM419cuDeNSDVnFJ'
        'K8eg+0c//z16d4pcHxloup2XWzNW11gzkeOZf8Gd4ss7GbezvsNnhBdSz7ndPMTOTvP3eroYy1u2Bp2NJh34NCmhwZrDKbD6uNrW'
        'EHB9dpiGhgW2rBrX/yN2y9oxicvtfDICfdHJy9LFCEIEnOZZnNWibbw8bL3M3c2tICoBVsTGvOLiriL+tFleyQ3Qwb0nZ/vqIuvb'
        '69veKc+/LhC1b3Zlo+MCAlkhHA7pa+mJLUM3prtzJF/1lBwipjnU2ppJv1W6gkIQ8AK6x2nVZIOIYvXaF9Ldg8o/q81qGi3XKjRd'
        '2/xNCeX+3sEjp9iVlbCXEr+25/8/d4qamoOhnkXlXcJHNmcFPc1LDaGhM3f21JvFkFll7U25HU3XlL9THipHUrR8T4skvPUpk7cF'
        'p3alnaX9kZ4dJUvCu9+sAXYKcF6SWdSfLdMHnp4T/k1sCq92WHFoqCXCgd/lmH9Jo20UrAH1z1uQNgdIwPKVRrVKk4f/tOXy7l3T'
        'sU7oM0RcpuMzndELQ1NW+ukPKCH+3juP+i+YDd8UBJqyH0WNuuzKIXdOSNDLsuktLfNMewkIik4z/qpho+G7umZfsaQXfOdaz1ld'
        'BgTlTbNp1LUAAtnjrXKL5/C0iRV5P77lG4saH6+w8RfGRx+Yy/897X4vCYnOl1aO7EaZrhHhJX9KnPov+/7xVQ5xOeI6YPEWOMox'
        'cUFOmJRJCcWSSxkQweZbR7cxby94G/bNFsnco9Fa7+qzALRWnqwxc77PL7aa5f3CgKFRrjL9CTWM2PqVAnHwFbN+hXhWPGhpaOAy'
        '5V9x0p6lSgGKbNhJFQftfUejM79EPZUxtjC2XqZx5GO97jne9cDmofEygaOIm0dMN6vx+w8tR3vcH3snXnK9bzXQC1k74uQ4//kL'
        'pzovN4/ph29s2vqeXQ+32N49bVXt1M+UiA+go8s3hKEZ2nn21ijiptb5bB4ljUwqIcpsqeCiqF/d2oDN5ga33FSt412+MrvieOgs'
        'jOs3UN1H1jsrLTN326XLQgTz3mf05rRscN2q6y4O8KLkr+vfFQUhIudU5LN2Uibnt7IyILZ+iWYtqqGivSpDMHSwcZrXtMg66+f/'
        'Kg3HFhXkCMOYxv5xAsHB2ZdiuaplL5Ajl6wVZeHmo5VYqsP24sXKi5PmguYzIwMeZsks+dRLuZy4ur45v7J/exOzQhgs/8mVCxNI'
        'yaJtCfRTn1/d7xcJp6fbtiEJwAl3yhb30XkgSVJuEvzafCL5nbIpeJCt3ac6Lh5vCxJER88K+sSb3ZOvzpUiKpYL5U1s/s8a2Bs9'
        'Gn0gfvix+4CmcUnj4FkLz/Mz3lUlFLoCVTy22B9qHWjdP5vsiigz6fYXbn5bZNIdTHetYAIquY7yBpikNxS1WrBk8tNWyemnYEFm'
        'WdXV/qFQMzDsME41SO0kPLmR+OTMMlGb258rKu08DhOV3XkgJ6LZAu7qGqxl/jP5nf0LyIpKSExNi0fwBC0K6ShTb95aGN+Ha8Kt'
        'pDgSnARdMMFYdgKHc8ZMVFABuiEosNkn6CooiyVXD4JGBIaEljrsK5mWZnQGGkawynNmSY749X+Y6nMABbAZRHcHpd+6Al6SPSav'
        '0+oZO8/v0q43FKZuoc4pPqDt0MNyogXipnlFmp7MDx1/lAMLf5J72vtoULp2jp8/KDEmpix7OcoIPuJjRyVMSzO6ggzCWVlSV6c+'
        '9PsN6XGQtFQJvJ0a6AdP7tM36wL6g38sNGxXJxejJFxatMPOAr//yErxaeA3R3YS83SBgbJmWl79CHs9WaxqdnZqtn5SnF5NoRS4'
        'We39tFeG2EAuhh/klSkzx/cYstlTksKu6XAMv9UIq2H0OJa8ucApLb8ldIvExOqEscpxVpkO+g1YbfEaXaO6rORifBiZm08fJ6+W'
        '+eWhXRbawAcUi5jOiMyx3pHbe9MjRE18qJFfdv1oTdYUIG5O5dpwULjDuGoUhqaGeCEKllOWeOw0IHobyPRUD4miuxAzF2zP1E/9'
        '+A95OIpDg7ZHfAczu7ewJYw10/M3BRgZ8yMnkPJH20mTPstBA2zSGiyeIAtiTRAuozRcOhZkhmsNTeyuHr+xN3HYlyYld6SDdEax'
        'GInTTEYaBeXWjLeSppzOXxtC58W0ie6xm3vhDvtyMr9FP344VRDWf/HrjdCS3FPq9ZbW4tv/3GPcq+lk7ECH/Rz747fIbtbZNwUI'
        'jj6/EZA+WySYTQ/dcpGytcG7pPQ8bTU/LjXIdqUh/I/edkNB+lXUMfj2ZVEx09KMNn8TDKscZ6XxcOz761OzoC5Wk9iW4D2bA/qN'
        'Ojr5xpPj1PWCBvrDglJbIjt9gHNWlU2LQYiMUoH1WFgnJF+ZMla2Cj/f8LJn9/ojqkJxq5yYfxk8h57l42sf4BUumaPYqJ7rDouH'
        'V+83Xp/cz5RmdIAFXHLd8ekkmJvuX5RmrUqpcqY1FKYehtHkDBRHPfi+n5lHNT5N/bKVtzXoqWun4sQPAXdbPkm/9kMj70pUW175'
        'cHnT7KpSklry99XLZ6GDe0v/KjOLVZlzO7vnvllOzDyOVh4WggkoI1eXXuosyzH4DqTGzsYVlRZVFtdyzuP5N/m7ebu38bz5OmdG'
        'znSVovnpMsN/8EjdMbly7Odxz+1IG3L1/diKFJul4xCJWex99sqHrnqgZlUkRFc9ViMVnUXC7C5sKIpJxhLj2bJxoBhicmwJtS6P'
        'RrFDusfiMCExhQEirIEiWFp4ZKw7DmlHCZ0ZB1RWr/4iO3MuU0d64mIjI6JpgWBWP3BsQTgG5xmLtKZQ86h1JbFJMSQ8KJsAwpKS'
        'YxiFjdlUSqjxmiak/DxUMkc70ImkYa9bhvepN86SpOi8Iyvo5CYiaxqSVAncQ18vdnBDsvCa8A0Zlv9uyF0TarrUVCow2SPFeK5/'
        'wlIdioDEwq38q2DcNO+5suXpSn4mSwYZLWjoahfy7IFTtDEcJQxAYCZUM9pevtAYqOPXlla+QFmQWL+1dbVqM1URN2zuhXd1IRKI'
        'mQr1lPosMnLeXeN4RGaUUTjI8EhEo6OjIjCJiGJ6oldYWDQ2NNQricZAlGKRWEyxB70M54XFjnZkpC14Q1FyTyeJ2NORktzblZjY'
        '1+m4c9UhM7sxu3X1JvRebiZLg/5fou27FzeJBSkFmwUzqzy9PDyYJN5e3rOO98bN4TtUqax2sFTNs8wcTxd9KwjeiCJXqdTk7ZeM'
        'QKfUoMUJepgcZPVL5v7eI6oio10OHERDVBSWB3hbOLinW9SqrGoPNCUEpVdhZUPl8fn+RfuNcmATKCN6VAPHnhPja2AJxZvkKKSw'
        'FGCapJPW57rmdOZ65lQueq+vXoHDr6xueG8tuC+vrnp5ra6uwdcueyBX+/sUVPoHmMrMPuW+fqayYl9/v2pfn7JZwmBTyUBmq2sT'
        'UckmlRmdvLTz7OaNzX+Wv4XuJirIO5Oc3LML2rNBDFwmKTqpOaORZRxkjYDAEE5wSy63am7BmFYypaL2Uqax5bgymIzlU4LB3UD2'
        'bNDKKnxwVrKXAx2UzO7j4JBWYBZWgsDZIYhMeQTJBy+b6YWz8yL2yXuS4HhZC6uwqSHvymNbme5fssO/rnl1wLPtjEprMwlR0em+'
        '5/5BtXpBQlwQAzozcB/fPJeNoZKQEtHz1DQysyclhdmXnNzbl5ra24NLcbcGdnOLinF1xcbAXKOx5zP6iqqKmBVMRhUj27aGLtBx'
        'hb+WIUuUnHNObiwszCmAYGl7wfjrxzkAyulE5eSLbc+jZFen46sW6WlBaKT1YqKNhrJ0UmN2qZz8cxqfMK27vZq+bBNvAUe6OFjD'
        'nF2cfSDs9gW8fLhmcnZuVUqEm198EJg1mCsGS2Wjjos8kNuRhYkqFjEBcTw9wohlkHMqhjtJU/ruys5akpsUe7A+MgTFhgbFrK46'
        '4TRenASYQaQBDuUEkIefPokrzNW5gf6rK8NGUed5n/87fc4CFMGuWoXwyD+/Zz8dp4ZGsaLgbl6GcQe4bXrqXmHG8f04Ox3jc0uj'
        '10eZY1sry+Nbg8jq/MbgXCwOWVBbEVwcSUDSXW4VM2UReC+SfC+CaGdoED+gRZmeSy00cw0+X9xX4ZYXzrVQCRExManz280qG02b'
        'Wi8o880/ry42Lr5TaLb59rFuRSvzMYFPQkRCdkuZFHCc1hiWjyfdRudDtEZYAnRkvnyztrH2I6hjtrMjIVsCCw8PDY2OQoWhQrBY'
        'FDI0NBIbFoaOUM5oG/3oI5DLVzY/D192G4Hu2M/e+NSKK1ung8trjk/Dy7R9/NKCp+b7Kwx+ganWNvLLCJj4wqkOkRARkxXx7HyS'
        'Q7r2CF/bqpmH//L4t/ITy9HlGwVd1d0Z9nkNvY2m0FP12sXugUGCPkuXdZs65GK4n5e9b2SYBdIkOM/fxhx9sc3Yx9Aj/2J8NaOt'
        '878p0PHbF69XnrYXliVEeboIyarFIszPPsyIlxCRkJCVtab8FGaZqlkuzmhmlhEJePbtJVX2MQdrRz6MnoI+gaxoeHxaVoIXHzKD'
        'Ox9K/0QwkhknR3YSVoD8GojKWmzsgHENQIehouoD/Rv9v6/nQeXZlQPszQN8Ty6eXf4m4Nc/Wb5++/nfJzrKEvfgUqI2lfgQhfOn'
        'XtjzUg5yMMgDdi+QA03DNa852H/xWX27UjzU3FI+fHmlbLyio3qEJDaYk8ser8wyZ51RlceVkJx3zhWSm0VcBuvJ4WhS3+xdb/qJ'
        '/ottYnAwtm9oC05d+kQRQz43cAqgdzJ23P/JFfd9pu8IL24tvp058AMiXD03x5IpjoyiRn688ex10JvZxUxtZdcspyzP1AyzIRLz'
        'iMn6iokVecN/U1ExORdTUoI5myKypAiDLi2OQ5t7eJhb6EzN3BBWlm5wV7mr41o+Kh7aF1TkzVCFSJ5IPSzc2k67GMBZRQ4jlHJR'
        'qApN/p9nnU6kG5zdHADC9Di/zlWGq1RqOaaFFGYGrSuLUD/HqJZmZ6BolwI3pk/kYvjlffj6upKIKGUj8NJlyxnZquXRFcqSpLnK'
        'UOVqTcd00wQBlvW4qn77jFKs0Iam1efWXMs5hZdfT64Z/YmdfSmJ7T0kUkdrQlJ3u0JEDvAPVw5hh1cO3Q7XD3X5qs1EKRXg4qtz'
        'uLkeRL1SqlKm9+v/aTLHBlqN1sBEJ4aM5g+e45dtfNQ38vBfdlnQoHpOKqsHq1+7ehZFHvgpHY4+Yso0zPHzB6eiY0trh0UWV9Sz'
        'WtRtNUyuqudUi651TA3I+rQ7mlNsoNVZ0FIVaOmTTui3qY/8VQJOs80dbSjQrOpSqEopGVCixBafslbHwdNSwoRWHleGEtuFndT6'
        'uddA54/j2OXo+MZ6Wzv/t0hvb7l87pHvtSoBkbMfMTRffda0L1/r0aXsz/ve8yq3IA1ZKUxIF0Aggwvdx0pXgtAxaT9XxAm36Tch'
        'uAE/s7l/OzXQXcpxaHy59Yfxw3ZafCVw+JRzxyjNtgw9aZzjIW9gGG9hCG8i7voM6Qqh8vbi/3qrscOuquUTCEmG+JBWtLYJZI/c'
        'hjwZNqb75g/WCw0d1m9xndEoJ9WBvAu5tFW1j/s2ZVhLBOf4gTawfji02tIKu3D832iJ+Ej48qfwiD+H77zs3fkZctk5vuDzBfY8'
        'IiETIEy+egG/ypVtAjd+3YYjZ+HTr/ryN8yTeFVoSXiL4Sez4OHoWfDaz9rdfw4/r7Lsz3z/yZB6D45UADhSn8Bdwh+SwW2lpInX'
        'w6JPjvCKJfg/M6uxmdhUGXRH7KZXJviK8pjJRuYrpbvWlH4OQMhMmB4rwfbijIL5GZH/uzcOJCfQ7C+p+e/ZaV2LCeBqayVE1AzA'
        '7eBkCTptiqUWc1/V1EAvStEo6hjuJgd015POfVQSkf8lWie0gmYlRP5nuIoOAEpfnDapTzDrYNZyJCM6Sav89xzXyxOmhK2PIgcM'
        'BR4Ap1w7DUBhztojVQvFBRUDKC5hv77z/K2GLCqJyIFELENRVOu0EiJ7DB3s6kXj3wEJ5284P9ObYpwbXSOLRQwIRe2aGw9eTmzy'
        'YDEZk+VKWKKXjfuLg+p8B1RqyXaSE59EVqMtYeiGSUN6tKpXLIub1b9XyqGtxTSMGdApKahRoQxk9OvZ9eTYSOgT5dWsWFqwrXK/'
        'cY3H2I3r986Fq9e/LM4b8Li2Z96E9nG0A6xH2mlTXBC6OfNNjUOl6mL1QiFvf3r1jkyvJQ6RuGWvngZ2k0DbtTDQ/NGDDcVCoqci'
        'Y9IMrq8OAWZKMmm0qAFBMoLWnIt+w4TjE+0lQeiTQqhLVUpyqdfXFEmNG9iYJ05eOCJNPMdJCpsPPG+9KshGHWjFPf/S+gz9ao1B'
        'KPJUScEjPHZxJ/xeuB9SG90PLT/yI1HkSYwdIwU0xpi9Fsth6Lpx2zvCcCs/Z+NusGOQK6mWmeGtj87R66vDG2K3vHhQbLfrdcPu'
        '3KFq2FOb5VI1IROPPpb37O6b8f4MP8G2+BYEfIf+tzr7vfjbmH4+xm+Ofyhmf7OFPwh4+8f6Le/OgF6rNi68999psEEP9WJ+qGbH'
        '4OBbNGTHdvhK/7oE+WasVz/m38/ZjM85E5TRp/Mv5pwAmn4sxv686IZHdNdO98fivFhqxkJmQwJQYJPo16M3ezEM+7y7gk0nsJ5/'
        'NbmX53FkJcjHHk2vbxCmv83Dti8mAfmxqYJNZubQFvUm0LZtDIo9tHHvfp8fPGced6/7w6QoL8p4rq1Rb9f7vvaffibtL+3wygPs'
        '/PAJa7SuyWBgLwJcBWjDlluGQvHEG2D3oDoBetC2wFR3jB7W96ocup8KmtuHVkiIS5USh2xijHsc4uTZI3G4NxRch7jDgWzolATQ'
        '7ikTH23iAQDRPQcqo1l4OUgjHMFdjgN+nTOlexqF3tKMayfwfeY4zIYnEkGcCyYCgvY2LLCS2Kc9m2qzMYU3nXtjD0AS+d6PMCTL'
        'Jox5kgEX/Cdg/lrHJ9Q360yJnyGtXRs7vqqZ7o9ToE0ZEgFaaMcF8cO5ho/pszRtO97FEIgLhF9pH48oaxARmnH7PVvrtQhAbMBD'
        'BBLGGv2QCeAIkOjAQlya16TjgYQi9+yb4SnK8nzct45f2o7WiGbM9QTnJKVGwLcACmirbut9M78zCPvTSSoIrM7WFQNe1e5aEMfB'
        'myEpwlonaLiTTc1oSWvLfrD9VJZrahUCbG545chr1zeCd6VvQOj425ebQOh1foShiCJcVkv9OpaUjGhaYdNknCP3Kw7hRw/e1DQW'
        'dsyYRoFJCjziByd1owi5UmIB7Z7NziXxusvmNC0Z6yxJIKGySEKAXuzw9UsFezOKApcGszeQOJXY0Ncp9hS+Wf96nZXIGFuxcCSw'
        'P6gyctiy64/MYi4cz80BXEmXh6JIijeRJNiY4M1g3n2HOcIzimrbIGSkOH804K5q4nIhwBjwfDCO8Z4vOXg2DriqvwTcbJ3KHyQb'
        'gCT1fClHd1Jv82r3ZXkTbBMTubmJw7B6E5zSrbf6RRLMWz1gz5fNhaSy8ABkTFvb4YbdeDOYrSwLyFrKsvJ1KJctyigaqCJPWZ/E'
        'fGwVK8WBG/1bYSM8cmghhvi9tH4UAWhHCwqs69TB5QEU/njCp2fn5+0ESw5cadHKPe2+RpJGbMbmjBiC5S3fFfviSAgO/W5cd3Zi'
        'xBv5qCkl4FybsA5gRSV25EQeSeGQwDGF+WodOqbMNst5RUoVslHuHIcBfdfSiM/EXBDHFvbcRyCFZS3bZfvsiAn2d8EuL2qduyYG'
        'MHWfXB7KipnWsIBMXdXv5VVYoE/FWqUmVCREmVNFqe5aKPgf3o9e9NZHz5mSXnvyk74aH8syfQFwR7Mnxc41sv5XINzzXv0R8Uc/'
        'IouZV3nMJS/xkkefe27zAZ4DNsKYjx59/O4HeByaesSZZII0K0wbEQZE/3jNv489EYLHSAoNxLlWFEchmyD0tCAO8W8q2CXnVham'
        'Rhq+xNplHWj7vRkKzvRCLTDlNBj0QJDopCxJoHMAzamqg2QQFzR53MTW6/wE6fkE8f4rMBRJQoSIJ7CJlxOQWM6NqXv0r44nicF7'
        'Lu/HYZ66xvRCPChZjj7leRzDpJiADvXY6IyFsTSOjVNDe6Qb8OQEYVKX6N7Z4cWP+15hTGyumHBAQKqcYAKHhM0DdlyrfBWn6Z9L'
        'mW0MOKSAe77QE3xP4C9LfKf8VsmsQE1CACKfABGYCSCuI7x3mtih/iGyvg4SQmomyXGz5VEoBcGlJEIoSIA/R4ODVPqQaO1k84Cd'
        'qvt5Bz1UUK9X4jKcUMbYmeCKjnW20E91phTxeYLTBNV1v/ZCa7pQearxd0kTSsQ1gMtdz1fM79+J4qmO6hfLZ9+LP/WafqvOrEKt'
        'lBHE/83elYuHCZGluZmpTn1wj+1J0uKlobbL6XExLY+W1QXm58WHxSiqheDlT50LPLQ0M9UZA+d1FZ9iahg5sGh41YNr8lZlj+2c'
        '1z/bzDEzQeAyiuLQnSAkkPnzDhiJIKmHiM54v44iefZunP4eboGrTRc+6BqHc/4WjkLGuRYE4r8w3bPLbKxYeh1wKJUsSXyS6MQm'
        'JXqeb00Y8CgYBGsldgrHEqiUgnjRxq4Uk7ychDiHrWWKr6KoIMMVF8T70eY+tVCSlhDBtUo9flwsM0GCcEsCvFsRr/50DyYdk9cm'
        'J/lPbRJeT/m6abDTqsHeFdrjm/rsxNhM2+gWaLONzVioHjHYPgXH8RXnwhc2cFGSBhHXDFfJoaW5malOfVySiylrSISZmsfKtaCh'
        'rIJ4goDzIudIMj+Zx3hvRKmfMCGkCxLimHFeg1mhVHDxOzFKWItvBICnEi/NhkuZA2gKYrG1rSrqVSTYzHkcJK6UsmA+xnq7xlDz'
        '6I1slqbI8xKTyJ4EBnzfcMqLkCVsgjiG0boI4m82cZag5hfIU+z3KyOpcLE4rW4I69U6dYTorQFvbodhkh7Ph5/tfLlDX6V4+RfL'
        'zw/fA59Zf37wtQH2L6PHvcvU79cTXp6jz06ae82KQL6xEet9QmaCLzj4KfDS50hKVn1JtT8YlaQyjSl5DMvkW3+hjDNFRgMX/J+5'
        'A+N34wiG9X/0GQmbsLdiE7JjxK6+dEcclUP9QYplnacgoQ5ltjNWhbO6rxPRqkD3xMWxRZlHOg1wXA4eJ3vGaqELpx5YWpRppH3U'
        'Gr0wnumyiDSzq6ckV/ksRuVnuyhUPORZOhMEzgSQ1AqtkkNLczNTnTrXkIT6GubPNKYaQRBjQpNjaqez2MiZWgtrZZ07onFQMRI4'
        'Cq7RveJVSSQF/wdLHbmICCmNUIcYhUQrhS4p3zHG52nffqlp7wP3O7rr8ol0wkYYiE884AoHWEfP0KS+hQgTBWygh/o0wk6YiNAv'
        'nnCNI+xgGqPoQwcRJXxEI1FEZBAOwkj84BEpHGKbd6UbEN3igpo3clhKzQlWv8vXsl+IU/PGloLvnk5q3nBdSGQBmVd5384ztXFc'
        'lsQWzN48gvOl9ngs93ip5YfBdulz9iYchml9pfPog19xpNwX1ILs5sTeLf+njij38rAgDzBbKZQhmMZmyE+Pu/GwNno39uZgsufU'
        'vJHUuX0dB3Ds8ek1fpr1+9/3/QLCIAYuGdwKdAjVeaQ6SdEtXvNbjCtbxVVC8XNclVNFJTW+pha9RmEk6dDyI76nlVwhZ5FIgQNh'
        'KpRDnhYXxFerGqKuqsL7JWyVUAXFIspVRTVNRrVTf3ML3/MjCfyRoktMvBQRuWUu7s9nYEnElpY41B7X3lkphikxi/8up/AfVoFE'
        '3JQGl9wKCCDNDmMpxjoZSs4wdLGFWQtdC5MWLrcwYmHYQm7hX4bYGE4N/WF1WB6WhnkLcxZqC+Pp2GB1dktqk6ipmOApyEhLFCfC'
        'd1kj1EO1lECOS1skEoBvQlGBWxM14vurSlCpxSZNXDw159a3P6MgFZAOBbs0c3otVHrKVGqhrsG1Qg5z2IZnl+2r9yQMY1oZd8/6'
        'XSgnnOG7S2JmwOTErQ6TzTVrkij7DQx5AeaTjDQtkpeZwHjw84Sli3Jz2wBJQDqA/G9/ADSeSLlysHp0TvccG9hPJseFThm7oG9l'
        'DOgLDY4za7bWoUbFwzQPl7Pl2fLjvk+EhcSrk3JIPha7vrv7ezRTYT/ZiHyxDxKnxuTykS2zat83/aJp+GL1C1tIYk5+iFlZW/7y'
        '07zNk1Jfm0ru/RtTXNoyIV1ZqUYDFxVk8aVQr5lYxh3zukWUC+ptfjyr0pJmATBlB6OA0YfIl98GL96a+jpDaf6a9SmSITkmD/Ru'
        '04l8vxyU4022L2OnsqEuXwVNJeVwz+5dnR7TY1E9cO+Y/yd1z+7rK7Rn3McyMb61fjmEpqW6ubx9uTlTEtgHcgsNtLDnDBqgGZ8c'
        '+nx36u2Wqiywt4lsNiB378z1A8zTGiJ67bU9VRG0M7TBrsdcCoIoCjoIDsO4Ab3fZ7iMFuZmpjojy+NiuYfQRRZHkn7odvm8N1qB'
        'c+1d2EHgF+DDcGNHLMvKExSPwMnYxnvD6h2OsE0WZioXTq12aTZQUk3zVel4YJH+iU+DnyaOUolPg5JnJyyTb9S+Vzup8TTlvHZm'
        '2lw71k41ATKU01+7VfgMZUhKxyHrV/F71da9e/V/q4Pb03NtzSEIbC6tHF6WagbgktZ1BzekQd7AvcUQZ1HlwqlVOvLEEpv29u3u'
        '93YmFo7qA3ieiqgcOBKoD11RH1Pe73vW9jqw0FB+e6933MJVC5cW5mamOqM8qgxjeun74NMf/mWUoETGMp7xvOfbDj4ASeoQOxaz'
        'Kuuy+2pS31DfU/tK2bw9b/5aPVAn6o/Tw2cmbp8lo67xkf36Rj6+85Vjdpjsjkl2lX1B4bFC97bbVsLjNDafeiI5uitgl7pezvn0'
        'IvNMxelqJHBFo6ZiuZMG6dYJCZ/dyJdnPVBrRVDGt3M5lIcVqh05tFCDl3c7K1zZsTTXsM4ds9frFybg2VSbtU3lJcW+7Z+2pSLd'
        '6qASQroqVv1BDECxysinb4vD4xhXMR7GeP7ZhdMcY2mWx/6D1yQ4TuaNBOzyveewUvrHL7Q8Q/jUEKzEnVg5tG9upgLj8/ikqJcd'
        '8mj35pZ80TQmiV/jrUOcQxBEMbPK7UDL6tZHM/gguQ9Wu9+kHP+iXVyQg7L/UndxiDKKFifk0NLCjlYDuufs5Wyfo3BobqZi60W8'
        'B/UgowunjkerlLntTl5UW5YTZqebtRhZvr7FC9egYxwO7kL5Odz3Kr/12adPnLgXiVv/xy+354qn/PHNzx+/EM3dpbtyj11xosKl'
        '3zc4+KE/Wp3v2eLUPfeNYqgcrq0AnkHXtXx3NqAX+ns2vicp7/q/svPE/LOvYwDBESD7v8BTiSe4kn1zM1WwOd7Swo4Lp+UYcspT'
        'tVKDMV2o1DOADW+jlq6pzY3r1eaEimsBmSJT8Sq0KxuQfWWBXpO0bqhY/+LEr/gx3+7ddj2j4nZfcQ1/FA7s+Vw7Sv9TzjLmF+9P'
        'hZcbBPff9R+KtecrPapkn/fU/4R/sPT+8JaUUVXct6lq31/ffUDpvx33bJXLYjltzPpg44g0II4FGekZgkwyPbW+Zw9u6Pul6Rje'
        'sodRRHq+Q9IzDgz8QVnJFHp2h5RH1oHsb21cJYflPHLhNMdYmg2MIXu1DJB+KVCde3LtBnPSVel62cRFMjcz1Rk52Tulk/Chn7hX'
        'QyVcbcBsbwmSsZn6TUKrS7ZpbNvY2LaD8bs1TgVf6FbmRhGf45CGl3kZhjoRIAYd7BBqtWN9GKI6OXJooQZ9tzObLnZgaa5hnTtm'
        'Tx7XTz/n3hU4SeI/L82YdEJuB2yDrMVz9fuhcjOrygigVA6/cTPapKJYnlBpjp0OlHrhDkFy7tTK1FwrzE2ZWzIfh7GtXXAYpWlg'
        'reG8l82EFh0Ca9AjMzYsi7v5hnlDo39YnP/bmq2Zs6D05NsflK52se/210ppi9RHRBplBuyzwCPB1v8B0jjEmHTI9QyzErOPOfgN'
        'ydSnealaijv1l37b8pHvPzyH8qUsQQvlH4LwsfC5VyjDt4fXcLsncIU/esLtUeTDJ8KKdaQRgkdVuNUTfHUGOoM2eJeH1ve/3xJB'
        'RKVnA0qMRxGlWqWY9lyNrs4oSEhb9CJSGYVeHMaRxJW0XEQY1/ILvgMq7q7Xc4UEm1id/XdxUN0H5UVQLAXSlDYR5UUIJWdPhgjN'
        '8k11XvSYm4z1mKEieL+yVQ1fpXjgpLII2OU/8cty0euyRXgFh5y4I8ufIp+qKSnK2fA8CoI4yB/XHk1jjtpDOWw5ToXW6znCpZtt'
        'u/qeVebHjNsvy8aVuy2Opq5o6hcmMz6nCC9WmFD6mZ4tx3uEcX/X9A3fi8sKz03XuzvKUW2heGxMJdWQMkbFV0yc9APf+AV5n++R'
        '00NFTsDicB8lh/zdzKvlWJWvGFGPeTEpLdRmt5Hpuv7UKoW9CnGd0k8tqL441qKxR+1mzwR6VjCVVReB4syyvVwpdFiqvCS4O63y'
        'ivPnCdPiyE1GUnQBy2xIR0sRCR/P7Vx7ytxOzX8Nzp/HtU3ZE+D87aau7pAVCLCuED+sR87omtHTHegC0W2DclJjPCnIGdQvLiKE'
        'tDRNe1dNpeHdORTC+6N05zfv+t0NWWEVykq1OI9ySyLiLGzC/UlDnX/m4DUrGvqwPUOGDFM+id1A6XJAfXuGl7ZQEGS0fhAlPbuj'
        'Yd1Dz8ydVYh0oQxNcFv/l0kTkQnJOyzBOEtv411oguo3QNUD9JOaipKighyXFuewgZaGurdP5g0JEbw2iwzlx/TSsPFuxTk0Oz9G'
        'iCCBN/G5urw31aLR09QRqSqbkJdGyho0Tp9nUiKHu3+YNehdE2xxIF0sAoo2seLDrdxVWuEbMr1jsEY/MI4MGrsm3HJmcLziLgs2'
        'XnsuwAZSl7UF/auvhXOSYPnVSn4TwDewt5j6NC9dPMqGTv2l3/azvj8d9kVqKb76st/koZ81G39RRqtyyF/fH3nGDSF4Oju/wrFn'
        'Vzdkp/8ATx7VCuop5NTOnOxyfWCqL/PIWKNiG/tWDgcg+++edb7voVlzxr55x6DXI+uD+Zq/gvYHefGy/k708v7voqPosN98HH4Y'
        '4fX6fbFarS+vSsE/bAGfa+ok1xD9EvrOj3Hn2aMB+Oet2drx6wtn6fqd58l6vMNs9YdWA1f8BKpgx963adfeu/wKB/aRfWZfROWO'
        'Tf+VNjTA5vprbAT9tvhJ204puyQu2wvflkLIAMixKR68ZpdgGGATB8eTMRmD+i3RK1TJQdxUeNc+k1ePD/M+YtSjXM1j4W4Xy+4c'
        'FCYWf4dp72aNSHxWkKMt4ggCLU31xLWzxJ0k8P0VVM3EgZfiSPeHjgT1T8U8ul/AOF5JrSTRhSypJykop5timzH5KxksupX9Df5q'
        'jf7nYm4vg03A06SKoVwuQ635FnDYvlx4nnkDSrew5YHd/KNbb9fZc/YnNx85J1s2yBuPHjs+nteqfytvM+TZ60g4FZt88y3YkAKw'
        'vQMjqUdtGzYOmEu5yxhIpH+iXpVj2BRBAMHVa+waupRVv0EhFR3rW4dwuILGmMbffZstabXoRWSNZcx2v5erltTWzXqpTjwOWke+'
        'MUUeS5lhG9o3gLqem3vSnMSfg7zx7O6ReKFXe0uHeynY8CBg+jzEMHSzGOvY3rLqxjDlhx8V7atZ02fNr+hKPpJdieS6vt9d+1N/'
        '94kgADmCIOycGo5PhXn8/cKiluLXfpmsmTVSZFUOIQuqZ9wQgp6dl+v4kSurfivxNzx5JOxmpiqQclk2qeuZt0F5ECW5LzNSmoj9'
        'nxop+7a7B6AR0XM9aLKMED1q7txpF/P5vUQ804r2I8ffbdBXJp/nycsfOILf5LHL/SeQ412e+YbfYL7fZC83kUJTv9gfbKV54vmG'
        'DGBw8QCLAmT8NgQA2r6FopPVkrtz7E+NmR9Xlthu4L2ePuj90Tsu0Vz2NQUX3w3g4Gk8h22v6Xp3fWd3xw1Bw5PDZrtd/xndE7rZ'
        'd+za3sySrgq/r+/N9mcXMw0aBA3vXkm/mS7S80YYutZsO+J56e8j5HyNn06SZWBXZnQa5v6Yx5o5g4gv/tvNrL1JG+rKlSrFvdsd'
        'vfoQs8Jmr/RqJ3ilpxTEeQPD/2KxAKihQ4YAYhk8hPz7+w4XKc5TnKVomqIuReP04biRZOpTvcuhA8ct4pWxnr9FYmuJ1gkiByPN'
        'k9gDgrNWaKmhXb7HOUGDaLS4yE92QTAhFbGfANDPkPa25Fnyf1cXONzebuu7F7uduWvW60a7engL+JNP1HWzW5nVn7Hp/ww2rBrr'
        'ZISwxTeWoeEjm41pcHdeyuc0wcJ8Dnt4503L1zVBIEf2HZa5LeohxA7IfoGzA5AZm/Z5r+HQTl0Dnp2/c8QNomSB6zJOYRT6PwEP'
        'GMZ3GPjwkTpbwXzOXC7lseTC93hkbjSYO2i2DTL7t2sjCoI+DGgKaTWnfT+K/IcQf6d96P8PcKI6piQqJ+lleFXnuSM2/bhagu8I'
        'BwRsX65nfuA/xE+CX/R+36M22PEYBQE1xV7fb2K/WNeWy92T4b/u37nOn8fGeUy+TCNJ/+QKrqGp5ujKD4VELWWL4mfx8tzWMNg1'
        'scuCZr4TuZcYQxfrKnMGskORJszVS1IfLZT/TPA4wgoOYQ7ThMRm9qaf/ZeorPPbY0vLEKVDYUQVAvdJIjRmf85CQ6dozfAhmdi1'
        'h+7tPiw8sGE4830OwNMkGAdq084G3AqY+g7UVsembMYO2YpJBu6aujORLizOfvuy13Ym8bRWkgNjrgciFMylOzRa/tGEh7dwwhfA'
        'MIo3PTXHfR2cbhxBNXWcDKltgs/F3j9/0/9CU+nyreAa2AhrL+LoO06EA7XVB3GCmRWN2JV78ledzCyybGN3fYbeAwdDb+rMHGpu'
        'ImYLaJ+ozhFPJLbpW7PL07reuIBC5xL6MFzLyt0Y9y/eyzcZubpvqav2lbXbfr9Na3WD7t0SI73RhSozHvmWstP8hkWRvc3iXyyf'
        'kRlRWzucJ0CzB4clLYteGyZAuc9lcYwXziEXXOAiNQZd7XZCxieqyVpqJU+cUoEOjbtELH88Qy9T6FPV68razL+kLCoROxr5VMu7'
        'etBKKCIeGd9PhasgCIBT1nN/bLO58dbPDGoyBkSohfaGfKYYfLfcuOD67bpmS1EhSvZLE/5scH31kF56elFwr5llN9TzxLaO540M'
        'EILTJRqTlnlXPQvM1uL7EHf9RHoZk5XgMgzl2m/xgFO2o4VzEG90la2BFU74OvxlQgFr9RgK8crogMO5Mj7LX8ZQo5ZMtu8OLNQs'
        'D2SSZxG60l1fS6Pu+AqNGWBNALnl5hMEMYsnsOhayX//z3gf/027GARiG3Mvv2x79ffdsLL073ztF8sHqsoF0SHlXMqtcuFCy9ra'
        'sg2+UcbI3DDs+t1ulDEp0SVWybXOtJ44ua+MgDhSMwBHk++BQgX97lXXgx0Z6HqulIR11wV3e2uZFSvH23Yx43yQpTwJKloa5NQu'
        'pOGLvqFpam9j9ovla6og9gyRdC7pVpIR25JlAwMYJDGy/w9IUyiO8b9Rj1gsgpijmReZHtebb8e+lCoABbm2kwl8H1/bES6rSarZ'
        'fMX35NrWNhPw+FLu9KVTex7AlV1N7j7SaJQlkG03PBykyTZ3M4U3pGF5QgO1wsbU1Ttbox2CVhqB46pSarraSrRpXHXH6SI2oLKy'
        'CLDOdVfN6mCJmLSsLLjMDkaMrcVqhYoumqwoi+eH6q66rBaZQJboMuqQa1+XDhunnB5gt0NF6mpZCVJ/ZUpqalFkSLq9BiB2SzBH'
        'pCPbPyAgOzK7ts6R414S6oBony96v7yCMjMr3Usyw2NzPfCJNGV1O0d2fbdjubS+XtfFCTVnow6s5/AOH+o411Epp3dDBimq+vBI'
        'BXPiMD/w9/L6TXzlUwxcjUYKu6BlMIDyjZwoL4UR0Sypb/Bp8TzKi8cpS1yr1vVATrKYvwyzS/zSGvONL+Holq+R6Ja2JLoVLBTd'
        'MnbeDCsW+k6cJYE2xSam/tWtjDKHu0nCZNXB7TSUGpSzV1PnlcPgUfelNjE3dj/FJkPSle6WBdi6JVaItHAQt9Ytu0BmFyN7m/3k'
        'EytLMZehGI6ifizPBRQPckKXDia9cv4qVTgkVhTihddxPecCF+m1ar++Kdv0gDyfS8nLvgMzOsyx64LWXHLp+dr8JEB3BvNJ87EK'
        'aiPMynbQPmV4p+uzPira29+kAoNsGlfSRRnHUPrgDC/Pla7DugPzQiqeAw71zk23sIBTOIFV6vAvmMMMptDBGGqAinhG9YktJZjo'
        'SGMNc32vqvIIk3rLx8pFlItbbG1NwEb/v9bliyRYAgNUS75arj/JiU3l17Xyx7PCi8kMuhVJkkQFqbt5OS6J1b5fdYh6urC+OwB3'
        'nwm6QoBVHZDnuhxJu077Xmy9uzmpzULWoBs/RFgTeHQyfMTX7BuPYbzQxjaHd34lvnryH+CPxu/ndGNc8od3G+8zJLWGkKFMyRXq'
        'zOoUDdKhhEwbl5X/oG80EUqUroP6/TlCI3WR1XTL9bBnvxPnyMS3rAwzZGjMs+/ENvPmlnbCx+7zB/yM6+3mTIAv3Q6ovj+2VJFX'
        'pEnki/uoIzz0/VmSX9AWjU+GfBiLvwcNxXxijNuSy5xth01WmetIAX/3C9+42/UKsgb1W6JXCL189C8RDqp7W9U+k7w6llpCXEQY'
        'L38KwtTkgKKCnCHJurxwkALTfLVaORoXGwlDK1xEHEFw8wpdaDRKnT9US4nIy4zTzSkAtZlSeTzxWt3XyqtW7qjKkwcrrUbFZjkx'
        'PbHRRfrxTZaSM+lFWyg9K+f/W2BnMTonNvCDfWBc+NyeLYsVtrhDeYMt7tIDekIFjsftkUJzOyGmvr9ZIHjTim2MAnAdUB/PBfyI'
        '4pp1Xqv3wv035QBwrYmOarrlenaI+2yltzw7BU0BHQSZRtvw6vGGfRyGyFtmBlmS+KIhtonQxMlSGjnRx3MAxzr2MdzSQR336/eR'
        'xZcw/9YZw0Qpm+G+E0vDtTZBbOIHErcT+bF/F+tYntSeef59jkAjYmQNGmjGD8XYdmWNQCtOJ75+8nyBRpuP5Ry0ltjv1i5d1rsy'
        'gni/X9WXl+Ra1TSz0HVjJ+gXGvOA37y14oI/wBYt1ncw8PXtOfedfUd440mHGPfOHTKXUV0WVWIK8ZfDfC88CLntZy5FXnTDqteR'
        'K6oAz4xVf76SthvXFLfkw5TlGp2/iK9JOe4F0q5LAIH1XDBsLqEpbjP2I6RfWt8FYRgTvgis9siHxpyzWwUQtuWR72vPCyy4zMy1'
        'InyBZUn8Oj8R/gxppdSqzUAZ+JhcL2c49rcFmQc805YU4lLtswP2gBGbd3U22QnOcvG5IKcNh9WZ5Ak0on3jwGB6LiscSH0TytGm'
        '1jJxGPlPPQp7wnmiVO4aU0zqt25VZVLgTBSyQ4DpDwDI4T6TwdlDU2X9N+kmgXNlx0f6s5HmP7ki21bxmKrKMHa7DwCJQ9RDwEz9'
        '/6mcdqcqUSkdS36yfySajs/JAoDO83lfQJFwTy22yQKs/UGDBpsDstXm05p3VqwhmLSAOYXs1SIpwKrgIM0kmngSPeJNsCSGBCXD'
        'MDhXQyI5UDEa6bsjDx3tj007mL0Jq5m3dh3DmE5H6+zI0HIB4NQRkjlghyYVDqGEC0Ep3ZG0Frj1vhM3KV0ondIKh7SAyr62C41V'
        'PEXrXnNArOP9zlELgPbXWT0pe5svjU10ddZmTd1MNmPaoRAFF5pKOsseAKuOEHmVP9qmjiMq1QNl6OgzcohSisCsMgrmxTC8CV+s'
        'ikbEEhLT68/MRkUqd9bpF+TzB3HUPjFj8xBy0opbr1pGkF4YDl9KU4n0SGg1Ky53cJCvQGZj9j1pV5hJczEIq2N5Ma+KAX2Aw44D'
        '+PswJy2AG0qj7Qvs2wICx6AiMVKlvXY5Dj6BiB9bszTm1cTSTRYchR9z0gJ4gBZtX3YDV+xDxRWBMemrY9rjxCLyADCgGWoVzadg'
        'jQbibxjBWW/wzgEJAC7JPlNZNdMNU92C2AHQFv3/h40El6yjhQpAcwngmMJ05inuBYvVfYdmPYDa6WT7egMLAD9Cb74u4sBimt57'
        'VYDGkw0Khm2ZNIFAbQMAzwG2N0LOMHIjC5cfbmRziUe1BfONipwSApOVOC00wFmMaCVJh00XCUOhNVzS+hSgESRIQ9wCls2VRlCa'
        'dFhD+gzoExdFqLXiRCqnMUeUcGGGc3YQ4OmaPPWngosYJr1DCEOJdmcYPDRd7iqi4mOl8HyEB5Pk0h4tGY5dlcMM0AwmxtpToKOn'
        'wtn0r02SZhgO6DJ9jCYucpYBIR9Se0etbRy/B7fNAE4CUEVkjXrVeSpIJBrUmEKwUENsGtUlVQmoKkHS8CcAvKhzhPtI/aD9w0gE'
        '0h7k+gNL0bduip+FNP8k5vhRLHCVsd6g3HAZrwCKMWL4Bj9/lopPnwjkT0DyvbH4WB/r3tEndUNnkm4rF02gePzw3sT38Ep+N+ut'
        '/MZK5JdXCPByFpEficDxukl5Epg8Uadjx5iJ/BE+otMZStfjk8SdK3BBq8XL7mw8fzEXzQ10n245veE0+0binDFPh6wCTzlPuU41'
        'n1p/6sipkVP+8SehZfToqDrK+Ch0nQA1Af81GcC9Tq/hZRvULpWqqqbeVVnJiHOEHh1Sh6g2dHeIlgw6B+mRAdD67/ZTV5/SR0v6'
        'mvsu9Zl9/OCBTHQfgObdcGk37BYpuGtnHPKduHP9TmWnudMo7Za66YZuaFE2KLRLAU25q1BX56rO5k62TZh4ZCts2VyGHe1ObHdn'
        'Y3NTLTYJByZCvJxgi5f9bUz2YyauLqtVZ3u5sBWWLZ2FS/s6UdZI2ReY7GOlaTQwCGG1bB5rYGuYr+ExpYGHSh5HpZCpsnLFHTfM'
        'FhacJRw4E5faiIBJYQi6QUCsNUaOAC6HW7lMgcgaBBC5k6/i67kP5yXcxZu5wie5yc05P48MzpoJuM4hhlGY78CXcWK/W8RxvmG2'
        '53OY6S7wxmq0uMjruQ6EBIfNna4JiLdv+3jbbdB/LMeSwiBzzAaSC2niDQ8eC2GW2GfPu/SLeGJxstnzkH72bKK4EiZIswvjmaAt'
        '20FPEBvMUaINFYM5VvKe8d0jbSgz5zzj22MYM/QpJbsYz4la2F3tPoYPxjw74jzjGqd0/SEA'),
    'arial-700': ('d09GMgABAAAAAEvsABEAAAAAkeQAAEuNAAIZmQAAAAAAAAAAAAAAAAAAAAAAAAAAGiIbhFgcSAZgAHQIhQgJjzQREAqB7ViB1RcB'
        'NgIkA4ZgC4M2AAQgBYNIByAMiRAbyoI1zLPOwG0D6McLyDVmH0WwcWDzjHtwcJyHjYMZ5mz07P//nCCHjAzoX4Ba1U2k2EmV3C27'
        'ZBWORCLRFo5Tcii0NFevuUS6SRcnDkfgrMr5Ed/Zvp/0IaxIn8DhTp8tAkKIhNgccUJb1kU+CVsd1xtwcOLIcPAT4EAw57xpkyHi'
        'wvOFSm4Z61nTcwv9qVbi2dpfaN3pkM3thK8rNSr+STbhElrwVoUiHqGxT3JJInAtqjqTzOzdA5EmAocsnz2CPPmk3hKwQp4M0Ny6'
        'BTAyNmrUiBz06FEbuTWOqgFSMRgxRBCQKJOyqFDAeCosVGidCAhWvCLa/P/8pr77/if6ksePvDafpI8YqZOa8mt/c6iw1klN4XS0'
        'm8PpSUVhLRVNagrLolVmTjsqznpoN4eaAg8495m0/AHT8iHBOxbyhkLP2dkJPYsehaf+3//S8lbdwkdVrx6QGoSGtue11fKx23C6'
        'w5qQNBCYzNE8hdDyQICsENoBXJBCYFj2spfYga8l+2M2QHboi+z3v186dx6Geen9JAUUZgKA6v8t6AjXUQVW8m/VnqoKUyUjW7u2'
        '5nw/9EKrYRxaIjfALohMOeh/qirgtEZl0gUpwP0R6ZUi6AJ3OneAlAF0pTK1PlbY2/CQKmfKmmWrY2zLjYchEzVYdLn+fWlhGrO5'
        'pHAS7qm4DEv/T2f5/8hr782fb63OQaiTpstLlepGGkPuTLABNvxG2usW2jBVwDSSQng1tjCLNKZ7hUyyytwu5pFuLVqH/yhWxe4c'
        'k6YFmrWd0e/w/1fT8lpfLc/K3k1iLSrhJbYPtwU66uVwDV+56le1uqtL3W5J9kQt75vI0oA08EbWkOxZcMsB2RMGB4gNAcmz0LYD'
        'tmfZYToyXsOn5HzK5cjEA7yp6vrgc6ubRo7yRg9bXds2Av8+7o744tfJcKFc4dYhl54Eh3MByaQva9Y+yUxjNMGe0sveyzrGRHTV'
        'jmS5ALsJFsa0kDiOyJUvD3/mF6Lx7ExnupyRi6hUcfTt/zeNqZ1WELvS9teKdeFAQUGGoJjE/vEEYHngFZBw/MeAzFiIPrKCwaBL'
        'YeBA9zvAkwIgTmclHwXUz06OiEXsgpDU+G6gAHrnb4lfJsc7/8zkeADGCzcEBVagR2VAWuqqaIJFOumcG+7aiFIoKc3tPMjLPIX3'
        'GQ6MSgKuO1Wa9KGZMGPBEoYbMjpfDHPmgan2QZjOhUG9Ej/QNGvWmWAsLWdlTHdGD9K3LxlVztNgCOGuCKIqVSeSz36GXIOmoIGy'
        '8PyIRFWqdiXEAlzCZd9KnEeKmJBLyitR4BRp5CW2SmcGV+k+BYIk2yQFksbgC4wtwoS7MwM4Q6VWKbGV7jxdJdslB3dog1AJ61AJ'
        'XOBCJQwCFz4CF7iEy1iJzqaOYGACs9F5LG0QiJIEoEm6bgKZp6EeVMrKSdQTGAbV4BthMs6CzDGzAEhRdLQHj9SRzlzx1eidlpCY'
        'AJifXkgqP14hc4rYORGhyfyQncbccJc81EgZwQNo9zYTQNbz0w9viCwSCx6cnixi6BfdjrZz2llv1dZ7k50AJOSmEjzLMzEmk12u'
        'HtOZ1F0aB2Bjej8SCsjk6kWBsoOgghcqBgIq1+HGKVIRqYpEIbtV1qhmSdtxYy0bG5VEyjWEqn+wDncOJ7YHtnu3O7fbttW3HJ5N'
        'QQ4AcW57WXaT0ziksZ4NFLK6kJIB6N/58NdlPrF/h2oBrzDrRMM372o/yycsu6XfQ/gNz1bRDi8Csqo9++b6E6d+5Xial8xnFs0a'
        'okxdUEf+oo3A5bt+x2r3PXETEA2dM6cpzx9gRUVLxAIv3taBRwREntrdcwhshxfVlZi6OK9gSxngAO+XWQ0Dpyy4Z593KQfo1t2P'
        'UVykGNQKhcvlazbcKxgAy5xxrGGv7aF5pHH+NwLE+4FhI7M/9hqlgm/xUz6mipTVMNhO59Gs5XTQEFOGC/j5GoBbRKkXksfGR3fD'
        '4Ijvz/vmhJkZHlTrjOchqjSmd745Xxaor6yi+qK1So8gBAxfECu/kOgchrf9qxuytz+d4P/08JsdNl5XM0jXx8fnU6/PznnSLPgS'
        'MFoNfC83P8YRXyqFTCL2KsHH28vTwx2Pc3N1cXbCOjrYX7e1scZYWVqYm6GNjD8f99vpeNjvtpv1ctRr1yaKm8r/kmiqJQC5gUmy'
        'VdZkqB6xlqRpN8W1u6EyoFJLbLIZjYyUXaqFBJmRU99xEsgZvQ3LflLFM3mVXe2/RBJ/i0t5gNsZ9yTfTF/UPWgHGZul0JdSyswF'
        'oVBTSuXmkyZuhOKnlqee7jXqLO3EAEvdPQ+5y+2OJbqXsHSdJ3leMpcvHm3v+5M4y5KpF3F8qjCFUMr/bBpFf72oz9Baf0fCryGk'
        'ZX/ac6YvlfToR1xrD7L5oHcv0mJ9x8EU+yaPZiN+/lAOaSxTodkX/9Y8b5bw6CVn8JDx7nZ2jAY73NeFw6WMZPwHyGnjf6WtIJ5G'
        'fB8GXgNOnXKVoqQyxM8lK8sYSsWgo01unVFs9fZ+vjNBgo4d0LqU319msLl2g8HQ8Mv+a1eWsxYjM72uyezJpp6xtOsNUheFaoXv'
        'q+m2KoawBq9uWqklKK+2hTVf1kJPXE4q04iPJCe0B+eNq/50jN1epca52UAq1djKxdKm0TC96UNWC2gTlfruqriUlZn+C0VxuCUv'
        'nfC0qIQx+8eCy+AjfJ1zsFmWjvUTuwnr3QtfLLX2y0uUrRMc6wyZAJVPmja0Kef92NYL4NK5T0lx65N6swZMenbCnKrDIdMvVvJi'
        'eEr3MEr5xuKUiqZfue76OTtitAPKFxJKyvxIbZYm5sXwyGOSzLpOLzuRdFaKTy/ZWfJFx4rxjoPJ/L5dLy5jIYhFVMKydEJBPFB4'
        'cksey+pEln+hU/6YvJE5ZyuyM113cRKYib4enU2mD+qSAirhEmLa3hwYEpv8Jpm9pWR5y1J+NdI2CVRZI+xx19KBGg/lgmWx/Cuv'
        'k2apoGDR36Pl9tLqzgiT9K/IQYd+obx0/BGXQ2u2HJSZre0L6ozUE0M9mx/IqSN0tNo7vkY6WiJPzTMn025euDRcYX0huN76No2d'
        'KxgLheCBqmviUiykh03NIzOy5Utg2wdkR0C1jLFuq9izTWk1A6dR0P4tysWW+DWA3+ZOKmuZBQ6F2JKb3+R0c7mHbH10UanZukrE'
        'XyXea/HC12CYWW7ncnctJKY81fn7kyT8/VnXrQ8yVvl47j4yeC3kPjXatEEqmoQYE/wUqiCLnIWK1KxYl22aKlviSfHVAHS3KkZA'
        'YU4ODqJltAkcto4QwYajptylEy3XbDd3bpHtN3fc3D3UxzMJZfnRTfodxLpAn3rRhyWi2mx+AG3ZkiII2itebMPFsNmLrovyCRD/'
        'Yt6Mobz62FHTbsialJyRi1xS9co3MfczrUzjJadcw4H6dQYOsySw7y2760s5eup5WuhG+EbIk0Bdapx/aqpz16YjTv70PacoQ+XA'
        'T+GDG5Pk3ugLfWRo68XdMplpci16R96FdQnb4WHzXxfJWC2SU0TYUsI0028eVvjeC8n1vQHZ/RhTEMeFOi5C7028v76IoS5fDW8l'
        '8lP1LoOXjdtHtW+s1F3lewv9wZtBBNZu4CNjLC65jlJ6tXgzesKWuKxjlxnOORMcuqchoqE3WrL6/OwyHzEm5iPG37eegTzF/xFp'
        'VMamtDnRYRpFIWXIkKt0fEQ1gWSkYxn6eOjdPNjYAEAhjmPayPo2PA+G3ufAdtgNgIUeZxwCPwdqnaxMNdUaikJickjzir6TqlPU'
        'VhQOREI/x5KnDqCXc99h5Bhwc3M3I8S6p+A5ISUDxjsZTPWGVwEr0W0epe7SJNBN3TEHaaQoNdkjqNcgklILGosicTmLgzsXuqAu'
        'aMIhQZ6Ke81W6syDv/M7vEWXX8fj7O3jvsnyk7T2IjUUbKWFNlcH/s6uM/7NjCZrP7DY/DI7pFx+/pj3NoepjK8UXhY++8xKqtqC'
        'aJuOcvUuyuFAmo8LHSzj2P+kfhW3SjO5hU44/7lCWnGxPZOEuPdN3Kal0oFBDkgxDFNqdVmiBtzBEChgdYXQSvakTmdmSgo1yniD'
        '2A6C1iWBaz0c8jYDYVm6ndJ6a+ygJFv6VApB0v2Sd0yGA+uu5VrxuygWPgW1kOeiTFBH4SrBIhPnP2dHvI+cgSfAMCdGIqg38XPG'
        'xq7BuiHzkRq82cYeI7Pi5XhB6M3Mr506Rt3gU8bHbkS71qQ4dcw9UCsrmdxrGaNe56fMPD3HKOzlbsBqpvitoULBKbuBwGoNgg1Y'
        'UbVD2eBa8dBG6+klhlb+4auDIPamsoHekG6JU70M5KgJ8ojFXf2PTLf/CVT9Tbsb+97M8Asu8y/H4efratOJouP8G+160wivN+fc'
        '75vcTiTdm1vCo0OPRZSbiiMV+DZMjqp9v9fJzijHQR8i/Sgr/9JS4KPLaPRIdRZDbwN2agh1FYF8S1XM7OJyIE6gwbCCY/UuRznV'
        '2MpRw5Vwi9ck2nD9pEqxb1NNaWNhMw9c8m2zb4cgtWzqfiIrvWnnFt8TL45d6Ys2v2cLa3dImmiLn0wNkGygizNRr6cyEh4cegPk'
        'E5q2+VzqsH5P/5QpNhamgpBKffNNKaSdlVwcZbTpZ7IYkR/oTsEmmeTlcT7uTbbNMYMNuP7wGnSuToXEW2nvHJnNkW4oOScsj40F'
        'err6Z1hcii6fzMtpgRqLmdld8HjKs7lUzNaG57txpY9H6hjBKmpJCGbN0N/QuoUsBsO1LGZaeG2xATJBbkFfv+Scw9iQR4s7kQ/D'
        '4/cj9nur9l3recXCmY4p+ZSeYyabT1aWZN4Q9MbBXGOStu3NCrfvQyS601U/Q72D712AkoC3U1iUwzyJoKBUqeOpKfZ/Gu9Ty3Fb'
        'qZqaRpqLnw3AK779H6ABN3PGA8HhpY5uqT6fPfh0rzBF80kZWMGardNNIf/UqpQIMqyOBf5t8D7iVQf/+DoopdHEqvWq6pRHcxKj'
        'RJkZahm/iO9h0FPOOX+ND9lW8uC7Rdk7m4HpsmEljZ3NyOp7LNUcyzC3eHBOh6rZG+rg7DcTTeC0N65vHVADtYEgkwQ2Kqu/+BIk'
        '1GEyeUKGO1ZWufjh+E8nGskREOhKsE0WvFT2ZpvJfh2YApXMfCQ0Gz75CDwkuizm1INorxXInHPdFFZyUbspju2tzsbxPuLHwmK6'
        'davFx7N0eOUpYddgBLNw3PLIjG+gkdWCoAEEKVayQvxyA1pSjJ2wqYhtLgr83f4YfG46K8o+T4TXwvHA4c6jCF95CVithNbDQqMZ'
        'A6xBdeHZVOXV+I/8WGXBik+bR/f9/C1H9U2IAxEz2FSgC8wMN5lyrpstidgGLbewuUUJGlpcKjNFUT6EJFnL4vjpeAYNsrMW0lnu'
        '1ri6giU1Jx+dBPULEDt+9k2Z9QYsXOZ1SyCZ5B1UTpCgrqjPuF4nBjTGav1Ncfp1k5okFYNEj0IvWLt/prtuIe4lSURRWNLVUKhw'
        'mfaJPC3A+g/QSRs7BM0W1Cc4/f5SkmAHG5V2t++1tdI1XjhTrVM+peA2yHFs2DsIGq2R9DkaaA77u8mLBtAgEJm9g6cXMAiTGKjj'
        'HGF+V+cpj+Eo7IQdhlHEv4Ur9QMWiUYRT4h2SdZatCZrrEk/sDyTPh1yGXy5XvPrdNlBRzZnXaTAoqMKAel1owqHnTYSZZr0vTCG'
        'kdOttyjF5ewdX0D1jTE6MYUoME1z2F9X4afNG+2bbERRIp0tQ1pSDEb97NV0phM3nsajsZ2MYleYXwsIyyiYCMplyXCVmy62SWFZ'
        '+FwaNo+BQ2Ih58SvQfxcNyDsO/Gj2G4Ab2pu5Rfuu6/e8j3G+egQfcBY0O86uhoNhI3FwhbF3f+/rai+CFpl5AvsobvsxPk1Q1ip'
        'QRXi7N2EDc0QaMosWr2lx9q/gWEK041m/2SNtGZi0WkE9dkg02D5FfprCnSircYpjZYpCzi/rQdnDNNR5lq8O/K+gxEEKCBf+GcR'
        'epRYbRiNdIE/S1E6BV0UiEJ7rJfo6f1oXHYEFZS982mhWgstQaPBKSmCyV3FtxKWb+QWQgdf29rRZZcf+/5kw4q0HbDmkksp/bOo'
        'PtqmsQKKpKqF8SedE53dwRsJQ0oEczXqGn8yeAUxCDqGHo0MlXJP0WTOnzzzrWJ9mFhHSURwRJAih7vGKQVcxD/JuX+lqbi+5XKg'
        's8d6/QGR3eDDNonNz3qzz9ePuHg8rPtIzj9LzDeB2YCKy3XVbh5mjd9p/7mENAx9mfsA64vrXuP7dEtj4tDAJSYymfzFKqnQC+qX'
        'w4+cS2zdG3rCVxRXVADtxcWcRBbwoURotEAfgeALiqig6lte+TeFa/TeXAlSxs8a2zlrpiATnoqUxyf1P7n2ord/YPfpdtf2rcGO'
        '5x5fKh5YHecsYvvFrnXvPHsy+LK/d2Dv6W7XU7LkTrNNsTvBpqSxxb7AA29fbC8x0vjPbyjboqYmhyIPd7vif6JH8osvLPUR8fWc'
        'hun2ofap5hIvr+yK6E6f0N6qlqhGs/uPXJxes29Rcf6O9vciPGndtq6YjvzFV39XjKYbrTzcHL0IVDe6WTRTj2Fr5MKjZnPlRvR4'
        'F+FsGCcj0ZFpGCGjVsCF/xOTq2hv2CmblJMtm2jYhjfuVkxLiJdPNL1WBbU3vzk5JiFZOdOjrdLz0kkpGaUUUFVpJuFtlNPMT5ub'
        'K9czq3/X/b6ZNbo0obMWH6PExdfpc5Znnp+p3K4s/4ut2dboc8w0vm7pfRPjiu/w5KBVVH3O7MP2WRlaBS1rKWH27aP4i28Sjl8m'
        'I/YTvu2t/o22Xz7d++tVNDxmWmOdHECg0gLV16YnURuUACKBFop6rMVZDJgkLm0G7wn0Oy3quk2bZ959cZZdm5F+3uPGTUZgsHAw'
        'QlR2en9hee/rw5Ewr2ZWUV1aWUJykrxDxStbbHXxHGT9867gI5kZRTnE3fsRCWFRgcVhRaG7/ixWqD89ODSAHhPER5eTlB4CLTza'
        '/DHXX3iuo1oeekGit7ceM6msLKTMWdYwqcRUjyzON5rz5oifdop2/dyAcbqwui0D+xr+N6Y4KCcjfSSBSI1mH89NSCuMScMzJCCS'
        'cJ9FgkxYxJGzdz7/TMFWL+z8Pnz2U8CfzhJh/7n2oFHnCkxdo7QwKX/npZ57s0/EKPcTfDUzPjckICE9NDu1JSgousjLse5iYH07'
        'PEcBp9eu0e+H66HseYy8mtRxciyf43ny9X/Y49ni8zcKpKFJcmV9KT3789sv9qcGU0p7UmWgxdLnrjp9C/fzDxievHvDnxGAPNx8'
        'Gnk0JY4dm5QQF5nkhU1ezxBP+XNrqUm3i08dVVOenrsD2tRw76aE33ryZ+MZ8PPd34NArXPHks8FBcQUZaRFnwxipGeRZz4hkAjl'
        'T3Ak/NBl7pfqHe9gN+wJzpfdOHDkoScVgnVAF++ZirvkAM67pjxk9y3IloOx5iZk05/KfnNBzki57K3/Dwpr7LoCDqGdTad4mDsZ'
        'YcN0BXkiIpvDXGLw9EQX3+SImIgTaYLBCoKIu7I72x9E1nRTx0VURNzTQleHc3W32gv8QxlEjQBeNHPmeFRj993hS/mKexcrpp17'
        'eFGnG1J/qnc5G79RJlSXUl6f7DsjpFw9/jlu8VHZwXQTSvnUFAp1zpbVFuhA7HgfOXab+Ub+z53R31JfwwZv4Ys2g9IzAgPr2KQ9'
        'VnLwsXAsmxzSZHq3OI4dBWdHaSI1OP5IHo7OXju1Vt6v8V59aZ1O8T9h2oWaCeVFYBLg4RwHw672ZRZeLlbolLzay1oJyvTJIASQ'
        'chJpxIM5hfQ6TkVB5HF0/4pglCCwS7rnMLdNSc5n+EWkUH5YzNlNQFyR0RPsY7cffP/0deWQRJe496TT2bLrLgbA+Rd+PFLLe/fd'
        'R+7izV9jWzymJYDjUPb0Qz/vfU6h7aXKQxsHF/cWeTQBHNE9nHHwcso69tK075NI3oTkSM6sbxI70D8lOeBzUbwoUTfmv7i8R+u/'
        '3316BnWX8Y/0r1DQREeiv1lxteLDCkQKSnLfjqKW1XXEj4Ywab6MtPhd+Cv76ac/v5n7/izqKQSXmSEvK9f3CFnrmr5JPKfG/T01'
        'Yj9wqcgP47oKqUSL7kos6eCYdMFXHjTe7vRlotNS0h6GI3Y7YibW+ac5dOyiwm3FG4Ptn4cRUfuu4qfYJr/eB4RA4/mnPV5O/Rue'
        'mUUUcka2j09mnp733jp4em4dePn6qcD43BoER4RMn8hefZnaHPiZmF8srL9ir7UeP+NF37HKOpaJCzSeR0ilH6BVQrPoCdY3QXdy'
        '5FMvrQ45LCkgMGwrjFGu4ETVEaKrDEMW118eE3/EN+7Vta1VqLB9ZL4u3oNmtRSw8xICCCGnHho/0RY1GdedUjBQSGgLrzcbsXH1'
        'yjcZVm9Uz9YLs3GholI8xpXuSvDyXtIYUURJM4r8coXaLSxdEow61e/q9OIigs2KSEaUxkbNxvm94b1DtyVJNVN5WJImo62p+1xT'
        'x2AHQTNUyB2Fx+oi6zmmEmolCLrBgBTV+JqEZAnaMuQz8CD41ahaKdsgW6B4QiiMECgzxNEVmq7Q58qXmv7p3nEf+CBFRmvKpZi+'
        'ELgkpnvoJBJidO5i+Wpv7Lyl5f//nzXvOr+yp23yBYtFYZXD7M2IZCrZ7ND6T2MXDS/d6X11sGB4aUEtPrkdCGlKY1KAHznjKGMt'
        '8RcHHyXMDiTk2sdlAD/YmBKwNJTVRbDLJ6dPu3IpeVi52jwNyZ/eZ73h8PBmsqQu+BdXRp+QbOzrPN/+pO8h6DXEIgYfSfHGucKI'
        '6sKIxrcX7y1s3rlV6qflbIRcPXOclTatFBMexR/Om7biC6sEhUCIqjpuNl6u7tbYo262uW5xuC8qQmtat1PawvQCwGowloM4n/+5'
        'VXgTpA8a+PD3xH1Vdf4bsQNJyeljg92p48lbNkTJA0F1XiFhnR/jP8eV2xHCgqSgUN/HsembhNhwoTC4kEh8fs9iINbTTiBTC8qY'
        'PhxdQPELb6jPp7QG6QWCQQNl8O1wvmIF1b7UkeSkuOGRxM0E1pQdXnKfByktxK+8/+abqQ5suCm15Wg9Kh8mk6whAxkIiykBZ1/m'
        'K4grSFCsZbPl2E1jTUm158ubfUJFh05o49px1NUxJ/LA3OdT8mVySBGHUDwhLbaywgoUA/afOxx9KA/jX1W+/54xxaMGy8AK8MRW'
        'KL/ieQd8fdaWfit+hxmylZh+KwThFGqZ3ZWQ0X19+X6vXKDiZCS7t8QJDrgPr4/jiyLA9p8/hD8Ur/uLgWNo/NDfFnrQGu4Cm1PD'
        'eYelw29VVp2dxyLfZJJPlZiGxBk3yL5yptai8oHptegqFKR4mRrTU+oMx9Gh8bpCqvyXlaEm2ecSjv4wfcdrnnM2LqPpytqdPlnL'
        'BUnMJmgZsdYziAR/fqOL/wT2+eCNlfjUdMB/uS4vj7IOhF8GqSEymdOTCdiH2CPpECPcF1XRDdRccnuonj9vwJlm+NuzfEHijrzR'
        'ptDAud+jD1XVBY9uJaZP9/elj8Xv2JDlhZ6g5t8zpgwEEu1EeGLL38pOQc+B/eehowuotyI9KWNJO8mJW/GZUzaVNkeg6fpCKvzD'
        'SlCtJHt/uh7WXOSdk4hpdGpHm6Sd4/82jcCv3a33J1F1B+pSnpH2+emx1g6mNJsoqQ8GVwi0/MDzH7u5k2/rFcp/wAUdAxwiw8OM'
        'bQw9zRniufAZ83QP1/TkS+Ls40UluSVjp+l/+/8tjC0Y+1i726ss9EapWMMLMUGKE2yZrpQvSkiw0o3HIqsbwtJ/M7kEOVOM9oj/'
        'jsX8GduFuSDUIY0kBryrdkS132Srp1pbvBADE1SzFsbLpXZk61/JXkaUyh87Pww9HDX5Xfy3WLfMIFPA8GXIixB0Jl8F2gHRHuEh'
        'dNtNz8Zbw46OYiJmDLU7fmketdmWC3R42/wPhZhJoT680Xx4gjT/p23lnsCdn5d0F5z12otaGipwyXGJ6aDpTGhsYhKupuFM6ewY'
        'xo8QFa0flFziJwENlE44EaAfQ4j0w4w7nZ8D+Gp5AVlrpvPGKsA7MkbfP7EkQBrKkEg5Eawf7R0VYDU2W9pwpgaXGJeUCZ3OBMWl'
        'JODKmxuLZ53MsFCPKm13eJEBzS1dx0FvNZHcFH3C4Jh+mKx+UZIf93eqGkromJ4IUkQiPAUMWX0Jhqweev5oXJX6JPru9Vs4V+7G'
        'RfBwu8TjW/Kn4MIiR5La9Fr9uUNC4QhB6TNbdwekxi+CgFQHK1Vm73e515FxZh/Y2IlV6locOz28EGHlXhntP9J59ced1QcrHZMl'
        'umdeG0h5El2wfj7JOTtKnUqMKGJ1mAWbGRMqFpB0vCvTOrywsOF8QWE4JoMVgikqamwsLrIOzUy3Cj1e2NhcWBSGYWWFWBadaGgs'
        'OmEVusOisbLo1Kxsav2NT6NlsUh/r0rVkC6Saknvxd4TagmgC6QaqdgFFWGyOFmFdf6SAK+AWHisIK+gh9q32qm3JxGFH+UWkrCM'
        'RCbGUds3VKdAoU2jhUhh0QPiKmiIQe+Btl/9b7Y+l6Lq3qtL+mS5Z2flOBCMfkfq3dBdMOo8nxgQlxepekQjpJhS//aSoom1W7pH'
        'N3JCpkCbFqZdrDTFX6yg3sd9zC3jrnHZ/qHTkxMEwsTkLOn2Lc/RyUkfn8nJKcLUuFfC5KVLcvLaolH2fCei49JFeblLly/L4zPP'
        'JPhKcVptDDYCL+/cbGDF7klgTy5t3r13b3m8oDfBMPW8VkOwk0tcfFkyEA5JZoY8kIfWgHQymJH8AaMw8ZAGZm5pHSvpg5GYCjTO'
        'QdzcjYDzhLid8C6wpQU5yvuB6OAtY2qUcWL54TS3w/iPGn/jJKt2E/RyMCj+vUu2WHmZ7lbbhpzEEf7X3K2DAcs0q6uG7mdP5ycF'
        'BqV5ya34PMFYuVu7HD+owmJdC9xmu8sDy2X1B2kFt24UFf43dJxGqa4h+RbfvNHIcfUPcnULDHZxCQl1dgoK0b0wRd2mVm9VU7Yp'
        'NVsOxtNbkC2s6RAo8340k4GhWdjjNP2IVP6QSahQ6OlM9rHa+LCcMyGRjp62n2NK8Zq7eWH1CaXFjVFCUSOC/P7MyOCAMstcE/t/'
        'uppcXV9+35uCAgFn4nLyKyKpDjiGtyiYBKP7ZfOkNiv/VgbrkiU1pYXC9CBI6hEvH1OCYTQUg8uBA/bgAacoxxlHfE83Y+G4Ar4E'
        'C8zMF8D8tUXhy8+0zWMdkzc6O2bGetMqHU9KoJFo+a9vA88H1eqnpaPQJS5qSVjUom1XJZIYAGUQD6EzQ6wbK92xWddS++idLLxe'
        'Hfri1ZvNZwauX77Yd72ppWdgvi0GE4zHO4QyY+wjnDzsw3X8T6odMv/GaXw8jHe7Jbm/Rd6DtgExiXxJFhuBQzzNsXe+qJZQpxh3'
        'eoLrtUOUk5KRQVheYk51RaF1Zznzu6NheZt52S93HVbabY3iP3zxrxfqmwh9IDmEE72ZxOFyKPFSd9582FyMC+eGx/4afwYOlpGR'
        'kpNTpLqERQQFNZ4PCijHbQwKCQpobKbzYW41uLOPN2aSbMX30dx5PDF1svxuQkCSwuDTHi9s/5OVWk9Gvrmk6D1qtsoylGGeNb8G'
        'NWn5tEDORRz6GafNrQMBJMwoRQTvFGUuvE5qCZR3mz9235D+iT7XWo8vyD6G5lqxCnOx7tWWF2933KpJ0XkgU6RmSMQ7W5l6+Prb'
        'tB89a24ewJlFE/Qd/b18o2Jzy7/BP7399+Xzgw/XzpsjKWinKwowKfjJ3IA2tofcMK5TRW+ClHn2XuGe3IWrXedaN3sfQz9BLI76'
        'hPtSPfAwb3VheMP7S48ep8RwYh65LSeTHK5JuxD73XMhzLikeDlwcPqnQVEQqqqem42Xu7uJ8QdnRrWwFj+9L80Kv2Ds66E8SA3I'
        '72L+V6+RPODoZvtiaqga68YVF7prB1MjyPCvYOIIr5NrS05FJmCsy27IyDleGShDZAuE/KXJNx/fpBdvQ7ZZFXfb3S2YbuKYb2L2'
        '9Zm1tOr39sEKzBeQwpNuXF9ILEdPfPUXcz1139r5KHA/PlDU6dQ9W7dIiDeFq2HffoI/gLSdXvD4gtwf0AbCgrim9a8NdMdfSUxK'
        'G750Kb0/fscBUY2BY+wMpP5TaL47Dl0ab1EA2b6wVDWLj66pi43Vg6Kj6ybLZZrg8OYmeDczS12iiRker6my36znq0E2cNdQ0u4R'
        '9izhSzRK9MN66h+ZB8ZpKGpNCOOLeRsSi5tsx+8d3JOZuJcP0PDOgF2zn2aZ3LDwvG7r5dyKy+NRQ+yNsYwGrMnDBW2n8qDKGr2e'
        'lGZ2Hq5teA4UqYW4woHmneq8FcPWJKOrrGk1dRP7abbZkKXncPlxFuSzzeRiXjjJMr5h5XOj8GLHnvEc9FUMkXuJ+NJLrJ4eVkZX'
        'd1ZWZ2dmVnenZFA+8ByJbkcroXvqe9Cg/47FN84dyb+1VaNVUzEX5jfvFEY7+PDw+Btuv/ihAjSHo/rxE6VElf7bGxl9DuFX4ONo'
        '1nlJyKb5a5puB54b3v1PoVNWlB9PJrqHMctFzrop1BnKqlIU64zkza8rkluwlhxbXF0urkI9siN9oW+tN2nq9P/zLLG2HFxuXQVO'
        'vYJMHFGii48FUudC5+AUyzzyfcj2mvLQL/LPuuBfzxeUedL+Uf79l3WnP+qV9SJle813T0GX7mxRBMlvFAuov7hfc8u4U1wDPvtr'
        'zQZbankBEKCASGxLgLV8eSvgQXk0ecET8HC4+r9HAxkhq2xNHhb+xxPattpdACm7gsSWgKqdsBoaE7+Wl/HrKT/94/iNVB4+lTEX'
        'NfX+zLxptlHsmlkbqrEX4teTYm8Y0JkwAqvX2fOsrXKe9Wc7Np63DaVpFbbRiI33TfxaQcStZ5btaRsT42tztjlDI97Er+Vn/HrK'
        '7I2RbQxJG+rA/vXIjnoxPjXI+Enz8dP645nWD5+KANK2nfXV1IgrZ3c2kYPjARycLeB82r6agMMce+6EEUhdz55n8kHFVFjzOWg6'
        'AhrhkR3Di/GpyYqfDBA/7cdBzChotHhHj+NTkxk36Q/boyFsBslxRT4r8r/PDbm2AiL/J3KvTGOvqm11VM4W31IusPtMpq2oRg/b'
        'vooqvmo1TADtlkkW2nTDyn3jKjQTQZSZ3irbKSWANlrrYbgNRaRvpPJOizDdcha1967Dr590+7p5Wo+b2t0nZZT+vu2ingnrJoCx'
        'zAZxr2fCugyHqwHa9sT0SdXM9gzafrbNhEunHOsRZnq1qN4IkPrWOtj2c3BpDwLyCN0iGVAuOU7vAZQbcY5uOR0RxcV6RpuhmrWo'
        '58M/DYiWyiP+9SD8k+FwsZlemScirF+6VwJiJ2NRTE0B0GBB1Gw9VSxYAnJmkwyj6qgII7onKuwrtXbxqcxzqcVAJXLgY9NSZ3yj'
        '3h6rr2WBroVeUvMA+97o3XxT0lu3ilrQMpTjU7l6kEMFCyWXn4hnd08h4rmB+5STC79qlNBlDVDzxamudoYoMJ6ys5W2xUieTh53'
        'dO+7HXeNy9d8Pj93U3fbv8v7sy7vrwLaEZQzN21jR6bxZBJPTo3nPlIpQBDNqdCKAYU/k6AIs8kohgnpqWn3sBPnv9NvGYGKlVz2'
        'BzkrhOotZCzVfmQcS7yiFDxNtOclJWd1EPQGNVscMql8FoTBDZKo12chmIUBs7G9gcvyisUmvPnQTzyPrmrirerNqvCJl4RxGPO0'
        'KDF5jaU95NAWk1med9Np2+68cLfExcSGQ53PHCmmGLljExs+OvjHcGo8P22WTzNWtSEfg6dH2XAwyLgGfvbM6VCELwKe9cbePLff'
        '11po9DwU0cZKu3ysPPYSvSHxh2Q4bDZaYUpSzvN2MxTQtqOd2nQ6mbQ790qV5slJ2XYPxSgpT9BklIKG33S2YElEJgiPJo9VVRIa'
        'AeL0Rn7qjdj8Tbd2VDdkJPSgRT09gauYr8KyrtWZgY5lqcJRuDCHImvfbgvcJVMGXVbTFEK6YCQOjKiSAm2jDuClNROu5pbOkoWj'
        'JeNTIdF8QfMchbNibnUYr0gEWKZQCVzI3mCtIsEpRUJRtl27e4tDxj3eqcXSfV0ISyQ806xO5sh57KaLq3XNsoIk0YIA8tm2Ff/p'
        '0ixRMAJnCLNhlB9V0k4y/FJ0L8jb6HD0aEwXFGaz0SjBr35B0GfT+3whSVf9ET8NwP20OYlmEufDU+GF8xODJ5kqzy6d3WJ4Ko/Z'
        'kkkGCY0wSVRvKVdHn0QxmNWbm7gpt5nuiCd29Z2wgao8Usr4rMZIjSQfUfMKhEJ6GEpEEwmAZgVmqgBYjXbvuBCkQA+EZ9T7yzkY'
        'AArNPc6kYsqLwpB6HjWWKdTUI77vaaF4KIETzkOE2aTdGZPSFJkK/pmcnuGS+l2oagCBGAbAOLtOzV+rjAy1lasiO+RdG/hKv0KK'
        '/almoKUxmYpMNweyIyfwFpK39RoxR3KYZxzIB/cAaGnhvlF7jzIC589iUra5SnkAHHoL2r6AlliWXqwo7m9ivoopSv2As7kuhCJA'
        'XgRKmJG6XTmb1B8bfcZ8i2qqIQhlspCEwPo9CTYIrNUvYCXUyEBZs6hktTTxU3pxT1I0C9lSALC0aheEOHZ8NbaxfYG3vPA7mfws'
        '+WJygdREBw3iGAem6RIaYtMMBuULDCTqtA9DuWvv2bfqTvGxnNv7da3uFpcSq7HpedE68hQbnFa4n/QodiBY+5rGXDhKFeEkSYHF'
        '7EUUj2MSCUFKmPFmz2TaBBDJh33NJWWRppBIUSYBQJ4I1usndW1fwNSDuotxEesa07R4kVSg9wIzebXuFT4oMrcJsQJwwkbXuxk3'
        '/cx+fkp6+k6EQQkQCFxdyZoXcVmmUZsXgJBEGIZa4uIYqwkugXXMRHr5mDfxuBDg+2Ai8AN/hxcIDgQjRdpabzLYMTEI62QFIMl1'
        'KMS4zfXi2rnmJRYX0dpeNS1d/8RLiX7wp/rUbjrYd1KUAYBwuLpiFl2TwJiBoRqNyTBrWGVj3ADMqQeNQSTwVf0yUjKw8K4SvFKG'
        'tGRLXpJXwQMkc39pUzL+SjHzPS5TwHBUIsccJR62ZHaloE3TftVwKhX8vNwc2VRchCvZkXJ6sXQ9KqoZcWjaPQ75VfGsutqOxVMQ'
        'xVaZ6JP2Lka5CrFQEnW2urCLlqb3qPYFC2qogSc68/9f5T/MzCSILAQtZd/5JGOHpOzjmUcLFY4FRyXEhAR52JiVQxvTfrVwip+X'
        'myObiotwJTtSTi+WrkdFNSMOTbvHIb8qnlVX27F4CqLYKhN90t7FKFchlqQE/w8s7IBzaatYN0XBgElFgDHKZ4II7DQyzMxJCu2n'
        '5eLx0PRiO5Hvkf3kokTjN6s0cOILxq/zniWGDdjVgRrZXFWbhoHl8wm8y5jsSTokc7l7e/4h7kAQ0Hd3dQ87XRn/quo9cyIoIJNK'
        'cEqxM8gwOpUwMgMCnEaT7v1Pr7nfpJlUEYBqMjYcRKVSC2Wz8KrbJkvTsoxvy+y1lAwUbDUr93ZS/oPZX1Cj6WZFfd5KVZXLAOuV'
        'nfInjk+dOh0Ovqz4ZZ9uWJh+YTmkTIvUpnfUXXVfMbN8VEh9DNPZ6YsXj6TZxU9OtPTxpz+lVUYSVMDjO/HEvvfvjxXz6NCFdRf+'
        'CLIQEFCFIJEJrpiSaGMZ0I5Q8SAQHBlYKeu9BE4JJkkwVIIBEnSWoFQCJgGW4K6EqARhCb6WoF6CnRKskaBSgnkSTJFgmASDiiqR'
        'S2yn3Zdzb/qsRdVSrOY0gUX/QceqdvHihq/U2MWbF9wZYmDRtdC6J3ruOTv4LDL/3Ek6M8jZSVLsuL37nZMv1NqTK0PDkopkTQHV'
        '7CsB1dlHk2zBKCdF3021SCVGzr3im9iWgiS1KuyCCD/ibpXXH35EHZjN1mcTP0z3TUbAA5XhHMpkCn/gJ0Gik6ZhRpcAmuHiMEib'
        'tOkw6SClKU/z4HGVMs6TDo5socwxd9gC16J9e3Ztmxdjw4XGl5i8arntnqLx/tGM5toaitog1lWQdFgbMKCWUqBzbd/v+F3n1u7f'
        'JAR0iGRckx3hyDx6eTZpVU2M363BcA84pImINu8gN2WOu30F42jY7Gzvs/a+oV2uNfhAfOGhBBaEXHUYfsU8SLxecTUffQPI8+zx'
        'Micp53nwuMmBENZBELTbDG5eJOOQDJudsafngciIFrbdB/USzoWiAj0fy7dkCPGRzIunNiXhUkKHRO7GPhn6BF8HdZXrRk8dpcl7'
        'jhIuWb8neIcQfhwXHWkaM59nfjLu+0G/soAiWsq097gpEZkC8JkfhJLuIofZjx9c5shXfCjy2965u6TUqmG2WyTbMLdvz53Vw8Gn'
        'HU4dc2DY4ViZtQ1fP6YNi70h5Xx3v7kVHbpm37Y58DDfOW/ProH7+S6y32uU4nYmroe+3UaGfhSFiIkLg44QQXYwBslenYwTMkvK'
        'HZQuPScJFQ7wiNLg+5owUbgXwQ1syXZpnH9S7csJIWWCvHD3tk0oXXYjgh9clilsGBVRVTJPJkVyJEHlld5RD7WXZAYjBe4XIvjO'
        '7Muc1/gfD7zXXzjwC170rC0b/I1vzaq87CPe6qZf90Mu+UIjA77/8qn0iewe7OkjaBSLH3Jei03P/DPyeq9ILxa3Uvj5b9vyk75T'
        '19K5FDMP033k0BVbZob3vc4qJyOCD7+zJ978Br7ScAGkqdlb2IgEuP4QeF4oGeMhNxFRvkAObrdMtrO5fXvuODQ2XMaxe055df3+'
        'RIYgoao92+Exlnew5DCGfbJn19zYQ8OK9D4tc6YeI4QMQEKWctsx/1tl6isUCrfvwV62a2wQK9cyX9cQ48Mme3EBoDCK+fJKWvMs'
        'Zb7AYb4fRcMOxCjZb4e9bNfc2EPDmmrTSas/e8T+2x8jQeC0Q2SRhjDUDIs8cJS6DkqB89gQzIHbC8hhNjYMbAssq7vZp+dLzGsO'
        'BdBbWMqlEPkCsBOjYAmrahiP6vUqht5zrRzKscQNbEtlXUm2rh/OZOV08G9QRiVqBYyzbt1K3NrAxuqK/zrfQX4h76F0Hm2xWPzJ'
        'H9murP7kvm8s71ODj5TIi/lZxB85/+yu93qFL9Twp2f+q7i3plckfsil9GWJEeZT6S/Op2cR36MpvbfacTXvbaZAPWt0S2dFv+Pe'
        'Bd13FzazilKsv0wYcRaxxIVsIXss2a2T7Wxu3547Do0N61kSOfsak+c0aY+AMNSv8DDw79zkgO1q5zVFQRwch6GsXHl2Y5XLf4wX'
        'Z06sYUoGntYBSwpelTqlVHGrjfYqXv81WLVSfWH0TRH7Dj107rW8rfewEU3em/s0ByOcVhvV09GLoY46mrJz2pm+Plq997/G1HiP'
        'PBvRsdrzMFPFNorDXQ9ejQR7rrnH6ZZ+tteaarnp/JlUbpjGJFgNSKDAaaqdneokDcePJ89NRe4mqoP6RzCcWWRazbr34YFPUWnB'
        'kWufeSIMlqruEhXhL+ebJ4RSJhVninlaCEAkikniNjyy4hHmkf9qvLfJHzb5ySYv5sgX5shykbbf9V38bXp94hfstXRXjIGHzX24'
        '5SDt3+V5mnvuFNeMCzs99yi3uw5dsW24arCkq8iuLWOD9DCosevyvOn+RaNfMgI8p+ug2q+13aKt+DV8Ck7RV1QUpZaMMs+XSmZG'
        'FVH19MRdzRMKPnl44b531x23HLpm355d2+bcevvUugvrk0QeN1ccUAAqTdh/kwDwgru0hpoWvs1bqnNSoJIRPSj5HsLPlMw+r3BG'
        'iECBSiIAYfu3VBrWvVswSRY8p2/irQRCCLTP99VfaAKG2nbeAvAXZYAYaGEGnbgiDuwBCdtuv7F7/y+tHDkiZRaZE4gmw9Mb4uiT'
        'CAHPlL69RE9GBE00iKhmkXP+EzhbtdBusbII+TsnYGuC7CzwI6ikupXUeM5x1RsK3twTxoQFhLC8lNZbxKmNwM9w+KgSmO+1kUWP'
        '793Tq8+YIii0p5m3BknpLH3XRbiF5wkL6a6iIaYpQLwF5OsOfyRablGgc0lPJ3pp2UEQSiawYnDajCKHLORAfK73cF2vFZ6Nc99H'
        'jD1s6tx/knzRxpvlnEQ8z0GI5EmEhegJrlhi344D+UECl/6us6Wd7MBgzw7Lst3TLqXKvv44woQIQmnGMlbknnkCD4BxtkXCDcne'
        'GcD+T/lLZpNA6rF14Yg7oL/K2XLJ8wYMjziHAzx5ojHZ6hZFZs2xLQKTgXyCr2bfYnyvgUtsnVHOMkYZNHsDZETTTgc71Og8BvDK'
        'IWeMVdLKeHgMVmYZor8N2sMArjkPm1scf9nzYHtHtms//V4zi+kulNKr9GW4YRmBpyBgKbiVD72REdVXjO0vaI7xgletLmLwineF'
        'YQhBMH9DYJjahjV42zurxmF2075tc9Zd19LuPx7E7OLa6l4C2rOPxD2fcGjXOx24Ysa4n+6eNzNgdkmDUsL9n0Ox+5Xw1RP5LSVA'
        'PKW15/sSGQsDIpXhwCBrQyJOD89m02nuE+vuMS5zwAACcEYAslVbtVU798r1erBki/YDeijWAAZq0LdS9dXRI0uY4ja2qDG1gRko'
        'yF7uJn+b/aSnnfcpb82v+F3b0oEA9911qzmAfbvazmX2mgnlxuGTzYrLGLX6O3gISiulUmVd2ZSQQMTIPXgYwzUr3634y54HC33K'
        '69ZVR+wOj2MRgIAi12YLbTEtXyTmewHZDcgqISqSnRKcv7L2wV9eyj4zLrOR8Ro1Nq52ep6FYVBDAMOBW/jabFweNtpg+WlztHvN'
        'KnDtDpXnAKYsQreNCi03kB2EcCW766ZOGxm5G0oH9OPfkGIxbeoQoE4FO3Z8MSyw6D/Bu2fIbkLQNIOGeqxpCoveE6RyxcV/LN/u'
        'Jbeysbm2dC5Ltz9GUd+/Cev/0IYkCLxQhYzlRcgFP77EE0oJo6tj5d3xhcaQhMndivyrIVd5WUTOYbPLg0yCOVyWZZW/7HnwVoIj'
        'GVZyWu15gqIvDeIj4M6bJ5C5BA8j0F9nBllE99xypoWgvGIXqSXYTbxy+STivFwhltHGpEVbU+WxEIkQ3N/8FcHVBCqJr6molw8k'
        'w+jncgiESTT5sfWSHtyAbxw8Dk+WExy244lAqP+H6SO7iKgQKCGdCUYk3bCDuEmABEmcaGwEEFmZKEQIEfD/xiHYJxYb/uuYCHYR'
        'DzlFYiRB5P0kJTy8UUhOxTQJArmu/WDcgpO1zzjHa1mUbRld2zbS8zcnRerPEJOT0tJESUjJzslhqSkpuR4G7zGYyWAsAzODXgza'
        'MdAxyGDwmOEfBlcZ/MpgP2tieDODlQxceb026YOaNk0Z7bQEdi6yv55+bE6Qg81WstQHZ81uRkMfbeRJ99R/Ljc/IzUlNk6WB5d/'
        'xPCF8ErT66GgBYr2GHMP/MMEf7tDwxFsZrZJZywbOoa7/+O6H9VONnfuQQ/Dk6KBqWzngShTTJlO7fjYruiDib12r3n6yhgDHGQh'
        'hj8a4n1jBwOmgMuFmyInKgmZMrHnScj0W73eGIxWu0lYCt70TUgB9sNqHpZTFkEAr2gHX2mPETmIU0Qutc/DQI/MHhbczw5shTqW'
        'bFCOT2bSN+hroqPYuQg9lhexZ5JIA98GmiDvlIUiliJsAyCsRbCMqZPC64ttj0wZdNkpBVIFJ1JRplAkQNuo38RzS8WMi+oUSheJ'
        'wplxVsXuwIq51J/z6jX7OiBTrkYrJTzkYIyMBshAwAWxcM+gVNATDru+pb3Ef7pSXWqy7iVgCo5D4ynf8UkEXChuwaKHLaJ+ZyB1'
        'Y/i233aWungwu6udTDb/HXldu4sKSQgKxXxPIMNtmCESZL0XsvnmyJWg39/U5meNtrzf9zFeQslWVmsllZQ5pcyicfVRA7C4qun1'
        'N8XyL2wBxgmARWK899C/XA9mCq0VEtq8apDnrF/3l+MNVTd1c1RdO1iGI8uNi2+Ig8OVSorc+T6/TvBvCmx9uQJo10ejxWJk+LYK'
        'kjJKiFacA7uN2hPlIkFbe0A/SIWZ3qF6T8llrtVJXiPpW9PbObyzlA4mKpPzOetLinLH2ozWuSgRzscOQqbyM3Q5/ajk+Kzl+QMf'
        'GZ34x+PI9XmWa1cErsV7PTAR2LuLI6hBf/KpYHar4695dMljPWgGg0CliUrYGjA4crTv+d5LNL7PrC1eIk2t5Ets6UXma2TtdjZx'
        'l7vZucbKPdC0Ey9cEelYg8edTVXZhGv0LlQIS7EfQXT0mDMlCXFqlg2uY7LH0D3mMSlXhyc/EYgE1+VO+/7ROP4cxfEme+HGwR9A'
        'Y+JSzUCpONSB5cQSl+W5dliU0g/820jCKSxAY83jhXP/GQV2y+weQAMbWJU5VJ6e6ijl8BCJr4ZwtWLc4rbb8wsHRL4aI0RpDhwI'
        '2wgZp2ESJzKixTFIbSPx/lgcfqOd/d7FbFpMRx7DleKxM6c2Npwr8NSoJ2bzqcfa3/JjGdT14m1p5t4zon+3kXr9PtS2HtboYw0S'
        'Hlx45pntj4eDjAHbwIaoPNqy3V48DI3VSqJagcSfZRf+9wvJABkqzQmQXxK75J0Y+XmhYd53YfNyQcux8+Nesrej5FtDNMwP+duu'
        'Mdj9eVuqcMShHT33smvd+hNAuIj1Ug1PHplYgMlJxc6d31g7s3x8+cOMz2gTc3xwnM6HiRkPxvRR7YSxzWs8Pj5NwoIg/SABYwvl'
        'IbHkgv5TcPn5nZHd+6tk6qgfBCiWl4sEk+MjsfJ3CAFm5hPjH1y0Qn9eTjbzvjH6ZZrPfkMYvkyvhtvo76eIK4rkspo+kGlC2EPr'
        'Mxlf0CAMdYyMRwNRn7nE94wRAQr8V2kQULalRDywasZ5AlI4k0TcG0TnRgjbP8JJoX7gqrGty1U+sHse4AY6cUlcETftkRYgUKTX'
        'ia+1mexkLj8PeB2L3CvV4okTxybLyyvDkycfO2YBjq0odubscOXEZOmc/xCr6+GHFqzYFWpWB6u0j6vzoN5sn6yuTlaQ7qGC00O/'
        'N8TNIN92E355bxCcMEJvY+E1EGh9ZCUvESHEy6lqzG+A6Hn2Bt7hEP/z29LmRyyMNCGhoDS2QXidByStbokq3EnKj8g0TqrpMqxX'
        'vhrdBfiBdKULgNWNBGP8gd/6GOG0v4pWfA74jNltgHW8V/Pfl6KskoEPMFgylRBrR5YiY6KXeRQt0hrx1dUsBNAL5bzsNsNyYSF/'
        'mYXP6joW94ts34booszj3jt2aI0gTt3oBw67xiAkp78oQ/Omls94d+XdfZANw5+IHorlxGEY0aKoo7rXL42JGpFuo6nIIVN/YkPr'
        'TKBR8zuJC0MJER7aGKSVVKOUIQEWstsoXk+IgkA7cUGEv8y/oKviDsdmIK+gOSI04sCt+R4LddYY4MDzzIUh2gzVrxIbN79y64t2'
        'zXwMKj2nYQbSPoYRQ9yJzEIMgl5g5mXg9ioaS0r6HMuiQXWJlEPHu6cXgVVH7lgbd+ZnRpEXrtsCID+Iem6pHc3Mjn44xVh4E7dB'
        'GmzB9VhRCga3y+4DMMuoj2yu397bRb7d1MWnJwHysujpZnbNqP7YIoiRjoUeuH8kUlbkc7HPRvY51FOjXUG9JnxDRRSGseaMAWhh'
        'WOKs8X0aK6r+VRGnvDyWUlBt5I/m/1rNlDA7PW+JQDWN7PdTSDPIBsNjXrFe2e/t3zfkrS82PCNK0sQwTTBFHD+ei7V8jca3s7vi'
        'HCZXR/Fp0Ny8QNPW26+rJIi6gSKNY0zMIbeFSBHBxAqqtZRMGcF2SFOSOsABFdJT2PIv+VvJAOLhF/Qp0lznZDX/Ip8+XTsn+Tcm'
        'Se040Vilfed+/nc0wRhZrMMw5b6EKAKGWa7iq71uQjWig0qjr7gHJ6bo1fNRCXWePY59Cx4va5LyRCcaOELYgeCu+kAv+aTbyuJa'
        'A/29gn+oCH80VwQNIweFOXN9NBZz6oe9SfYX+5XGvn1Vb5RBwNdIeHtPCy14dLRIWjG4EBgkQo+EISY64oJCmTKtXkWJBRvBBMUG'
        '3igZo1fMb+9btVwBrRfYevalhjzDbO2cEy92KI35au5g7PYoUALois8nogySotCSA19ocqlkR/Lzzu9OekERNIoEXCnuea7DQ14c'
        'VXrQFI5P6f4vn10qzDPCz75IooivkQKKFR5wTXtVvcBa1D0JXAfVTtXT0YKEwXRqdd1BBw/E84ol31jaXGpN/GFjPGVcfMoh7eXv'
        'KNAZPb3MbuYJRQE8hWEgLbktE64VJZDh8czmDyHk9p4Q2k35WqtmIxlnYobeN+PlYjVk/bwPua9SwtCLMFo7Ug3LRbbcuKZD+SRl'
        'TmSZS8Ryh9aCmRuEtKAPSZhxnVFsev5kff3/hr7qN0rn+BpJbmcjtQnDaKzBncp9Vy3DqD1JSHkH/hllYdTh3KlyyFOMsAbQJ9Od'
        'GzA1+7wz8YSQEUgoyoR3PE/SJZfqtMtdytEVFnIKhQMvogd7P9qTXX5vAMXaybg/GPB4DfhkPThZ4DIu19sswwBR7yUXDsZg++I6'
        'D/rsex2ZBFMNhdS5sRGT07f3bO3p7thgWnFjuHEGCbHoPH06JucmPHeuczG9OrkYW3LxVV+IqRTk7KnWne2KDT91nDlDzjmP60oE'
        'i3tYWV0926fliTODgX/CJckpKU/08cJ57+STzJnyK2Fwxj3jnWpztmFy8wR1CuwG7lLtSo156Fxul46wI1tcWSHWd11ZAZZ382SI'
        'FDE+1KV7lBPro4SbbY2Q31Vly/wb10NEd2CG0kJi0rzALU0L1MyDulh/Q9w7I+482jS42TAe1hgorF6FtO/3F6Av1OIzvgCx9lSi'
        'XnaEeA+AzjS+RsZdlie2hKiuPN3gUKM+slYmYFlcV1Xm4ijon2NbxEFJZCCWHxtEDjOVnXCEt07KduLkisdcB3VWVfwCloKlNiiE'
        'pD3PSfFMqwpZPGHaM+TP+ZUIOosiDi3E5TMhqgvtpNoGBgM78vz21FCXApYw7xIepVwTEoRKXycoEqFSnMCzipAECXeuG/mWwrCJ'
        'fSE7vXP6ekU/Z2mTysYZrpgXgwdLy/28V7BqGFZb2NBeknHgSuY9qXbY/w5VSSTrfmRd5oeYVix2gxqJsLMsY6FgVbNzRshZVCYN'
        'baqWL2S0M8l3/cpzwaytDUmSNNOpHi4mTdC/In1gLsoh84nzm5YFkPtqBLAlZG+MktoTOBOBuH3z8WIgu+DngyvQqhWi8IiPiqhf'
        'ljCEGNKSGenkFXmAB5A38Yv5aRMpxHXVwgJwAkRVavPrRP3rwuxXwDW5zz48zm1e6yqr5dcI4VWBq4tSPhAfRnAenhU/JF5h/0xq'
        'YCLWLZE7y4KDnOYD5UmyU/bJu+Sv5LB8T+5ZgBIYBpVQu3JROU1uTATTd1Ve1sqgly2yWw7IEVmD5GdyheyVg3Jchnz7PG2dmh7t'
        '7BZwpEaxQz7EFqJn9ObRU5rWuOcpAD9Q3qvF1J+qxA4Cw/5268zXAEjp+ZL1XCUtjSpbZ0YThYwpCaCUHyh9MP67TpyMuKLGCFUk'
        'TuNR/qfU9NXU9fgpq9q7Mw+bZYkPvvWpz33Ii8wjLp2o2DKATMaDjxzzBkSyjE6mhNYqcjZJHDjrqM+Vy9KI9SAdy/ghO4WDR8ZS'
        '9qaECAOtEdpJy66Sj+Arng8whUGoCWf8FVLAoJ3E/hUAqvVBDDkVcDKO0VyFdGUwKNb6S0uR9X3nRWVRIIvY0WNr/rgTLAeLNraf'
        'JpvP9GMTExO38Sy+Wf21yn0M4iCWadq8gCkHZVt2IdNYlqmU8AJz3NYpoMUhzvXDeBgNUX5QTzdMIz1AuJ/nj2A64lrJyCBgWfk+'
        'AkQGfE3D/YS2/tjH0a0+Tvnqiz5wTSkPeWSCENqPHXWyptWPg2GoguC4PlC9fwTn/UwsRFcj5PppX5up8puCOq+qq4a5G2wK8K0a'
        '70UYtHN6ICf89Gapgooqv1F0GqEgpPHBMhov3NXz115/H+7ZNSud5bPfX8E3H0XLb1hnpQFoJLPOPScu6O8Noja/w5QXAIDnD2ai'
        'AOCTK7RHfzT+/O1OWDgDgQGnkwUw7TF7c1raicivLObruLm9OwLAK8UKUO4zOdxTXFOopanlJ0UmbR4jr8SRjIQLHuZl3noIzQpl'
        'iuApSymSRAAH3MAQlMEePMAXHKWbXc7Cmo5nUFS/+67AaUFamx9LlkCjmDSO1N3e0aoYKVbIiR+8SXXSREjRfCIGrKXsE7LLItNK'
        'YJISkGocsS3llGJFmobCazf9mtLfk4lFig3j3CWBQhTWUmofFLLSztTt2yQ+UpOiDalkV/f9lEExVuF4O3flZcFGO/ySIloWqwBw'
        'TL+sUmw11C26tRtRdzlFYCKlYVnFIDJIM64Way8gy4HMFH+7RUGsTllj+6fBBKOGQ39JEwW9LfTaoEhrKJfB6CeV97GRgNEOhI1R'
        'dVey5qNCfgEAFUJXH8aKVd+IYLb3Lrned2BbUBdxa/UtcbJRB1vNPNvKmsIUM5PidoxDADxu7X1CJlerR4ahvUD/I2rCSILo9Hm4'
        'DWLcbcWKlerSqf/hmqWz37Hsfqz4sRaPVqkvVAC4C/ZSFjguAOCL0Obi4RvPcIGKQCsvANAyxCON+q8Qen9BtD8EAvgwJBT+eIGJ'
        'MeQPGA4fKKCBS5swQIBqKgI8APg4GkRJ99FgMHePhjC1dDSUVniP5oGIwVS8UMFxFi1KIfX4WSKEQ0ZDpM6EFCZBIpZkAmEylloN'
        'qU3HN2YEzQjcZEIvelSE5yTBqhKfVQjnay9BPAMCnJjA2CYJ0HCg1x0vXhgDnjK04zNlJLKQ6qXAsjy6Szo+ZZhBxgNpHpI+3fNx'
        '90qgB8mraGE7xaJgYsB0j2bRht1PPwPhblWfravd+3iQPVB6qG123bFxIEU5jqBctmYSTEtaglilXPZy33cFpyPboFHZLjBKoyn6'
        'sl60HZLUbsELrDW0hDK7zIABSttK+4uhiNpWRNog7saSZASMz3k/FxXOh57nVCbamP1plGDu+9771feF2/GJBWO8Ko5tMWKMhWCX'
        'Ygddj2luRfX8ZrQPvxEp479HUrPrfa5ar10UrOhq+VV8FWSosV86tEBAG6Xeg5IVehDLVVrm5atXMMHZZbgk9ubhM/n8tzMGXnH6'
        'muBpIZWBkI+c1jRuLU9egVqDkZah0kZgCoVTJw1cObbcT41urWylCwoVQ30fjuZnb0RjQxpHDRw1yAalIW+4a3A3pZ8NoYYfgxpB'
        'r2S8vK2yLtRxdV3ogv82z5JZl56p0hpbDX8q9OZT9vKQScHsCTyhEyiUrmtDK5X7jX6Tv8ovUj8o/n6mosP3DuthIXL4w/jggS78'
        'gMXAm0AHck1vMUuU64HuB7oPjkMzyEa9iSNX+djSm2/bXMa3MmxZjHszbFBb8qr1/vV4ndqFUx/34TVeA1/9idZQD/fYPe88MatZ'
        'teJ1keaVoCtAWdFDVbqUL8WLFlJuW4iuC9QFPN/Sk/MYnPB2vpUDdI4I5F7Xc45be3iaA0YGbUzE+8iRlqHa57zM56gduQzNrXmd'
        'MDS5k2BNEhK83udW2FrSVt1xo/oBx6hlfPSod/kotQPP7phl1YBgFTtqQLsAVDAJZsEuuASNbSgoQ1u2VaW9RVGr7ObqzCEfDFl+'
        'Kgw253MLavLMrcx4pHk6AjdCltJOLeWvqHn8ZbWQv6R24Y9U2OCb5L+ss7KOuVYJqFXbkVpgQNagBB+AVKNLTZ5WaSdz59REbdRF'
        'RUqN1Ezt1EOv0wTtpvl1FKOCfTIZjhh0nG9BGz9b55XWdhA6sxbhuAd8LFP1XJKZLjwHp4tuzyXg+82bb99o9ZDFi8ohP+QDvA4J'
        'aO3goTTOcv/w0bnvsU5M/kRjMZt6qKP1sB54D2vHOjaSR4oVaaRIs4fPRAOXLIkO2BF59AeL5xYbig8huUj9IDzNdMJaaPfXjDxU'
        'D53kyRg6pMWd1QY='),
    'chillax-600': ('d09GMk9UVE8AAB/gAAwAAAAAM5AAAB+QAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAADbhTGmobnwAcgggGYACCVgE2AiQDg0wEBgWC'
        'cgcgG7gyUdRLVkuViKpJOfhDgXaEx0pveqFiFY/LOHF4YpPhR0maG4fl2GvF314nxo0Rr8hF+HmKkG2205cjNPZJ7g+4rX8L1mxU'
        'yMCNasVszsYELLTvWr0oz/tRnf6E578/aOfd93dnijyhsnQ5baaWA20m4MhSCPBO6tKWQytKV2kausxAUwDR8C/DI8cQZLq9yNOP'
        'QevNzG9uiIopi2BqlmioUZALt37pb7UNvfY1TUFHaX7iQUQy+cMk6KKbe8j/X2f9Kjhv1qx3zrsjKVJVku4OURVoYLeI1QewG6QA'
        '/n3+ac5+v0xC3tD3dVbo+Zm1ihkb6kbbhQpUVCEldUNcaqb38W+APvsmGXBPR2fp/nrvkpV2A0Bkh2DC+MVINc5b5761Pm3Xzifq'
        '4Ad1SEKG1KkACRch53elZ6e6jmAOYc7t7tGe+kt5EyCy4ed39hBIJUKyUBFKhRX56JJwDfmW7W7q+IjIWMyrmYyXDm97erHgud1F'
        'SIhIiEREuOv6XQEEHkAGUX8WcnxuV6hvZtNCgSvLYx75K7D2ljXxAWvvXXNsrfC6H9iXD/yfiX8aC4jRf7Tiz6OFzlf1Ac1aqxrI'
        'QVi+7uf40w5OsmxZzk21ojGxcDSKoOP/F1tcFNEXovSEoEoNXzt+zeLucApVPzah7pzZvW7+zds2J3f9wtE6OdLmijAh+C8QAIEA'
        'CVwL5IVbgGfhDhA4cA+IgntB7AIPg9IDDeAp0LjwImhdeBXyDdoPvAl6wFug9wIfgKEDmwbUD3AuuABcCgSgBNYBFDjAImABDlSg'
        'GtADI2AMVIEawIM6gIF5oAAcEAdsYBzUAgIUAhKMgn1gKYDAEJRs5mx2qGOd624Ped9nfgqL8Ig6B3JEnFHSl7vyqK6WyvU10Q1d'
        '7EN9si/0jX42eb5Vrm3Z7dqBHTfr/Gtaz/o3dG9xDq+8xuu9Q2/sZu+5e+s+vhf0rWbXamgztQXaMu2gds1iWNpZVlnuWX+yBlpj'
        'rRc8GnnM9yj2+EjPZ2tl62Trautjm2lLs50XDhEmMsRp8X92Tj1E/8yFZytPH8/BntM9l3mmel72fFvtf9X6V1tSLb5asewpz8jb'
        '8lEPye8nXj7xfU3RQFxWsemFt+Ax40MDXV35+KkiAf0UTJ+PSTvyCk4fTxk/ACBnvciqhmeNEwnucn+AT9eSZ+qUdv92k8pErgdl'
        'upuySC5SJw8AuSRzlW4wvQcCP+rns2gv7DxxnOC41E4MFhvVi9XvopUW0M4nfhH4YHxowLZOxu4Ku3gBi16gic+x6g+fL4DeZbrv'
        'dPkkZNH/jA6yWuEintRFuEcJuXWpnuRSuccJl3zkm8rE4oKPsGN60Vds6dBa8NRza8Mx8N0vqG5VXB53uqutS0DWQrsMEHK8kEpg'
        'qLquLrctIUI4JwTC8AjqbsBG7q7NbcDZyfKYA0NdUuZyCoIIXU4Ng8+4L8ObW6vX7PIq34ojuK/GdywBxLqEbQzi0NaKiIpSZmeW'
        'DM+R4G607eBpaOx+0yR8LFY90X1pT46Oi8MhTr/0Ce2vujKqeeWiHy4XdUVzIzNQRKNvVp1ksQ3xWD0jHM2/Ojohv0IJUdFfs6/l'
        'wao5Mw8vN8Tr0sAuOwfYlpv1sT1J1IwuHE6HZh3B4vnXruZBbnnjzWuvuoJpPPIyfArZBjHmotNYqQaihXhi2A8NUg+NErFSyC9r'
        'Ux3bVIhZsSy9G1UnZL+kOfhiYNzMTjlTTNSXJ+XPDHfn2/INF6lquGqt0c5iRsr58mfUd09a69DsmC9qid+Y4cdOAgg9FZSkL31v'
        'lYxSdKFl25yH3FNOCF5pGnK6mFNtTuI5WQIndkp1HQhhjlZtJqv0gDvDXWRnD+GvPVEtlb8XzhQ7Ucu9K6CJ6kasqyAXrhsuFY2F'
        'S1EziV9FrvsD+irAewMDIUgYZMIzABTeQh/32wBnSeq2Ov0Qwgg3sPS8h3a/cbGg9MqVggE+B9XyfSC98fCwN3KNQWqrJA/i2Uci'
        'WHrDhR8eHxq1RG3RULS4zFrM4lnUyuU+aqdWiiUOp/h11uKYsEklkip/R2A8Arlwpw5fGZ3A4r4IZ0gaz7nkOwRWQo4um0TSav02'
        'aFuHFuB9TxBH648uMRQo5Cgh8c9o+XJ6NPXJOuyB89O71qyozuIlSUlseSYSq34t6vTRjZjeu+1czcXBTmJOHdyM6QUH1vVMh7gE'
        'KCUauROvFHJ1sRPbyjuNcc8G5N7OxKH6dHLpksusEabND0pFWFNWmRj3MklFVwBpHbI6mo9Hh/VFEx2ksCIQN5XpnndhTLsCZ/mM'
        'hMbiFozwP39OQQRJJIxCCosQJl/r3ua4iJ+WmeA/LFcvkfrZdp8IMEUUFCVGkiL//DMF4UeyPQ0diGc7tdyxKrlypXCgz0GVbB9I'
        'XsJYNQhRzSkDGfIV3QRVb7aA3MhFeAzVLKKZWKTwbcQN94DZr88gRD8xer1rSO2rK9KilyUToRJTIFPfKWQoCmMg4bqODqclOJgj'
        'UOIghw12ia3orx7AdsE+k1vvjo6zbFl8P/EgJXxAG0WZFD229PgFjxvs3+qy+xFYhlScW9F+wvILqcup2WP5G/ZRzlp7UKvZ6BAe'
        '1BHLo/pqV9UVbW8oX6OxY5HKoXr5msYiRFPk7thwcLDiLraejkk+b4mgKnKI+1Ok0ZxTPFXb5Z9104XpWvBXqtrVzch+5eZc5nbU'
        'fKiDIMww49KePKpTrUjVj2uYYximtoWv17nvL2AwL9y7er28NRlh6zbpDJKuwlfqMy+fFKv1Ok4l3IRdc5yjneDHmlPxlxq6j3HZ'
        'X11awarrHBW47WRhbMWFF/B5X9AidgHHCj8CfG0t//hQ9wwsTgjIYAJunRGYVNwmz0h6rJRvqXmikcNKyg2BK9LmzZyW1RKNFpMW'
        'ZfPnnQpz1OQbuen1ON5SnDSN0WY6lAp9Xme+Sc3qvNpZT75DUUP+7TlUf9e/v4i5nP/pV7sh2t3UBHIm1Own/CzJpeqw6tsPcLMr'
        'xosDIwx6f9jiIzxTP9uhM876WWpEpXWywfL0lk1qJZybOZ7ng3ihBl12wJXD6Sj85QVMiIueoaOtCUPCrWe8hbYr0hXeLcU03ryy'
        'nE2eJdaarEpVZn5LPpBdXmud+vgHoHap6gixOoPWv1xAjsBtg+nw/fULM2Gb6QHNJ63jCIOhYqtKM2WdaGM6zJYfoqj99VeEmyBo'
        'oifTNDSVXrpxJmu45IReewwkjZxYYbQcbrvCDUoAVPglbbXzLVm59/R3XOquNxmJ94cGKn+9Bu7N8eUrH4FzR6Ln173AzXqXYYVm'
        'bkNutRjJ6KF2R9gkPkCR+80bVY1y9nzGFXeNpLavraUF0kqT8zDwql7HMcVtEyNRO9s5U9Uao2u3Kf1w36gh6J/pd8oq+DeB8byt'
        'HG/EpLWFsgwTJ1jqbbVo3QvaOb7+M2/jpDbOZPueUBplh48YWvuWsnNXsETZnkh90T0bd1nkd/K0lFC1ZQicHJKyu5cxqHSRc39q'
        'x3fXexrgsf2VsfiplD8ODfrwFiw7F4tQU975akjohfDNzrfBQYRAieSeSN3SPRvFede/QvKMqdmOIHs6HCHk5bKlS84nEtSU7EAN'
        'gep4gcwuCLpxIqBN+GiUMMLdkLcMpc7OBkXUEiIX6t4HaoUQz0coPdYYhoU1KXUAWiD4dW/Y5e1xn5deprzin78WC/c63GWdd6pq'
        'iMzEzsHB+AqD0WI1GCqt9SB74TP2x3kUXYnYdODnfESHhAU7rw8kUK6i5Z3obZ6CuYlpxlUsPTboH99e51GhlRusdRXWBpWcJbA1'
        'spO6RobjKhnaYolbWmlpBjkfOW6KhOOtfTZ84r7SWhu7IyehAsfFNoUrKDvX9xJ8Wn7QapkbJvw5IH5WsZ0LJJNR0lWb9/XbrQf0'
        'Xg9ImJVnsQT9tvjt6L0kCW/TtY23b1HgOYsnsE6HsT7Ufpb52OmgebMW+wNuamKpt4RInIa+giHFg6cp29N8BjmfoRlBUipA8gIP'
        'YU2pkkGq1KSxfMZWCchpKJMGoVgmoRwh5iNpyrae5A338JaAK+HM/8xGdyrqTvoz5535v9lk5hnbLrnzZS4PzkCqldQ6BF6vUT7s'
        '85/NdHA+/vbDU5zLr9g0qXptnO6zgXy6B2AjBeNTLzRE4Q9djy2lczqKm8+v0Q9c1DGQtDJj58r8Yx9ysceSFZmfBd1dwZ1eTS51'
        'e3NTuMGmIMi+dHHsfAxPiWQX4PL4mCWQH1B/9Bk5uy9hcGwpMaYPRB2Rmr1equwFc67vmuW/68Z1HUfWmB1iZh2h/L1hPVnOl5zn'
        'F36IUd63NfhcbOgheOY4N8cU/8Uz2YSy7zvgNfpg1JFcD/Szu05Qw8sNI0fbe6RsRs2JMpeEmhZhPdHY/WclaBtXhObRzfDtpfNP'
        'zZuTQkdBamRgCO1BQZKcLWyprr1R9pECE1b5vGEgvcus0nnHeN/fm2Y5mfEvErIPdj6d3wjIWWWnT1aeorFCooxJjleLhQw3Lm3B'
        'k/xVHX7MdPdGaZPaeAZPNsLCKB0U9SpiwrG8avY6yS+dnCFyoWJHVwTtgvTL3L07ansxiG23//c0S1GM99DWd4/4iSjiPyTUVQ+O'
        'vxw6YfLVNbN2HvxJZuO88lkwpV5ZiPUp3ExIYZGvhcs96ulyfbhXZCkriQW9ZIA17aNwBk/OV9V0x6uI0Ll5r/JZZXNH2PnVv8fK'
        'z7tz7N5g1ookeuMaDVsBfHd2jX6f/W/ofHYH3/tVcy0/f0sDXU6TYNMF4b1fguHXV9Nr9aazUgnVL1vy1352fCUwWY4c4xHu8sjt'
        'y3N+T+oXZXdfhpj03qlN3xjj7LLDNZuqNxiwrf4GU/qgmRfjFTZYyDbByIuEF2t11UHvuAFnpparrWzGqAIG++o9sgBQratN4pT9'
        'UGVCUubX48Tu6PXfVwipFsr514ZXFB1Pa8X9Pygd6t9/ZkGWNcA6naubNaY5naZjaFYPh31ydTDvGI/83cb3EqcOYzbKgkgvKdxU'
        'scwsJsmKzfmnSgQLPggJyrmf0SrTrL9SI+HzehCaI6Cjt6mpZy49b2kxbZRMqteIQSJcxHJXpMZnGt8AiFe1p2PbFRKpqV60DWHn'
        'PbY3DqgxQb93hxeVPzZH7KOLRxNnUcboD+mcdlBoSTmNs/5T//gnf1zBRAwBSxoDn9x3YN/EchAb1jyImNKPkRra0udC29YaKCP1'
        'Sy/z5MUex1k7/iOjshVL3smhskblr5px/KtP5FkMLSnksr2f5i4SP0n3XcbnUZe/h38CpD78V28J84R0tiusWiUZif9BwkwAQdOw'
        'kpVp0WfcrC1WHeM0Z7vY1a73ss/9ERzRxBp7vImmNm3pTToP9EMne3br2rAX2PMOn7rx7e+HI3DLeS92XXf67d+k/6IIrYHWTuun'
        '+WtztPXaHi1CS9MKtfPaHe2F9oWYIumW/1hGWw5brlj/bm1i9bVutCZaL1tBTevRymOIxyyPII8THrke1z0+0NPYTFsrWx+bv22u'
        'bYNtry3SlmErs12yPag8NKClvE9XpqByE0TFUtXLAQ0VfRj1PQ5eUXgFvjwT1vrhbR9+z8QeSTrGdfhSEmxcfkbXP7H/5f1Hn/SZ'
        'RJ7URutzxwRVJ5FunC8MS2/DA6YhowABjSi7hMIyfQNZgvjJuo11oWFw9uHLUxFDM5GR3E8naDxY9+kUkkTBKqSAaPKclRNKDMEW'
        '5p730J43Lhb4CQMj30Mx2M5HHPxOFKONpOsL0pRT8QVoXM2fiFkC8pNtIfbmCsahpke4oZbnThSG+9C19rwurX2ENKoShwaDXBYK'
        'aA9A5c6gK0GjCoOUdMwTRs9UH+NyYdHmvpEgW6/g0vS4Tbd5FfdacBAviIRw8CrvNZ+DtUk9dWFJzGWX+Ux5Zcyt3UrbFEw0Go7n'
        'kfeH2+3C4nGlItzX5DgQA+/0rRbsJBqW5wTUQillzq/+e81xoCu5qJaG41lT/EBdmpu44jQ/rm3w57/rWrf9f3XUV59JT9kqAK68'
        'Kneu4b76mGHJWgI3BfM6gmurWruzcFyph/YzObYugrruGtsQ9OZCV+5G/aKunkKvLAOlYCiob9WQnDrSHb7q4wctzVMIx8ihE52e'
        'N35H4vn0o90qWiZoNFK0qVdGcW0+Ib2W1ijj4TcwtTQO+uf6CuJCTuJmyiMPKg3uniCUFV7xTJu+sBXrrtTS8LYyo53GFPnCGEuS'
        '7nb5LVDPx0ikG0jAQdDUYmQb6NOS5UnXAbC/kR3aqqLV1roDpZu7m0oSFGGW/OQrqHqnUoSPov3NS8X5F+O+HuY4oFAfAGnwnbQx'
        'iBdFnhcEjDt53KKiHZ2t4JRv8cJ2/qGaF9NmZy1dLRwhmHfrKZsx45TVQfWulv3SKDRJcLrVN2ziRB0viALGCtF7wz0tZDC60D9r'
        'i52Pi+PKFOLiGK1WoyWYK4pu74+7bhhmD7lR/fPbWi6dYzvnw8NcRZ0Yja8BnGxrNJKkmZ/ct2x13biT0HO3yT1IHLsF8uthj1+P'
        'P3Nsl6DBX/hyf0v2VW2K4BAhRRhupTrCcUE3bgFHy8tqcUFO4hpWbx8iMv3ez354rHDruRdk0W8y2PDMcSLpxivn476M52RBGVos'
        'vjPscsKvclcYvVoi/N9uAzLEV1ASkum2WgfMoWiO0OqlvfkKZS1h/uuJd3JMZCS5kz6bMpVJHMVklnwCDfxHz6H4KD9QUgJgX9UA'
        'W5B4hmTNrPyKaFCDBBUl3UoDip9PvzfRpcvW+mq60FB3W3d7if05+fKElUzr1TK3OvllfNaZ7OOy1z96TffFDTrXi6oC8mt/XpeU'
        'qfhP1olObLASy/WIyaJCKCdHPPf8YN594sBeaImQuNbLYuOnlQiq/D2B6LtmO+66MT0rLaO25U0uTforahZoT01TQwX+JtB+0ZbK'
        'VqYlJA7Xp5PHotn+ZqR771E87QApicrUevq0zLcE/PN6dlL38HBcFUNbzAxTaW4GeVoEhRHVXFa4Fgat+pC0KBk5Gx77eUXXSBlj'
        '3k66ytIEOit5cWDEpZlcMobWdb7zUeVcVM1t60frbUS9iAoPjw6eIjIeDD8XjWMkabd3DDi2j8jIQeaWZGUFAyPqhLJTIWbN0DMb'
        'M404j3ubZKLLoHfH6igxRHqW+iJgS0P9eMtWXDxbSi18lswmhyxh+ysisViS9cWe5lZAFzNv5PGGjKH6anH26YkpsbrbUJSl7d1t'
        'dDvB8cXvHIQDSb978npCvny/ff7jyPOIEFHlaM3pDKfazPiT77PBib2y2o7Qz7GqyCzV1FHhU5Hzkdktzme3PukLsVgh/YBgyypD'
        'tbEmCDZVUZ2Z43gmOUa/Fbap/MTVdA1TEz3qY9kp2fFNurZM2SOQq+iaPp7U3ibFKVSc2QHqjM4br07f+/bn1Gvfmater23EhLzU'
        '9rWpk37pR7+wOUBjR6XNXXIpJzkr8y2gLjjm9UJp9Z0/0XcGaVi/6XScxheB6zxhbrYtETmLtvKLjWLRx9P59oxG0Nv2cATqA6aq'
        'bNuqU7HUE/DwHz8B/nF+gKy4E7hfrnr8BdJyWKEDO9RnS3nDrsztV3oc95Y49oUA6u2n73UZDVa4eytdfhuu80JjOkkcPwwW45cM'
        'K0nO3/+ZgLM5BvMywk98j8P9Zlbx1uXEPgcJj3BIp2s43RFd+jUDm9CJgI3o6ODBeHX6LgBs7dtz1eu1vVQ8xNQ4pPiqT5a0ajNC'
        'OtqOBTziWGrOWZazEhbrVJPGJRxpm7fzJhNo9ifH95R9kyQz02mTsKs4g9WQ7Zl/N5mkFl+IpzhCSj0mtdd+9fKI1bTP0ITMcl60'
        'eXTiCz0HC/uVHFUcxZeNyIpdqBHxVlLsDnVeUEYsYZ7jeQYeTFuOgPttl4qRuyOd9FYDl9T27YZuFFmMYlzf/sIHN3UPjzDdLbdR'
        'N9xn+cipzuNkOy0G30ePoG7V+S6tu2Y77x6TdbTyKrLtLMEJdqVaRCDzUocZnoGgsOR1x3mh4+xyQ5zNm3H0hM5+CEgkJwZMv7ii'
        '4PhBlC8TPHFQn92cT8ivq1d3aOtGqk2F32OBdX5QivUNuru70kq8LhgfYtULSQ+cU9k5s7X1cjVnOti6+xZZyXQ34C43kEn62pX5'
        'pMaQynW3UjUuuT7IUgemeAvWyLr0CmVhP3q6kbuzp3sRlqeO194FKRoBAcABAABACVAohAIJweAgeCoITZAInS3SwCptROkgSSeP'
        '9AnKqCKZkJClqmSNBjVwyQy/MtjLV0c/6N4XZzag/p5b3jwbHAD8yMH7/F6sRlOAbIBDW6GYreBdEq/UN6Fi7lkL/0aKNyWpSyrz'
        '2ZxdK3GlKHJYmpi2+GLMcZrxk7qHCQnqkLiJPJPPWsxNoZZ2NNNpuqO30n9pG3oahcIm9NeEQhOoqBkYmVhYFbCxcygkkTm5uHl4'
        '+fgFRETFFSlWqkyFSvWatWqTtE67Dp26pPRJy5oyYxaOJ3CWDLUvi0RDC1iB70WqRl+NIYIxlAmUSRRElgKGxxnqQlYF1FAhS4Br'
        'KEs1q69Z2RIFtCtYbJXC6puRFYYYUPIywoQqiFhMppR8KTKpVMCWYkoIdgZtCYKqpAOjn6rUF+cmJLvTXhRlKBvIS57qHKmtaHhW'
        'V795BpZsCwQ+6SXa4dIlIc0ozcZkTrJaB9Hg1caoNNEQjR2aMJ5UcofDMmKzETaArdkOR4NQhzo52+HNlVr6o6MznSesq+/s0GpY'
        'TLYQ2QikGckAF7jBA95wXxV/hXjLihYUU4JQQqUZlFG5Jld0qKoX1YT6Vo1Vmta3uSRZaR1KB7dsX5F4a3N3tfZLWz9aZUXPTens'
        'nIIQAxnmcAHhJ6QIfXTCAfPxUiFAVLwKeeJgHqmraQdWH/m6JxWAhU2oC+6kBPmQpQP5EVX5xwvm55cXLwY/ydLmx89/1n55kfkq'
        'cobdhpryXHE71wxjZskzyGc8PylZxz5qvP8Q8OmK4lMx390sWVup1n3Ip75mc+rvqRkuN0fHfU5jwGi1e4c1Okct2fswRKVaHKno'
        'dgxyXWaKxyjcakB/LI3RCCeFpVvXIsOqcGap0Pv8JNJHw9kV9yUvoV/BtQCB5qKzXq1ia8NPc300vclX9UTr0MkLNkKHO/G6k3AO'
        'GVxg80JtWX/rkLcze3K7qjt41AKwTW8FqJPvj631kdFTD4xPfjlF5yRSNyhqqj9bf6wLrebo+7o6KZAAp6MmKM/cZM1oE/0C6cXy'
        'P+ruSyun0MMz5klrSgOjK7wN05SXs1RCUGg6HjLHjqIcOtv0GgGZ6nsqnBXVA4DoWHEsII47Ifcit+Je8i3O4lvJiglWAagTo+wV'
        '7FzL3Z+RPYnuULMM6RfLN3pm6EK1L3YW4zpCPrQeDoRcXeceL+/Ld2+3QM04wwl+4nmxo6iyy/D8cFdSxRcnAt5aKHw9tQCD1niq'
        'y1BkRsdx7q8LMj535CoxOufMf9Q/hl4Ou2VUQGTIXebr86E232dyPWb+h8u0WHxlozDb1xNP5RFTqc8jGQQpiJ0A5JixpxBFty4A'
        'CaEYiEMwwSk1MkV0imKhqHCGHsmogVYTe62VMqBOWjYZlc3GZYucbDXFbe9a/CQEaoRalz4WanCzCImzMfMCYkDgsQITIw5hHjQ3'
        'Cg9fnRYycCK69MOxsC5VCuiwQLqFnQRWWhokhZHcHaEEnmVBeoLLghslEHQg2/tByVc7AAy0IAAiNmVDM5I11FisAoKVlb77wywS'
        'dbRwTCXNcIsEhEl0BUNPagpfvYkCR+eLVAEszoKLob+hZn1fGiFfgtHvCO/DXZOj5vqgrx8ZB1huqXYHuEH+KaAIa4MovhaD/6vb'
        '5YDlvjCXA8d9y9RGcDf9gpJqQAzAUMgUxogy8wFqFAHluEGP9iDoMxxQzI/XA5OV1N1yq57pzXr/XtuiTcNYWrybP6cRKqgJKjZK'
        '+EKy1GEKgP7YTQDtsyJvRkaryLj0JSZvLd3wEIe/99r/PsjImKzjMQb578Wgo4TO5pBOGEGJTwNJPcLPz5eIcivu9LCnPe9lr3rH'
        'x772vZ/96u/nE3CIquCG6UE+2Nf99AhWSBk/DIZsuajJFg41YtCMjDmbbTVr1Ji0eX2mpGT1G7DBgvWGbIH+EaUZszJYHP7zkDEa'
        'us9E2Iw324iLzhkxaZNpi6TPR/SFg8AxtBJcjhtTpUatOvUajNtmwsatWT+47dd7/rhQ9Uth2FcA4L2nZmNb+EsO512Pd9LongCb'
        'pX32gZUNvD7bEs/hfUox/6XENI0FoH/MdfKVMrmcnO911FY9MD2lL89VZcsOnmaIHZhlRB7v9hyV2R9ElkK4AQV5YM6syaZ0K+c3'
        'IZRKfN6TzHNfRrmvUucjW2j2o9PDn51kGFMVP9WnDSbNlcx07HF6JqQWnGxnWJ6UiZ5t3ew7qrJfjpFRU8mXOzOq5g9wz3OY5CTS'
        '2ldS7AR1divMEeLRCWQvc65Z/uWK55PJ0suIqSVlmi4urtSTfsrCT1adNv41ktZLUf7wadYenzOSIgwMyBh62SWRST9Lrf7nJPVt'
        'xLlQsbxYZkmBdNgcBswxah/HwvnRpcqrWjTAtanKjcoTIu42ptOmfZXY2R652SIOesASAFIGBjk0AOwBVDuEw552KN457TAlrgri'
        '3HYKFh9sD8FhTaMtttpt0YI585Y5xHd5VLkQQXHGOiRtNk3KabJDv922mmFciy2247RatFv4s+tttJFDmZdImlGYoR2HpgfU2OGF'
        '+xE5u5rQR5sKf9IWG0Gp16g52+8SF8WERatvqlJSvxbdKrVuP8SDg2mp4C32o2q5Kei4rM9/GclQAAAA'),
    'goodtime': ('d09GMk9UVE8AACD4AAoAAAAASLAAACCvAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAADbAtG9UkBmAAggoBNgIkA4MwBAYFgw4HIBv4'
        'RyMRgvOAOKcy+Y9CQHda98JBCo6o1ITBfyjgxnBxEOs4OaZETdoupg1D727LsrvlkTb7rSOXsb4WPkMIJoeVMRsR/XhDjjJh/hzz'
        'lP+rgpX1cFWuPkJj1+QOT9v8B+3BrLjz7sCV9XWJ4sCYFcNIBLFAAbPXzvjOuVYXzihMNu1Fsqj2+yvYHz/0+bUyeUn+n92dnbkC'
        'oEJVoVCeKpOvq9An61yVqXEEf8z93obKTL+Lp0ZJtKghkRKHVbS0HtQ9uq2PfmwZdKM1oky8ZpJsr80yMIyBQTbvAZIJHuwDzJ7L'
        '0fP0/cH+7L5qsrSmMKDMkiQskzjFQD5+sQv/39t9zzuveg2czR7qQ5mQWY6cAooBxrpd/zTF8J4SCnlAE+Iu/k066d8+H39+fFw+'
        'LpfLy+FwOBweDg+Hw+Hlcq/229c9VBq0FyL0dqiGxJDce4BkkhiSJZNkKRBaFk/w6/f/W76zc9lfEjnQHQNdfuHSHNJsZjY/5+by'
        'KH2Zk+MHuo5qVWGjFC6S5loXGqNRDqJqWeKMiYrDcgSIsL7de1lInNkYGWiDK4QV/G5l9pxEqBAXIuIChEg9EKWlO3cWERX1YXoN'
        'OmX63f7/3yr6uu/k2jLGkjFGsqXzyCRwAUMwvUqwfMaR3K6R/vk5hekFCvFQ+x+G4O9MeBNM8ONCPBnpy15y0e+zB13lrwJl3X6Y'
        'jx/M2p2d7xVuA2gILrf0jki0TU20Y93CTT5TSb4xoirGymSaC/4jR24JMwszs7AvdFIB7afktdXsoOPOuuSmD7EgSj6zuYtqXuQ1'
        'PuensipW2ZdLZVRBldfh6qyh+ipLsbVc/gpRgpKUrhw1q1M9mtVZXdRHLehn/WG2VzjYiU61zAXe7l0+4CFPeNZnfMEa3/UjP/MH'
        'f+ef/Kf/CZlCp8BhZ0Wc4hJ+GikJ18X1cDlusMtzo9xUN8ctUKvUuuIx8Lwg0LrBpmh1PwiklfD0JUohJiPCGQQWiwlqnSiU2Lp+'
        'xdjdWsWL16pdPC5209JUeWVm654qbMPc7FYZUmWOMYP4nSEq2KBWHR2o3NGKLd3RUzGC/HeHljme376saeT3Hh4UFDvx+nWD9kOA'
        'MTJaoykCXhZ88MH6HqIst8aThoBXLibu5wxk6jIIjFz+FKiqKIYHXVDy8CvVubt45TkaM1xYGotIM7q0iNlGsV6ksgT9+MFW8wfd'
        'u5f/diZY77/7sRHvL7nionOhejZUDUMzUMRHEaNdew/wG7PqZcYqeF14ayMGvx0PtPvPfk8//9N7bA1gyWYInuSoV59sebYv9PLq'
        '2aP9yInJ6CqqFfjQaEBDkZD/+0ACJSvypqHzVszUNORDrJ8cizSOFwgUpBp6DmAZgRyEzGqfAMBHd7TMF58tV0xwY/SgK8Vy+XHT'
        '1cSs50BesNn9WMtmK+JbmkbtXL+Qsai5uM192WAdZWfTCzkkFU6BLYkXi2XNi8xs12VXmsZkamhW2ZcugA0bMkAlO86vadIY3AYn'
        'aioQyCOnyIBU8xscUZ9ePnn/NQyrEj/rGmVRPQBC0ce6pb9pH+ibR5RJ4jwlN56tJXlK6oNmifWY7uoDZqCGYnr3RuFNF4jFeU+B'
        'mo+X9Hza1zA8nQx9GFxowMif5oJAHF6BDt6UUQbTch8hOH/82vGDRzEpEChk6iswVEK6s6gbk3W4nIxB5VgKNlEVOTjicThiK7Ld'
        'gWmoJBQEug91itaR+Z0Sm5am02CdvOT6nZ69dq7tkhoGvf5LOmRxvECAeY3QG3e1+u+O+6j+qTjdwLVX9hXn5pYUS/CKjzUMI6Y1'
        'Q0Aw1M8dzZMrcnMTcGOr6zXI1fXycW5JGzWjW6XqpuMIF65/2LgcKgp2mZ91hSUUWHkSemewHP+iPz4rFmhyOaUwNQCFxkM0NUpS'
        'qVhIaDy7NVNO8h7W4PLCEr/cEZUeCgWevJYSRUSKRBG4WLvhMcTLmbol/QA2xYzU/KPnt7Uj3789o7WNu+2ePAr5CUU/koPkeagb'
        'RrKWTjIwBQcCCGgCDlvj86Jh2zylD+BLfgoTOONLwmdfgQB9Goc7oI75qca6d+uULNW+JdfFpQOGbDJIFdLIls3u+9wYw3VrgxOL'
        'UYZrrOQWrmStQqC+DvQmUQUfzaXYpkw7ECnOtpE/YnigOOuAOhUjYKlmL97MAC3T24H2g7Zf3K3xZBjZ3uuBvnk4OSkpX8KNG7pS'
        'TLG47VbKV99s8O23r57/+KOr9BNDNGmUKMcbwRBJ3ikRY3J4LYNr0AAcVUrg6lQ2lT867RyLt+qeFxWC5wo9AZ+K0fW3MWHkAEjy'
        'xooYN1r7kgt5AoUHmAolOZMC9jNSfVEZB3jQeNCTbiJbUq9enGag/kOzvkhaVVL5wWgGea5wKiSK5nIqJIYyy7U6Mvn/HoW12gw7'
        'JRZJpQxEhgKpEu5w3IkyNlpPG7deC9091srlaVG4aC4PGBJg4OsgYIQCT8DxZKZA13vQooxqg7BFCTYp6umxtklJ0a7m8IEWwEqe'
        'zwRyF1TYSDSMSNGLAE4c/5A8AQSM92AboIABLAEkoIAFmMAGJMgAPAI66AMDRAAP6AEOqJAEJAJkMAR8AIE7QAPuA5XAIDAOTAAz'
        'AZ8BDXAbuA88DvgC2ABlAVmzMJqdZWLl4hMUEZPky1+lGlvtsEuHLj36qYz4YMEPfo4VUbK4nOvoQh4LWMwyVnCWp3meV3iNH7nA'
        'Rf7I3/hnLSH61p6aEokUKpkuWp/s5xYfdIdP+qKfxTGu0eRlPjUy1ajltvzW3U626+33bkAz7St6ff+h/zSA4TpsGGKHzKFp/H76'
        '5+k30x+kP37qqaf+HhQK4kHZIDuoFzQL2gYd7LpporK+6SxTSWa5e+WGbYb5l4AodGAEHI78RjMVMG0xvDfIN+t7oqa5TDdMd/ph'
        'Ssh0ArXhw9m2EozVG++OvP4MN6euLl9qOTSG/ah7WkVrXZH99e3dP/+8U6t48dq1ixevdedXzNSSKY9pJ1NKBlvcl4TPtZGAa5xA'
        'UaHRUSDIgUwVmfbUwTSUKSaz05nmKHdwRW4ajoYR0DPe2MN3FHNRsGuBSiQ+JCLZvsPnNVcn5s6eVSeEhqXGx+AmtzJmdrSGTHGZ'
        '7DDV3bDnsVxtnCk85qOE2pjDB1N8hGLZINYHuxthkB7Nf3ValtlRKma6YriY9A2b8dH9bxA3EG8r00eGi/1jBlvClTnq0zE5tQB/'
        'cXx6Py+zz5BseZ4v9NJq1bEB5PjRbAi8iby0ZpD3xyNFk4+pn5WeLVMS04KdODfHvpBq7RnHWQ9euIm8ZOzELP/BOIRILVJpQ/Zd'
        'UoHELzqSvXUlPixUkhATmzp3VaOeP4ObBjIVanxD/XoypTEXQr1cGKqrW082ehRDNWKiQoX12tTAdFdF35DcCMPrhkHYmkC5pr2j'
        'vwfrl1W0F1FTUTPaa5Ox4MlHjZaR5R2u90QMpZmEGzZsOg6HTYO3gcOkQd/yIr2MyAQKAphsFzENNTtduLOzYMJZgRWFkoNtHolk'
        'nyqlgrP7hmuxl5d25tUn0ftvzJDyMkns8TDAm5uhCn50hjMC7wFg+njsY5ofyjLnQzo6bZvfuu4lK2vEOi/FIM30yEuRgwkSEAnC'
        'B57Z5YQu2A7ZLWjM2NryoyUqwIlgPdFuv+4B+jOgD1m9pkjuermMn0lS34cBnjAWnoDTWO6DBqP1Wevu5P6o++fRdLPRGbpSC0Mo'
        'FWN1QDeOzs3FxvcvjkmAiYNBMnCanQl2eaMKP+n+si9rkL2zfceMzc6O0YnxdKEwbbNx0/NNwicHLR5l0bBClEaeu6jA8sw6t8Mt'
        'sWdPnrh5Cgaj4lua0KRifTIGHQlUK7H2E+V+YTDZj2tgPTj/u69lvzXqo/anMa5Dqr10Wp6SIqeLVCdPqsaER7FpybGjPmgqXyoS'
        'SdC42Yh5ZFkaMUshTgfgYmxnN3bsxeNn52BgZIJCHOmWQQoxGj0uiSUzCi7hnX32QlqiMC1NKEwfn50Zw93EzVYshBJLj2zaMpvZ'
        'D7gSHvB8gJXIRnY2bOkZj+bTms169/0vnfcePupcV6bs5OZNC81dPHEtds9Nrd+IG50+hH3huXtjR5fuTN/gASaPmLfco+HkgfyF'
        '9UbaoGN/MLEl+uKw9wP/Nzud1uDB2vvP7o9n92nNe5Bu+MNI38wCnCYx9nZB+QPqPzS71hdNjpWKOT7+P0pS9x2gt9zJ8r7hfXQm'
        'UEbqU5FQwUTvo68dzshw9V1O4u5wdHoqFrqWLxVjv2q/sTC42w5CymI4pQF6ZwT25RrXK9K7jzyz2JO+YkFtUQk8lVU76tv3tB2d'
        'UbdNaOimAFwHOw3aTAAPfmejyEK5TofCixOZrKYn3ZnHfKwnB1WfPm6dfYsPf6by2kWXrs2kJ62AggtXLKNtrScUsCRKj/mF3dal'
        'KzOQOTMODONQkD05dmCCsk2OFG/eoljxT2v9OvfMib5ePLgcdxNOz/+yuBqLONVs3tTRqem+0dGRfqlInCWV4YbB10O13VPior3R'
        '+zP2Tkf5VbDkdHSN++CmLL1wUdFNK/Dsgqsfwe0R3ZQ55L5OttEA2W5AG0SEx52/Za0OvtHNcEfdIRfH1F1d1zEQsbKm7jFnuLce'
        'X3V2YGB+N/37TVfCAvhV0FVQ/zaX0T67AelDTwbMp2J1Rk/yDYGp/9sKRKP1Ra0nLNZm3dJmgsq7zWGFpdmib35Z/Vpb0tt5erWe'
        'b8rQfLMqFoP5pgZlH3V7D7T3SXv4Gu97mC1Whgtoqpho3T/l4K4Nec7N3bBw5qKAbhEZlGco9AzjHBY2WjrqgByG8nxRngNnJnRE'
        'KM4VxXlgJQPMMPm6+2jJ9bChGt9rp+jq4RI8FTZ4xkH1MVtckQufBO3bWIptSkBwGA/rMeCibSrQjML5p5oPHtrX0IDBygtGNBTZ'
        'JTu5ZDUOporh5JItii3bZTCISG5s2D94eIsI65/nXrRuqsWPB4bVDnRRQ3WNonkUyw800/D74/OTT/WO3MQMuGGew+wBMBQRfXIW'
        'SqY+waphoKcZQ8FQz6lRtOB0Werx5vcV0/VxiJl6nBn1eDsz0vvBUDTRu55QaFXBkqF3PpFcxIzVKZfK0xYVPPgdMZ9x18NGG8DR'
        '4xh05ILDIacED83uhi0Q0pPOWPyDl4t09vwTuLDBdYmeCuPghkd4OxW4XpKJx4uJPl6lVRZ7MqzHChdt256UnUrOkQZiyU1hUjhv'
        '0s6a6q0+B1apZxs6fpy+9wr7SjOm4NSO/YP7WyBAUpc0bFFU7Z/GrgV5T+DbyY/LTx2v9tPd3HDo4OBOKZa3KUwEGx7BJve0jl/G'
        'h5kaf7vY+pX8RqHaVnz4SO9asfi9aaO0tf/QKF+6drNAMAnNgnSbU9EvdtrKkmgJH17hhK1K+UT8INYhhIWYrV/cR7hztPX50/dG'
        'hT5jyFbZ/iW/ealKxrQ3Q5LtodIx7dbf7bYq45vKT65wFyS7tO5ju/d1t2m4xmx/TtyogA4okZK7SOM9Xay5mtncyQ5e420+4Lui'
        'EJcQ+bWxfCukpPVttdWdelBv6n/SDcmAZClreSpQ9dqtvbqnR/pBv3qlHc21wEKneJt3+5TP+LKv+Zaf+IXfeqH/w21AMQ1KeO3j'
        'nPXEJ+ObkIQnOnGRJSsFKc7W7ExT9uZg2tKTwZzMfM5faFzEyAaJVFg8fLnzggZr933e7DS0SKWY9PD3cvzKdYbPlOEpEtS2g5d7'
        'biBvbJWU4CM3+taKt/m6+6DMPIm8/VyHuh/vl4KFHL+raEM2GKSCXcPvNiQDTb0W4MuWEjFxvwz2k8nHZ/mr4hAiPQHyQqqtZxxf'
        'FRTUV2LL+ySLdeQtA5okx9K6Y3XUwrdGfjD2nSWnd1xumm+lw/j8uQXtiqJs/8ys96j5OpKyzjS8+BhcppT7wiOhQDFZs72+j3xN'
        'bpKX4fQynZTgFzxtqzsXQftp/+lnfbMzeGfEFZLHU17PDYmlSmTciOPncYyTR41HvbdaQj8r5R6eun22cgy0+V64p1Wb0ANKF2xw'
        'XOdtycHqMt6i4cqdmSXQfQDwx3dgvvhccdYpboyBdGIGZXCnE0oegdGT0wF0nkCMjXCBuDkUj86lVZQVFecRyMjtio6KEfpn8LRX'
        'zxYm7sPpqa9uG+xWI7L7ptZ/xPVyt8KcfQGzOutNlG/zKDevtLAV2Hww4SheH/hj4m+bJdk8lpJhqhITu+1g4wkvlBYkdZP02Boz'
        'dg3+6CXV+W+x/DV9VQOFiyAWvtLXu98boROp3STb0QlOTV9wOozKhTpZW2O0KbroRtbWSds2GcLqumbEXTTe1TXy4AVcX6QB+XmM'
        '2hgGKGBaEOjOJvyOoCkSKO5DJPZ5P3CrLDnq0C2luNIP9YJAKz4Mf/XSsaFvsWfW9lR2blFrfQqvn592QIZI/Bes1CstG5+unskS'
        'wXcZXKfdsVCgsE5Hv+y05es1zNU35ePcnDZ6erdK1dM9yKI8uTxXi+fViTeVDFQyBW1zzF58uXcocr7P03C08EGCgnm0hA5w9ehD'
        '4RjU2cDRE/tPmw8OR39jWHPQU1MOn8OP77+1q4FhuyLTRx2LR2g+3RyDOKAcF2w6Pd09UbL9OLZ431jpPALzfQIxN8KVYtnpfsUS'
        'C5vaoNI6t7MiqwJLkV+wCXzUexPOTFfOI7C+AyrYcfJW246jEmJiJXNXNRPzZ86q48Mw00oTERwu51/HDkubO6TC+vmPBvvbsH6e'
        'FwrIY4N3dKioLR6hdW1SyY6Dt8q+fXHu7JmJhNAwSXxsTOq8BhNu0vLbl7UJlB2sQccAFB2oYccoSBIqEAi8wt0ZzHcA9/FBUaJJ'
        'YxL1kYRMATJ+Zhn/VcjUsEIpLFiqkKKNAtAMWrCV5mhVVGh5wZET4smWZI9JjwfGAJcEtZeyQRk/W16W/K2VgA0GqDKlVUf07p0t'
        'z4aj8iYTaQYukzq1mjLFd+VBI3EV01DBXChJoKziVS6Lq4ruA3AGGu7MVLcpwN5HBqPZg+bIOu+IFghnnO6QJqn8UUZ+/jRDIV2j'
        'IxQocYVWyI8K5do4tP98SP43OIYoR/dQG9EV3EMBoyKaZq2jKQHHymDAmyopECBSNPg/az3AUtQbwoGGWq63i4k7Bo50erSBvHXy'
        '40v43koSNyx9MeQVCMATRuHuyHh5MgqTaQF5OoiW8RXBrlpYHF1FdJnWG6dagrgBRgxsYMC0wYQndtPiOHFRIkMxRAtWWQFPCzFg'
        'ZBMjJpnGrJaSPCWdnhoLQ4WhAQZHHQg/Yo9IBggAcpIT+vyQrwT670eF2UCfAYDXiTmvZ/nZgA7N3WMFgGLjMLDnP3K+xFBA8B4Z'
        'wBo/ieCTaUWJ68Okkrua9cppXgxv+i9NzbS1dlbv6T8Ma4bS4fSCrBe0aF48WlovU5Z9y59WuasTqwcjlek6ysf28dYarG9r1USe'
        '2XRaMTXgv4EDNaMNAMxRnklkr5RUcBo6JAMjhpUNxwFpgUeUKC+0VRHaqQntDaUdzKRydCq8msLZvIs8t6LoNlDnYrRAnydBZDCY'
        'WFL0ZyYD0DCF0f7m00WiWKJIrqCQKYvKmbqCBtNCV/SQwdGY/wxMf7JZOUj5Udk0aU211lprqqnmgpDABQBAgEK9Gm1jn9qWpNK0'
        'yDaST5AIGNXt8Xr7C6/H6/V6dV4vAGOhhaGMxaLt+UxGNQTPJ33+zI8MlxKUIlprLZVUrPnveFRbvJY0hhljMgYN3EPHRNNjsYno'
        'pJjCB4XKUkoppSxlKSZdbsH9uBDcxd3cf6JeaSSzE9l1Egm34DyZlZTxeH50Ss/q4C+jyU+Fa//MCsE2dhu2aSmTYoRSgFwV0Shn'
        '+rxNM7SHNucCD3F6ETly7IZVISJHRESkyFEwx6Ejwgm329ftcPv5meZKqVNlkiJVhiBcNRI1+h8mor+I5WT1oFHqJMtzpCkAUutj'
        'tvYgXft5o21ZOSRjJWB9l/zGeZlHYEx0rC9GrY+twcLwuNqzaR7rxNYBgOhCqRRIQIuAnllGY34ek/xZXGmrvofVWOSYzyPnhJMe'
        'YNBILBGIJcQsEaUgn0XtugvkWN4Yfe4Z3k8+zK8Cn4JKaBd+HnGij3aSt2/jEUGikEqANK1BiJqAcd1mubQUIJMW0laMxeMUYqpt'
        'SinEExygjeDMTSxgQnjGiwoeiGFaXcGAA6xaokAeSqmmvVUSO29/bTTjtg22rbTQ+7EaeXg/+vSwgnmUZyKBx+ORoGtXt21taxul'
        'kWCkrfM82uc9Q8/YWytbnhubQSIRac//hU/x3sXGs70HLXj3300gxhP9ALU4d3LOOeVdkYP8XfczgmvIAPCdPd5iyAOtvSzrqJa1'
        '3zSgXwaI5tqrzekXXenzoVPCsi/PGqvZt/bwTXedf6W6XxwgQEc82uYVBkegMVgcnkCkoKZnYmZh5+RSkCpNOimZDJl4Hm3JGGky'
        'xmhhwBCwCAQAQlhgiSx5uLZTHJpMGMZ3Hvm5k5umujbkFGwyQQBLB6Ib0eVy5HI5puOc2bkfb2qxapsIVAwdg+c2zdAte6LfqDfz'
        'qR8HX4Yd/jl9nL79L+37evJIj8fj8XjAAx4u4kq5lVKKK76qrU1HHIO3EhEQkPQbrekhPXaHEKUQfRVibhdnx44VlMvFlgsNS2GC'
        'oXMIh/KQmxIcDvF8x3DnTkuZbKQnWpp/FtQF0IowOIQnGiCIID3QYkuMiOpcxON8aZBb4Zs/O+a3hn3Lr1D5U/gnBmZoDDm2buaL'
        '3LLpRDzbe/QMzM4+glPobjSZFKfFaaiVTs2eqfuFM/DUaHsqwbLiM+lcOZmjJeeOumNgqhmZQXo2Q20uSNVkKsHevWKE5s9+RMo3'
        'lVAPlA+CjmIwWptt0EHEs6HKDe/1FzAW/uUEiaYxGCviZDwkiCSWmWnJaN1pvww6rVyiWIm3QofaVg89bxbm2wLLsirrfvUm2qJd'
        'ts8ODsd8csqGV0ekF0ASZJxasWgMvV6vZXm9Xu0lDDFGffVKjGjciF4V7EhCCy1jmiwCZ/AUUCTIzLDQmtFedP4DLsZ6MP7osRlX'
        'd2yw5a65Lx7AY+cTCW7pQCXHdjweH8uLtUrqcGzEqRy97o3raWAxR4IREaVRwoDTOK/bPXSHtCqFS3eEndpJ6e6tvBxVcTzmwwln'
        'pI3z7LfqL1kWIL46VNuhHFWss4bIUT7qhXCyncqB1KdZrrW3ed2J9GW4sdoBEBz0/CYullS8hjaWWH7cwcPLxy8gKCQsIiovVDxj'
        'QIL5hDW4EEIgZ++jQnQ5R+TXM20EZL5dTELR1UOncDhcvi6X089JcM2hxuqhd5QUJGyBZVlZa3Bz4zYpsmjfPLgivzp1DNdURQjh'
        'YVXhcrmok/rlP1FaKQClFAmXF6WLfomwYBdBPZ2uLOd02zIV4upansLOafkqNcyuJs7fs7igBK1hvWtKNMlaNWUbzFQEApKhWZ8k'
        'Jtcwx7Yk1jnWQvMx0enWQbBM9ELVYzD+VaFScI7EgtoY4syyljXjvdNYHu4UYk8EX4eHgFncItxiglKmqHmw8NistmHn7Xlw+Rii'
        'mSWilFcHMDGRgNlD7slYVVNV1ZUc0Kja3AMj91u6mY9MmtqUSaIQ4g/WBulyN1Jq2xS/lISInn1AJ4Uxtta21jZK+1Uvq2llsVm2'
        'urbdTxj6yzZ0npED8/s6rCwDyPUEVdzl8JWudbLx5uosXwa3qr0KZVOQIkrSy5W0l98SHiC5c8rKMFClBGOqeJCMXjoBPA9fNZDX'
        'e1XVsqClhl7csU9Dp0ltBpDlmi3LtIvdUTTpqBLTY5TDKD9rqqDm20idtsGjsQ28ir6+K7PIrWUJ3ZikaE38VQf43T/8vxS5kjmK'
        'X+1tWl+poRf0IxHMfZtJJ4uWV9DQElKMUrXZ7LbaMMPlhFrXorQt72AxAmKfd1sxpIZF1ZxRmR7mzS4fBHrA3CBC+WMeowWegkOP'
        'Dg3aXVY+YNBJK/mGUKZsjjH1Z4nxIn6NNL+sK3Y6+/zyhxu3FTsP+I8PPpGLX7L2wZ5QKpuKYaxGvmqxa3x+0fbjOtZVRNsa2Nt3'
        'H+MBZG5vhA87qJzm6aoifuwRhms2psiqEi5dVODOyTRjvVcLxkAiENEmrVisCILPBjb1SKoxJue88KmBSsO7W7cV3nBRgGdygTZF'
        'Clm9Qp1uAjBYhcm762YKDRf2pJFEZ7ua+M3oTLpSlnxK+lJ/AmZZH6wiChhjOvigPaJR8Z+nmsg2pHt7iV7JrBh2dnpOLgYeHiZ5'
        'gRzVyDsZFmczivghoryq3iQAZBFNNzQWLgAAAFk9zeBEwjON4fuPlgTiKThoUk0mMfydSI1/GAAKAEYCgOIHzagLK+odSzESsdZ2'
        'CCephwhd/AaJaVgrBTKXZmQuZlHhDGxsXv/ixJgbEzIAU+qx5FhwhIpdEE1axL9ZGcTF7SFxepZkE8ncjv/f2nE2g8KtrzgAEFy/'
        'hfDAmrAARFkAQVlC6z0F94hI4Inlv3P/lwPvek0jAO8Cwl/NgUXmAREkmopY+3Pfsi2Z63/9goCEBBLlqp1z1U133ffMW9/50a9+'
        '9vsAWByCkoSSVXQUMvx/hjH9JUcdtM8ezeptV6VciWK5EZwF/YAIJEwF/P3rpAWI4aElRKBw8cL48RLKUyx3Sd6EEkXw5U9BIE6C'
        'IMHEom0iEoUAgADHxg4fYMD7SieRFgAAePjZPqR+17fl9cV7kEq9BgAkLx2h9s/8+xnI9kY0om3pQOynjAyA+INgIey4ox1ka8PX'
        '6T0XCcLbubn/R1vLy4p/sad7l39DfyL21uUarm/9i8HsIkd7osgQ3iFQCahQAV+oXO1oAuJ17WzVdzRgl++DoMmwBx/LUMtLDQ16'
        'cdU5XRQZAOHfqhMuYhjdyLATLfTzjxv9eGNozaRCpfMaWa9G8nk0rjjuJm6txCuj5SGIfxWeubu3Nqbc19OXwxuncbr7jHc9vNDn'
        '9l+0tiKig/MihFubbEyWsWLf6GPF5dq+DwYEgBIANLeRcKMHADKA1lk6b3+2TLbOylXvZ+2037NxJUAt/wlvOXKVyZdJJkMhFr0V'
        'OzInOwefaZfKkCuS3ykzyjJX6bS1CUrayJJRQZPpinQWD9MOqHgfvm1ODrVpoo45S/o/yFfhZ6sQUS8vU0QpWb423FYoudGNfuby'
        'kmUpVcQw3zCzlL08spX914fL6nxFiLRJGC8hWDoi+a64k+D/U61ZBg=='),
    'inter-400': ('d09GMgABAAAAACGoABAAAAAAUMQAACFJAAQAQgAAAAAAAAAAAAAAAAAAAAAAAAAAGkYbtHgclwwGYD9TVEFUXgCCQBEICsJYtyoB'
        'NgIkA4QYC4IOAAQgBYQ+ByAMBxvwSLMREWwcAADVx4Div1wwVdbdKGU3pNPtoenGSAy5bAzt2oGzjZZImavlxHv2yJ71MauDMGH8'
        'geaOxuEXXB6PkGSW56m1/zzd0w94/ttPMMsQ1KhTsTEGyIV1FNoYE79GJix87F7/a+0/z+3umXn0CQDdhiSBCssIuRUZFZXh+W3+'
        'nwtiLoxeWDF9s2qKggLS0gYGRgJSRmEkGIkuXBgrY9Pt6ZTtuSzm8pW6rvf+357+83Z+9ya+J8l8V1K1gCpwEHxq4Zm8ZtLOb5fq'
        'hN4KViia5fn8sf937Tlz7vtAQv6iBGAFLAFQNo2vUSibxldIjq+uUMBTAP8qNyErocuUwFVu/4/E/OvUVv0qeq3LKtBUF2HYHL93'
        'E+EGOMzSt5Kvn59vcyMDlROX5KMC2QooKiCMh1RGH8MExOuNPN10PMIw5d2440bzdjZFrWc7oQNXcekFEX6Pbex9G7V1H3hnz7Ec'
        'ZZhSimnMeKznPv8faQUsAVRqxAfx44cESgVJhwFplQ7SLgtkmAhklBRkVR0IgblY9bTuuY9AB9bPl4jygfPLoow84PxGqoQPnAkg'
        'qxghw0J9/UURH6yzazYHFQGaYwvbazJvaiqcjilbhMH4Y6gxEb4Bs3wiTaaGBOhYc+WPcDnySMFkzRtE0zZM13xVcEshLfMYxJ4A'
        'c+FSkZAkSpNPVGzmGllixUvAIyJRolIVuLT5Ln4uSwCGMfhNQCZwWfMYcT6pARRd7DDzs6Jq9xUV0sKF0DIYsplVOROqZgLc8KyQ'
        'AT6fH2CdQgvaZ9uWBUtTw7zkicZWuHlw4r8DhOWaBbH/M5PbQB4AkMcAKvBlBYyn/ePyI37sp0PGq4bPktixfFCAdjervMKyzxve'
        'hMORd5PPV3w6fTMZv0zBOSxPUYIGkWlYodwHJbNzviwBafY5/lLnMXMrJBNsFOQ3HLylH0C/358oMnm4slR6Ap29cJAqutV/fcPC'
        'IyAiIaOIQ8MUL0EirhQ86TJly1NAqJBYqUpVIKnCaDFmNPQAWxpaMoUEdqFlI3C2hHfoeGLXzKVqlvyUKvuG64Mz6hy2HkihZUGf'
        'GkyYhtkMpCYE5ctIuKE1Jasq3NCA1DdjxI/J3Ioq8PFMnAmwlIkrXCYSNq50uYRk6kB0VPQZMGPFlj0HjsLUqwNTMv24IwepmXkw'
        'xdMvaSZB6ufsENsP5rGV44ezzeDNM7E5sQ431ZQAI848+QsVjUis2HGQhUvj4JIN6zcXQGLnX+KPkgt27jta0H+385Q3H5iqHasg'
        '5k8LkxRymm6bUgshjK2ZCy8jHW+S3/e3n2nMy2caqtPZ58zyGvQ7pVyPyzvK/ZVr9H72RxP14jL1ZC4oZsn5frRHvRRqI6anT/2X'
        'f7OUxCecN6MkWV0DaUW35DTnT3T2Q2J+wi3IGyAfrMG9by6d/2C/QXeDHVeiond5iv98phMgN5VATRpPlenedIe6od697IhSd/gv'
        'PVPYzJP6DOnRzLxD5HOrNOir7vyDFlLDT/H8OK/QaoMnu+jHeuBhneEcOjWe8BR3RaW4yH2henyRA2JYslp2zaTlTybkZE+p2QDL'
        'hVMAEWm2slB883Eaw5ropVDj/MNpSibeBtIb5+RgH6Iqdc248yMtylc33WKq16BEpTsh+SrKK3Dipcc0ZIWXMt3HVMsXqX1N/ruW'
        'XnrUK0+SE1pyTO4XZ3/0xT52fMj7sdDUSSlJrRlekAtNXK+E0OnTOihRCk/mSh7zg739eHm0Dz/coKypBiFSFqIh4xhH3nSxBqFM'
        'TMOLp3oSsohQPyRt2U4nbvohFhA22WfZPUKjSe3Kvmxvrne+c7WWqDV2ZUzJlKv513W4+Mgfqw86lz/lGcvf+AOFl6zssb+RseN3'
        'VRn/J5k2S6bkjJNS8qSnf69wEZWWFpAn+mBo6dqpf0p7YwsvOR3fnZ9FuvSPMkaKoFfyJDou9BjkqSeDc/7VHwY5lS8Emq0FJUPU'
        'ZarjkzByJptRg7pfjull5+Srf4whmh2PNiuIXetSJAuKWz6SYyqxmee8BL9urzucWHlgyflq2NHp5iqp9Mkr1nf9WZUYb5q2WLZD'
        'cz9x4IbGdZh63EMzOAQ3Sq81/BZWNiUt4gPu8+MjQBoPGbBQ8CiixaHBY2IiipeIhIuLKkWaOKVKMUDINASJEQuCQuHBBsCUKUsA'
        'jeBCMGFIj4qKM0fmdGwxDCFQEDvWGDXMiBmQaljq2pqGPhn/5Go5sKdlzJcTuMsP8JAPX168uYNHDL5RxNdBXVHliCeOONA/KL8f'
        'EQiQG7VDAITkh+V3raZmzpoRMWEtTFiP7aU5MQC6R0J4BxjhXVBLZvHu1bBiQcOUM1dwnQu4wos7GDiBU970ARvHSQWWbeqDLYfS'
        'ZIDe/OVT81Tbwci6XzgRY9ph5+juO+m2wNKAQKJgRE+D2NONE6Tnn82XANsX+IIC4PySKJUHPN4Q8PJB7FvSAhGgAAoHUAiwIlGo'
        'aekxYMSEGQtWbNiBAig4J6kajLrQb2LYOXchbXDRDRCCNjABbjFfTG0NokC+fOlWW9zmI8JOOXGONihU/boZY+4IYyAoo5df1YMY'
        'IFA9MIzA5NJQYyckBAfCUTuo8mp9A3RHMu4MNUkjIiYhJVOkWIlSZcpVqFIJRvAZPDzbMElFBlMtwbqC1Kw2smTYKVNwuBgkCIyC'
        'KI2L/eyDmPGVLVudPeYsehMtyLp4FXTYyU15lNmZQ5nNudxigM7NGYKxK2HzAvN4bbPUYBarbeYSpnFaZq5gEpPezA2Mw1PNEsEo'
        'NNXMCVoYMosFXQgys4Pql0w5ZC2dUOl1ZUaOYr2oOSj5YBjm4sDUf/Z7YHmWsNHavHAOPFcGsbXWlomdtDIGBGatrfuVQ0QJHivW'
        'Wj8gnnZywWPBWtuuFEBJDHjstNZ2VzGkii14jFsr+xfIR3r+A0Ky1g5X/y19fwBxtOSYaX1Ldc/9rnWVjRLkNArSjCbgFKNjC3Mp'
        'QfzH2SpDpizZcuTKk68An0Ah4QGYhmNRfvi8E9YGCGgAZE2Sow6rQmr+zbBMGzzSTm67Y+75URKQfQkqlAgjT1dGM5tLeZR3pQXb'
        'WNHFrNySV39N1YX6o750Arfvwjr64q89a3G9apjWxhbUWnqwj/WVXtkwhPXIDweFKWZVNggMCKkFR0ZLYfKRny3hqi1D2VIu0dJ6'
        'r8tAmAJUcIwpe7QmAGGAJUqwgVC+VpLCV/xw4XfQlExHLCy4JAacLCQtP3DJ7FxaRF6bwSW4c4SZlKUNLmDdWT9SyozDUQWeouuM'
        'ABToD4MGWxoTRlP+6euDr4Xhs9OCJ/bNJcHeZByviYkmTM3yQybICpU9o/C8GnF0UAlBOVKkO/e6OCSoeKGkCElZ6OLcURkApQFQ'
        'bCwHwDQePoAo57TPBNpwijV1iOWVxuQo4QofrEwaP6vEg0Ocy9v6EmhaQUN5fat4kLrUTezf8pm/vTF2kIf5Ocn/YKW0yIJP+n4E'
        'L9koMGGFLM/Vt/JfIOc9jyW3f+minvfSqTyDA47Ir/AyHzb1kk2JkdeZ/+pwApBBMBf5zU/yxEZHuZUsw1yIzPAGIl4dDvemwblC'
        '9u5rRSEqJha2JCkgsnxkNHQMieC4ZTUOgXwGHIJCb7dyD8i1NywpBVzeLZejsmjAzd2yc2aFPUD59bkVZyR/OwIq765qXEwpqiSo'
        'UacMhBSCkAJwpB/kR3FyBejpa2oxoYN8/D00uLR85zf9QpatvkMLwBx3l/qDigFLpCECnJkLsbFxNmilhdYcKREyGIwho6Xj3bkD'
        'y/r23AGBpASzrDYNSE1p7quaUjRKeGqIImnrWns91AEBo6vbdcAvTlv1e8pSvUXSAlCJT4DO9Ch69zEiDSywPb87WfjfGGD6S/UA'
        'CtAe3hrAQIcQFQ52cXAPe/sdcSkUBJ++nC2BIED/8dgDIaW86cacEVBuYQw6hGHpAOq3gA7bUSSAAqiQgpDz7auIB3jEkWDIkZcA'
        'UaKViSdVasZpl1132x2PLHvprY8++99gmlVk4MlXoGhJmFLJ4hiTDPRzBrucIReAXJ79E5nw1QiFZ4gEkEGD75/I3MG91zgPwHsA'
        'EHFLaRLEgXCCRKaipqGlR58Bw29qsLlgS1mzNScuXLlx5/lNLO8jYNggIUKFi+TkkYoRKw6hCQ0U6wDlFIAvgOmvwPoqKJ8C5R4A'
        '1IksMBb2lFwHH6kP1bEQdM5jFpFQn5M7y/dbREV9J0MGozs6lrDmREIQvQ1QBtokKdGaE+ozBVnFZ7RM5/rO+22NvutSy3iuo6X9'
        'y2nfH07NRprv1HztPPSHt7YH/Y022K1mdKM/aGuTgsruq8KKOJTde+3cd+14erJ0B5vavjTXdrm6A8ERVFgqtbw1M9msxdbobrif'
        'qe1wsRKcIruVYb98ychyubJQcCRbLJrIQ7czrBGUNiUFcl0vFT4cVPrjU8a5rF9izPAoIOZ4/2uL33+YyvoNKS6Di4fP5O4CVABv'
        'IU+0OOZb/lliy+8Luf4764iCKqeET5shZFwC1EW8LsYajYx59wLlG44Ey1o5onZ4ygxyQwfnKCIuRri0qLaPYH+NfYvkpBHQDlrO'
        'XcOrxuLOGan+OjmXxA2eX8I5Ji03nlRrS/asrgy+kHRTKFK+du0yWgM3h1cNP5xIRwC66Zz7o2bBKHO0pqOtIDxeO/bBWJUSc7VO'
        'kqSNY2yHl6nYKLwu01Q554jvIBzgicmL1WcUHmdCcaUYZ3n/jrwhdwnbR5LwW8vCeUkumaVgxzHpCI8piM7WjQJFaZDiZ8kdOZPo'
        'y44MPzwos3Fziq0c1IKgQ0szI7EAWPF1bJ+VhyS4kk1OfbabgEZ9XgFiVjg43zFLJbhqTd+2IQahgLBcRZ550wofxuJtfVwiXI3h'
        'pwuJQgA3YoLk+uXSYshAviVKp6F/zOgCadNWbTCkUNZc0/AtQ6nTLlm5eB6ivpQ/HpK7bN6coQNFCXai8Tb9KOUCFNkjXjXrGuGr'
        'YPFHS435OyycrXW7JwJlUhmUgAQTcHAiehui3gZEeNmhRhgj2C+j2z0wbh2oEDEJRYDxkpNKk2LlCRFuYZy61ugMjvELw4ukFEgA'
        'Ig9mcoGJi8OOBEvO9tXIhiJEQbgo2Kpp5YSpWmCHBAa57c7qHnJPtlMSJTiDyCtC995hXE5K+LH1DCLgqn7wICLiRx5x4brYHprC'
        '9Bm3hy3p4qYXp3MnMaGPwwgY1MIoj4k5KatxH0V6ypr3xJe6NMnf96sGVpzgcjZpxGlq5cMHp5ZBHgBPCOKHyH3ntOfFD5JGTUDS'
        'AYprqEsJvaK/5QwrkNhUbtBvReEsheKHXWr2lFMiiXcU8Ah1IB3TvMYU4FGa1K0hiZlz53SHxr0WO+luLL2mjHpQ6UZzhonk/meN'
        'bDSJR/guHVFy7n6zkPd1HeqLIcWTKn1ba+WriRvCY5GubFF6EQyoYLLxHnT2AeeeJRw2prKWY5vK6AkjlPVY5BUyMzaUT3w/4c5m'
        'WCesf5GYgr2EcISDtDnXq0ISFJ0t8MgnH5HLbXKadYpTX6gZZzQuvYgNc4vWyqXBs5YGv8UT7RVKUpx0btkILbEhr7aamTjFdFx5'
        'QOLGlOcDOAsFzB1Qzsn3a88XMMFfaO2jr8uzLOCn0jVcS/fQneozCOmTrPIZNNAnDx2kuzVcihdjKJaXXG0RQ0wolaQUvcH/yqkM'
        'kj0oyOSp2XCevn0pXrFsXs43L05KtoHq1WP5SzCt6avmQfM8DVXeObRp+4b/AeqO+Sc3fbEmVQ4cWn8ufR1xLQQ/xlOv/dOyM48K'
        'uZHlBXiUyRocopkZPyiS5Bz7O/to+kjq+Pa6LAKhvBXLy9tDoVVviy0kZijq2xnAa8nsjOf8IdbL14eYnuozostRe6pyj5uIT64n'
        'EqQCaoMrXvFIUa6rnq/QfdTSgm9w41OIUkOC2rgw79hu+WUUqMgeTfz1vUKqdXxaAj1rmZCN1j7yOzpMeP5yhLRt2kaqAQiN2thy'
        'XcPA6J/PDu0/9O+T0Y8+WlpHb//bPtreCrwNzS56qA8yX74+wHRXn5Zdj9lbkzdtnL9ghiFIcuMaPCiN91sqdE/OV+o8UigrT+fx'
        'zzc0q0dC983sNjTtIyxS1xvWq53z7TfcD8x7r74RK5Nz35/fo6gpzcp2sdjclGbXedd7X58Dj4MaH1RGWU5x7qnlb2UHOjZ3u3/i'
        '2mERsISAexu/iztdxS30PQHCY/a2H0W6Fg5HF2xTnQR2BWr3K3Z5jkL79AXzs0f1AEJzgvkLkMAqYDVrjE3RWxVbqp1z7pjBmXvN'
        'aEyNY5ZHlVerJcbMAlYJyaEibybcX384w0+mRQoJCkdiozZJewCqcd81DxCav+zu0Mxiy1IOoor+pyXQnoM3uzKA14LZgsf8YdbL'
        'V2YQD/XCaXc1OV+9xHW7zy+MNzxolOv8tiDXRayh4WGTE1v4Ta4N27W+7IcfWi4V3GloEN5dLjtUMioWdxBRLRwOqqmTKAkHCE9w'
        '5faFkYcD33EX9j5UzW0fGJ0MJIIbDY2FV5eFh3buV4nb0egqNgdd04GVRO2eKYNZg4sFg0BpNfQhv/6Mdu0Cgp0s2xnCzdoTmSgj'
        'x+Dj60IZ5ke8TvleVPdW1aufZ3f1ruRUn4DLZg3Ex6taUjojKAUYHDuxLjDSqN81xqg7rCKJqEgrl5/9KAQIqcdo/uh9gPCQ66DA'
        'h4NJ7eb29wP31ZfyufuPJJeVTqYkjeZfUt8fiB47Ws2Aah+tuWBytsg6lvL/wBOuAWryP1axJrSiC3ZPNeCsVYbmt3V3+owxdr02'
        'qrVk83VkG5VDrzFmvUPfvfXwPhOMfa+dah3ZerwfjDDrzvadsarX/G5ocswy0fOuWa2rWYX7rQ1ZhvBjwMeRh1TY0zY9vB/mgQxL'
        '9k/8Yfv/y0EjUrYgfw+7izvcrMURjnmAKM0NYfuyX7nd9+eEchQ6pYDKs0cJHroseZFIXa6ZBNdsUrcn3nnpYc2UB0QtW3yXPSPT'
        'a22SOFrHoXiHUWulu/imV3Suwg+1/zdxCuJ4jYLbFrmHiOmqguRYaTm6346ol76mdO0eNx2UX3KWD5Es9IohPBrzsEtvLp0KSka2'
        '21ZSyX1Ff0/26ztTqbUBkbsyGgnRZei+w2iT+PVs/cffBc4oXERQCCHDGQyYp8qRRE6G4aExgNBMeRnQ8axKZLpSoyhanZiUAY1y'
        'dDBTmYedLyrCzCpzsjIVmdiZsjLsXGs24FioVtoqoYNjlbCVNhWtc4uURpOZxI45HfbCRvsnbAoqaBdi5kVCzFybgB+UuAkTuJWg'
        'HnMywdOKZMxuTxBgrrijlIHJCdnqoqIlvQqJZ9ENvKYAQjN2yDCDyKlCYgYzlNm4ubIy7IwyMzNTmYOdLSrCzrfmgXSLPc/by1YP'
        'HiyFL3X2csfDmxvId7qj0/vgFP+CmP1N3HReWzJ+MJlbEne4n5OJznchEoPGnCyZZfWzscDNkdJf1b+WTnmXyKhQRsQFk9drO6vO'
        '6tpRYkiky4A9UzqDLBJuilFhGRiCzCeh8WBts2atFM+sCuU13pGXfBk7XPRjUaHgVUUQORlrj4xndclnHzEUyRnKJOxkSRHmmDIj'
        'M6s1G3tMIsNNtqYAbGdXcQ/2VKujj2q+pkp4ODFlrm1ueqymvkNKqUTh6oGKMkUBeumU6UkeplNJzPbc54JH0+PANuWjjUsv/oIb'
        'mOSiaESzLsOxjRXlRgPAtFeDi/fx0I2Dj70lK01cF4wt3dFtJt5gSs6S9SA5qbtp3IM1T6aWShuz4gn54aF8zPWjn7jlhclRorDo'
        'Ys50hv0oh4H+5oE9ZDGVTmxF9biNGo0drITeYt8gv0MQMycsjFF3CPmSv3zQtxcgPo1NGNLxrCpNvZaUqXIkgZNhQPB321yvGGrv'
        'vimCQQaRU4lM2yYM4SIynBjb3H1pczz7VZTDh/Q301QZPDPvW9OFzx3xxRFoMfkoWG8hmkaLGw15B21ME2vYWeKmtOiQODzZ6Nct'
        'ffbdfdLk7I4Zqkw0hEmvMqHtszVC8tNz0+UJMeEcXKLZAReVQ0ePOK2g9wwdOKEp/ZH9h9dNRWNCkDHG0XEbe2fQOnbtOzrrgck6'
        'edtonZs6XNtQm1yJPoi0rmnK2JpNvgMn5eC+dTrlzOsWhxTfhQ3xYRdqvwX7lFctp6OdB21mphR14/KGjPBvm7o3bWoL+7Yxt355'
        'vtbHWSuDddrYdGz7uilnG1ann7TTbZ/N8K47XYZMae4mca7DrrvMYts/g+DZEtC4J+mW4p4Piax0i0p0j8IpfUlt967t49UdE9wc'
        '/sebQGxsT2rHNvoQRv8BLSr77TRr6nokxhLjlG0tod1g1rb75U3Lwubhnzb0REGpP3FLpD4oqneu3azPGQprdeo218sdBtWmo6+O'
        'VzA+fqxgvJ4ZGXkzU+4oH8qZwXWNDvO3t1ENTp6iriWZX9psp645dZJqEACuCO0ys/8Z2urmal8ifQAK5dc1DI6gIbAUQ8XJqsJp'
        'HDk2uoYz3VRy/Y6oqfGGQHqqhB62s2O+spbJ1T8xAopMex7n1M/Byk5qEWmFraGclK5IejGZSivZgRaUDJdwGrfFCgmEKGFZGI1a'
        'H0zNh4jHYcXVMw+y6luu8QUzBWUNk2J7fe66xlRMT1JZ7elnApAdOuDW/VP0LNaGB+nXjtSG5gCs7TRAaECcSf1ibsUMQjKjHU0u'
        'qA4nJbYyyL3JqdT+dhaX2hu4+4gh+X92I/KtJ3U8uwNomWO4isaY4wUd8uW/5aDCNH0e1z3MXHfhLMZLuXiFX1N5nld+1FAya5Gm'
        'qJZIR5qY/x3RzxewFL8Qa+5UVvzV3lq+slzXOxLfzqGrkhKpPa2seLTUj5XgXRTFoanaE8Apt3oH/dWRM5NuGQ5AaKp6mitXlyQT'
        '9zbk0dZqF1jXzZaIpNPXMutrrmdKp0UldbN51tpxaxvySHuTS6rVz3J7hngdSJKUQqNVduKSkjtx9EoahSTtQvIWyKXhMYV4Appf'
        'GkaNKwtD8Ql4dGFZOKCYVp3nVUwbSk+YpytrpNLhJtbqUf0EIat5K6lmMffdrlhZqeuD0sAJXPcQc82Fc1hv5eJlvmChgDYTfWQo'
        'Nq3n/kmIb2fT+xITqT1KFricMByZIcLhSsbx2wVxIYTuRj+jfE/6xHj5YvUZwLRiTuVv9Vlf2x335ccRto+nhVtsMjJzaLnmTNlt'
        '4P6r5Wbtf4bNdQBv0aWRthGAhB0YAOS7JQdgBOg+HmM5XR5wAuZrAwnEQMgPcgYHSNtCX3GgSLJXBfsKxSIRhLUHCMQ/t9xjqfW5'
        'wonh6EBzckQ5OKPAesm9d4OW/XLtXRIctbCts2r94BcSg43FJCaCPUiE5rD5uxc06vUP3b18afiBSjX88OKlfff660ikrsZmUjeJ'
        'SO5paiJ3Aus7Hh6D+3ROt+04XAF4fLNNrG10L9/YQN+AqLDAAdFgbVGZqi7NzY7GElIYpRW65HrQoses8yMmh++NomwJCKOGevkT'
        'UERqOTUEs81v6wW/rQwP14EIUkp1AJkuDQ9PD4nGJ/3UZegxsgkZh+sAramK6JA1g1xM1ntY+7Np0g3V5wEq9MllQZi0rdsDMD5e'
        '28ikcCSNgbL6yWqz9GlbrKdazCPscFauBFlMdAmJjC+rxwCFnr/ALpkesr2km3G6JzmJVBxKzNRD7rwf5etHTqou1TPOCEBiJejo'
        'InLR0L7m6gg6A7mNwkC6RDrtDoxlJoMy1i69jvrAFvZeUKmX0BJCyET5uNFjgx7o/InhRSAxqeWBVGp5ECY1AolLG9e5iAveQvNF'
        'ETNbQuJL0fgI/yBqdHgENTrIHx+BzvePDvXxjQoOCooM9vWJCgUifVJJGCFLL3LXpSg/P39CiLswTtc+KzgcK0NHF5NoxOpmLBsC'
        '+TYpcWHby3sYZ7qS2b0ekW4uKMdARhIKGccMDycxQHk3x+li1IxbZFd4LdamKGZDa+jo1uyuGDH+Kwghe+WG7rdWoouxNuE1ne7I'
        'yFmni5yS2K8YCXig7/Gnh2cTDrInBgM0Q+yvwxW/Rtkrs7oeML30JYXzpdPOwBVh5hRjuYQ1sa7eWAFjE6UUl0irDpyVVW9sKSwp'
        'rqAJwbrflrPfifb2fgft4/sOmjYZDbQvRWBiMfdS43EyO5ClrcaZNaq75CdrUnexXDlrdm2WU6NEATW4s3nAd+DYWsCJXzwF7P5e'
        'RpCgOHNN/KuIDeWXnkTDCVkpjcMAv/AA8qVatoAvIWJLmbIhWgdUzcrf/92SrRHRo7to7NLn/zMG29J2TPUBcwPgV9wK8BVtA66d'
        '6+A6uS6um+vherk+rr/SwN3ezgzAxFpu/HfJLuLaX967XgGef+2K+DdC4D6M7j9qNg60B5xq9ZwQdn3fUS7xvN7D5sPzYgfIbLSx'
        '7hx0QJOpg7oeB8ob+18q+Xf0Wv37fy5aBOrPWwM92lnEiyhAL7yYj11GXf8ymCo7KLAAvMvm6l0WXQhUbwCObdTg/4dKp1u651NO'
        'tw2ZaJjVKhVxUAvnakybtBcQamed23+IqdGMb40kclW7i7khUDN0U10vzK4dtZ9gFDiBUYWWomBaANhxfX+rKGb2HRhCCSRDlu7+'
        'C0aap77ff//Xq0c/V99CrVpdWOdAoEm+jPBTr+ds2P8Rvy4A/vuosQPs7a6/+5/ju0PTJUCHAQr8qta591LG9L1kBKZhv9vIYLeE'
        '52xwfx/2IvGeIV+fB3wwAB+ZFW+Zg6qrcTeZmhYbP3Ly7s/Q5GBhpMc29AEYuzVuc73bWsVedhiaSngeaVQ7nc/m4uwQGO5cbFDf'
        'pupyqRCQ1auqh0xa46j3U2WJDFmqqvO3t6moszSocvhYo0frHpcKiZnbrnpFyXbaSsWE0NbfUDbvA9+2JghG7rTGKdpaYGR5Kuur'
        'FP1C0d6sq2dI+xlxC7F6hfgQr+uuwMFy3o6Gy9qjuQFMQTdE+V1bbTVYsp002WF+vdPTgrpScZL3f0pnKLeMpNdrSUsX1C8bpfVZ'
        '9kKA3DoFVas2QDx/qsC1JTRTBFGjR39yAD8Afi8fKC8B7T3jgI9A4Dt11hikg0wSipe3XxcctR6A7wGkJTF12JLR99qSi/RFS8HV'
        'Py0l4VnXQuYcdEcQBHTJbBnEMqKWYVRpwcgk15V5JP0MQhEQKiGSI0s2CVvBAgUJV1zqg4zCLHwSYJGsqZCIQK4MvBh/EimpswmI'
        'iJX31LklCSGxEAECdMgJW7NUml+0ECiwtfcXEMPRlaK8W7rCIJEGFcf1LWWRypdKxI+/wDzVMYrREI0uFFCsgeeoTW9kOxJm0OWL'
        '5RDgs00olRL0FH4WYj5CC25GCTOIsmSwTMjGn4MXm/PZKsGlmksQxJF0MIzEMfaupeKDA7x4DpSm5N+y+u033QoA'),
    'logo_cs': ('PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxODExLjUgNzkzLjkiPjxwYXRoIGQ9'
        'Ik00MjggNTkwQzMwOCA1OTAgMjE3IDUwNCAyMTcgMzk2QzIxNyAyODcgMzA4IDIwMiA0MjggMjAyQzQ4MCAyMDIgNTI4IDIxOSA1'
        'NzEgMjUxTDY2NSAxMThDNTk1IDYzIDUxOCAzMCA0MjggMzBDMjAxIDMwIDMwIDE5NCAzMCAzOTZDMzAgNTk4IDIwMSA3NjEgNDI4'
        'IDc2MUM1MTggNzYxIDU5NSA3MjggNjY1IDY3NEw1NzEgNTQwQzUyOCA1NzEgNDgwIDU5MCA0MjggNTkwWiBNMTAzMS45MjQyIDIz'
        'NEMxMDQ4LjkyNDIgMTUyIDEyMjcuOTI0MiAxODcgMTI5MS45MjQyIDI0OEwxMzU5LjkyNDIgOThDMTM0NC45MjQyIDg2IDEyNzcu'
        'OTI0MiAzOCAxMTQxLjkyNDIgMzBDOTI3LjkyNDIgMTggODUxLjkyNDIgMTE3IDgzOC45MjQyIDIyMUM4MDQuOTI0MiA1MDAgMTIw'
        'Mi45MjQyIDQzMyAxMTc1LjkyNDIgNTU5QzExNTkuOTI0MiA2MzYgOTUzLjkyNDIgNjA1IDg3NC45MjQyIDUxNUw3ODYuOTI0MiA2'
        'NjBDODQ0LjkyNDIgNzAzIDk0Ni45MjQyIDc1MCAxMDUzLjkyNDIgNzYxQzExNjguOTI0MiA3NzMgMTM2Ny45MjQyIDc1NSAxMzgy'
        'LjkyNDIgNTU3QzE0MDAuOTI0MiAzMDUgMTAwOC45MjQyIDM0MiAxMDMxLjkyNDIgMjM0WiIgZmlsbD0iIzE3MTcxNyIgc3Ryb2tl'
        'PSIjMTcxNzE3IiBzdHJva2Utd2lkdGg9IjYwIiBzdHJva2UtbGluZWpvaW49Im1pdGVyIiBzdHJva2UtbWl0ZXJsaW1pdD0iMiIv'
        'PjxjaXJjbGUgY3g9IjE2ODguOCIgY3k9IjYyNS4zIiByPSIxMjAuNyIgZmlsbD0iIzk4ODM1NSIvPjwvc3ZnPg=='),
    'logo_redsuma': ('PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzMjcyIDYzOCI+PHBhdGggZmlsbD0i'
        'Izk4ODM1NSIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMSAyNDhMMSAxMEwxMDUgMTBDMjE4IDExIDIxNyAxMSAyNDMgMTZDMzA5'
        'IDMxIDM1MyA3MCAzNjggMTI3QzM3NiAxNTggMzc1IDE5OSAzNjUgMjI4QzM1MSAyNzEgMzE3IDMwNCAyNzIgMzIwQzI2OCAzMjEg'
        'MjY1IDMyMiAyNjUgMzIzQzI2NSAzMjMgMzcxIDQ3MyAzNzkgNDgzTDM4MSA0ODZMMzUzIDQ4NkwzMjYgNDg2TDI3MSA0MDlMMjE3'
        'IDMzM0wyMTMgMzMzQzIxMCAzMzQgMTczIDMzNCAxMzAgMzM1TDUxIDMzNUw1MSA0MTFMNTEgNDg2TDI2IDQ4NkwxIDQ4NkwxIDI0'
        'OFpNNDM4IDI0OEw0MzggMTBMNjAxIDEwTDc2NCAxMEw3NjQgMzFMNzY0IDUzTDYyNiA1M0w0ODggNTRMNDg4IDEzOEw0ODggMjIy'
        'TDYxMSAyMjNMNzM0IDIyM0w3MzQgMjQ0TDczNCAyNjVMNjExIDI2NUw0ODggMjY2TDQ4OCAzNTRMNDg4IDQ0Mkw2MzEgNDQyTDc3'
        'NCA0NDJMNzc0IDQ2NEw3NzQgNDg2TDYwNiA0ODZMNDM4IDQ4Nkw0MzggMjQ4Wk04MzggMjQ4TDgzOCAxMEw5NTEgMTBDMTA3MyAx'
        'MSAxMDY5IDEwIDEwOTggMTdDMTE4MSAzNCAxMjQzIDg1IDEyNzEgMTU3QzEyODYgMTk1IDEyOTAgMjQ0IDEyODQgMjg3QzEyNjkg'
        'Mzg5IDExOTUgNDYzIDEwODggNDgxQzEwNjMgNDg1IDEwNjMgNDg1IDk0OSA0ODZMODM4IDQ4Nkw4MzggMjQ4Wk0xMDY4IDQ0MEMx'
        'MTQwIDQyOCAxMTkxIDM5MyAxMjE4IDMzNkMxMjM4IDI5MyAxMjQzIDI0MCAxMjMwIDE5MkMxMjEyIDEyNCAxMTU4IDc0IDEwODQg'
        'NTlDMTA1OCA1NCAxMDU2IDU0IDk2OSA1NEw4ODggNTRMODg4IDI0OEw4ODggNDQyTDk3MyA0NDJDMTA0OCA0NDEgMTA1OSA0NDEg'
        'MTA2OCA0NDBaTTIwMSAyOTFDMjczIDI4NCAzMTUgMjQ5IDMyMiAxOTBDMzIzIDE3NyAzMjMgMTY3IDMyMSAxNTNDMzE1IDEwNCAy'
        'ODQgNzIgMjMwIDU5QzIwOSA1NCAyMDQgNTQgMTI1IDUzTDUxIDUzTDUxIDE3Mkw1MSAyOTJMMTIwIDI5MkMxNjEgMjkyIDE5NCAy'
        'OTIgMjAxIDI5MVoiLz48cGF0aCBmaWxsPSIjMDAwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMzM0IDYzN0MxMzE2IDYzMSAx'
        'MzA1IDYxNyAxMzA0IDU5OUMxMzAzIDU4NCAxMzA4IDU3MyAxMzE4IDU2NEMxMzMzIDU1MSAxMzU5IDU1MCAxMzc0IDU2MkMxMzc5'
        'IDU2NSAxMzc5IDU2NiAxMzc1IDU2OUwxMzcyIDU3MkwxMzY5IDU3MEMxMzYwIDU2MiAxMzQ1IDU2MCAxMzM0IDU2NUMxMzAwIDU4'
        'MSAxMzExIDYyOSAxMzQ4IDYyOUMxMzU3IDYyOSAxMzYyIDYyOCAxMzcyIDYyMUMxMzc0IDYxOSAxMzc5IDYyNCAxMzc3IDYyN0Mx'
        'Mzc2IDYzMCAxMzY3IDYzNSAxMzYyIDYzNkMxMzU2IDYzOCAxMzM5IDYzOCAxMzM0IDYzN1pNMTQ0MCA2MzdDMTQzNCA2MzYgMTQy'
        'NSA2MzEgMTQyMCA2MjZDMTQwNiA2MTMgMTQwNCA1ODkgMTQxNCA1NzNDMTQzMiA1NDUgMTQ3OCA1NDcgMTQ5MSA1NzdDMTUwMiA1'
        'OTkgMTQ5MyA2MjQgMTQ3MSA2MzRDMTQ2NSA2MzcgMTQ2NCA2MzcgMTQ1NCA2MzhDMTQ0NyA2MzggMTQ0MSA2MzggMTQ0MCA2Mzda'
        'TTE1MzUgNTk2TDE1MzUgNTU0TDE1MzkgNTU0TDE1NDQgNTU0TDE1NzAgNTg3TDE1OTYgNjIwTDE1OTYgNTg3TDE1OTYgNTU0TDE2'
        'MDEgNTU0TDE2MDUgNTU0TDE2MDUgNTk2TDE2MDUgNjM4TDE2MDEgNjM4TDE1OTcgNjM4TDE1NzEgNjA1TDE1NDYgNTczTDE1NDUg'
        'NjA1TDE1NDUgNjM4TDE1NDAgNjM4TDE1MzUgNjM4TDE1MzUgNTk2Wk0xNjUyIDU5NkwxNjUyIDU1NEwxNjgxIDU1NEwxNzEwIDU1'
        'NEwxNzEwIDU1OEwxNzEwIDU2M0wxNjg2IDU2M0wxNjYyIDU2M0wxNjYyIDU3N0wxNjYyIDU5MUwxNjgzIDU5MUwxNzA0IDU5MUwx'
        'NzA0IDU5NUwxNzA0IDU5OUwxNjgzIDU5OUwxNjYyIDU5OUwxNjYyIDYxNEwxNjYyIDYyOUwxNjg2IDYyOUwxNzExIDYyOUwxNzEx'
        'IDYzNEwxNzExIDYzOEwxNjgyIDYzOEwxNjUyIDYzOEwxNjUyIDU5NlpNMTczOSA2MzdDMTczOSA2MzcgMTc0NiA2MjcgMTc1NSA2'
        'MTZDMTc2NCA2MDMgMTc3MCA1OTQgMTc2OSA1OTRDMTc2OSA1OTMgMTc2MyA1ODUgMTc1NiA1NzZDMTc0OSA1NjYgMTc0MyA1NTgg'
        'MTc0MiA1NTZMMTc0MSA1NTRMMTc0NyA1NTRMMTc1MiA1NTRMMTc2NCA1NzFMMTc3NiA1ODdMMTc3OCA1ODVDMTc3OSA1ODQgMTc4'
        'NSA1NzYgMTc5MCA1NjhMMTgwMSA1NTRMMTgwNiA1NTRDMTgxMCA1NTQgMTgxMSA1NTQgMTgxMSA1NTVDMTgxMCA1NTYgMTgwNSA1'
        'NjQgMTc5OCA1NzRDMTc5MSA1ODMgMTc4NSA1OTEgMTc4NCA1OTNDMTc4MyA1OTUgMTc4NCA1OTYgMTc5OCA2MTVDMTgwNiA2MjYg'
        'MTgxMyA2MzYgMTgxMyA2MzdDMTgxNCA2MzggMTgxMyA2MzggMTgwOCA2MzhMMTgwMiA2MzhMMTc5MCA2MjBDMTc4MiA2MTAgMTc3'
        'NiA2MDIgMTc3NiA2MDNDMTc3NiA2MDMgMTc3MCA2MTEgMTc2MyA2MjBMMTc1MCA2MzhMMTc0NSA2MzhDMTc0MiA2MzggMTczOSA2'
        'MzggMTczOSA2MzdaTTE4NDYgNTk2TDE4NDYgNTU0TDE4NTEgNTU0TDE4NTYgNTU0TDE4NTYgNTk2TDE4NTYgNjM4TDE4NTEgNjM4'
        'TDE4NDYgNjM4TDE4NDYgNTk2Wk0xOTI0IDYzNkMxODk3IDYyNyAxODg2IDU5MyAxOTA0IDU3MEMxOTEyIDU1OSAxOTIzIDU1NCAx'
        'OTM5IDU1NEMxOTU0IDU1NCAxOTY2IDU1OSAxOTc0IDU2OUMxOTgwIDU3NyAxOTgyIDU4NCAxOTgyIDU5NkMxOTgyIDYxMiAxOTc3'
        'IDYyMiAxOTY2IDYzMEMxOTU1IDYzOCAxOTM3IDY0MCAxOTI0IDYzNlpNMjAyMiA1OTZMMjAyMiA1NTRMMjAyNiA1NTRMMjAzMSA1'
        'NTRMMjA1NyA1ODdMMjA4MiA2MTlMMjA4MyA1ODdMMjA4MyA1NTRMMjA4OCA1NTRMMjA5MyA1NTRMMjA5MyA1OTZMMjA5MyA2MzhM'
        'MjA4OSA2MzhMMjA4NCA2MzhMMjA1OCA2MDVMMjAzMiA1NzJMMjAzMiA2MDVMMjAzMiA2MzhMMjAyNyA2MzhMMjAyMiA2MzhMMjAy'
        'MiA1OTZaTTIxOTEgNTk2TDIxOTEgNTU0TDIxOTYgNTU0TDIyMDEgNTU0TDIyMDEgNTk2TDIyMDEgNjM4TDIxOTYgNjM4TDIxOTEg'
        'NjM4TDIxOTEgNTk2Wk0yMjQ3IDU5NkwyMjQ3IDU1NEwyMjUxIDU1NEwyMjU2IDU1NEwyMjgyIDU4N0wyMzA4IDYxOUwyMzA4IDU4'
        'N0wyMzA4IDU1NEwyMzEzIDU1NEwyMzE3IDU1NEwyMzE3IDU5NkwyMzE3IDYzOEwyMzEzIDYzOEMyMzA5IDYzOCAyMzA5IDYzOCAy'
        'MjgzIDYwNUwyMjU4IDU3MkwyMjU3IDYwNUwyMjU3IDYzOEwyMjUyIDYzOEwyMjQ3IDYzOEwyMjQ3IDU5NlpNMjM2NCA1OTZMMjM2'
        'NCA1NTRMMjM2OCA1NTRMMjM3MiA1NTRMMjM5MCA1ODRDMjQwMCA2MDAgMjQwOCA2MTQgMjQwOCA2MTNDMjQwOSA2MTMgMjQxNyA1'
        'OTkgMjQyNiA1ODNMMjQ0MyA1NTRMMjQ0NyA1NTRMMjQ1MSA1NTRMMjQ1MSA1OTZMMjQ1MSA2MzhMMjQ0NyA2MzhMMjQ0MiA2MzhM'
        'MjQ0MiA2MDZMMjQ0MiA1NzRMMjQyNiA2MDBDMjQxMSA2MjYgMjQxMCA2MjcgMjQwOCA2MjdDMjQwNSA2MjcgMjQwMyA2MjUgMjM5'
        'MCA2MDFMMjM3NCA1NzVMMjM3NCA2MDdMMjM3NCA2MzhMMjM2OSA2MzhMMjM2NCA2MzhMMjM2NCA1OTZaTTI1MTkgNjM2QzI0OTQg'
        'NjI3IDI0ODMgNjAwIDI0OTUgNTc2QzI1MDggNTUwIDI1NDcgNTQ1IDI1NjcgNTY3QzI1NzUgNTc2IDI1NzcgNTgyIDI1NzcgNTk2'
        'QzI1NzcgNjA3IDI1NzcgNjA4IDI1NzQgNjE1QzI1NjkgNjI0IDI1NjQgNjMwIDI1NTQgNjM0QzI1NDggNjM3IDI1NDYgNjM3IDI1'
        'MzYgNjM4QzI1MjcgNjM4IDI1MjMgNjM4IDI1MTkgNjM2Wk0yNjE4IDU5NkwyNjE4IDU1NEwyNjQyIDU1NEMyNjY0IDU1NCAyNjY2'
        'IDU1NSAyNjcwIDU1N0MyNjgwIDU2MSAyNjgzIDU2NiAyNjgzIDU3NkMyNjgzIDU4MyAyNjgxIDU4OSAyNjc2IDU5MkwyNjczIDU5'
        'NEwyNjc3IDU5NkMyNjgwIDU5OCAyNjgzIDYwMSAyNjg0IDYwM0MyNjg5IDYwOSAyNjg5IDYyMCAyNjg1IDYyNkMyNjc5IDYzNiAy'
        'NjcxIDYzOCAyNjQwIDYzOEwyNjE4IDYzOEwyNjE4IDU5NlpNMjcyOCA1OTZMMjcyOCA1NTRMMjczMiA1NTRMMjczNyA1NTRMMjcz'
        'NyA1OTZMMjczNyA2MzhMMjczMiA2MzhMMjcyOCA2MzhMMjcyOCA1OTZaTTI3ODQgNTk2TDI3ODQgNTU0TDI3ODkgNTU0TDI3OTQg'
        'NTU0TDI3OTQgNTkyTDI3OTQgNjI5TDI4MTcgNjI5TDI4NDAgNjI5TDI4NDAgNjM0TDI4NDAgNjM4TDI4MTIgNjM4TDI3ODQgNjM4'
        'TDI3ODQgNTk2Wk0yODc0IDU5NkwyODc0IDU1NEwyODc5IDU1NEwyODg0IDU1NEwyODg0IDU5NkwyODg0IDYzOEwyODc5IDYzOEwy'
        'ODc0IDYzOEwyODc0IDU5NlpNMjkxNyA2MzdDMjkxNyA2MzcgMjkyNiA2MTggMjkzNyA1OTVMMjk1NSA1NTRMMjk2MCA1NTRMMjk2'
        'NSA1NTRMMjk4NCA1OTZDMjk5NCA2MTkgMzAwMyA2MzcgMzAwMyA2MzhDMzAwMyA2MzggMzAwMSA2MzggMjk5OCA2MzhMMjk5MiA2'
        'MzhMMjk4OCA2MjdMMjk4MyA2MTZMMjk2MCA2MTZMMjkzNyA2MTZMMjkzMiA2MjdMMjkyOCA2MzhMMjkyMiA2MzhDMjkxOSA2Mzgg'
        'MjkxNyA2MzggMjkxNyA2MzdaTTMwMzYgNTk2TDMwMzYgNTU0TDMwNTggNTU0QzMwODIgNTU1IDMwODYgNTU1IDMwOTMgNTYyQzMx'
        'MDcgNTc0IDMxMDQgNjAwIDMwODggNjA3QzMwODMgNjA5IDMwODIgNjA4IDMwOTUgNjI1QzMwOTkgNjMxIDMxMDMgNjM3IDMxMDMg'
        'NjM3QzMxMDMgNjM4IDMxMDEgNjM4IDMwOTggNjM4TDMwOTMgNjM4TDMwODMgNjI0TDMwNzQgNjExTDMwNjAgNjExTDMwNDYgNjEx'
        'TDMwNDYgNjI0TDMwNDYgNjM4TDMwNDEgNjM4TDMwMzYgNjM4TDMwMzYgNTk2Wk0zMTQyIDU5NkwzMTQyIDU1NEwzMTQ3IDU1NEwz'
        'MTUyIDU1NEwzMTUyIDU5NkwzMTUyIDYzOEwzMTQ3IDYzOEwzMTQyIDYzOEwzMTQyIDU5NlpNMzE4NiA2MzdDMzE4NiA2MzYgMzE5'
        'NCA2MTcgMzIwNSA1OTVMMzIyMyA1NTRMMzIyOCA1NTRMMzIzMyA1NTRMMzI1MiA1OTZDMzI2MiA2MTggMzI3MSA2MzcgMzI3MSA2'
        'MzdDMzI3MSA2MzggMzI2OSA2MzggMzI2NiA2MzhMMzI2MSA2MzhMMzI1NiA2MjdMMzI1MSA2MTZMMzIyOCA2MTZMMzIwNSA2MTZM'
        'MzIwMSA2MjdMMzE5NiA2MzhMMzE5MSA2MzhDMzE4OCA2MzggMzE4NiA2MzggMzE4NiA2MzdaTTE0NjYgNjI2QzE0NzMgNjIzIDE0'
        'ODAgNjE2IDE0ODMgNjA5QzE0ODYgNjAyIDE0ODYgNTg5IDE0ODMgNTgyQzE0NzUgNTY2IDE0NTggNTU5IDE0NDEgNTY0QzE0MzUg'
        'NTY2IDE0MzMgNTY3IDE0MjggNTcyQzE0MDEgNTk5IDE0MzEgNjQyIDE0NjYgNjI2Wk0xOTUzIDYyN0MxOTU5IDYyNCAxOTY3IDYx'
        'NyAxOTcwIDYxMEMxOTczIDYwNCAxOTc0IDU4OSAxOTcwIDU4MkMxOTU5IDU1NiAxOTIxIDU1NiAxOTA4IDU4MUMxOTA0IDU4OSAx'
        'OTA0IDYwMyAxOTA4IDYxMEMxOTE2IDYyNyAxOTM1IDYzNCAxOTUzIDYyN1pNMjU0MSA2MjlDMjU2OSA2MjQgMjU3OCA1OTAgMjU1'
        'NyA1NzFDMjU0MCA1NTYgMjUxMyA1NjEgMjUwMyA1ODJDMjUwMCA1ODkgMjQ5OSA2MDIgMjUwMyA2MDlDMjUwNyA2MTkgMjUxNiA2'
        'MjYgMjUyNyA2MjlDMjUzNCA2MzAgMjUzNCA2MzAgMjU0MSA2MjlaTTI2NjkgNjI3QzI2ODEgNjIyIDI2ODEgNjA3IDI2NjkgNjAy'
        'QzI2NjUgNjAwIDI2NjIgNjAwIDI2NDYgNTk5TDI2MjcgNTk5TDI2MjcgNjE1TDI2MjcgNjMwTDI2NDYgNjMwQzI2NjIgNjI5IDI2'
        'NjUgNjI5IDI2NjkgNjI3Wk0yOTc5IDYwN0MyOTc3IDYwMiAyOTYwIDU2NiAyOTYwIDU2NkMyOTYwIDU2NiAyOTQ5IDU4OSAyOTQy'
        'IDYwNUwyOTQxIDYwOEwyOTYwIDYwOEMyOTcxIDYwOCAyOTc5IDYwOCAyOTc5IDYwN1pNMzI0NyA2MDdDMzI0MyA1OTcgMzIyOCA1'
        'NjYgMzIyOCA1NjdDMzIyNyA1NjcgMzIxOSA1ODYgMzIxMSA2MDRMMzIwOSA2MDhMMzIyOCA2MDhDMzIzOSA2MDggMzI0NyA2MDgg'
        'MzI0NyA2MDdaTTMwNzggNjAyQzMwODcgNTk5IDMwOTIgNTkyIDMwOTIgNTgzQzMwOTIgNTc2IDMwOTAgNTcyIDMwODYgNTY4QzMw'
        'ODEgNTY0IDMwNzcgNTYzIDMwNjAgNTYzTDMwNDYgNTYzTDMwNDYgNTgzTDMwNDYgNjAzTDMwNTkgNjAzQzMwNjggNjAzIDMwNzQg'
        'NjAzIDMwNzggNjAyWk0yNjY1IDU4OUMyNjc2IDU4MyAyNjc3IDU3MCAyNjY1IDU2NUMyNjYyIDU2MyAyNjU5IDU2MiAyNjQ0IDU2'
        'MkwyNjI3IDU2MkwyNjI3IDU3NkwyNjI3IDU5MUwyNjQ0IDU5MUMyNjU5IDU5MSAyNjYxIDU5MSAyNjY1IDU4OVpNMTkzOCA1NDBM'
        'MTk0NiA1MzNMMTk1MyA1MzNDMTk1NiA1MzMgMTk1OSA1MzMgMTk1OSA1MzNDMTk1OSA1MzQgMTk1NSA1MzcgMTk1MCA1NDFDMTk0'
        'MSA1NDggMTk0MCA1NDggMTkzNSA1NDhMMTkzMCA1NDhMMTkzOCA1NDBaTTE0NTUgNDk1QzE0MDQgNDkyIDEzNTcgNDgxIDEzMTgg'
        'NDY0QzEzMDQgNDU3IDEyODMgNDQ1IDEyODIgNDQzQzEyODIgNDQyIDEzMjQgMzQ2IDEzMjYgMzQ0QzEzMjYgMzQzIDEzMzAgMzQ1'
        'IDEzMzQgMzQ4QzE0MDQgMzkwIDE1MTMgNDA0IDE1NTAgMzc0QzE1NjIgMzY0IDE1NjQgMzQ2IDE1NTMgMzM0QzE1NDIgMzIxIDE1'
        'MjMgMzE0IDE0NTQgMjk5QzEzODQgMjgzIDEzNTAgMjY4IDEzMjQgMjQyQzEyOTkgMjE3IDEyODkgMTg5IDEyOTAgMTQ5QzEyOTMg'
        'ODIgMTMzNiAzMyAxNDEwIDExQzE0MzkgMyAxNDYyIDAgMTUwMiAxQzE1NTUgMSAxNTk3IDggMTY0MCAyNUMxNjUyIDMwIDE2NzQg'
        'NDEgMTY3NCA0MkMxNjc0IDQzIDE2MzMgMTQxIDE2MzMgMTQyQzE2MzIgMTQyIDE2MjYgMTM5IDE2MTkgMTM2QzE1NzggMTE2IDE1'
        'MzkgMTA2IDE1MDAgMTA2QzE0NTEgMTA2IDE0MjUgMTIwIDE0MjUgMTQ3QzE0MjQgMTU2IDE0MjYgMTYwIDE0MzMgMTY3QzE0NDQg'
        'MTc4IDE0NjIgMTg0IDE1MTkgMTk2QzE1NTAgMjAzIDE1NzIgMjA5IDE1ODcgMjE0QzE2NTAgMjM1IDE2ODIgMjY2IDE2OTIgMzE1'
        'QzE2OTQgMzI4IDE2OTQgMzU2IDE2OTEgMzcwQzE2NzYgNDM5IDE2MTcgNDgzIDE1MjUgNDkzQzE1MDkgNDk1IDE0NzIgNDk2IDE0'
        'NTUgNDk1Wk0xODk1IDQ5NUMxNzg0IDQ4NyAxNzE1IDQyNSAxNzAwIDMyMEMxNjk2IDI5OSAxNjk2IDI4MSAxNjk2IDE0NUwxNjk2'
        'IDlMMTc2NCA5TDE4MzIgOUwxODMyIDE1M0MxODMzIDI4MyAxODMzIDI5NyAxODM0IDMwNUMxODQzIDM0OSAxODYxIDM3MSAxODk0'
        'IDM4MEMxOTA2IDM4MyAxOTM3IDM4MyAxOTQ4IDM4MEMxOTgyIDM3MSAyMDAwIDM0OCAyMDA4IDMwNkMyMDEwIDI5NiAyMDEwIDI5'
        'NCAyMDExIDE1MkwyMDExIDlMMjA3OCA5TDIxNDUgOUwyMTQ1IDE0M0MyMTQ1IDMwNSAyMTQ1IDMxMiAyMTM2IDM0N0MyMTI2IDM4'
        'NCAyMTExIDQxMiAyMDg3IDQzN0MyMDc5IDQ0NCAyMDY5IDQ1MiAyMDY0IDQ1NkMyMDIyIDQ4NiAxOTYyIDUwMCAxODk1IDQ5NVpN'
        'MjE4MCAyNDdMMjE4MCA5TDIyMzYgOUwyMjkyIDEwTDIzNzUgMTQ2QzI0MjEgMjIxIDI0NTkgMjgzIDI0NTkgMjgyQzI0NTkgMjgy'
        'IDI0OTYgMjIxIDI1NDAgMTQ2TDI2MjIgOUwyNjc3IDlMMjczMyA5TDI3MzMgNTZDMjczNCA4MiAyNzM0IDE3NiAyNzM0IDI2NEMy'
        'NzM0IDM1MiAyNzM1IDQyOCAyNzM1IDQzNEwyNzM2IDQ0NEwyODMyIDIyN0wyOTI4IDlMMjk5NCA5TDMwNjEgOUwzMDYyIDEyQzMw'
        'NjQgMTcgMzI2NSA0NzAgMzI2OSA0NzhMMzI3MiA0ODZMMzIwMSA0ODZMMzEzMCA0ODZMMzExMiA0NDBMMzA5NCAzOTRMMjk5MyAz'
        'OTRMMjg5MyAzOTRMMjg4NiA0MTJDMjg4MiA0MjIgMjg3MyA0NDMgMjg2NyA0NThMMjg1NiA0ODZMMjczMyA0ODZMMjYxMCA0ODZM'
        'MjYxMCA0NTVDMjYxMCA0MzggMjYwOSAzODEgMjYwOSAzMzBMMjYwOCAyMzZMMjU0OCAzMzdMMjQ4OCA0MzlMMjQ1NyA0MzlMMjQy'
        'NiA0MzlMMjM2NiAzNDFMMjMwNiAyNDRMMjMwNiAzNjVMMjMwNiA0ODZMMjI0MyA0ODZMMjE4MCA0ODZMMjE4MCAyNDdaTTMwNTMg'
        'MjkzQzMwNTMgMjkxIDI5OTMgMTQ0IDI5OTMgMTQ1QzI5OTIgMTQ1IDI5MzggMjgwIDI5MzMgMjkyQzI5MzMgMjk0IDI5MzkgMjk0'
        'IDI5OTMgMjk0QzMwMjYgMjk0IDMwNTMgMjk0IDMwNTMgMjkzWiIvPjwvc3ZnPg=='),
    'montserrat-600': ('d09GMgABAAAAABnsABIAAAAANwwAABmFAAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGhwbllAcgmYGYD9TVEFURACBPgh8CZ8UEQgK'
        'owSbUwE2AiQDghoLgRAABCAFhBoHIAyDKBuUMRXs2EuA80BI3hlViKImCk692f9fErghIrg+ot1nCG9aQVHEJDuKMhbFrjbKtZ3R'
        'XUXpmZtmOhhof2/r3uNQgsMDjArH8dd5DaemjFFw4to4T/5fV02Bz1flVPs1ALDQxPH2dAnHjtDYJ7n+8+9VnXsf8hJ3dXoWrddV'
        '3T2AMgAyUC3MrPhJZck/UH9U5p+21QdsjGSRyDYIHVCihjCIRSzCiGLzqkLunpcVrjz/z1G7/80KMsMDOm3cTp0sXVcNcAOOOMEA'
        'wzDqnO+Xttc7E55TeUaB1Wypb9eY8H0jrS4kfZwUHdeZ2XTNU1AuQxfbpDZCy2QyRySbyYbYF8C/H831zgTMvNsf+xkKQPrj7s4x'
        'GNOziRElW3YErjpQLWX7SYqgCFaxFZ7ZphauF5TvbPJgVezITfOweSKhJPjonlMMDf9nM23/7N7m1iyFS1OIio56wKLx693O/JmR'
        'dma0p9WatNKxQjLrjNIZpDuDzkhVkCsg+QLMHXCZErBoUqZOU6co05Wp8xiqA9T0PENXkrb6ibs7/2dkpnk7mZQyQikhTxZCZ6Un'
        '/nnD2BaI/eszL063f6sgQAAAAMaIj4R6IBDAM02Pgt19ux+wLubG04B1M55MAdxjfDILWAoAqA4Qcr0Bfrgaz4LK5ZJYAAIDyfev'
        'RzCGmVfKEAIpAgQGHDMarp6n6F8WMSaVb9sTKY4gTxJH4YSaIBBVJJ4Q4rFWNcDHEXY3iMYMPfzBDOYTD14nQfwMx9XDwjGerrqz'
        'c1Itgmqj+6WWmwdUCasmxFj/xtI/ZL4CE2SsDGJHUmc0UxpPCm7KhRXaehtIoeKs1tdSNC7M4qyJQ7zZBRoF4mUbpGENr/SCmbmE'
        'ZLbHIvHUpdyUIW1z2hjOZ6B/FLqkPQmAFIU5ZSp/JXBdPUOgnNy3mztYEVhqmu3V6SNpFhTaInhcvY7cOhGPgtA201N0g+Q3IZOn'
        'j6G/2TjwTraOQ8LeWm3KA6xkJFVQyqAJkwcCkyKpiznRs0at4dp8wV6DZd4nesdsUJ1+1AX0euOAQVKewXqJmJQbeQnxjkRDmmdu'
        'DRtQGKgNXb2yBxtoATs4JOkEkew6eItNpv2W51YagfIb65U6ZtLYFpKhKdPRWzY4nrmfy4bdDkHGQGE071zu0JMevEQLEnJBb3Ui'
        'vTBiAokTuXrkhLOYUSCQKvBH1HxEtAImmj/kW1R4BnGmllNi5SLmiZr4XDEH4q3KCMXnKjiEMKraO6EgfKbzHtVhYv4EOXyuSOoQ'
        'jFo1KrWp0gqjgLaFBFLuOxo+9TcpsleBgrFcYMZAn0nuNU4CmLNJZh6ebPgBtyubK/X3N6fIL3gb4qh/PNUyIvfvvY6HzwJJqh/j'
        'SEPiCEPjSHP/UVApGFo7jkL3taxYAN6O0liE9YOyyFj/bHv1d7zvlQUF5z0DzE/8NwAIIlQ/YsujGlB6W3kptiFv/1Wj1af8YH6H'
        'Cf8EiHsz0sAFtvMWEzRF/LsA8jKwRxU367gAbh4gtSdVtlLbawuGqJp4cNOEepe3jkqlUspkf1IFxWYbAcEBSkI00K8/qVoTm0Kx'
        'EfEs0WXWX1eYqQQb7w4pilP7Gqj6tZGQZpz2imkzJPAXEmN1fACzWJQhdXQohs/j0BQXE3AoMVKmmYYjJeDckpzEJdQb8GxyIfFa'
        '2q439a+i41j1j5VA7mz5KQiHdgsFb0FEnkhny4HsEXHz6vJ5JAMo/4KmF2A9jiTSQPS0sOJ5KjMOdGxexIzuG+rbQF3lNTIBs4a5'
        '7XQPyvqmCBrDJYEf3QhpHWoeQhkSMZZ6E2Ffq6+ffbx7qiyo075MYELYF037QzpqnHBsGGVNf1Jv40eeoAWAzMURhcAfsj/AkmvS'
        'MVkVETjtxOKLgHUHRoo9dlEXT7cCeVRPAAgAnnMeYKEQYjAghQT0Qr7cDE4iAPA3+yEIYlxKZgCgWfPI2JWr65IyTCAfadzGC9zx'
        '3nSohhKwRLRgXe7znBe84g1v+XBBqypYTkjCKJC36l7fDfbUCxrhwQyeVFMjm9PPEgPIi+gdpBkujy8SS9SoVQ/jEKxGOPh8SeRJ'
        'DlOBXsxAshfb72ak0KEi5kld8kkc9U2pCvSrFumaQFul2h933w1soIQUVp03tHZccP555+5sb21urK+triwvLS7Mz83OTE9NToyP'
        'jY5kM+nU8NDgQH+yL3E4HotGenu6u8KhYAD2+zxul9Nh7+ywWaF2DtmdUM24w8r7/MscftqfGd4q7vOu1puFecpSF5yYV4MVjpCd'
        'it0/k/qZsdYbtsggqRcXxJ42Yz2vVMVACE1+X/vnvH/aCNW6A7Ck/iKQyEqvJctdFlyvCPNdUB2EBTWILKwBsEiAvTIBbi32SkD1'
        'lQqZSbR9ZFVfcqxwnrHLsWXp68qSUdBzEZ4e9wn2VtptcFFOsItnNa85EyhrBHbHwO8oC0D2YT7feYay8fbwggJskwga7pyI9pR0'
        'sgnGz4QHn0Z7Gpa8z9UjBI9e3pGVVmLNTg06b1XKyvPWNJITlPa8tfKVG88JT3zqLdMCWDuzFkToWc8xxZJyyZm1d3qTsz77NLOF'
        'OCo0M2li73DjEpo4dRdi9bMi4SbZ8sIkssk0xRlEjJXMcwMkoeyJaZhQKY/2aEZlU9l0NschtycKq6+m4eMkuIQHghZSDk6zzzof'
        'pdynm2UyqfTYiQQHJHI8lFXNxMtvwui6ddr3XtfIt0Ahta9YUz+Z3sZKq078dlynKWfBZIC6gzd8DEIR0Vp4LnhdwVg/B/7ZGDas'
        'Z0nCfcM+pakeVqckebqvc06bZsYn86edE/3BaX3DWpblaoPKINjtcjvUuxiSWe3G2e4VGW+Xkj27qGprLWebEb4lYO7jtS/R1lfO'
        'KGbcR4sOSq/3n8DvTxL3n1nMtDQ4raDD4Z9wzTUtv9Emd4iQncjQDHyEbSLjCNmfmCQ121q/XA5vUZ3gdM9WWvunKTt2J88lARpN'
        'Wsyl6WP9sRvbCzyzhq3GX7wx95nH9moKykyjQtOtPWelOPOI8zhSD9kpJAT4+Bk2Df7cF41o8GcfnMv7YzzSndSNhrreaN51duez'
        'lVY5Q1E3fmWSSPP5HtEd3OfPFrsCd0J7ht3RW+MQqIGiBoa8J4pvbCrqYq57TVx40S4h6kws9Xx9ub5wS9/nODEVCALG7ZpMDTjE'
        'DNvvQct9UfN+ur0YEyBZ5Sg0MV3O4gCDg7xLHyzitF2kNuENXnJCsg3bSi2505rxwqR1s2MR2VucpGOsh/TGFm1s1LAwKWV3HOLY'
        '0UcFaIgFY0o5TltJwVMIBfgE1ghRORrEmoWXXH1iC3vEG6Eo6pqxEOHzpwvOkK5sn22AUXoTjkf9HlGyB/gEwBdFoyjJZGh3VhCU'
        'ob27ZvuKwxzHPuwOWZ4FpGM9KXUMcrrI1Gx9ljl0IxZad2btWj7zpjZ2ErYGB8WS1go7WTfeoLcqOu6rexUcW6qoTeUcRBNgAehd'
        'EPhNELlcF07L58sZB7u0dbIvIsDkQ13OocYLE+AVrEw3DgTlHZ5E/FiroOFZ+jY7I0sphEgLdsMIZKE1lAUCD+jLkd4l800EZJPW'
        'fmrZhK62LwUaPbcDcMEEhzigW2SadkxJ8MMDKizwQfiHK88IxfiUaCk/HOUk/ZG4FaLycE7vYWQ0l8nVnlvWMDAIvRetjRDEFmyN'
        'ttFYHKzdFAMmJueWr3fVr40zHtSOVpgszalThV7tuHyu9pwm2qKHiW2Cz2ekPOdgb9gv1aPwJ67eEVF3n6fu6ZNG2XOxlu1ke4bw'
        '/JGwxmnTrtRnh6b2rgxsXYbK+VzMh0IVwKAEfWG57CxsSTYAU3NZwV9ZZBprXXB7Jm5OSceFaK5qPiiaPE8OvZt06YkAmvatPBYE'
        'uMQd3DjGMeCX8faxvDNLG8e6BowrTE0gVmQbWxwnagOaFfscgAaNKwRrn6LYAYURBMb4c+0CfiXaDk8NU6Olk9+DXKdGuKo9Rojn'
        'c6jFZS2Xti6cnVHgpVLpLXisw2HUkLvFO6kcwi1Wm4johhdihO+XWYbZrKp05ne9Zu/EAW3aMbAX5ergP0tMUQAIcYJzmSYpsWEi'
        'VN7q9kKFq24DcRYxhADntVf8JGtwEfaRkmZGeJNPMzcMBInosS5krH08h2eqINhwZZdnSycMdEqVigSWAm7Xwr/2I5pxA5AVD5Z7'
        'RFhDWZzsei6HFuaWuMapBDPvywpOhxuMkafCdK/g17ML3pe0W/o9VqH49L+nlQNq7RbhLUD02pdhrnnauyIn6BzDPs5+fXvxC/mE'
        'Tor+lyyEcsp2oU2xoSTevKcc6h5y9aeKVWd8Fa6Ob+lNhKyyEe4Ih8juJCXb8wtcpMXOjI578QrjLdtw/+zJ+H7OG+GKymnFtBch'
        'n98x5hKCRDKV6x505uobwrUKvZDtRcmFWlst5amU1kATZw89OtJwdBYTtDHYyi6TiwIHNa+Y42LJOaTfxrwZq2Zs8uVqm68dmqaJ'
        'thLUMwb5rXVDSUaE39lcCcPaF9ITAJcSx22vhfW68SY1+UpWmAIEEnwg2eS0XbhAHMghKP8eWtLM1U2EhpXZvAYzfNeiA+pOeQDr'
        'W4Z+ezGfZCxeQVOCrgSLpdxS3aKb2HJFkyZSFwxCZR7SA+us9y9pIFCDGEAWAAAuBqwH5DfoL8ANgAtNl+YGjPBO/KtR8qUJCk4y'
        'uV5E0jSr5w1hJbG/ztp6CurIH3wqa7W6jzZSy7oEuqUH+mnoJKhPI3Qa14cF/ghTa6ojrxwqHWK3Kequx+gAvVKXCfeM9u2yYSyw'
        'Y2ioPP1oViYYyRhDVeMQm+ylPLlcFPQfTDyyn6efCLeyrfS7xXj6e2hnT+zPOEgfjFFeVi88dEfOAX1Bij6zrJClQsBun/khE5Xd'
        'SnFqtOTqQyQxohni2ArCBnIPNMy8iEMEz0n1H8Wywhr2XCX+RN9REwmbqVT9AF1bHOk2fe3Rcg5BT3LlNSmjKH0EJjOSayBjrtVH'
        'GBHk3ghQrVy1jbPlLOBT56z1jFi76OgHqq5fLhfs8j6vBLqG8XDtCduoU2u9D5GXDQjmiHK3bUTvvTWQSkk9EQsnJFbwwqly0mOY'
        'MUYywdDUUZPGIlaV+qAYUB+lZxV0ueeOyIQuJHK/GoAnazih4XpVCaEoBV2CCBEiRI1OhE0EHvyqX2QRdZzzdd5Z9yyYKi7ZqMr0'
        'MjZkfQeiH6A8QNcnZFkZQU5V2R4VQwUttjlktapCsKSbp5CND/RbO3f+x4w7/Iayx+Rx4YzElP66PBeO6yuHNTkcFrbeUVGdW0fh'
        '7itHLpmmLC+s/vucGBE3rVbAMwPjUXhfGMETEFi/6YhppG+dPdQxSwyDBdJWsy9LxTV0lb1k3yHF+AqKN1blhBmmUjUkDy3k9B9f'
        'aMHsjHbLcp4Gs7GGfeLPivks97JL44UiPoCunPeQhI0qgvc3W1/jwG5vk1bVib4g2DQ0Wkn1M7ptZd0i6sIxe6gRDESa6CtpEyQH'
        'p3CaQQ7p5knwEEyfbWA/Z29+/CTG05Xk/wNRhZ2k0YM3lqUKVt78yMIHbkBnOh4vn/jON6QrSb+bq5xWVEyXXUFLztOSIJK3Lm8c'
        '9mnkzgBPXqfv5ak8TV1HErl3kq/aHGKlwiGxvZ981GIVS6RWseV+cIXrzin6YuoNp1O9kYztKDyBE7pSnzPUy1Gru+gmIyOsUjHC'
        'JmMXXa3u5YR9rpITehDJy8ZvCkYvGh6KXnxTcPy2zI3OCX1zymprHp7QO28EkfxBZunTY5mzhameFHhgVxk625sFV7venCIp69n0'
        'x44ovOGT2mKPKxdhadW9dHMLlK/AbOqmaxQxyr22WOp0wVOh+eqiBdCRX89nubSMP7IyAiL4HoH2os5V7i+SxIv9ZFm4Oz6Y21gf'
        'sp/MWTuNa+triw9s59ZvyVlG7zZ41jWPyiW20FMWNjezNvxPZuHlxdk58MpNRRdkF8+UmCHn75z8er4f3QxHHJewjpzZ7PFZpaSn'
        'NIJTKbB7IvgXd3CjDnUj6b+4mffilPg1sDi4xvUeUSZj6n7PyVToq93jzQUP3khGcw3GlGG60cQIqVREiVJRqQzRTYSGImgEInlK'
        '76YeGnE4mMrPp/fti4v/ufTVQMBqMgegwKuXsT8wqt543meeZFqqTSyo+ZYj9LsFv+Ha2HqozQsDoSPDSh6sBReRj1+6MeVi2U3d'
        'k11YbL19/9gd+6/9fcmrgYBNMqg+/eeI7hb0nb7AN6rNh/7GUd60YkJ1IZyVJ4Q0WkNkURNrWSB/wOn7LoETqUyN3+ApT1obwvWh'
        'RitXAKk1hsiSBny//OusN/u1Exx1T7/yiguOrW+ne+Iw3B1Pb68euyD5dAGhdPdE9aynbnZdsgtQX+3uvDhrfnN29uVZ42uzi1/t'
        'Hn1Yx3hEB0pZ5xzG7pz1MvX2F2knMKsRzvnnvifXvy0HZQ0El/jPY7+d7fzj7NVlr0RXA+AGH2N//PwhRtf450+ywFXq2/R1Xj4x'
        'wVSKPv+Gz/6iSLGRb1QKKTgZP8xJy8FSsVURwP6QwqcMXFwcfSGDyQN6sKGYUnNjncSoaJV76a93tW0fNQTsoxJDuJlWY5La9n/8'
        '9LoLsqC4tOM47w91XyTF1Lc7NFIJpHa3hp/6AbOZD4LmvZjDZq+tjnfp9Yl5A6Be2hV69Jjv0dY6fvafSy9DZU7MXwjqiEEF6W93'
        'm1MrpSK8jdYb6IsXZVLmJhzBbDgxuKzSxZqb9Mn5JtBVGt1xQxeMzQauuRBOKmMNGHH8UVMlMzExN1NXG17AfhnAy9tSipaYsc2c'
        'nFA7k5z3mQx1Z0sr78c2OqWhlQyusDuNJz68d+4LSrCqD1hKgyvytkhrqxmfljAcXhVaQi2t7ZFVeSBp9emVCj6c1erRK5QvG2pu'
        'hhRCsU1uMEBysbBdYXB5JnjNXp2hNTAldjg/Oo0Bgy58sike+MlVRhtY4vij5kqGVkcu+RPGKyzppdrNfZNqKLZtxMu5AJYv8E6p'
        'aNT6AzHnfQZT3dkC3tTw0FiyjxQsbl+ygb9DqLFAkMYsFGL+VlmAA7r0t3T/CeiR47+dDgGB5s6LKkzVh04KafAf368F2U2eYJuS'
        '9NQ/5264yiDwtFbF8VfTTGd2NvBkp3D4FyQK3UZurxCyaTZ2ckSP36ymX+RlgOpu3aMlicdLLnZBV3T3FLc73D+DJ8eOEMNdQzOu'
        'udLKZ1NuXsB+Uwf9/lXNTV8lrD6KhsFA/0lf69hQKt6mTQyprNQfUmQz9xmsxWFtqhAIo/kOlkrYTr6AxXmok6Y0cR4jkR7ncRmk'
        'mqYzwdQTS1vowaz7+ITmwX7whtb5yV8x2G/48XoDjH+DzfgKJuuMUhOeYJKKTQS8TLzL/xGL3efx3sdiPzrL16NRKqKtbk/MqFD2'
        'qsGVmrKfIpu1D2AtDptB7v67HexvJTdvp0ljQ8OHLdq+IRXlcx6TWNN0JpXzKpn4Bpgrop1isP6n0f5nMU6BE8/T9lnMfRrjAybr'
        'A3DtbQT8HoW8hyeQ0Htkyh4aWD3kCynUC8jkI1TKUfDWtu3cWbfkwPxP+HPK/qjGnFNqKze4FYSz0b+/PbPNEgitc4MiFkAAAAe0'
        'gQ5wrnWKbFkTetjBBKnt0qB9iD0wAtTbcw6exKiMEQBAREfoiByxI3GkjsyROwpLeTC1oL5kqjj4RUUJ/4paBhEgKeicQv3+CZ9H'
        'bQHBwZ+C5IVgCD/0SFgEBnEu8jHgQBAR08g8UFCroDAltQWkRp0HqgHIhiKDOqulKABnJbkKD3DaFyESePd3+4N/p0AAXLhg6W81'
        'YsNvBi2+B+DjP3cB8NXGWZn/D388nR7iAaAxACD4+jwL/dpwn6uRUYu956cTJz/0P9Pyf2zLi4YNdOJfCrCUGRSkwBtSLdGrlmBp'
        'Z6qqNe+EKthSu+zw9u0gyORNxC28N2im0NOlYNCGUI+OvKb+ZzgLn3u4uar/ynkG5wrDaklJ5sMzQ+RW9VhV5EiCxBBy3KBXHlu3'
        'gr9sSwaQFtJGun1LbZj2mK9SPQB+NagIMJSLwRkA4H0HQgAWmFQlV4olxC4EHsRnkgjgKwg0dAGU4A4h/W4/hEXePUSY4vN6GT5E'
        '2bNI47X+0ixAQFDb4JA2VNew6iw5J7wzXSirc8wxYtSccUMGDJpEISMhJUXhT0hSORQqW44mJFX5cfGRcq/RiOHUJPzIaErUIEbj'
        'JlBzpJhXo0GkI4b8gKEg1RQPE0lMKlNQHaFKF1VyiuLgl4oX+m1uXbidUL6gmDHE1BiT1sdrBgRVvD1DS0RS3Xk9mJ2RXuLkhRDg'
        'OsxQZB1FZFVwSVBa2jdtbEpRcz7Ba8I8cVkoOKHqYmM8bNYYDQo9rGX3kTXsA7KatXdVzAZK5r9kBdNPljNegYwOrpTmSqhzianX'
        'kUUUcIXkQECCgE8acXnEgEvUuRyCS210KThFFpeEcYmHCCHAG7Io24012LAbt7MOZRsaWz//67rq/uPWmmu5NXG1PMnDWwNY3Srh'
        'IJd5LLtli4zKU+Uz8iPpxLdGsN/lwU6XhulWwFE+Kjo9Qnq5zq1GfK4J4RgjOM1LPqM+Au2ByGgRxQouU1g63MBiOMMm5zzmbm7h'
        'KJ/Kz/BH7DycEKo1U/QonV6u5S8pJ54uKV335pJyZd9Z65Vmnk2lzpWAN23eeB8hLs63LroIxO0l5aVrQvcLcJwrv4+Rc1ZVXIma'
        'y3Qk+Pg3mMgdBX6PTRjS/AEhYD1itin4PemhhxBxGWgsAAAA'),
}

# ─────────────────────────────────────────────────────────── MARCA ─────────
MARCA = {
    "agente": "Cristian Stedtfeld",
    "red": "Red Suma",
    "cargo": "Agente inmobiliario",
    "whatsapp": "+54 9 11 6695-1945",
    "email": "cstedtfeld@redsuma.com.ar",
    "web": "csrealestate.com.ar",
    "pie_1": "Los corredores públicos intermedian y concluyen todas las operaciones. "
             "Los agentes operan bajo el control y supervisión de un corredor público.",
    "pie_2": "Cristian Stedtfeld, agente inmobiliario · Red Suma | Corredor responsable: Diego Enrique Mastrangelo · VL REALTOR S.R.L. · CUCICBA 7615 · CMCPSI 6609",
    "nota_legal": "El presente Análisis Comparativo de Mercado (ACM) es un informe orientativo de valor de "
                  "mercado. Los valores se basan en propiedades comparables disponibles al momento de la "
                  "elaboración y no reemplazan una valuación profesional certificada.",
}

def hoy_ar():
    """Fecha de hoy en Argentina (el servidor puede estar en UTC y adelantarse un día)."""
    from zoneinfo import ZoneInfo
    return dt.datetime.now(ZoneInfo("America/Argentina/Buenos_Aires")).date()

# Aclaraciones que van SIEMPRE en el PDF (ACM y pre-ACM), en formato legible
def aclaraciones():
    venta = "de alquiler cerrado" if MODO["alquiler"] else "de venta"
    return [
        ("Son precios publicados, no " + venta + ".", "Lo que se paga de verdad suele ser algo menos."),
        ("No todos los avisos están bien detallados.", "Por ejemplo, algunos mezclan los m² cubiertos con los totales."),
    ]

def aclaraciones_html():
    ico = '<span class="ai">!</span>'
    items = "".join(f'<div class="ait">{ico}<p><b>{esc(t)}</b> {esc(x)}</p></div>' for t, x in aclaraciones())
    return f'<div class="acl"><div class="lbl k">Para tener en cuenta</div><div class="aits">{items}</div></div>'

MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
         "septiembre", "octubre", "noviembre", "diciembre"]
MESES_C = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]

# ───────────────────────────────────────────────────────── FORMATO ─────────
def miles(n):
    return f"{int(round(n)):,}".replace(",", ".")

MODO = {"moneda": "USD", "alquiler": False}   # se configura en main() según datos.json

def usd(n):
    if MODO["moneda"] == "ARS":
        return "$ —" if n is None else f"$ {miles(n)}"
    return "USD —" if n is None else f"USD {miles(n)}"

def usd_k(n):
    if MODO["moneda"] == "ARS":
        return f"$ {n/1e6:.1f}M".replace(".", ",") if n >= 1e6 else f"$ {int(round(n/1000))}k"
    return f"US$ {int(round(n / 1000))}k"

def um2(n):
    """precio por m² con la moneda del informe"""
    return f"{'$' if MODO['moneda'] == 'ARS' else 'USD'} {miles(n)}/m²"

def sim():
    return "$" if MODO["moneda"] == "ARS" else "USD"

def rango_corto(a, b):
    if MODO["moneda"] == "ARS":
        f = lambda v: f"{v/1e6:.1f}".replace(".", ",")
        return f"${f(a)}M - ${f(b)}M"
    return f"{round(a/1000)}k - {round(b/1000)}k"

def pct(x, dec=1, signo=True):
    s = f"{x:+.{dec}f}" if signo else f"{x:.{dec}f}"
    return s.replace(".", ",") + "%"

def esc(s):
    return html.escape(str(s)) if s is not None else ""

def plural(n, uno, varios):
    return f"{n:g} {uno if n == 1 else varios}"

def fecha_larga(d):
    return f"{d.day} de {MESES[d.month - 1]} de {d.year}"

def mes_anio(s):
    """'2026-07' o '2026-07-15' -> 'jul-2026'"""
    if not s:
        return ""
    m = re.match(r"(\d{4})-(\d{1,2})", str(s))
    return f"{MESES_C[int(m.group(2)) - 1]}-{m.group(1)}" if m else str(s)

def redondear(x, paso):
    return int(round(x / paso) * paso) if x is not None else None

def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")[:40] or "propiedad"

# ─────────────────────────────────────────────────────────── IMÁGENES ──────
UA = "Mozilla/5.0 (ACM-CS/2.0)"

def cargar_imagen(ref, base_dir, max_w=640):
    """Devuelve data-URI (JPEG) o None. Acepta ruta local o URL."""
    if not ref:
        return None
    try:
        if re.match(r"https?://", str(ref)):
            req = urllib.request.Request(ref, headers={"User-Agent": UA})
            raw = urllib.request.urlopen(req, timeout=12).read()
        else:
            p = ref if os.path.isabs(ref) else os.path.join(base_dir, ref)
            raw = open(p, "rb").read()
        from PIL import Image
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        if im.width > max_w:
            im = im.resize((max_w, int(im.height * max_w / im.width)))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=84)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception as e:
        print(f"  [foto] no se pudo cargar {str(ref)[:70]}… ({e.__class__.__name__})", file=sys.stderr)
        return None

# ─────────────────────────────────────────────────────────── ESTILOS ───────
def css():
    A = __ASSETS__
    def ff(fam, key, w):
        return (f"@font-face{{font-family:'{fam}';src:url(data:font/woff2;base64,{A[key]}) format('woff2');"
                f"font-weight:{w};font-style:normal}}") if key in A else ""
    fonts = (ff("Goodtime", "goodtime", 400) + ff("MontserratCS", "montserrat-600", 600) +
             ff("InterCS", "inter-400", 400) + ff("ChillaxCS", "chillax-600", 600) + ff("ArialCS", "arial-400", 400) + ff("ArialCS", "arial-700", 700))
    return fonts + CSS

CSS = r"""
@page{size:A4;margin:0}
*{box-sizing:border-box;margin:0;padding:0}
html,body{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font-family:'ArialCS',Arial,'Liberation Sans',Arimo,Helvetica,sans-serif;color:#2B2B34;background:#fff}
:root{--navy:#253C64;--navy2:#1F2A5C;--gold:#988355;--gold2:#AD8A48;--goldtxt:#8A6A2F;--cream:#FBF0D9;
 --red:#FF5F5F;--ink:#171717;--txt:#2B2B34;--gray:#6A6A6A;--card:#DBDBDB}
.page{width:210mm;height:297mm;position:relative;overflow:hidden;page-break-after:always;break-after:page;
 background:radial-gradient(ellipse 75% 60% at 50% 52%,#FFFFFF 0%,#F7F7F7 45%,#ECECEC 100%)}
.page:last-child{page-break-after:auto;break-after:auto}
.hdr-logo{position:absolute;left:65px;top:72px;height:38px}
.hdr-right{position:absolute;right:65px;top:79px;display:flex;align-items:center;gap:13px}
.hdr-right .tag{font-family:'MontserratCS',Montserrat,sans-serif;font-weight:600;font-size:10.3px;letter-spacing:.34em;color:var(--ink)}
.hdr-right .dot{font-family:'MontserratCS',Montserrat,sans-serif;font-weight:600;font-size:12px;color:var(--ink);margin-right:2px}
/* Regla fija (Cris, 2-oct-2026): logo Red Suma 3 px más abajo, alineado con AGENTE INMOBILIARIO. Va en todo documento. */
.hdr-right img{width:97px;display:block;position:relative;top:3px}
.content{position:absolute;left:65px;right:65px;top:183px}
h1.t{font-family:'Goodtime',sans-serif;font-weight:400;font-size:31px;line-height:1;color:var(--ink);letter-spacing:.005em;word-spacing:-.14em}
.sub{font-weight:700;font-size:15.2px;color:var(--gold);margin-top:22px}
.h2{font-weight:700;font-size:16.5px;letter-spacing:.12em;color:var(--ink);text-transform:uppercase}
.lbl{font-weight:700;font-size:9.4px;letter-spacing:.2em;color:var(--gray);text-transform:uppercase}
.lbl.k{color:var(--ink)}
.val{font-weight:700;font-size:20.5px;color:var(--navy);line-height:1.15}
.small{font-size:9.6px;color:var(--gray)}
.box{background:var(--card);border-radius:5px}
.footer{position:absolute;left:65px;right:65px;top:1056px;border-top:1.7px solid var(--gold);padding-top:8px}
.footer .l{font-family:'InterCS',Inter,sans-serif;font-size:7.7px;color:#222;line-height:18px}
.footer .n{position:absolute;right:0;top:9px;font-family:'Goodtime',sans-serif;font-size:27px;color:var(--ink);line-height:1}
.rrow{display:flex;justify-content:space-between;align-items:center;margin-top:22px}
.rule{width:80px;height:2.8px;background:var(--gold)}
.pill{background:var(--navy);color:#fff;border-radius:20px;height:27px;
 padding:0 17px;display:flex;align-items:center;font-weight:700;font-size:8.3px;letter-spacing:.2em;text-transform:uppercase}
.sample{border:2.2px solid var(--gold);border-radius:6px;background:#fff;padding:13px 18px;margin-top:30px;
 font-size:11.2px;line-height:14.5px;color:var(--gold)}
.cards{margin-top:18px;display:flex;flex-direction:column;gap:12.4px}
.card{position:relative;height:122.6px;background:var(--card);border:1.3px solid #F2F2F2;border-radius:4px;
 box-shadow:0 0 0 .5px #E6E6E6}
.card .ph{position:absolute;left:10.2px;top:9.2px;width:155px;height:103px;border-radius:15px;overflow:hidden;background:#C9C9C9}
.card .ph img{width:100%;height:100%;object-fit:cover;display:block}
.card .ph .noimg{width:100%;height:100%;display:flex;align-items:center;justify-content:center;
 background:linear-gradient(135deg,#D0D0D0,#BDBDBD)}
.card .tx{position:absolute;left:182px;top:8px;right:14px}
.card .pr{font-weight:700;font-size:19.6px;color:var(--navy);line-height:24px}
.card .pr s{font-size:12px;color:#8A8A8A;font-weight:400;margin-left:8px}
.card .ad{font-weight:700;font-size:15px;color:var(--txt);line-height:20px;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:306px}
.card.wide .ad{max-width:490px}
.card .mt{font-size:12.2px;color:var(--gray);line-height:19px;margin-top:1px}
.card .dt{font-size:12.2px;color:var(--txt);line-height:19px;word-spacing:1px}
.card .dt b{font-weight:400;margin-right:11.5px}
.card .m2{font-weight:700;font-size:12.2px;color:var(--gold);line-height:19px}
.badge{position:absolute;right:16px;top:16px;width:153.5px;height:31px;border-radius:6px;background:var(--cream);
 color:var(--goldtxt);font-weight:700;font-size:11.4px;display:flex;align-items:center;justify-content:center;text-align:center}
.badge.navy{background:var(--navy);color:#fff}
.delta{position:absolute;right:16px;top:57px;width:153.5px;text-align:center;font-weight:700;font-size:11.2px;line-height:13.5px;color:var(--red)}
.delta.ok{color:var(--goldtxt)}
.par{font-size:11.3px;line-height:17px;color:var(--txt);margin-top:10px;text-align:left}
.par b{color:var(--ink)}
.contact{margin-top:14px;background:var(--card);border-radius:5px;padding:20px 22px;display:flex;gap:26px;align-items:center}
.contact img{height:34px}
.contact .n{font-family:'ChillaxCS',Chillax,sans-serif;font-weight:600;font-size:19px;color:var(--ink);letter-spacing:.01em}
.contact .r{font-size:10.5px;color:var(--gray);margin-top:3px}
.contact .d{margin-left:auto;font-size:11px;line-height:18px;color:var(--txt);text-align:right}
.contact .d b{color:var(--navy)}
.sec{margin-top:28px}
.acl{margin-top:26px;background:#fff;border:1.5px solid var(--gold);border-radius:6px;padding:12px 16px 13px}
.acl .aits{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:8px}
.acl .ait{display:flex;gap:9px;align-items:flex-start}
.acl .ai{flex:none;width:17px;height:17px;border-radius:50%;border:1.5px solid var(--gold);color:var(--gold);
 font-weight:700;font-size:10.5px;line-height:14px;text-align:center;margin-top:1px}
.acl p{font-size:11px;line-height:15.5px;color:var(--txt)}
.acl p b{color:var(--ink)}
/* contacto + botón de WhatsApp (de pre-ACM/generar_preacm.py, escala final) */
.cta{margin-top:12px;background:var(--card);border-radius:5px;padding:11px 20px;display:flex;align-items:center;gap:18px}
.cta .n{font-family:'ChillaxCS',Chillax,sans-serif;font-weight:600;font-size:18px;color:var(--ink);letter-spacing:.01em}
.cta .r{font-size:9.8px;color:var(--gray);margin-top:2px}
.cta .d{font-size:9.8px;line-height:14px;color:var(--txt);margin-top:4px}
.cta .d b{color:var(--navy)}
.btn{margin-left:auto;flex:none;text-decoration:none;background:var(--navy);color:#fff;border-radius:30px;height:40px;padding:0 22px;
 display:flex;align-items:center;gap:10px;font-weight:700;font-size:10px;letter-spacing:.18em;text-transform:uppercase}
.btn .fl{flex:none;display:block}  /* flecha dibujada en SVG, centrada con las mayúsculas del texto (Cris, 2-oct-2026) */
.cta{margin-top:10px;padding:9px 20px}
.cta .n{font-size:20px}
.cta .r,.cta .d{font-size:9.4px}
.cta .d{margin-top:2px}
.btn{font-size:11px;letter-spacing:.16em}
/* tarjeta del reporte de búsqueda (aprobada por Cris, 2-oct-2026) */
.pcard{position:relative;background:var(--card);border:1.3px solid #F2F2F2;border-radius:4px;box-shadow:0 0 0 .5px #E6E6E6;padding:14px 18px 20px 14px}
.pcard+.pcard{margin-top:30px}
.pcard .top{position:relative;display:flex;gap:17px;min-height:103px}
.pcard .ph{flex:none;width:155px;height:103px;border-radius:15px;overflow:hidden;background:#C9C9C9}
.pcard .ph img{width:100%;height:100%;object-fit:cover;display:block}
.pcard .ph .noimg{width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#D0D0D0,#BDBDBD)}
.pcard .nn{font-weight:700;font-size:9.4px;letter-spacing:.2em;color:var(--gold);margin-top:2px}
.pcard .pr{font-weight:700;font-size:19.6px;color:var(--navy);line-height:24px;margin-top:4px}
.pcard .ad{font-weight:700;font-size:15px;color:var(--txt);line-height:20px;margin-top:3px}
.pcard .dt{font-size:12.2px;color:var(--txt);line-height:19px;word-spacing:1px;margin-top:2px}
.pcard .dt b{font-weight:400;margin-right:11.5px}
.pcard .m2{font-weight:700;font-size:12.2px;color:var(--gold);line-height:19px}
.pcard .badge{top:0;right:0}
.pcard .bot{display:grid;grid-template-columns:1.25fr 1fr;gap:20px;margin:18px 0 0 6px;padding-top:16px;border-top:1px solid #C9C9C9}
.pcard ul{list-style:none;margin-top:9px}
.pcard li{position:relative;padding-left:14px;font-size:11.3px;line-height:17px;color:var(--txt)}
.pcard li+li{margin-top:3px}
.pcard li:before{content:'';position:absolute;left:0;top:6.5px;width:5px;height:5px;border-radius:50%;background:var(--gold)}
.pcard .tc li:before{background:var(--gray)}
.mkt{margin-top:24px;font-size:11.3px;line-height:17px;color:var(--txt)}
.mkt b{color:var(--ink)}
.cierre{margin-top:40px;padding-left:12px;border-left:3.4px solid var(--gold2);font-weight:700;font-size:15px;line-height:20px;color:var(--ink)}
.hoja-final{display:flex;flex-direction:column;min-height:835px}
.hoja-final .cta{margin-top:auto;padding:20px 22px}
"""

def page(num, body):
    A = __ASSETS__
    cs = f'<img class="hdr-logo" src="data:image/svg+xml;base64,{A.get("logo_cs","")}">'
    rs = f'<img src="data:image/svg+xml;base64,{A.get("logo_redsuma","")}">'
    return (f'<section class="page">{cs}<div class="hdr-right"><span class="tag">AGENTE INMOBILIARIO</span>'
            f'<span class="dot">·</span>{rs}</div><div class="content">{body}</div>'
            f'<div class="footer"><div class="l">{esc(MARCA["pie_1"])}</div><div class="l">{esc(MARCA["pie_2"])}</div>'
            f'<div class="n">{num}</div></div></section>')

def datos_fila(p):
    out = []
    for key, uno, varios in (("ambientes", "amb", "amb"), ("dormitorios", "dorm", "dorm"),
                             ("banos", "baño", "baños"), ("cocheras", "coch", "coch")):
        if p.get(key) not in (None, "", 0) or (key == "cocheras" and p.get(key) == 0 and False):
            out.append(f"<b>{plural(float(p[key]), uno, varios)}</b>")
    if p.get("m2_etiqueta"):
        out.append(f"<b>{esc(p['m2_etiqueta'])}</b>")
    elif p.get("m2_cubiertos"):
        out.append(f"<b>{miles(p['m2_cubiertos'])} m²</b>")
    return "".join(out)

def tarjeta(c, foto, sujeto=False, precio_txt=None):
    ph = f'<img src="{foto}">' if foto else (
        '<div class="noimg"><svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#9A9A9A" stroke-width="1.6">'
        '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg></div>')
    meta = " · ".join(x for x in [c.get("operacion") or ("Alquiler" if MODO["alquiler"] else "Venta"), c.get("tipo"), c.get("fuente")] if x)
    right, wide = "", True
    if sujeto:
        pr = precio_txt
        right = '<div class="badge">Tu propiedad</div>'
        m2 = ""
        wide = False
    else:
        pr = usd(c["_precio_mostrado"])
        m2 = f'<div class="m2">{um2(c["_usd_m2"])}</div>'
        if c["_vendida"]:
            wide = False
            right = f'<div class="badge">{"Alquilada" if MODO["alquiler"] else "Vendida"} {esc(mes_anio(c.get("fecha_cierre")))}</div>'
            if c.get("_brecha_obs") is not None:
                right += f'<div class="delta">{pct(-c["_brecha_obs"])} del valor<br>publicado</div>'
        elif c.get("dias_publicada") and int(c["dias_publicada"]) >= 180:
            wide = False
            meses = int(c["dias_publicada"]) // 30
            right = f'<div class="badge">Publicada hace {meses} meses</div>'
    largo = len(str(c.get("direccion") or "") + str(c.get("barrio_tarjeta") or ""))
    ad_st = ' style="font-size:13.4px"' if largo > 30 and not wide else ""
    return (f'<div class="card{" wide" if wide else ""}"><div class="ph">{ph}</div><div class="tx">'
            f'<div class="pr">{pr}</div><div class="ad"{ad_st}>{esc(c.get("direccion"))}'
            f'{" (" + esc(c["barrio_tarjeta"]) + ")" if c.get("barrio_tarjeta") else ""}</div>'
            f'<div class="mt">{esc(meta)}</div><div class="dt">{datos_fila(c)}</div>{m2}</div>{right}</div>')

# ─────────────────────────────────────────────────────────── PDF ───────────
def a_pdf(html_txt, pdf_path):
    html_path = os.path.splitext(pdf_path)[0] + ".html"
    open(html_path, "w", encoding="utf-8").write(html_txt)
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            kw = {}
            if os.path.exists("/opt/pw-browsers/chromium"):
                pass
            b = p.chromium.launch(**kw)
            pg = b.new_page()
            pg.goto("file://" + os.path.abspath(html_path))
            pg.wait_for_timeout(300)
            pg.pdf(path=pdf_path, format="A4", print_background=True, prefer_css_page_size=True,
                   margin={"top": "0", "right": "0", "bottom": "0", "left": "0"})
            b.close()
        return "playwright"
    except Exception as e1:
        try:
            import weasyprint
            weasyprint.HTML(filename=html_path).write_pdf(pdf_path)
            return "weasyprint"
        except Exception as e2:
            print(f"No se pudo generar el PDF ({e1.__class__.__name__} / {e2.__class__.__name__}). "
                  f"Abrí {html_path} en Chrome → Imprimir → Guardar como PDF (A4, sin márgenes, con gráficos de fondo).",
                  file=sys.stderr)
            return None

# ───────────────────────────────────────────────────── RESUMEN INTERNO ─────

# ───────────────────────────────────────────────────── COMPONENTES ─────────
# Arman HTML con las clases de arriba. Cualquier pieza nueva se construye con
# estos bloques; si hace falta uno nuevo, se propone con los mismos colores,
# tipografías y medidas (ver sistema-diseno.md) y se muestra antes de usarlo.

def titulo(t, sub=None, pill=None):
    """Título Goodtime (con punto final) + pill opcional a la derecha + subtítulo dorado."""
    p = (f'<div class="pill" style="position:absolute;right:0;top:2px;height:24px;padding:0 15px;font-size:8px">'
         f'{esc(pill)}</div>') if pill else ""
    s = f'<div class="sub">{esc(sub)}</div>' if sub else ""
    return f'<div style="position:relative"><h1 class="t">{esc(t)}</h1>{p}</div>{s}'

def seccion(t, margen=28):
    """Encabezado de sección en mayúsculas."""
    return f'<div class="h2" style="margin-top:{margen}px">{esc(t)}</div>'

def kpi(etiqueta, valor, nota=None):
    n = f'<div class="small" style="margin-top:9px">{esc(nota)}</div>' if nota else ""
    return (f'<div class="box" style="padding:17px 15px 14px"><div class="lbl">{esc(etiqueta)}</div>'
            f'<div class="val" style="margin-top:8px">{esc(valor)}</div>{n}</div>')

def grilla(items, columnas=3, sep=6, margen=16):
    return (f'<div style="display:grid;grid-template-columns:repeat({columnas},1fr);gap:{sep}px;margin-top:{margen}px">'
            f'{"".join(items)}</div>')

def parrafos(textos):
    """Cuerpo de texto. Admite <b> del redactor."""
    return "".join(f'<p class="par">{t}</p>' for t in textos)

def aviso(texto_html):
    """Caja con borde dorado (avisos importantes, p. ej. EJEMPLO / DOCUMENTO DE MUESTRA)."""
    return f'<div class="sample">{texto_html}</div>'

def contacto():
    """Tarjeta de contacto del ACM (datos a la derecha, sin botón)."""
    return (f'<div class="contact"><div><div class="n">{MARCA["agente"]}</div>'
            f'<div class="r">{MARCA["cargo"]} · {MARCA["red"]}</div></div>'
            f'<div class="d">WhatsApp <b>{MARCA["whatsapp"]}</b><br>{MARCA["email"]}<br>{MARCA["web"]}</div></div>')

def link_whatsapp(mensaje):
    num = "".join(ch for ch in MARCA["whatsapp"] if ch.isdigit())
    return f"https://wa.me/{num}?text={urllib.parse.quote(mensaje)}"

# Flecha del botón: SVG en vez del carácter "→", para que quede centrada con las mayúsculas.
FLECHA = ('<svg class="fl" viewBox="0 0 14 10" width="14" height="10" aria-hidden="true">'
          '<path d="M1 5.25h11.2M8.2 1.65 12 5.25 8.2 8.85" stroke="currentColor" stroke-width="1.5" '
          'fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>')


def contacto_boton(boton, mensaje):
    """Contacto + botón azul de WhatsApp con mensaje precargado (como el pre-ACM)."""
    return (f'<div class="cta"><div><div class="n">{MARCA["agente"]}</div>'
            f'<div class="r">{MARCA["cargo"]} · {MARCA["red"]}</div>'
            f'<div class="d">WhatsApp <b>{MARCA["whatsapp"]}</b> · {MARCA["email"]} · {MARCA["web"]}</div></div>'
            f'<a class="btn" href="{esc(link_whatsapp(mensaje))}">{esc(boton)}{FLECHA}</a></div>')

def tarjeta_busqueda(n, p, foto=None):
    """Tarjeta del reporte de búsqueda: foto, precio, zona, datos, USD/m², lectura de precio (badge crema),
    "Por qué encaja" (3 puntos) y "A tener en cuenta" (1 o 2). Sin portal ni anunciante.
    p = {"precio", "zona", "datos": ["3 amb", …], "usd_m2", "lectura", "motivos": [...], "atc": [...]}"""
    ph = f'<img src="{foto}">' if foto else (
        '<div class="noimg"><svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#9A9A9A" stroke-width="1.6">'
        '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg></div>')
    dt = "".join(f"<b>{esc(x)}</b>" for x in p.get("datos", []))
    li = lambda xs: "".join(f"<li>{esc(x)}</li>" for x in xs)
    m2 = f'<div class="m2">{um2(p["usd_m2"])}</div>' if p.get("usd_m2") else ""
    return (f'<div class="pcard"><div class="top"><div class="ph">{ph}</div><div>'
            f'<div class="nn">OPCIÓN {n:02d}</div><div class="pr">{usd(p["precio"])}</div><div class="ad">{esc(p["zona"])}</div>'
            f'<div class="dt">{dt}</div>{m2}</div>'
            f'{"<div class=badge>" + esc(p["lectura"]) + "</div>" if p.get("lectura") else ""}</div>'
            f'<div class="bot"><div><div class="lbl k">Por qué encaja</div><ul>{li(p.get("motivos", []))}</ul></div>'
            f'<div class="tc"><div class="lbl k">A tener en cuenta</div><ul>{li(p.get("atc", []))}</ul></div></div></div>')

def hoja_final(contenido, cierre, boton, mensaje):
    """Última hoja: contenido arriba, frase de cierre y contacto con botón apoyado abajo."""
    return (f'<div class="hoja-final">{contenido}<div class="cierre">{esc(cierre)}</div>'
            f'{contacto_boton(boton, mensaje)}</div>')

def numerar(paginas):
    """paginas = [(tipo, cuerpo)] con tipo "A" (anexo, 00), "M" (principal) o "C" (continuación NN.1).
    Misma lógica que construir_html() de generar_acm.py."""
    numerados, main, cont = [], 0, 0
    for kind, b in paginas:
        if kind == "A":
            numerados.append(("00", b)); continue
        if kind == "M":
            main += 1; cont = 0; numerados.append((f"{main:02d}", b))
        else:
            cont += 1; numerados.append((f"{main:02d}.{cont}", b))
    return numerados

def documento(titulo_doc, paginas, css_extra=""):
    """paginas: lista de cuerpos (todas principales) o de tuplas (tipo, cuerpo)."""
    pares = [p if isinstance(p, tuple) else ("M", p) for p in paginas]
    body = "".join(page(n, b) for n, b in numerar(pares))
    return (f'<!doctype html><html lang="es"><head><meta charset="utf-8"><title>{esc(titulo_doc)}</title>'
            f'<style>{css()}{css_extra}</style></head><body>{body}</body></html>')

# ──────────────────────────────────────────────────────────── DEMO ─────────
def _demo():
    ej = {"direccion": "Calle 123", "barrio_tarjeta": "Barrio", "tipo": "Departamento", "fuente": None,
          "ambientes": 3, "dormitorios": 2, "banos": 1, "m2_cubiertos": 70,
          "_precio_mostrado": 150000, "_usd_m2": 2143, "_vendida": False}
    p1 = (titulo("Plantilla base.", "Página de prueba con los componentes comunes.", pill="Demo · Plantilla")
          + aviso("<b>DOCUMENTO DE MUESTRA.</b> Datos ilustrativos.")
          + grilla([kpi("Etiqueta", "USD 150.000", "nota"), kpi("Etiqueta", "USD 2.143/m²"), kpi("Etiqueta", "70 m²")])
          + seccion("Tarjeta de propiedad") + f'<div class="cards" style="margin-top:18px">{tarjeta(ej, None)}</div>'
          + aclaraciones_html() + seccion("Contacto") + contacto_boton("Coordinemos la visita", "Hola Cristian"))
    return documento("Demo plantilla", [p1])

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Plantilla base — Cristian Stedtfeld · Red Suma")
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    if a.demo:
        motor = a_pdf(_demo(), "demo_plantilla.pdf")
        print(f"demo_plantilla.{'pdf' if motor else 'html'}  [motor: {motor}]")
    else:
        ap.print_help()
